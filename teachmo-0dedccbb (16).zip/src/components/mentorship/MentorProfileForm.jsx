import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { X, Plus } from 'lucide-react';

const EXPERTISE_OPTIONS = [
  'Homework Help',
  'Behavior Management',
  'Communication Skills',
  'Special Needs Support',
  'Academic Planning',
  'Emotional Support',
  'Time Management',
  'Technology & Learning',
  'Reading & Literacy',
  'Math Support',
  'Science Projects',
  'Arts & Creativity',
  'Physical Development',
  'Social Skills',
  'Teen Issues',
  'Early Childhood',
  'School Transitions',
  'Parent-Teacher Communication'
];

const AVAILABILITY_TIMES = [
  'Early Morning (6-9 AM)',
  'Morning (9-12 PM)',
  'Afternoon (12-5 PM)',
  'Evening (5-8 PM)',
  'Night (8-10 PM)'
];

const DAYS_OF_WEEK = [
  'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'
];

export default function MentorProfileForm({ profile, onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    expertise_areas: profile?.expertise_areas || [],
    experience_description: profile?.experience_description || '',
    bio: profile?.bio || '',
    max_mentees: profile?.max_mentees || 3,
    availability: profile?.availability || {
      days: [],
      times: [],
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
    }
  });

  const handleExpertiseToggle = (area) => {
    setFormData(prev => ({
      ...prev,
      expertise_areas: prev.expertise_areas.includes(area)
        ? prev.expertise_areas.filter(e => e !== area)
        : [...prev.expertise_areas, area]
    }));
  };

  const handleAvailabilityChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      availability: {
        ...prev.availability,
        [field]: prev.availability[field].includes(value)
          ? prev.availability[field].filter(item => item !== value)
          : [...prev.availability[field], value]
      }
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.expertise_areas.length === 0) {
      alert('Please select at least one expertise area.');
      return;
    }
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <Label htmlFor="bio">Bio *</Label>
        <Textarea
          id="bio"
          value={formData.bio}
          onChange={(e) => setFormData(prev => ({ ...prev, bio: e.target.value }))}
          placeholder="Tell other parents about yourself and why you'd like to mentor..."
          rows={3}
          required
        />
      </div>

      <div>
        <Label>Expertise Areas * (Select all that apply)</Label>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-2">
          {EXPERTISE_OPTIONS.map(area => (
            <div key={area} className="flex items-center space-x-2">
              <Checkbox
                id={area}
                checked={formData.expertise_areas.includes(area)}
                onCheckedChange={() => handleExpertiseToggle(area)}
              />
              <Label htmlFor={area} className="text-sm font-normal">
                {area}
              </Label>
            </div>
          ))}
        </div>
        {formData.expertise_areas.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-3">
            {formData.expertise_areas.map(area => (
              <Badge key={area} variant="secondary" className="flex items-center gap-1">
                {area}
                <button 
                  type="button" 
                  onClick={() => handleExpertiseToggle(area)}
                  className="hover:bg-gray-300 rounded-full p-1"
                >
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}
      </div>

      <div>
        <Label htmlFor="experience">Experience Description *</Label>
        <Textarea
          id="experience"
          value={formData.experience_description}
          onChange={(e) => setFormData(prev => ({ ...prev, experience_description: e.target.value }))}
          placeholder="Describe your relevant experience (e.g., years as a parent, education background, special training...)"
          rows={4}
          required
        />
      </div>

      <div>
        <Label htmlFor="max_mentees">Maximum Number of Mentees</Label>
        <Select 
          value={formData.max_mentees.toString()} 
          onValueChange={(value) => setFormData(prev => ({ ...prev, max_mentees: parseInt(value) }))}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="1">1 mentee</SelectItem>
            <SelectItem value="2">2 mentees</SelectItem>
            <SelectItem value="3">3 mentees</SelectItem>
            <SelectItem value="4">4 mentees</SelectItem>
            <SelectItem value="5">5 mentees</SelectItem>
          </SelectContent>
        </Select>
        <p className="text-sm text-gray-500 mt-1">
          How many people would you feel comfortable mentoring at once?
        </p>
      </div>

      <div>
        <Label>Availability</Label>
        
        <div className="space-y-4">
          <div>
            <Label className="text-sm font-medium">Days of the Week</Label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-2">
              {DAYS_OF_WEEK.map(day => (
                <div key={day} className="flex items-center space-x-2">
                  <Checkbox
                    id={day}
                    checked={formData.availability.days.includes(day)}
                    onCheckedChange={() => handleAvailabilityChange('days', day)}
                  />
                  <Label htmlFor={day} className="text-sm font-normal">
                    {day.slice(0, 3)}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium">Preferred Times</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2">
              {AVAILABILITY_TIMES.map(time => (
                <div key={time} className="flex items-center space-x-2">
                  <Checkbox
                    id={time}
                    checked={formData.availability.times.includes(time)}
                    onCheckedChange={() => handleAvailabilityChange('times', time)}
                  />
                  <Label htmlFor={time} className="text-sm font-normal">
                    {time}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="timezone">Timezone</Label>
            <Input
              id="timezone"
              value={formData.availability.timezone}
              onChange={(e) => setFormData(prev => ({
                ...prev,
                availability: { ...prev.availability, timezone: e.target.value }
              }))}
              placeholder="e.g., America/New_York"
            />
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {profile ? 'Update' : 'Create'} Profile
        </Button>
      </div>
    </form>
  );
}