import React from 'react';

// Performance testing utilities and benchmarks
export class PerformanceMonitor {
  constructor() {
    this.marks = new Map();
    this.measures = new Map();
    this.thresholds = {
      componentRender: 100, // ms
      apiCall: 2000, // ms
      pageLoad: 3000, // ms
      interaction: 16, // ms (60fps = 16.67ms per frame)
    };
  }

  startMark(name) {
    const startTime = performance.now();
    this.marks.set(name, startTime);
    return startTime;
  }

  endMark(name) {
    const startTime = this.marks.get(name);
    if (!startTime) {
      throw new Error(`No start mark found for: ${name}`);
    }
    const endTime = performance.now();
    const duration = endTime - startTime;
    this.measures.set(name, duration);
    this.marks.delete(name);
    return duration;
  }

  getMeasure(name) {
    return this.measures.get(name);
  }

  getAllMeasures() {
    return Object.fromEntries(this.measures);
  }

  checkThreshold(name, category = 'componentRender') {
    const duration = this.measures.get(name);
    const threshold = this.thresholds[category];
    return {
      duration,
      threshold,
      passed: duration <= threshold,
      message: duration <= threshold 
        ? `✅ ${name} (${duration.toFixed(2)}ms) is within threshold (${threshold}ms)`
        : `❌ ${name} (${duration.toFixed(2)}ms) exceeds threshold (${threshold}ms)`
    };
  }

  reset() {
    this.marks.clear();
    this.measures.clear();
  }

  // Memory usage tracking
  getMemoryUsage() {
    if (performance.memory) {
      return {
        used: performance.memory.usedJSHeapSize,
        total: performance.memory.totalJSHeapSize,
        limit: performance.memory.jsHeapSizeLimit
      };
    }
    return null;
  }

  // Bundle size analysis helpers
  analyzeBundle() {
    const scripts = Array.from(document.querySelectorAll('script[src]'));
    const styles = Array.from(document.querySelectorAll('link[rel="stylesheet"]'));
    
    return {
      scriptCount: scripts.length,
      styleCount: styles.length,
      totalResources: scripts.length + styles.length,
      scripts: scripts.map(script => script.src),
      styles: styles.map(style => style.href)
    };
  }
}

// Performance testing wrapper for React components
export const withPerformanceTest = (Component, testName = 'Component') => {
  return React.forwardRef((props, ref) => {
    const monitor = React.useRef(new PerformanceMonitor());
    
    React.useEffect(() => {
      monitor.current.startMark(`${testName}_mount`);
      
      return () => {
        const mountDuration = monitor.current.endMark(`${testName}_mount`);
        const result = monitor.current.checkThreshold(`${testName}_mount`);
        console.log(result.message);
      };
    }, []);

    return React.createElement(Component, { ref, ...props });
  });
};

// Performance assertions for tests
export const expectPerformance = {
  toBeWithinThreshold: (duration, threshold, message = '') => {
    if (duration > threshold) {
      throw new Error(
        `Performance assertion failed: ${message}\n` +
        `Expected: ${duration}ms to be ≤ ${threshold}ms\n` +
        `Actual difference: ${(duration - threshold).toFixed(2)}ms over threshold`
      );
    }
  },
  
  toHaveRenderedFast: (renderTime) => {
    expectPerformance.toBeWithinThreshold(renderTime, 100, 'Component render time');
  },
  
  toHaveLoadedFast: (loadTime) => {
    expectPerformance.toBeWithinThreshold(loadTime, 3000, 'Page load time');
  },
  
  toBeMemoryEfficient: (memoryUsage) => {
    const threshold = 50 * 1024 * 1024; // 50MB
    if (memoryUsage.used > threshold) {
      throw new Error(
        `Memory usage too high: ${(memoryUsage.used / 1024 / 1024).toFixed(2)}MB > ${threshold / 1024 / 1024}MB`
      );
    }
  }
};

// Simulate slow network conditions for testing
export const simulateSlowNetwork = (delay = 3000) => {
  const originalFetch = window.fetch;
  
  window.fetch = async (...args) => {
    await new Promise(resolve => setTimeout(resolve, delay));
    return originalFetch(...args);
  };
  
  return () => {
    window.fetch = originalFetch;
  };
};

// Simulate slow CPU for testing
export const simulateSlowCPU = (factor = 2) => {
  const start = performance.now();
  const duration = 100 * factor; // Block for duration milliseconds
  
  while (performance.now() - start < duration) {
    // Busy wait to simulate slow CPU
    Math.random();
  }
};