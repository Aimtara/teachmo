import React from 'react';
import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { renderWithProviders, testUtils, createMockUser, createMockChild } from '../testUtils';
import Dashboard from '../../../pages/Dashboard';
import { server } from '../mocks/server';
import { rest } from 'msw';

describe('User Flows Integration Tests', () => {
  it('completes the onboarding flow for new parent', async () => {
    const user = userEvent.setup();
    
    // Mock new user without completed onboarding
    server.use(
      rest.get('/api/users/me', (req, res, ctx) => {
        return res(ctx.json(createMockUser({ 
          onboarding_completed: false,
          user_type: 'parent'
        })));
      })
    );

    renderWithProviders(<Dashboard />, { 
      initialEntries: ['/welcome'] 
    });

    // Should start at welcome page
    expect(screen.getByText(/welcome to teachmo/i)).toBeInTheDocument();

    // Complete parenting style quiz
    await user.click(screen.getByRole('button', { name: /get started/i }));
    
    await waitFor(() => {
      expect(screen.getByText(/parenting style/i)).toBeInTheDocument();
    });

    // Answer quiz questions
    const quizOptions = screen.getAllByRole('radio');
    if (quizOptions.length > 0) {
      await user.click(quizOptions[0]);
    }
    await user.click(screen.getByRole('button', { name: /continue/i }));

    // Add first child
    await waitFor(() => {
      expect(screen.getByText(/add your child/i)).toBeInTheDocument();
    });

    await testUtils.fillField(user, /child's name/i, 'Emma');
    await testUtils.fillField(user, /birth date/i, '2019-05-15');
    
    await user.click(screen.getByRole('button', { name: /add child/i }));

    // Complete onboarding
    await waitFor(() => {
      expect(screen.getByText(/you're all set/i)).toBeInTheDocument();
    });

    await user.click(screen.getByRole('button', { name: /start exploring/i }));

    // Should reach dashboard
    await waitFor(() => {
      expect(screen.getByText(/dashboard/i)).toBeInTheDocument();
    });
  });

  it('allows user to discover and schedule an activity', async () => {
    const user = userEvent.setup();

    renderWithProviders(<Dashboard />, { 
      initialEntries: ['/discover'] 
    });

    await testUtils.waitForLoadingToFinish();

    // Navigate to activities tab
    const activitiesTab = screen.queryByRole('tab', { name: /activities/i });
    if (activitiesTab) {
      await user.click(activitiesTab);
    }

    // Select an activity
    const activityCards = screen.queryAllByTestId('activity-card');
    if (activityCards.length > 0) {
      await user.click(activityCards[0]);

      // Activity detail modal should open
      expect(screen.getByRole('dialog')).toBeInTheDocument();

      // Schedule the activity
      const scheduleButton = screen.queryByRole('button', { name: /schedule/i });
      if (scheduleButton) {
        await user.click(scheduleButton);

        // Date picker should appear
        expect(screen.getByText(/select date/i)).toBeInTheDocument();

        // Pick a date and time
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        
        const dateButton = screen.queryByRole('button', { 
          name: tomorrow.getDate().toString() 
        });
        if (dateButton) {
          await user.click(dateButton);
        }

        const confirmButton = screen.queryByRole('button', { name: /confirm/i });
        if (confirmButton) {
          await user.click(confirmButton);
        }

        // Should see success message
        expect(screen.getByText(/activity scheduled/i)).toBeInTheDocument();
      }
    }
  });

  it('handles premium upgrade flow', async () => {
    const user = userEvent.setup();

    renderWithProviders(<Dashboard />, { 
      initialEntries: ['/upgrade'] 
    });

    await testUtils.waitForLoadingToFinish();

    // Should show upgrade options
    expect(screen.getByText(/teachmo premium/i)).toBeInTheDocument();

    // Select monthly plan
    const monthlyButton = screen.queryByRole('button', { name: /monthly/i });
    if (monthlyButton) {
      await user.click(monthlyButton);
    }

    // Click upgrade button
    const upgradeButton = screen.queryByRole('button', { name: /upgrade to premium/i });
    if (upgradeButton) {
      await user.click(upgradeButton);

      // Should redirect to Stripe (mocked)
      if (global.fetch && global.fetch.mock) {
        expect(global.fetch).toHaveBeenCalledWith(
          expect.stringContaining('/api/stripe/create-checkout'),
          expect.any(Object)
        );
      }
    }
  });

  it('completes teacher onboarding with Google Classroom integration', async () => {
    const user = userEvent.setup();

    // Mock teacher user
    server.use(
      rest.get('/api/users/me', (req, res, ctx) => {
        return res(ctx.json(createMockUser({ 
          user_type: 'teacher',
          onboarding_completed: false,
          school_id: 'school-123'
        })));
      })
    );

    renderWithProviders(<Dashboard />, { 
      initialEntries: ['/teacher-onboarding'] 
    });

    // Complete school verification
    await testUtils.fillField(user, /employee id/i, 'TCH-001');
    const verifyButton = screen.queryByRole('button', { name: /verify/i });
    if (verifyButton) {
      await user.click(verifyButton);

      await waitFor(() => {
        expect(screen.getByText(/verified/i)).toBeInTheDocument();
      });
    }

    // Connect Google Classroom
    const connectButton = screen.queryByRole('button', { name: /connect google classroom/i });
    if (connectButton) {
      await user.click(connectButton);

      // Should redirect to Google OAuth (mocked)
      expect(screen.getByText(/redirecting to google/i)).toBeInTheDocument();
    }

    // Mock successful connection
    server.use(
      rest.get('/api/google-classroom/status', (req, res, ctx) => {
        return res(ctx.json({ connected: true, classrooms: 3 }));
      })
    );

    // Complete onboarding
    const finishButton = screen.queryByRole('button', { name: /finish setup/i });
    if (finishButton) {
      await user.click(finishButton);

      // Should reach teacher dashboard
      await waitFor(() => {
        expect(screen.getByText(/teacher dashboard/i)).toBeInTheDocument();
      });
    }
  });

  it('handles referral code redemption during signup', async () => {
    const user = userEvent.setup();

    renderWithProviders(<Dashboard />, { 
      initialEntries: ['/welcome'] 
    });

    // Look for referral code input
    const codeInput = screen.queryByPlaceholderText(/referral code/i);
    if (codeInput) {
      await user.type(codeInput, 'GOOGLE2024');

      const applyButton = screen.queryByRole('button', { name: /apply code/i });
      if (applyButton) {
        await user.click(applyButton);

        // Should show success message
        await waitFor(() => {
          expect(screen.getByText(/code applied successfully/i)).toBeInTheDocument();
        });

        // Premium benefits should be reflected
        expect(screen.getByText(/premium features unlocked/i)).toBeInTheDocument();
      }
    }
  });
});