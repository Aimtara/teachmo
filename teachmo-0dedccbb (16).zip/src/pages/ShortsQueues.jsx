import React, { useEffect, useState } from 'react';
import { shortsAdmin } from '@/api/functions';
import { Loader2, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import RoleGuard from '@/components/shared/RoleGuard';

function ShortsQueuesContent() {
  const [rows, setRows] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadErrorData();
  }, []);

  const loadErrorData = async () => {
    try {
      setIsLoading(true);
      const { data: errorData } = await shortsAdmin({ 
        endpoint: 'errors',
        query: 'since=2025-01-01'
      });
      setRows(errorData || []);
    } catch (err) {
      console.error('Error loading shorts errors:', err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-center h-32">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Render Jobs</h1>
          <p className="text-gray-600">Monitor render job queue and errors</p>
        </div>
        <Button onClick={loadErrorData} variant="outline">
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {error && (
        <div className="text-center text-red-600 bg-red-50 p-4 rounded-lg">
          Error loading data: {error}
        </div>
      )}

      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle>Recent Errors & Jobs</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {rows.length === 0 ? (
            <div className="p-6 text-center text-gray-500">
              No error jobs found
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="p-3 text-left font-medium text-gray-700">Job ID</th>
                    <th className="p-3 text-left font-medium text-gray-700">Short ID</th>
                    <th className="p-3 text-left font-medium text-gray-700">When</th>
                    <th className="p-3 text-left font-medium text-gray-700">Worker</th>
                    <th className="p-3 text-left font-medium text-gray-700">Error</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {rows.map((row) => (
                    <tr key={row.job_id} className="hover:bg-gray-50">
                      <td className="p-3 font-mono text-xs text-gray-600">
                        {row.job_id.substring(0, 8)}...
                      </td>
                      <td className="p-3 font-mono text-xs text-gray-600">
                        {row.short_id.substring(0, 8)}...
                      </td>
                      <td className="p-3 text-gray-700">
                        {new Date(row.when).toLocaleString()}
                      </td>
                      <td className="p-3 text-gray-700">
                        {row.worker || 'Unknown'}
                      </td>
                      <td className="p-3 max-w-xs">
                        <div 
                          className="truncate text-gray-600" 
                          title={row.error_excerpt}
                        >
                          {row.error_excerpt || 'No error details'}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default function ShortsQueues() {
  return (
    <RoleGuard allowedRoles={['admin', 'system_admin']}>
      <ShortsQueuesContent />
    </RoleGuard>
  );
}