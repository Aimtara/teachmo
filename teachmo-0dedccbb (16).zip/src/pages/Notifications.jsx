import React, { useState, useEffect } from 'react';
import { InAppNotification, User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Bell, Loader2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { Link } from 'react-router-dom';

export default function Notifications() {
    const [notifications, setNotifications] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchNotifications = async () => {
            try {
                const user = await User.me();
                const userNotifications = await InAppNotification.filter(
                    { user_id: user.id },
                    '-created_date',
                    50
                );
                setNotifications(userNotifications);
            } catch (error) {
                console.error("Failed to fetch notifications:", error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchNotifications();
    }, []);
    
    const markAsRead = async (notification) => {
        if (notification.read) return;
        try {
            await InAppNotification.update(notification.id, { read: true });
            setNotifications(prev => 
                prev.map(n => n.id === notification.id ? {...n, read: true} : n)
            );
        } catch (error) {
            console.error("Failed to mark notification as read:", error);
        }
    };

    if (isLoading) {
        return (
            <div className="flex h-full items-center justify-center">
                <Loader2 className="w-12 h-12 animate-spin text-gray-500" />
            </div>
        );
    }
    
    return (
        <div className="p-6">
            <Card className="max-w-3xl mx-auto">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Bell />
                        Notifications
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {notifications.length > 0 ? (
                        <div className="space-y-4">
                            {notifications.map(n => (
                                <Link
                                    key={n.id}
                                    to={n.action_url || '#'}
                                    onClick={() => markAsRead(n)}
                                    className={`block p-4 rounded-lg border-l-4 transition-colors ${
                                        n.read ? 'bg-gray-50 border-gray-200' : 'bg-blue-50 border-blue-400'
                                    }`}
                                >
                                    <div className="flex items-start gap-3">
                                        <div className="mt-1">
                                            {n.read ? <Bell className="w-5 h-5 text-gray-400"/> : <Bell className="w-5 h-5 text-blue-500"/>}
                                        </div>
                                        <div className="flex-1">
                                            <p className={`${n.read ? 'text-gray-700' : 'text-gray-900 font-medium'}`}>
                                                {n.content}
                                            </p>
                                            <p className="text-xs text-gray-500 mt-1">
                                                {formatDistanceToNow(new Date(n.created_date), { addSuffix: true })}
                                            </p>
                                        </div>
                                    </div>
                                </Link>
                            ))}
                        </div>
                    ) : (
                        <div className="text-center text-gray-500 py-12">
                            <Bell className="w-16 h-16 mx-auto mb-4" />
                            <h3 className="text-xl font-medium">No notifications yet</h3>
                            <p>We'll let you know when there's something new for you.</p>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}