import React, { useState, useEffect } from 'react';
import { User, School } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';
import RoleGuard from '@/components/shared/RoleGuard';

function SchoolSettingsPage() {
    const [school, setSchool] = useState(null);
    const [settings, setSettings] = useState({});
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const { toast } = useToast();

    useEffect(() => {
        const fetchSchoolData = async () => {
            try {
                const currentUser = await User.me();
                if (currentUser && currentUser.school_id) {
                    const schoolData = await School.get(currentUser.school_id);
                    setSchool(schoolData);
                    setSettings(schoolData.settings || {
                        enable_parent_teacher_messaging: true,
                        enable_assignment_sync: true,
                        enable_calendar_integration: true,
                        require_parent_verification: true
                    });
                }
            } catch (error) {
                toast({ variant: 'destructive', title: 'Error', description: 'Failed to load school data.' });
            } finally {
                setIsLoading(false);
            }
        };
        fetchSchoolData();
    }, [toast]);

    const handleSettingChange = (key, value) => {
        setSettings(prev => ({ ...prev, [key]: value }));
    };

    const handleSaveChanges = async () => {
        if (!school) return;
        setIsSaving(true);
        try {
            await School.update(school.id, { settings });
            toast({ title: 'Settings Saved', description: 'Your school settings have been updated.' });
        } catch (error) {
            toast({ variant: 'destructive', title: 'Save Failed', description: 'Could not save school settings.' });
        } finally {
            setIsSaving(false);
        }
    };

    if (isLoading) {
        return <div className="p-6"><Loader2 className="animate-spin" /></div>;
    }

    if (!school) {
        return <div className="p-6">You are not associated with a school.</div>;
    }

    return (
        <div className="p-4 md:p-6">
            <Card>
                <CardHeader>
                    <CardTitle>School Settings for {school.name}</CardTitle>
                    <CardDescription>Manage feature flags and configurations for your school.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                        <Label htmlFor="messaging" className="flex flex-col space-y-1">
                            <span>Enable Parent-Teacher Messaging</span>
                            <span className="font-normal leading-snug text-muted-foreground">
                                Allow parents and teachers to communicate directly.
                            </span>
                        </Label>
                        <Switch
                            id="messaging"
                            checked={settings.enable_parent_teacher_messaging}
                            onCheckedChange={(value) => handleSettingChange('enable_parent_teacher_messaging', value)}
                            disabled={isSaving}
                        />
                    </div>
                     <div className="flex items-center justify-between p-4 border rounded-lg">
                        <Label htmlFor="assignment-sync" className="flex flex-col space-y-1">
                            <span>Enable Assignment Sync</span>
                            <span className="font-normal leading-snug text-muted-foreground">
                                Automatically sync assignments from integrated systems.
                            </span>
                        </Label>
                        <Switch
                            id="assignment-sync"
                            checked={settings.enable_assignment_sync}
                            onCheckedChange={(value) => handleSettingChange('enable_assignment_sync', value)}
                            disabled={isSaving}
                        />
                    </div>
                    <div className="flex justify-end mt-6">
                        <Button onClick={handleSaveChanges} disabled={isSaving}>
                            {isSaving ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : 'Save Changes'}
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}

export default function SchoolSettings() {
    return (
        <RoleGuard allowedRoles={['school_admin', 'district_admin', 'admin', 'system_admin']}>
            <SchoolSettingsPage />
        </RoleGuard>
    )
}