import React, { useState, useEffect } from 'react';
import { User, SchoolResource, SchoolEvent, Announcement } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { Plus, Loader2, BookOpen, Calendar, Megaphone, Upload, Link as LinkIcon, Edit, Trash2 } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import RoleGuard from '@/components/shared/RoleGuard';
import { UploadFile } from '@/api/integrations';

function SchoolContentPage() {
    const [user, setUser] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [announcements, setAnnouncements] = useState([]);
    const [events, setEvents] = useState([]);
    const [resources, setResources] = useState([]);
    
    // Dialog states
    const [showResourceDialog, setShowResourceDialog] = useState(false);
    const [newResource, setNewResource] = useState({ title: '', description: '', resource_type: 'link', url: '' });
    const [resourceFile, setResourceFile] = useState(null);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const { toast } = useToast();

    useEffect(() => {
        const fetchUserAndContent = async () => {
            try {
                const currentUser = await User.me();
                setUser(currentUser);
                if (currentUser && currentUser.school_id) {
                    await loadContent(currentUser.school_id);
                }
            } catch (error) {
                console.error("Error fetching user:", error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchUserAndContent();
    }, []);

    const loadContent = async (schoolId) => {
        try {
            const [announcementsData, eventsData, resourcesData] = await Promise.all([
                Announcement.filter({ school_id: schoolId }, '-created_date'),
                SchoolEvent.filter({ school_id: schoolId }, '-start_time'),
                SchoolResource.filter({ school_id: schoolId }, '-created_date'),
            ]);
            setAnnouncements(announcementsData);
            setEvents(eventsData);
            setResources(resourcesData);
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'Failed to load school content.' });
        }
    };

    const handleCreateResource = async () => {
        if (!newResource.title || !newResource.resource_type) {
            toast({ variant: 'destructive', title: 'Missing Information', description: 'Title and type are required.' });
            return;
        }

        setIsSubmitting(true);
        let resourceUrl = newResource.url;

        try {
            if (newResource.resource_type === 'document' && resourceFile) {
                const { file_url } = await UploadFile({ file: resourceFile });
                resourceUrl = file_url;
            }

            if (!resourceUrl) {
                toast({ variant: 'destructive', title: 'Missing URL/File', description: 'A URL or file is required.' });
                setIsSubmitting(false);
                return;
            }

            await SchoolResource.create({
                ...newResource,
                url: resourceUrl,
                school_id: user.school_id,
                uploaded_by: user.id
            });

            toast({ title: "Resource Created", description: "The new resource has been added." });
            setShowResourceDialog(false);
            setNewResource({ title: '', description: '', resource_type: 'link', url: '' });
            setResourceFile(null);
            await loadContent(user.school_id);
        } catch (error) {
            console.error("Error creating resource:", error);
            toast({ variant: 'destructive', title: 'Error', description: 'Failed to create resource.' });
        } finally {
            setIsSubmitting(false);
        }
    };

    if (isLoading) {
        return <div className="p-6"><Skeleton className="h-96 w-full" /></div>;
    }

    return (
        <div className="p-4 md:p-6 space-y-6">
            <h1 className="text-3xl font-bold">School Content Management</h1>
            <Tabs defaultValue="announcements">
                <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="announcements"><Megaphone className="w-4 h-4 mr-2"/>Announcements</TabsTrigger>
                    <TabsTrigger value="events"><Calendar className="w-4 h-4 mr-2"/>Events</TabsTrigger>
                    <TabsTrigger value="resources"><BookOpen className="w-4 h-4 mr-2"/>Resources</TabsTrigger>
                </TabsList>

                {/* Announcements Tab */}
                <TabsContent value="announcements">
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between">
                            <div>
                               <CardTitle>School Announcements</CardTitle>
                               <CardDescription>Manage announcements for your school.</CardDescription>
                            </div>
                            <Button disabled>Create Announcement (Coming Soon)</Button>
                        </CardHeader>
                        <CardContent>
                           <p>Announcements list will be displayed here.</p>
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* Events Tab */}
                <TabsContent value="events">
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between">
                             <div>
                               <CardTitle>School Events</CardTitle>
                               <CardDescription>Manage events for your school calendar.</CardDescription>
                            </div>
                            <Button disabled>Create Event (Coming Soon)</Button>
                        </CardHeader>
                        <CardContent>
                            <p>Events list will be displayed here.</p>
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* Resources Tab */}
                <TabsContent value="resources">
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between">
                             <div>
                               <CardTitle>Custom Resources</CardTitle>
                               <CardDescription>Upload and manage documents, links, and videos for your community.</CardDescription>
                            </div>
                            <Button onClick={() => setShowResourceDialog(true)}><Plus className="w-4 h-4 mr-2"/>Add Resource</Button>
                        </CardHeader>
                        <CardContent>
                           {resources.length === 0 ? (
                                <p className="text-gray-500 text-center py-8">No custom resources added yet.</p>
                           ) : (
                                <div className="space-y-3">
                                {resources.map(res => (
                                    <div key={res.id} className="p-3 border rounded-lg flex items-center justify-between">
                                        <div>
                                            <p className="font-semibold">{res.title}</p>
                                            <a href={res.url} target="_blank" rel="noopener noreferrer" className="text-sm text-blue-600 hover:underline truncate">{res.url}</a>
                                        </div>
                                        <Badge variant="outline">{res.resource_type}</Badge>
                                    </div>
                                ))}
                                </div>
                           )}
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>

            {/* Create Resource Dialog */}
            <Dialog open={showResourceDialog} onOpenChange={setShowResourceDialog}>
                <DialogContent>
                    <DialogHeader><DialogTitle>Add New Resource</DialogTitle></DialogHeader>
                    <div className="py-4 space-y-4">
                        <div>
                            <Label htmlFor="res-title">Title</Label>
                            <Input id="res-title" value={newResource.title} onChange={(e) => setNewResource({...newResource, title: e.target.value})} />
                        </div>
                        <div>
                            <Label htmlFor="res-desc">Description</Label>
                            <Textarea id="res-desc" value={newResource.description} onChange={(e) => setNewResource({...newResource, description: e.target.value})} />
                        </div>
                        <div>
                            <Label htmlFor="res-type">Resource Type</Label>
                             <Select value={newResource.resource_type} onValueChange={(value) => setNewResource({...newResource, resource_type: value})}>
                                <SelectTrigger><SelectValue/></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="link">Link</SelectItem>
                                    <SelectItem value="video">Video</SelectItem>
                                    <SelectItem value="document">Document</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        {newResource.resource_type === 'document' ? (
                            <div>
                                <Label htmlFor="res-file">Upload File</Label>
                                <Input id="res-file" type="file" onChange={(e) => setResourceFile(e.target.files[0])} />
                            </div>
                        ) : (
                            <div>
                                <Label htmlFor="res-url">URL</Label>
                                <Input id="res-url" value={newResource.url} onChange={(e) => setNewResource({...newResource, url: e.target.value})} />
                            </div>
                        )}
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setShowResourceDialog(false)}>Cancel</Button>
                        <Button onClick={handleCreateResource} disabled={isSubmitting}>
                            {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin"/> : "Create Resource"}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}

export default function GuardedSchoolContent() {
    return (
        <RoleGuard allowedRoles={['school_admin', 'district_admin', 'system_admin', 'admin']}>
            <SchoolContentPage />
        </RoleGuard>
    )
}