import React, { useState, useEffect } from 'react';
import { Challenge, ChallengeParticipation, User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Trophy, Target, Users, Calendar, Award, Plus } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { format, isAfter, isBefore } from 'date-fns';

export default function ChallengeHub() {
  const [challenges, setChallenges] = useState([]);
  const [myParticipations, setMyParticipations] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);

      const [challengesData, participationsData] = await Promise.all([
        Challenge.filter({ is_active: true }, '-start_date'),
        ChallengeParticipation.filter({ user_id: userData.id })
      ]);

      setChallenges(challengesData);
      setMyParticipations(participationsData);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load challenges."
      });
    } finally {
      setIsLoading(false);
    }
  };

  const joinChallenge = async (challengeId) => {
    try {
      await ChallengeParticipation.create({
        challenge_id: challengeId,
        user_id: user.id
      });

      toast({
        title: "Challenge Joined!",
        description: "You've successfully joined the challenge."
      });

      loadData();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to join challenge."
      });
    }
  };

  const getChallengeStatus = (challenge) => {
    const now = new Date();
    const startDate = new Date(challenge.start_date);
    const endDate = new Date(challenge.end_date);

    if (isBefore(now, startDate)) return 'upcoming';
    if (isAfter(now, endDate)) return 'ended';
    return 'active';
  };

  const getMyParticipation = (challengeId) => {
    return myParticipations.find(p => p.challenge_id === challengeId);
  };

  const ChallengeCard = ({ challenge, participation = null, showJoinButton = true }) => {
    const status = getChallengeStatus(challenge);
    const progressPercentage = participation 
      ? Math.min((participation.current_progress / challenge.goal_target) * 100, 100)
      : 0;

    return (
      <Card className="hover:shadow-lg transition-shadow">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <CardTitle className="text-lg">{challenge.title}</CardTitle>
              <p className="text-gray-600 mt-1">{challenge.description}</p>
              <div className="flex items-center gap-2 mt-3">
                <Badge 
                  className={
                    challenge.challenge_type === 'individual' ? 'bg-blue-100 text-blue-800' :
                    challenge.challenge_type === 'family' ? 'bg-purple-100 text-purple-800' :
                    challenge.challenge_type === 'community' ? 'bg-green-100 text-green-800' :
                    'bg-orange-100 text-orange-800'
                  }
                >
                  {challenge.challenge_type}
                </Badge>
                <Badge 
                  variant="outline"
                  className={
                    status === 'active' ? 'border-green-500 text-green-700' :
                    status === 'upcoming' ? 'border-blue-500 text-blue-700' :
                    'border-gray-500 text-gray-700'
                  }
                >
                  {status}
                </Badge>
              </div>
            </div>
            <div className="text-center">
              <Trophy className="w-8 h-8 text-yellow-500 mx-auto mb-1" />
              <div className="text-xs text-gray-600">{challenge.participants_count} joined</div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="font-medium">Goal: {challenge.goal_target} {challenge.goal_type.replace('_', ' ')}</span>
                {participation && (
                  <span className="text-gray-600">
                    {participation.current_progress} / {challenge.goal_target}
                  </span>
                )}
              </div>
              {participation && (
                <Progress value={progressPercentage} className="h-2" />
              )}
            </div>

            <div className="text-sm text-gray-600">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>{format(new Date(challenge.start_date), 'MMM d')} - {format(new Date(challenge.end_date), 'MMM d')}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Users className="w-4 h-4" />
                  <span>{challenge.completions_count} completed</span>
                </div>
              </div>
            </div>

            {challenge.rewards && (
              <div className="bg-yellow-50 p-3 rounded-lg">
                <div className="text-sm font-medium text-yellow-800 mb-1">Rewards:</div>
                <div className="text-sm text-yellow-700">
                  {challenge.rewards.points && `${challenge.rewards.points} points`}
                  {challenge.rewards.badges && challenge.rewards.badges.length > 0 && ` • ${challenge.rewards.badges.join(', ')}`}
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2">
              {participation ? (
                <div className="flex items-center gap-2">
                  {participation.completed ? (
                    <Badge className="bg-green-100 text-green-800">
                      <Award className="w-3 h-3 mr-1" />
                      Completed!
                    </Badge>
                  ) : (
                    <Badge variant="secondary">
                      In Progress
                    </Badge>
                  )}
                </div>
              ) : (
                showJoinButton && status !== 'ended' && (
                  <Button 
                    onClick={() => joinChallenge(challenge.id)}
                    disabled={status === 'ended'}
                  >
                    Join Challenge
                  </Button>
                )
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (isLoading) {
    return <div className="p-6 text-center">Loading challenges...</div>;
  }

  const activeChallenges = challenges.filter(c => getChallengeStatus(c) === 'active');
  const upcomingChallenges = challenges.filter(c => getChallengeStatus(c) === 'upcoming');
  const myActiveChallenges = challenges.filter(c => {
    const participation = getMyParticipation(c.id);
    return participation && !participation.completed && getChallengeStatus(c) === 'active';
  });

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Challenge Hub</h1>
          <p className="text-gray-600 mt-1">Join challenges to stay motivated and earn rewards</p>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-purple-600">{user?.points || 0}</div>
          <div className="text-sm text-gray-600">Total Points</div>
        </div>
      </div>

      <Tabs defaultValue="active" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="active">Active Challenges</TabsTrigger>
          <TabsTrigger value="my-challenges">My Challenges</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {activeChallenges.map(challenge => (
              <ChallengeCard 
                key={challenge.id} 
                challenge={challenge} 
                participation={getMyParticipation(challenge.id)}
              />
            ))}
            {activeChallenges.length === 0 && (
              <div className="col-span-3 text-center py-12">
                <Target className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No active challenges</h3>
                <p className="text-gray-600">Check back later for new challenges to join!</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="my-challenges" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myActiveChallenges.map(challenge => (
              <ChallengeCard 
                key={challenge.id} 
                challenge={challenge} 
                participation={getMyParticipation(challenge.id)}
                showJoinButton={false}
              />
            ))}
            {myActiveChallenges.length === 0 && (
              <div className="col-span-3 text-center py-12">
                <Trophy className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No active challenges</h3>
                <p className="text-gray-600">Join a challenge to see your progress here!</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="upcoming" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {upcomingChallenges.map(challenge => (
              <ChallengeCard 
                key={challenge.id} 
                challenge={challenge}
                showJoinButton={false}
              />
            ))}
            {upcomingChallenges.length === 0 && (
              <div className="col-span-3 text-center py-12">
                <Calendar className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No upcoming challenges</h3>
                <p className="text-gray-600">New challenges will appear here when they're announced.</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="completed" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {challenges.filter(c => {
              const participation = getMyParticipation(c.id);
              return participation && participation.completed;
            }).map(challenge => (
              <ChallengeCard 
                key={challenge.id} 
                challenge={challenge} 
                participation={getMyParticipation(challenge.id)}
                showJoinButton={false}
              />
            ))}
            {challenges.filter(c => {
              const participation = getMyParticipation(c.id);
              return participation && participation.completed;
            }).length === 0 && (
              <div className="col-span-3 text-center py-12">
                <Award className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No completed challenges</h3>
                <p className="text-gray-600">Complete challenges to see your achievements here!</p>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}