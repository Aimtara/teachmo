
import React, { useEffect, useState, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, XCircle, Filter } from 'lucide-react';
import QuickFilters from '@/components/discover/QuickFilters';
import { useDebounce } from '@/components/hooks/useDebounce';
import BreadcrumbNavigation from '@/components/shared/BreadcrumbNavigation';

// Lazy-load tab content for better performance
const ActivitiesTab = React.lazy(() => import('@/components/discover/ActivitiesTab'));
const EventsTab = React.lazy(() => import('@/components/discover/EventsTab'));
const LibraryTab = React.lazy(() => import('@/components/discover/LibraryTab'));
const RecommendationsTab = React.lazy(() => import('@/components/discover/RecommendationsTab'));
const ShortsDiscoverTab = React.lazy(() => import('@/components/discover/ShortsDiscoverTab'));

export default function UnifiedDiscover() {
  const location = useLocation();
  const navigate = useNavigate();

  // Parse URL parameters to set initial state
  const urlParams = new URLSearchParams(location.search);
  const initialTab = urlParams.get('tab') || 'recommendations';
  
  const [activeTab, setActiveTab] = useState(initialTab);
  const [globalSearchTerm, setGlobalSearchTerm] = useState(urlParams.get('q') || '');
  const debouncedSearchTerm = useDebounce(globalSearchTerm, 300);

  // Parse filters for each tab from URL
  const parseFiltersFromUrl = (tabName) => {
    try {
      const filters = urlParams.get(`filters_${tabName}`);
      return filters ? JSON.parse(filters) : {};
    } catch (e) {
      console.error(`Error parsing filters for ${tabName}:`, e);
      return {};
    }
  };

  const [filtersByTab, setFiltersByTab] = useState({
    recommendations: parseFiltersFromUrl('recommendations'),
    activities: parseFiltersFromUrl('activities'),
    library: parseFiltersFromUrl('library'),
    events: parseFiltersFromUrl('events'),
    shorts: parseFiltersFromUrl('shorts'),
  });

  // Update URL when tab or filters change
  useEffect(() => {
    const params = new URLSearchParams();

    if (activeTab !== 'recommendations') {
      params.set('tab', activeTab);
    }

    if (debouncedSearchTerm) {
      params.set('q', debouncedSearchTerm);
    }

    // Add filter parameters for each tab
    Object.entries(filtersByTab).forEach(([tab, filters]) => {
      // Only stringify and add filters if they are not empty
      if (Object.keys(filters).length > 0) {
        params.set(`filters_${tab}`, JSON.stringify(filters));
      }
    });

    // Construct the new URL search string
    const newUrlSearch = params.toString();
    
    // Only navigate if the search string has actually changed
    // This prevents unnecessary re-renders and history entries
    if (location.search.substring(1) !== newUrlSearch) {
      navigate({ search: newUrlSearch }, { replace: true });
    }
  }, [activeTab, debouncedSearchTerm, filtersByTab, navigate, location.search]);

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };
  
  const handleFiltersApplied = useCallback((newFilters) => {
    setFiltersByTab(prev => ({
      ...prev,
      [activeTab]: newFilters
    }));
  }, [activeTab]);

  const handleQuickFilterSelect = (quickFilter) => {
    setFiltersByTab(prev => ({
      ...prev,
      [activeTab]: {
        ...prev[activeTab],
        ...quickFilter
      }
    }));
  };

  const handleClearAllFilters = () => {
    setFiltersByTab(prev => ({
      ...prev,
      [activeTab]: {}
    }));
  };

  const currentFilters = filtersByTab[activeTab] || {};
  const areFiltersActive = Object.keys(currentFilters).length > 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-6">
        <BreadcrumbNavigation items={[{ label: 'Discover' }]} />
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Discover</h1>
              <p className="text-gray-600 mt-1">Find activities, resources, and events for your family</p>
            </div>
          </div>

          {/* Global Search */}
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Search across all content..."
              className="pl-10 py-3 text-lg bg-white/80 backdrop-blur-sm border-0 shadow-md"
              value={globalSearchTerm}
              onChange={(e) => setGlobalSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex items-center gap-4">
            <QuickFilters onSelect={handleQuickFilterSelect} />
            {areFiltersActive && (
              <Button variant="ghost" size="sm" onClick={handleClearAllFilters} className="text-red-600 hover:bg-red-50 hover:text-red-700">
                <XCircle className="w-4 h-4 mr-2" />
                Clear Filters
              </Button>
            )}
          </div>
          {areFiltersActive && (
            <div className="mt-2 text-sm text-gray-600 flex items-center gap-2">
              <Filter className="w-4 h-4" />
              <span>Filters are currently active.</span>
            </div>
          )}
        </div>

        <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 bg-white/80 backdrop-blur-sm shadow-md border-0">
            <TabsTrigger value="recommendations" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              AI Picks
            </TabsTrigger>
            <TabsTrigger value="activities" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              Activities
            </TabsTrigger>
            <TabsTrigger value="library" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              Library
            </TabsTrigger>
            <TabsTrigger value="events" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              Events
            </TabsTrigger>
            <TabsTrigger value="shorts" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              Shorts
            </TabsTrigger>
          </TabsList>

          <TabsContent value="recommendations">
            <RecommendationsTab
              initialQuery={debouncedSearchTerm}
              appliedFilters={currentFilters}
              onFiltersChange={handleFiltersApplied}
            />
          </TabsContent>

          <TabsContent value="activities">
            <ActivitiesTab
              initialQuery={debouncedSearchTerm}
              appliedFilters={currentFilters}
              onFiltersChange={handleFiltersApplied}
            />
          </TabsContent>

          <TabsContent value="library">
            <LibraryTab
              initialQuery={debouncedSearchTerm}
              appliedFilters={currentFilters}
              onFiltersChange={handleFiltersApplied}
            />
          </TabsContent>

          <TabsContent value="events">
            <EventsTab
              initialQuery={debouncedSearchTerm}
              appliedFilters={currentFilters}
              onFiltersChange={handleFiltersApplied}
            />
          </TabsContent>

          <TabsContent value="shorts">
            <ShortsDiscoverTab
              initialQuery={debouncedSearchTerm}
              appliedFilters={currentFilters}
              onFiltersChange={handleFiltersApplied}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
