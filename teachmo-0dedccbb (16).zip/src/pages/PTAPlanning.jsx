import React, { useState, useEffect } from 'react';
import { User, Task, PTADocument, Conversation, Message } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { ClipboardList, Folder, MessageCircle, Plus, Upload } from 'lucide-react';
import RoleGuard from '@/components/shared/RoleGuard';
import { DashboardSkeleton } from '@/components/shared/ImprovedSkeletons';
import { Tab } from '@headlessui/react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { UploadFile } from '@/api/integrations';

function PTAPlanning() {
    const [user, setUser] = useState(null);
    const [tasks, setTasks] = useState([]);
    const [documents, setDocuments] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const { toast } = useToast();

    // Placeholder for chat functionality
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');

    useEffect(() => {
        const loadData = async () => {
            try {
                const currentUser = await User.me();
                setUser(currentUser);

                if (!currentUser.school_id) {
                    setIsLoading(false);
                    return;
                }

                const [tasksData, docsData] = await Promise.all([
                    Task.filter({ school_id: currentUser.school_id, category: 'pta_internal' }),
                    PTADocument.filter({ school_id: currentUser.school_id })
                ]);

                setTasks(tasksData);
                setDocuments(docsData);
            } catch (error) {
                console.error("Failed to load PTA planning data:", error);
                toast({ variant: 'destructive', title: 'Error', description: 'Could not load planning data.' });
            } finally {
                setIsLoading(false);
            }
        };
        loadData();
    }, [toast]);
    
    const handleFileUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        try {
            const { file_url } = await UploadFile({ file });
            await PTADocument.create({
                school_id: user.school_id,
                file_name: file.name,
                file_url: file_url,
                file_type: file.type,
                uploaded_by: user.id
            });
            toast({ title: 'Success', description: 'Document uploaded.' });
            // Refresh documents
            const docsData = await PTADocument.filter({ school_id: user.school_id });
            setDocuments(docsData);

        } catch(error) {
            toast({ variant: 'destructive', title: 'Upload Failed', description: 'Could not upload the document.' });
        }
    };


    if (isLoading) return <DashboardSkeleton />;

    const tabs = [
        { name: 'Internal Tasks', icon: ClipboardList, content: (
            <div>
                {/* Placeholder for a Kanban board */}
                <h3 className="font-bold mb-2">Task Board</h3>
                <p>A full Kanban board for internal tasks would be developed here.</p>
                {tasks.map(task => <div key={task.id} className="p-2 border rounded mt-2">{task.title}</div>)}
            </div>
        ) },
        { name: 'Documents', icon: Folder, content: (
            <div>
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold">Shared Documents</h3>
                    <Button asChild variant="outline">
                        <label>
                            <Upload className="mr-2 h-4 w-4" /> Upload File
                            <input type="file" className="hidden" onChange={handleFileUpload} />
                        </label>
                    </Button>
                </div>
                <div className="space-y-2">
                    {documents.map(doc => (
                        <a href={doc.file_url} target="_blank" rel="noopener noreferrer" key={doc.id} className="flex items-center p-2 border rounded hover:bg-gray-50">
                            <Folder className="mr-2 text-blue-500" />
                            {doc.file_name}
                        </a>
                    ))}
                </div>
            </div>
        ) },
        { name: 'Board Chat', icon: MessageCircle, content: (
             <div>
                {/* Placeholder for chat */}
                <h3 className="font-bold mb-2">Board Member Chat</h3>
                <p>A private, real-time chat for board members would be implemented here.</p>
                <div className="h-64 border rounded p-2 overflow-y-auto bg-gray-50 my-2">
                    {/* Messages would be mapped here */}
                    <p className="text-gray-500 text-sm">Chat is currently under development.</p>
                </div>
                 <div className="flex gap-2">
                    <Input placeholder="Type a message..." value={newMessage} onChange={e => setNewMessage(e.target.value)} />
                    <Button disabled>Send</Button>
                </div>
            </div>
        ) },
    ];

    return (
        <div className="p-4 md:p-6 space-y-6">
            <header>
                <h1 className="text-3xl font-bold text-gray-900">PTA Private Planning</h1>
                <p className="text-gray-600">A secure space for board members to collaborate.</p>
            </header>
            
             <Tab.Group>
                <Tab.List className="flex space-x-1 rounded-xl bg-blue-900/20 p-1">
                    {tabs.map((tab) => (
                        <Tab key={tab.name} className={({ selected }) =>
                            `w-full rounded-lg py-2.5 text-sm font-medium leading-5 flex items-center justify-center gap-2
                             ${selected ? 'bg-white shadow text-blue-700' : 'text-blue-100 hover:bg-white/[0.12] hover:text-white'}`
                        }>
                            <tab.icon className="w-5 h-5" /> {tab.name}
                        </Tab>
                    ))}
                </Tab.List>
                <Tab.Panels className="mt-2">
                    {tabs.map((tab, idx) => (
                        <Tab.Panel key={idx} className="rounded-xl bg-white p-4">
                            {tab.content}
                        </Tab.Panel>
                    ))}
                </Tab.Panels>
            </Tab.Group>
        </div>
    );
}

export default function ProtectedPTAPlanning() {
    return (
        <RoleGuard allowedRoles={['parent']} ptaBoardOnly={true}>
            <PTAPlanning />
        </RoleGuard>
    );
}