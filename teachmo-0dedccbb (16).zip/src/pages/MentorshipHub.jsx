import React, { useState, useEffect } from 'react';
import { MentorProfile, Mentorship, User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Star, MessageCircle, Calendar, Plus } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import MentorProfileForm from '../components/mentorship/MentorProfileForm';

export default function MentorshipHub() {
  const [mentors, setMentors] = useState([]);
  const [myMentorships, setMyMentorships] = useState([]);
  const [myMentorProfile, setMyMentorProfile] = useState(null);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showMentorForm, setShowMentorForm] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);

      const [mentorsData, mentorshipsData, mentorProfileData] = await Promise.all([
        MentorProfile.filter({ is_active: true }),
        Mentorship.filter({
          $or: [
            { mentor_id: userData.id },
            { mentee_id: userData.id }
          ]
        }),
        MentorProfile.filter({ user_id: userData.id }).then(profiles => profiles[0] || null)
      ]);

      setMentors(mentorsData);
      setMyMentorships(mentorshipsData);
      setMyMentorProfile(mentorProfileData);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load mentorship data."
      });
    } finally {
      setIsLoading(false);
    }
  };

  const requestMentorship = async (mentorId, topicAreas) => {
    try {
      await Mentorship.create({
        mentor_id: mentorId,
        mentee_id: user.id,
        topic_areas: topicAreas,
        status: 'requested'
      });

      toast({
        title: "Mentorship Requested",
        description: "Your mentorship request has been sent!"
      });

      loadData();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to request mentorship."
      });
    }
  };

  const handleMentorProfileSubmit = async (profileData) => {
    try {
      if (myMentorProfile) {
        await MentorProfile.update(myMentorProfile.id, profileData);
        toast({
          title: "Profile Updated",
          description: "Your mentor profile has been updated."
        });
      } else {
        await MentorProfile.create({
          ...profileData,
          user_id: user.id
        });
        toast({
          title: "Mentor Profile Created",
          description: "You're now available as a mentor!"
        });
      }
      
      setShowMentorForm(false);
      loadData();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to save mentor profile."
      });
    }
  };

  const MentorCard = ({ mentor }) => (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg">{mentor.user?.full_name || 'Anonymous Mentor'}</CardTitle>
            <p className="text-gray-600 mt-1">{mentor.bio}</p>
            {mentor.rating > 0 && (
              <div className="flex items-center gap-1 mt-2">
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                <span className="text-sm font-medium">{mentor.rating.toFixed(1)}</span>
                <span className="text-sm text-gray-500">({mentor.rating_count} reviews)</span>
              </div>
            )}
          </div>
          <Badge className={mentor.current_mentees < mentor.max_mentees ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
            {mentor.current_mentees}/{mentor.max_mentees} mentees
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div>
            <span className="text-sm font-medium text-gray-700">Expertise: </span>
            <div className="flex flex-wrap gap-1 mt-1">
              {mentor.expertise_areas.map(area => (
                <Badge key={area} variant="outline" className="text-xs">
                  {area}
                </Badge>
              ))}
            </div>
          </div>
          
          <p className="text-sm text-gray-600">{mentor.experience_description}</p>
          
          <div className="flex justify-end gap-2">
            <Button 
              variant="outline" 
              size="sm"
              disabled={mentor.current_mentees >= mentor.max_mentees}
            >
              <MessageCircle className="w-4 h-4 mr-1" />
              Message
            </Button>
            <Button 
              size="sm"
              onClick={() => requestMentorship(mentor.user_id, mentor.expertise_areas.slice(0, 2))}
              disabled={mentor.current_mentees >= mentor.max_mentees}
            >
              Request Mentorship
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const MentorshipCard = ({ mentorship }) => {
    const isMyMentoring = mentorship.mentor_id === user?.id;
    const otherUser = isMyMentoring ? mentorship.mentee : mentorship.mentor;
    
    return (
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-lg">
                {isMyMentoring ? 'Mentoring' : 'Being Mentored by'}: {otherUser?.full_name || 'Unknown User'}
              </CardTitle>
              <div className="flex items-center gap-2 mt-2">
                <Badge 
                  className={
                    mentorship.status === 'active' ? 'bg-green-100 text-green-800' :
                    mentorship.status === 'requested' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-gray-100 text-gray-800'
                  }
                >
                  {mentorship.status}
                </Badge>
                <span className="text-sm text-gray-500">
                  {mentorship.sessions_completed} sessions completed
                </span>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div>
              <span className="text-sm font-medium text-gray-700">Focus Areas: </span>
              <div className="flex flex-wrap gap-1 mt-1">
                {mentorship.topic_areas.map(area => (
                  <Badge key={area} variant="outline" className="text-xs">
                    {area}
                  </Badge>
                ))}
              </div>
            </div>
            
            {mentorship.notes && (
              <p className="text-sm text-gray-600">{mentorship.notes}</p>
            )}
            
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm">
                <MessageCircle className="w-4 h-4 mr-1" />
                Message
              </Button>
              <Button variant="outline" size="sm">
                <Calendar className="w-4 h-4 mr-1" />
                Schedule
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (isLoading) {
    return <div className="p-6 text-center">Loading mentorship hub...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Mentorship Hub</h1>
          <p className="text-gray-600 mt-1">Connect with experienced parents and educators</p>
        </div>
        <Button onClick={() => setShowMentorForm(true)}>
          <Plus className="w-4 h-4 mr-2" />
          {myMentorProfile ? 'Update' : 'Become'} a Mentor
        </Button>
      </div>

      <Tabs defaultValue="find-mentors" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="find-mentors">Find Mentors</TabsTrigger>
          <TabsTrigger value="my-mentorships">My Mentorships</TabsTrigger>
          <TabsTrigger value="mentor-profile">My Mentor Profile</TabsTrigger>
        </TabsList>

        <TabsContent value="find-mentors" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mentors.filter(mentor => mentor.user_id !== user?.id).map(mentor => (
              <MentorCard key={mentor.id} mentor={mentor} />
            ))}
            {mentors.filter(mentor => mentor.user_id !== user?.id).length === 0 && (
              <div className="col-span-3 text-center py-12">
                <Users className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No mentors available</h3>
                <p className="text-gray-600">Check back later or consider becoming a mentor yourself!</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="my-mentorships" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {myMentorships.map(mentorship => (
              <MentorshipCard key={mentorship.id} mentorship={mentorship} />
            ))}
            {myMentorships.length === 0 && (
              <div className="col-span-2 text-center py-12">
                <MessageCircle className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No mentorships yet</h3>
                <p className="text-gray-600">Request mentorship from experienced parents to get started!</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="mentor-profile" className="mt-6">
          {myMentorProfile ? (
            <Card>
              <CardHeader>
                <CardTitle>Your Mentor Profile</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <span className="font-medium">Bio: </span>
                    <span className="text-gray-600">{myMentorProfile.bio}</span>
                  </div>
                  <div>
                    <span className="font-medium">Expertise Areas: </span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {myMentorProfile.expertise_areas.map(area => (
                        <Badge key={area} variant="outline">
                          {area}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <span className="font-medium">Current Mentees: </span>
                    <span className="text-gray-600">{myMentorProfile.current_mentees}/{myMentorProfile.max_mentees}</span>
                  </div>
                  {myMentorProfile.rating > 0 && (
                    <div>
                      <span className="font-medium">Rating: </span>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span>{myMentorProfile.rating.toFixed(1)} ({myMentorProfile.rating_count} reviews)</span>
                      </div>
                    </div>
                  )}
                  <Button onClick={() => setShowMentorForm(true)}>
                    Update Profile
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="text-center py-12">
              <Users className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No mentor profile yet</h3>
              <p className="text-gray-600 mb-4">Share your experience and help other parents in their journey!</p>
              <Button onClick={() => setShowMentorForm(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create Mentor Profile
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>

      <Dialog open={showMentorForm} onOpenChange={setShowMentorForm}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {myMentorProfile ? 'Update' : 'Create'} Mentor Profile
            </DialogTitle>
          </DialogHeader>
          <MentorProfileForm 
            profile={myMentorProfile}
            onSubmit={handleMentorProfileSubmit}
            onCancel={() => setShowMentorForm(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}