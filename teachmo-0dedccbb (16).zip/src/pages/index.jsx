import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Progress from "./Progress";

import Settings from "./Settings";

import Achievements from "./Achievements";

import Shopping from "./Shopping";

import Upgrade from "./Upgrade";

import Store from "./Store";

import ResourceDetail from "./ResourceDetail";

import Calendar from "./Calendar";

import SetupSummary from "./SetupSummary";

import PodDetail from "./PodDetail";

import Notifications from "./Notifications";

import Journal from "./Journal";

import Welcome from "./Welcome";

import Messages from "./Messages";

import VoiceSetup from "./VoiceSetup";

import UnifiedDiscover from "./UnifiedDiscover";

import UnifiedCommunity from "./UnifiedCommunity";

import Landing from "./Landing";

import AIAssistant from "./AIAssistant";

import Community from "./Community";

import Discover from "./Discover";

import Integrations from "./Integrations";

import TeacherDashboard from "./TeacherDashboard";

import AdminDashboard from "./AdminDashboard";

import TeacherClasses from "./TeacherClasses";

import SchoolAssignments from "./SchoolAssignments";

import AdminUsers from "./AdminUsers";

import AdminSettings from "./AdminSettings";

import AdminAnalytics from "./AdminAnalytics";

import TeacherMessages from "./TeacherMessages";

import TeacherStudentDetail from "./TeacherStudentDetail";

import Announcements from "./Announcements";

import SchoolUsers from "./SchoolUsers";

import SystemUsers from "./SystemUsers";

import DistrictUsers from "./DistrictUsers";

import SystemDistricts from "./SystemDistricts";

import DistrictSchools from "./DistrictSchools";

import SchoolAnalytics from "./SchoolAnalytics";

import DistrictAnalytics from "./DistrictAnalytics";

import SchoolSettings from "./SchoolSettings";

import DistrictSettings from "./DistrictSettings";

import SystemAdminDashboard from "./SystemAdminDashboard";

import DistrictAdminDashboard from "./DistrictAdminDashboard";

import SchoolAdminDashboard from "./SchoolAdminDashboard";

import TeacherOnboarding from "./TeacherOnboarding";

import AdminOnboarding from "./AdminOnboarding";

import AdminUserEdit from "./AdminUserEdit";

import UserProfile from "./UserProfile";

import SchoolRequests from "./SchoolRequests";

import PrivacyRights from "./PrivacyRights";

import DoNotSell from "./DoNotSell";

import PartnerSignup from "./PartnerSignup";

import PartnerDashboard from "./PartnerDashboard";

import PartnerAdmin from "./PartnerAdmin";

import PaymentSuccess from "./PaymentSuccess";

import PaymentCancelled from "./PaymentCancelled";

import SchoolDirectoryMonitoring from "./SchoolDirectoryMonitoring";

import SchoolDirectoryAdmin from "./SchoolDirectoryAdmin";

import TeacherAssignments from "./TeacherAssignments";

import AccessibilityAudit from "./AccessibilityAudit";

import DeveloperGuide from "./DeveloperGuide";

import SupabaseSetup from "./SupabaseSetup";

import OfficeHours from "./OfficeHours";

import ModerationDashboard from "./ModerationDashboard";

import CommunityGuidelines from "./CommunityGuidelines";

import AskTeachmo from "./AskTeachmo";

import PTADashboard from "./PTADashboard";

import PTAPlanning from "./PTAPlanning";

import SponsorshipDashboard from "./SponsorshipDashboard";

import SystemSchools from "./SystemSchools";

import ShortsOverview from "./ShortsOverview";

import ShortsQueues from "./ShortsQueues";

import ShortDetail from "./ShortDetail";

import SchoolContent from "./SchoolContent";

import AdminPermissions from "./AdminPermissions";

import CurriculumAlignment from "./CurriculumAlignment";

import UserContentHub from "./UserContentHub";

import MentorshipHub from "./MentorshipHub";

import ChallengeHub from "./ChallengeHub";

import WorkshopCenter from "./WorkshopCenter";

import LicenseManagement from "./LicenseManagement";

import Onboarding from "./Onboarding";

import UXReviewGuide from "./UXReviewGuide";

import AdminUXDashboard from "./AdminUXDashboard";

import GamificationHub from "./GamificationHub";

import EnterpriseAdmin from "./EnterpriseAdmin";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Progress: Progress,
    
    Settings: Settings,
    
    Achievements: Achievements,
    
    Shopping: Shopping,
    
    Upgrade: Upgrade,
    
    Store: Store,
    
    ResourceDetail: ResourceDetail,
    
    Calendar: Calendar,
    
    SetupSummary: SetupSummary,
    
    PodDetail: PodDetail,
    
    Notifications: Notifications,
    
    Journal: Journal,
    
    Welcome: Welcome,
    
    Messages: Messages,
    
    VoiceSetup: VoiceSetup,
    
    UnifiedDiscover: UnifiedDiscover,
    
    UnifiedCommunity: UnifiedCommunity,
    
    Landing: Landing,
    
    AIAssistant: AIAssistant,
    
    Community: Community,
    
    Discover: Discover,
    
    Integrations: Integrations,
    
    TeacherDashboard: TeacherDashboard,
    
    AdminDashboard: AdminDashboard,
    
    TeacherClasses: TeacherClasses,
    
    SchoolAssignments: SchoolAssignments,
    
    AdminUsers: AdminUsers,
    
    AdminSettings: AdminSettings,
    
    AdminAnalytics: AdminAnalytics,
    
    TeacherMessages: TeacherMessages,
    
    TeacherStudentDetail: TeacherStudentDetail,
    
    Announcements: Announcements,
    
    SchoolUsers: SchoolUsers,
    
    SystemUsers: SystemUsers,
    
    DistrictUsers: DistrictUsers,
    
    SystemDistricts: SystemDistricts,
    
    DistrictSchools: DistrictSchools,
    
    SchoolAnalytics: SchoolAnalytics,
    
    DistrictAnalytics: DistrictAnalytics,
    
    SchoolSettings: SchoolSettings,
    
    DistrictSettings: DistrictSettings,
    
    SystemAdminDashboard: SystemAdminDashboard,
    
    DistrictAdminDashboard: DistrictAdminDashboard,
    
    SchoolAdminDashboard: SchoolAdminDashboard,
    
    TeacherOnboarding: TeacherOnboarding,
    
    AdminOnboarding: AdminOnboarding,
    
    AdminUserEdit: AdminUserEdit,
    
    UserProfile: UserProfile,
    
    SchoolRequests: SchoolRequests,
    
    PrivacyRights: PrivacyRights,
    
    DoNotSell: DoNotSell,
    
    PartnerSignup: PartnerSignup,
    
    PartnerDashboard: PartnerDashboard,
    
    PartnerAdmin: PartnerAdmin,
    
    PaymentSuccess: PaymentSuccess,
    
    PaymentCancelled: PaymentCancelled,
    
    SchoolDirectoryMonitoring: SchoolDirectoryMonitoring,
    
    SchoolDirectoryAdmin: SchoolDirectoryAdmin,
    
    TeacherAssignments: TeacherAssignments,
    
    AccessibilityAudit: AccessibilityAudit,
    
    DeveloperGuide: DeveloperGuide,
    
    SupabaseSetup: SupabaseSetup,
    
    OfficeHours: OfficeHours,
    
    ModerationDashboard: ModerationDashboard,
    
    CommunityGuidelines: CommunityGuidelines,
    
    AskTeachmo: AskTeachmo,
    
    PTADashboard: PTADashboard,
    
    PTAPlanning: PTAPlanning,
    
    SponsorshipDashboard: SponsorshipDashboard,
    
    SystemSchools: SystemSchools,
    
    ShortsOverview: ShortsOverview,
    
    ShortsQueues: ShortsQueues,
    
    ShortDetail: ShortDetail,
    
    SchoolContent: SchoolContent,
    
    AdminPermissions: AdminPermissions,
    
    CurriculumAlignment: CurriculumAlignment,
    
    UserContentHub: UserContentHub,
    
    MentorshipHub: MentorshipHub,
    
    ChallengeHub: ChallengeHub,
    
    WorkshopCenter: WorkshopCenter,
    
    LicenseManagement: LicenseManagement,
    
    Onboarding: Onboarding,
    
    UXReviewGuide: UXReviewGuide,
    
    AdminUXDashboard: AdminUXDashboard,
    
    GamificationHub: GamificationHub,
    
    EnterpriseAdmin: EnterpriseAdmin,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Progress" element={<Progress />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Achievements" element={<Achievements />} />
                
                <Route path="/Shopping" element={<Shopping />} />
                
                <Route path="/Upgrade" element={<Upgrade />} />
                
                <Route path="/Store" element={<Store />} />
                
                <Route path="/ResourceDetail" element={<ResourceDetail />} />
                
                <Route path="/Calendar" element={<Calendar />} />
                
                <Route path="/SetupSummary" element={<SetupSummary />} />
                
                <Route path="/PodDetail" element={<PodDetail />} />
                
                <Route path="/Notifications" element={<Notifications />} />
                
                <Route path="/Journal" element={<Journal />} />
                
                <Route path="/Welcome" element={<Welcome />} />
                
                <Route path="/Messages" element={<Messages />} />
                
                <Route path="/VoiceSetup" element={<VoiceSetup />} />
                
                <Route path="/UnifiedDiscover" element={<UnifiedDiscover />} />
                
                <Route path="/UnifiedCommunity" element={<UnifiedCommunity />} />
                
                <Route path="/Landing" element={<Landing />} />
                
                <Route path="/AIAssistant" element={<AIAssistant />} />
                
                <Route path="/Community" element={<Community />} />
                
                <Route path="/Discover" element={<Discover />} />
                
                <Route path="/Integrations" element={<Integrations />} />
                
                <Route path="/TeacherDashboard" element={<TeacherDashboard />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/TeacherClasses" element={<TeacherClasses />} />
                
                <Route path="/SchoolAssignments" element={<SchoolAssignments />} />
                
                <Route path="/AdminUsers" element={<AdminUsers />} />
                
                <Route path="/AdminSettings" element={<AdminSettings />} />
                
                <Route path="/AdminAnalytics" element={<AdminAnalytics />} />
                
                <Route path="/TeacherMessages" element={<TeacherMessages />} />
                
                <Route path="/TeacherStudentDetail" element={<TeacherStudentDetail />} />
                
                <Route path="/Announcements" element={<Announcements />} />
                
                <Route path="/SchoolUsers" element={<SchoolUsers />} />
                
                <Route path="/SystemUsers" element={<SystemUsers />} />
                
                <Route path="/DistrictUsers" element={<DistrictUsers />} />
                
                <Route path="/SystemDistricts" element={<SystemDistricts />} />
                
                <Route path="/DistrictSchools" element={<DistrictSchools />} />
                
                <Route path="/SchoolAnalytics" element={<SchoolAnalytics />} />
                
                <Route path="/DistrictAnalytics" element={<DistrictAnalytics />} />
                
                <Route path="/SchoolSettings" element={<SchoolSettings />} />
                
                <Route path="/DistrictSettings" element={<DistrictSettings />} />
                
                <Route path="/SystemAdminDashboard" element={<SystemAdminDashboard />} />
                
                <Route path="/DistrictAdminDashboard" element={<DistrictAdminDashboard />} />
                
                <Route path="/SchoolAdminDashboard" element={<SchoolAdminDashboard />} />
                
                <Route path="/TeacherOnboarding" element={<TeacherOnboarding />} />
                
                <Route path="/AdminOnboarding" element={<AdminOnboarding />} />
                
                <Route path="/AdminUserEdit" element={<AdminUserEdit />} />
                
                <Route path="/UserProfile" element={<UserProfile />} />
                
                <Route path="/SchoolRequests" element={<SchoolRequests />} />
                
                <Route path="/PrivacyRights" element={<PrivacyRights />} />
                
                <Route path="/DoNotSell" element={<DoNotSell />} />
                
                <Route path="/PartnerSignup" element={<PartnerSignup />} />
                
                <Route path="/PartnerDashboard" element={<PartnerDashboard />} />
                
                <Route path="/PartnerAdmin" element={<PartnerAdmin />} />
                
                <Route path="/PaymentSuccess" element={<PaymentSuccess />} />
                
                <Route path="/PaymentCancelled" element={<PaymentCancelled />} />
                
                <Route path="/SchoolDirectoryMonitoring" element={<SchoolDirectoryMonitoring />} />
                
                <Route path="/SchoolDirectoryAdmin" element={<SchoolDirectoryAdmin />} />
                
                <Route path="/TeacherAssignments" element={<TeacherAssignments />} />
                
                <Route path="/AccessibilityAudit" element={<AccessibilityAudit />} />
                
                <Route path="/DeveloperGuide" element={<DeveloperGuide />} />
                
                <Route path="/SupabaseSetup" element={<SupabaseSetup />} />
                
                <Route path="/OfficeHours" element={<OfficeHours />} />
                
                <Route path="/ModerationDashboard" element={<ModerationDashboard />} />
                
                <Route path="/CommunityGuidelines" element={<CommunityGuidelines />} />
                
                <Route path="/AskTeachmo" element={<AskTeachmo />} />
                
                <Route path="/PTADashboard" element={<PTADashboard />} />
                
                <Route path="/PTAPlanning" element={<PTAPlanning />} />
                
                <Route path="/SponsorshipDashboard" element={<SponsorshipDashboard />} />
                
                <Route path="/SystemSchools" element={<SystemSchools />} />
                
                <Route path="/ShortsOverview" element={<ShortsOverview />} />
                
                <Route path="/ShortsQueues" element={<ShortsQueues />} />
                
                <Route path="/ShortDetail" element={<ShortDetail />} />
                
                <Route path="/SchoolContent" element={<SchoolContent />} />
                
                <Route path="/AdminPermissions" element={<AdminPermissions />} />
                
                <Route path="/CurriculumAlignment" element={<CurriculumAlignment />} />
                
                <Route path="/UserContentHub" element={<UserContentHub />} />
                
                <Route path="/MentorshipHub" element={<MentorshipHub />} />
                
                <Route path="/ChallengeHub" element={<ChallengeHub />} />
                
                <Route path="/WorkshopCenter" element={<WorkshopCenter />} />
                
                <Route path="/LicenseManagement" element={<LicenseManagement />} />
                
                <Route path="/Onboarding" element={<Onboarding />} />
                
                <Route path="/UXReviewGuide" element={<UXReviewGuide />} />
                
                <Route path="/AdminUXDashboard" element={<AdminUXDashboard />} />
                
                <Route path="/GamificationHub" element={<GamificationHub />} />
                
                <Route path="/EnterpriseAdmin" element={<EnterpriseAdmin />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}