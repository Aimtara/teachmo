import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Shield, CheckCircle, AlertTriangle } from 'lucide-react';
import { User } from '@/api/entities';

function DoNotSellPage() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);
  const [currentStatus, setCurrentStatus] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
        setCurrentStatus(currentUser.privacy_preferences?.doNotSell || false);
      } catch (error) {
        console.error('Error fetching user:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchUser();
  }, []);

  const handleOptOutToggle = async (optOut) => {
    setIsUpdating(true);
    try {
      const updatedPreferences = {
        ...user.privacy_preferences,
        doNotSell: optOut,
        lastUpdated: new Date().toISOString()
      };

      await User.updateMyUserData({
        privacy_preferences: updatedPreferences
      });

      setCurrentStatus(optOut);
      setUser(prev => ({ ...prev, privacy_preferences: updatedPreferences }));

      toast({
        title: optOut ? "Opted Out Successfully" : "Opt-Out Removed",
        description: optOut 
          ? "You have successfully opted out of data sales."
          : "You have removed your opt-out preference."
      });
    } catch (error) {
      console.error('Error updating privacy preferences:', error);
      toast({
        variant: "destructive",
        title: "Update Failed",
        description: "Failed to update your privacy preferences. Please try again."
      });
    } finally {
      setIsUpdating(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/2 mx-auto mb-8"></div>
            <div className="h-64 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <Shield className="w-12 h-12 text-blue-600 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-gray-900">Do Not Sell My Personal Information</h1>
          <p className="text-gray-600 mt-2">
            Control how your personal information is shared under the California Consumer Privacy Act (CCPA)
          </p>
        </div>

        {/* Current Status */}
        <Card className={`mb-6 ${currentStatus ? 'border-green-200 bg-green-50' : 'border-yellow-200 bg-yellow-50'}`}>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              {currentStatus ? (
                <>
                  <CheckCircle className="w-6 h-6 text-green-600" />
                  <div>
                    <h3 className="font-semibold text-green-900">You are opted out</h3>
                    <p className="text-green-700 text-sm">
                      Your personal information will not be sold to third parties.
                    </p>
                  </div>
                </>
              ) : (
                <>
                  <AlertTriangle className="w-6 h-6 text-yellow-600" />
                  <div>
                    <h3 className="font-semibold text-yellow-900">You are not opted out</h3>
                    <p className="text-yellow-700 text-sm">
                      Your personal information may be shared with our partners as described in our Privacy Policy.
                    </p>
                  </div>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <Card>
          <CardHeader>
            <CardTitle>Your CCPA Rights</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">What does "Do Not Sell" mean?</h3>
              <p className="text-gray-700 text-sm mb-4">
                Under the California Consumer Privacy Act (CCPA), you have the right to opt-out of the "sale" 
                of your personal information. This includes sharing your information with third parties for 
                monetary or other valuable consideration.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-gray-900 mb-3">What information might be shared?</h3>
              <ul className="text-gray-700 text-sm space-y-1 ml-4">
                <li>• Usage analytics and behavioral data</li>
                <li>• Marketing preferences and interests</li>
                <li>• Device and technical information</li>
                <li>• Aggregated demographic information</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-gray-900 mb-3">What information is never sold?</h3>
              <ul className="text-gray-700 text-sm space-y-1 ml-4">
                <li>• Your children's personal information</li>
                <li>• Educational records and progress data</li>
                <li>• Private messages and conversations</li>
                <li>• Financial or payment information</li>
                <li>• Sensitive personal identifiers (SSN, etc.)</li>
              </ul>
            </div>

            <div className="border-t pt-6">
              <h3 className="font-semibold text-gray-900 mb-4">Make your choice:</h3>
              <div className="flex gap-4">
                <Button
                  onClick={() => handleOptOutToggle(true)}
                  disabled={isUpdating || currentStatus}
                  variant={currentStatus ? "outline" : "default"}
                  className="flex-1"
                >
                  {isUpdating && currentStatus ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Updating...
                    </>
                  ) : (
                    <>
                      <Shield className="w-4 h-4 mr-2" />
                      {currentStatus ? "Already Opted Out" : "Opt Out of Sales"}
                    </>
                  )}
                </Button>
                
                {currentStatus && (
                  <Button
                    onClick={() => handleOptOutToggle(false)}
                    disabled={isUpdating}
                    variant="outline"
                    className="flex-1"
                  >
                    {isUpdating ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-600 mr-2" />
                        Updating...
                      </>
                    ) : (
                      "Remove Opt-Out"
                    )}
                  </Button>
                )}
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-900 mb-2">Important Notes:</h4>
              <ul className="text-blue-700 text-sm space-y-1">
                <li>• This setting only applies to the "sale" of information as defined by CCPA</li>
                <li>• We may still share information for operational purposes (security, fraud prevention, etc.)</li>
                <li>• You can change this setting at any time</li>
                <li>• This does not affect other privacy controls available in your Settings</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <div className="mt-8 text-center">
          <p className="text-sm text-gray-600">
            For questions about your privacy rights, contact us at{' '}
            <a href="mailto:privacy@teachmo.com" className="text-blue-600 hover:underline">
              privacy@teachmo.com
            </a>{' '}
            or read our full{' '}
            <a href="/privacy-policy" className="text-blue-600 hover:underline">
              Privacy Policy
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}

export default DoNotSellPage;