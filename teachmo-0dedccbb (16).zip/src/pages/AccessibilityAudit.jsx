import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { 
  Eye, 
  CheckCircle, 
  AlertTriangle, 
  XCircle, 
  Scan, 
  Download,
  Keyboard,
  MousePointer,
  Volume2,
  Palette
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import RoleGuard from '@/components/shared/RoleGuard';

const ACCESSIBILITY_CHECKS = [
  {
    category: 'Images & Media',
    icon: Eye,
    checks: [
      { id: 'alt-text', name: 'Images have alt text', status: 'pass' },
      { id: 'decorative-images', name: 'Decorative images marked appropriately', status: 'warning' },
      { id: 'video-captions', name: 'Videos have captions', status: 'pass' }
    ]
  },
  {
    category: 'Keyboard Navigation',
    icon: Keyboard,
    checks: [
      { id: 'focus-indicators', name: 'Visible focus indicators', status: 'pass' },
      { id: 'keyboard-trap', name: 'No keyboard traps', status: 'pass' },
      { id: 'skip-links', name: 'Skip navigation links', status: 'pass' }
    ]
  },
  {
    category: 'Color & Contrast',
    icon: Palette,
    checks: [
      { id: 'color-contrast', name: 'Text meets contrast requirements', status: 'warning' },
      { id: 'color-only', name: 'Information not conveyed by color alone', status: 'pass' },
      { id: 'focus-contrast', name: 'Focus indicators have sufficient contrast', status: 'pass' }
    ]
  },
  {
    category: 'Screen Readers',
    icon: Volume2,
    checks: [
      { id: 'headings', name: 'Proper heading structure', status: 'pass' },
      { id: 'aria-labels', name: 'ARIA labels for complex elements', status: 'warning' },
      { id: 'form-labels', name: 'Form inputs have labels', status: 'pass' }
    ]
  },
  {
    category: 'Interactive Elements',
    icon: MousePointer,
    checks: [
      { id: 'button-purpose', name: 'Button purpose is clear', status: 'pass' },
      { id: 'link-purpose', name: 'Link purpose is clear', status: 'warning' },
      { id: 'error-messages', name: 'Clear error messages', status: 'pass' }
    ]
  }
];

function AccessibilityAuditPage() {
  const [isScanning, setIsScanning] = useState(false);
  const [scanResults, setScanResults] = useState(ACCESSIBILITY_CHECKS);
  const [lastScanDate, setLastScanDate] = useState(null);
  const { toast } = useToast();

  const runAccessibilityScan = async () => {
    setIsScanning(true);
    
    try {
      // Simulate scanning process
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Update scan results with some random variations
      const updatedResults = ACCESSIBILITY_CHECKS.map(category => ({
        ...category,
        checks: category.checks.map(check => ({
          ...check,
          status: Math.random() > 0.2 ? 'pass' : Math.random() > 0.5 ? 'warning' : 'fail'
        }))
      }));
      
      setScanResults(updatedResults);
      setLastScanDate(new Date());
      
      toast({
        title: "Accessibility Scan Complete",
        description: "The accessibility audit has been completed successfully."
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Scan Failed",
        description: "Failed to complete accessibility scan. Please try again."
      });
    } finally {
      setIsScanning(false);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pass':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case 'fail':
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return null;
    }
  };

  const getStatusBadge = (status) => {
    const variants = {
      pass: { variant: 'default', className: 'bg-green-100 text-green-800' },
      warning: { variant: 'default', className: 'bg-yellow-100 text-yellow-800' },
      fail: { variant: 'default', className: 'bg-red-100 text-red-800' }
    };
    
    return (
      <Badge className={variants[status].className}>
        {status === 'pass' ? 'Pass' : status === 'warning' ? 'Warning' : 'Fail'}
      </Badge>
    );
  };

  const getOverallStats = () => {
    const allChecks = scanResults.flatMap(category => category.checks);
    const pass = allChecks.filter(check => check.status === 'pass').length;
    const warning = allChecks.filter(check => check.status === 'warning').length;
    const fail = allChecks.filter(check => check.status === 'fail').length;
    const total = allChecks.length;
    
    return { pass, warning, fail, total };
  };

  const stats = getOverallStats();

  return (
    <RoleGuard allowedRoles={['system_admin', 'district_admin', 'school_admin']}>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Accessibility Audit</h1>
            <p className="text-gray-600 mt-2">
              Monitor and improve WCAG 2.1 AA compliance across the platform
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" disabled>
              <Download className="w-4 h-4 mr-2" />
              Export Report
            </Button>
            <Button onClick={runAccessibilityScan} disabled={isScanning}>
              {isScanning ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Scanning...
                </>
              ) : (
                <>
                  <Scan className="w-4 h-4 mr-2" />
                  Run Scan
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{stats.pass}</div>
              <div className="text-sm text-gray-600">Passing</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-yellow-600">{stats.warning}</div>
              <div className="text-sm text-gray-600">Warnings</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-red-600">{stats.fail}</div>
              <div className="text-sm text-gray-600">Failing</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">
                {Math.round((stats.pass / stats.total) * 100)}%
              </div>
              <div className="text-sm text-gray-600">Overall Score</div>
            </CardContent>
          </Card>
        </div>

        {lastScanDate && (
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4">
              <p className="text-sm text-blue-700">
                Last scan: {lastScanDate.toLocaleDateString()} at {lastScanDate.toLocaleTimeString()}
              </p>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="detailed">Detailed Results</TabsTrigger>
            <TabsTrigger value="guidelines">Guidelines</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {scanResults.map((category, index) => {
                const Icon = category.icon;
                const categoryStats = {
                  pass: category.checks.filter(c => c.status === 'pass').length,
                  warning: category.checks.filter(c => c.status === 'warning').length,
                  fail: category.checks.filter(c => c.status === 'fail').length
                };
                
                return (
                  <Card key={index}>
                    <CardHeader className="pb-3">
                      <CardTitle className="flex items-center gap-2 text-lg">
                        <Icon className="w-5 h-5" />
                        {category.category}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-green-600">{categoryStats.pass} passing</span>
                        {categoryStats.warning > 0 && (
                          <span className="text-yellow-600">{categoryStats.warning} warnings</span>
                        )}
                        {categoryStats.fail > 0 && (
                          <span className="text-red-600">{categoryStats.fail} failing</span>
                        )}
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-500 h-2 rounded-full"
                          style={{ width: `${(categoryStats.pass / category.checks.length) * 100}%` }}
                        />
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="detailed">
            <div className="space-y-6">
              {scanResults.map((category, categoryIndex) => {
                const Icon = category.icon;
                return (
                  <Card key={categoryIndex}>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Icon className="w-5 h-5" />
                        {category.category}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {category.checks.map((check, checkIndex) => (
                          <div key={checkIndex} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div className="flex items-center gap-3">
                              {getStatusIcon(check.status)}
                              <span className="font-medium">{check.name}</span>
                            </div>
                            {getStatusBadge(check.status)}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="guidelines">
            <Card>
              <CardHeader>
                <CardTitle>WCAG 2.1 AA Guidelines</CardTitle>
              </CardHeader>
              <CardContent className="prose max-w-none">
                <h3>Key Accessibility Principles</h3>
                <ul>
                  <li><strong>Perceivable:</strong> Information must be presentable in ways users can perceive</li>
                  <li><strong>Operable:</strong> Interface components must be operable by all users</li>
                  <li><strong>Understandable:</strong> Information and UI operation must be understandable</li>
                  <li><strong>Robust:</strong> Content must be robust enough for various assistive technologies</li>
                </ul>
                
                <h3>Common Issues to Address</h3>
                <ul>
                  <li>Ensure all images have descriptive alt text</li>
                  <li>Maintain sufficient color contrast (4.5:1 for normal text)</li>
                  <li>Provide keyboard navigation for all interactive elements</li>
                  <li>Use proper heading structure (h1, h2, h3, etc.)</li>
                  <li>Ensure form fields have associated labels</li>
                  <li>Provide clear error messages and instructions</li>
                </ul>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </RoleGuard>
  );
}

export default AccessibilityAuditPage;