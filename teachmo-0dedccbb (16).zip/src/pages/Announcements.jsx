
import React, { useState, useEffect } from 'react';
import { User, Announcement, Course, School, TeacherClassAssignment } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { Megaphone, Plus, Loader2, Send, AlertTriangle, Eye } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';
import { RoleGuard } from '@/components/shared/RoleGuard';

function AnnouncementsPage() {
  const [user, setUser] = useState(null);
  const [sentAnnouncements, setSentAnnouncements] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newAnnouncement, setNewAnnouncement] = useState({
    title: '',
    content: '',
    audience_type: '',
    audience_id: '',
    is_urgent: false,
  });
  const [audienceOptions, setAudienceOptions] = useState([]);
  const { toast } = useToast();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);

        // Fetch announcements sent by this user
        const announcements = await Announcement.filter({ sender_id: currentUser.id }, '-created_date');
        setSentAnnouncements(announcements);

        // Prepare audience options
        const options = [];
        if (currentUser.role === 'teacher') {
          const teacherClasses = await TeacherClassAssignment.filter({ teacher_user_id: currentUser.id, is_active: true });
          const coursePromises = teacherClasses.map(tc => Course.get(tc.course_id));
          const courses = await Promise.all(coursePromises);
          courses.forEach(course => {
            if(course) {
                options.push({
                    value: `class-${course.id}`,
                    label: `Class: ${course.name}`,
                    type: 'class',
                    id: course.id,
                });
            }
          });
        }
        
        if (['admin', 'district_admin', 'school_admin', 'system_admin'].includes(currentUser.role) && currentUser.school_id) {
          const school = await School.get(currentUser.school_id);
          if (school) {
              options.push({
                value: `school-${school.id}`,
                label: `Entire School: ${school.name}`,
                type: 'school',
                id: school.id,
              });
          }
        }
        
        setAudienceOptions(options);

        // Set default audience
        if (options.length > 0) {
            setNewAnnouncement(prev => ({
                ...prev,
                audience_type: options[0].type,
                audience_id: options[0].id
            }));
        }

      } catch (error) {
        console.error("Error loading announcement data:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load announcement data."
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [toast]);

  const handleCreateAnnouncement = async () => {
    if (!newAnnouncement.title || !newAnnouncement.content || !newAnnouncement.audience_id) {
      toast({
        variant: "destructive",
        title: "Missing Information",
        description: "Please fill in all required fields."
      });
      return;
    }
    
    setIsSubmitting(true);
    try {
      await Announcement.create({
        ...newAnnouncement,
        sender_id: user.id,
        school_id: user.school_id
      });
      
      toast({
        title: "Announcement Sent!",
        description: "Your announcement has been successfully delivered."
      });

      // Refresh list
      const announcements = await Announcement.filter({ sender_id: user.id }, '-created_date');
      setSentAnnouncements(announcements);
      
      setShowCreateDialog(false);
      setNewAnnouncement({ title: '', content: '', audience_type: audienceOptions[0]?.type, audience_id: audienceOptions[0]?.id, is_urgent: false });

    } catch (error) {
      console.error("Error creating announcement:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to send the announcement."
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAudienceChange = (value) => {
    const selectedOption = audienceOptions.find(opt => opt.value === value);
    if(selectedOption) {
        setNewAnnouncement(prev => ({
            ...prev,
            audience_type: selectedOption.type,
            audience_id: selectedOption.id
        }));
    }
  };


  if (isLoading) {
    return (
        <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
            <div className="max-w-4xl mx-auto">
                <div className="flex items-center justify-between mb-6">
                    <Skeleton className="h-8 w-64" />
                    <Skeleton className="h-10 w-32" />
                </div>
                <Card><CardContent className="p-6"><Skeleton className="h-48 w-full" /></CardContent></Card>
            </div>
        </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <Megaphone className="w-8 h-8" style={{color: 'var(--teachmo-sage)'}} />
              Announcements
            </h1>
            <p className="text-gray-600 mt-1">Send important updates to classes or the entire school.</p>
          </div>
          <Button onClick={() => setShowCreateDialog(true)} disabled={audienceOptions.length === 0}>
            <Plus className="w-4 h-4 mr-2" />
            Create Announcement
          </Button>
        </div>

        {audienceOptions.length === 0 && (
            <Card className="border-yellow-200 bg-yellow-50">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-yellow-800">
                        <AlertTriangle className="w-5 h-5"/>
                        No Audiences Found
                    </CardTitle>
                </CardHeader>
                <CardContent className="text-yellow-700">
                    <p>You do not seem to be assigned to any classes or schools that you can send announcements to. Please contact your administrator.</p>
                </CardContent>
            </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Sent Announcements</CardTitle>
            <CardDescription>A history of all the announcements you have sent.</CardDescription>
          </CardHeader>
          <CardContent>
            {sentAnnouncements.length === 0 ? (
              <div className="text-center py-12">
                <Megaphone className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg font-medium text-gray-900">No announcements sent yet</h3>
                <p className="text-gray-600 mt-1">Click "Create Announcement" to send your first update.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {sentAnnouncements.map(ann => (
                  <div key={ann.id} className="p-4 border rounded-lg hover:shadow-sm transition-shadow">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-3 mb-2">
                           <h4 className="font-semibold text-lg">{ann.title}</h4>
                           {ann.is_urgent && <Badge variant="destructive">Urgent</Badge>}
                        </div>
                        <p className="text-sm text-gray-600">{ann.content}</p>
                      </div>
                      <div className="text-right flex-shrink-0 ml-4">
                         <Badge variant="outline">{ann.audience_type}</Badge>
                         <p className="text-xs text-gray-500 mt-2">
                            {format(parseISO(ann.created_date), 'MMM d, yyyy h:mm a')}
                         </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-end text-sm text-gray-500 mt-3 border-t pt-2">
                        <Eye className="w-4 h-4 mr-2"/>
                        <span>Read by {ann.read_by?.length || 0} people</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create a New Announcement</DialogTitle>
              <DialogDescription>Compose your message and select the audience to send it to.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="audience">Audience</Label>
                <Select onValueChange={handleAudienceChange} defaultValue={audienceOptions[0]?.value}>
                  <SelectTrigger id="audience">
                    <SelectValue placeholder="Select an audience..." />
                  </SelectTrigger>
                  <SelectContent>
                    {audienceOptions.map(opt => (
                      <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={newAnnouncement.title}
                  onChange={(e) => setNewAnnouncement({...newAnnouncement, title: e.target.value})}
                  placeholder="e.g., School Picture Day Reminder"
                />
              </div>
              <div>
                <Label htmlFor="content">Content</Label>
                <Textarea
                  id="content"
                  value={newAnnouncement.content}
                  onChange={(e) => setNewAnnouncement({...newAnnouncement, content: e.target.value})}
                  placeholder="e.g., Don't forget, school pictures are this Friday..."
                  rows={6}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch 
                    id="is_urgent" 
                    checked={newAnnouncement.is_urgent}
                    onCheckedChange={(checked) => setNewAnnouncement({...newAnnouncement, is_urgent: checked})}
                />
                <Label htmlFor="is_urgent" className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-500"/>
                    Mark as Urgent
                </Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCreateDialog(false)}>Cancel</Button>
              <Button onClick={handleCreateAnnouncement} disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Send Announcement
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}

export default function ProtectedAnnouncements() {
  return (
    <RoleGuard allowedRoles={['teacher', 'school_admin', 'district_admin', 'system_admin', 'admin']}>
      <AnnouncementsPage />
    </RoleGuard>
  );
}
