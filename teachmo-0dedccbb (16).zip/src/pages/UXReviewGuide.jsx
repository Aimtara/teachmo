import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Lightbulb, CheckCircle, Search, Waves, MousePointerClick, MessageSquareWarning } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const GuidelineItem = ({ icon: Icon, title, description, tags }) => (
    <div className="flex items-start gap-4 p-4 border-b">
        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <Icon className="w-6 h-6 text-blue-600" />
        </div>
        <div>
            <h3 className="font-semibold text-lg text-gray-900">{title}</h3>
            <p className="text-gray-600 mt-1">{description}</p>
            {tags && (
                <div className="flex flex-wrap gap-2 mt-3">
                    {tags.map(tag => <Badge key={tag} variant="secondary">{tag}</Badge>)}
                </div>
            )}
        </div>
    </div>
);

export default function UXReviewGuide() {
    return (
        <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-8">
            <header className="text-center">
                <h1 className="text-4xl font-bold text-gray-900">Teachmo UX Review & Design Principles</h1>
                <p className="text-xl text-gray-600 mt-2">
                    A living document outlining our commitment to a world-class user experience.
                </p>
            </header>

            <Card>
                <CardHeader>
                    <CardTitle>Core Rule: The UX Review Mandate</CardTitle>
                    <CardDescription>
                        This is the foundational principle for all new development.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="p-4 bg-amber-50 border-l-4 border-amber-400">
                        <p className="font-semibold text-amber-900">
                            For every new feature or significant functionality change, a UX review must be conducted. The primary goals are to optimize the user journey, reduce cognitive and system load, and ensure alignment with our established design principles.
                        </p>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Ongoing Iterative Refinement Principles</CardTitle>
                    <CardDescription>
                        These are the tasks we continuously perform to maintain and improve UX quality across the application.
                    </CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                    <GuidelineItem
                        icon={Waves}
                        title="Micro-interactions & Delight"
                        description="Continuously seek opportunities to add subtle, meaningful animations and feedback that make the app feel responsive and enjoyable. This includes hover states, click feedback, and transitions."
                        tags={["Animation", "Feedback", "Polish"]}
                    />
                    <GuidelineItem
                        icon={MousePointerClick}
                        title="Modal Optimization"
                        description="Regularly review the use of modals. For complex tasks or forms, prioritize full-page layouts or multi-step components to avoid user context loss and 'modal fatigue'."
                        tags={["Flow", "Cognitive Load", "Interaction Design"]}
                    />
                    <GuidelineItem
                        icon={CheckCircle}
                        title="Toast & Feedback Clarity"
                        description="Audit all system messages, alerts, and toasts. Ensure they are concise, written in plain language, and provide actionable information when necessary. Avoid technical jargon."
                        tags={["Communication", "User Feedback", "Clarity"]}
                    />
                     <GuidelineItem
                        icon={Lightbulb}
                        title="Visual Consistency & Active States"
                        description="Maintain strict visual consistency in components, spacing, and typography. Ensure active navigation items, selected filters, and focus states are always unambiguously clear."
                        tags={["UI Design", "Consistency", "Navigation"]}
                    />
                     <GuidelineItem
                        icon={MessageSquareWarning}
                        title="Form Validation & Error Handling"
                        description="Review all forms to ensure they provide real-time, inline validation. Error messages must be clear, helpful, and guide the user toward a successful submission."
                        tags={["Forms", "Error Handling", "Usability"]}
                    />
                </CardContent>
            </Card>
        </div>
    );
}