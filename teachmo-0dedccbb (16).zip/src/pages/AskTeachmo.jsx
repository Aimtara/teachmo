
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import IntentRouter from '@/components/ai/IntentRouter'; // New import
import { invokeAdvancedAI } from '@/services/aiService'; // Assuming this is where invokeAdvancedAI comes from

export default function AskTeachmo() {
  const navigate = useNavigate();

  // State variables for the chat interface
  const [messages, setMessages] = useState([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [suggestedIntents, setSuggestedIntents] = useState([]);

  // Placeholder for user context data - replace with actual data fetching/context if needed
  const [children, setChildren] = useState([]); // Example: [{ id: 'child1', name: 'Alice' }]
  const [recentActivities, setRecentActivities] = useState([]); // Example: [{ id: 'act1', name: 'Math Homework' }]

  const handleSendMessage = async () => {
    if (!currentMessage.trim()) return;

    const userMessage = {
      id: Date.now(),
      text: currentMessage,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setCurrentMessage('');
    setIsTyping(true);

    try {
      // Call the advanced AI function with intent detection
      const response = await invokeAdvancedAI({
        message: userMessage.text, // Use the userMessage.text for the API call
        conversation_history: messages.slice(-5).map(msg => ({ // Last 5 messages for context
          role: msg.sender === 'user' ? 'user' : 'assistant',
          content: msg.text
        })),
        detect_intents: true, // Enable intent detection
        user_context: {
          children: children,
          recent_activities: recentActivities
        }
      });

      const aiMessage = {
        id: Date.now() + 1,
        text: response.data.response,
        sender: 'ai',
        timestamp: new Date(),
        intents: response.data.detected_intents || [],
        suggested_actions: response.data.suggested_actions || []
      };

      setMessages(prev => [...prev, aiMessage]);
      
      // Update suggested intents for quick navigation
      if (response.data.detected_intents && response.data.detected_intents.length > 0) {
        setSuggestedIntents(response.data.detected_intents);
      } else {
        setSuggestedIntents([]); // Clear if no intents detected for this response
      }

    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage = {
        id: Date.now() + 1,
        text: "I'm sorry, I'm having trouble responding right now. Please try again in a moment.",
        sender: 'ai',
        timestamp: new Date(),
        isError: true
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleIntentNavigation = (mapping) => {
    // Add a message to the conversation indicating the navigation
    const navigationMessage = {
      id: Date.now(),
      text: `Taking you to ${mapping.label} - ${mapping.description}`,
      sender: 'ai',
      timestamp: new Date(),
      isNavigation: true
    };
    
    setMessages(prev => [...prev, navigationMessage]);

    // Example of actual navigation. IntentRouter component should handle the specific URL logic.
    // This part assumes mapping contains enough info to navigate.
    // The previous 'handleIntent' logic for 'ask_community', 'find_activity' should ideally be
    // encapsulated within the IntentRouter component's internal logic, or passed to it via props.
    // For now, this callback simply adds a message to the chat.
    // If IntentRouter needs to call `navigate`, it should expose that capability or take `navigate` as a prop.
    // For a fully functional example, we might re-introduce a switch or map intents to URLs here:
    // if (mapping.intent === 'ask_community') {
    //   const content = encodeURIComponent(mapping.data.query);
    //   const url = createPageUrl(`UnifiedCommunity?initialContent=${content}&initialType=question`);
    //   navigate(url);
    // } else if (mapping.intent === 'find_activity') {
    //   navigate(createPageUrl('UnifiedDiscover'));
    // }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* Header Section */}
        <div className="flex items-center justify-between mb-6">
            <h1 className="text-3xl font-bold text-gray-800">Ask Teachmo</h1>
            {/* Additional header elements can go here */}
        </div>

        <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl border-0 overflow-hidden">
          <div className="h-96 overflow-y-auto p-6 space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                  message.sender === 'user' 
                    ? 'bg-blue-600 text-white' 
                    : message.isError 
                    ? 'bg-red-100 text-red-800'
                    : message.isNavigation
                    ? 'bg-green-100 text-green-800'
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  <p className="text-sm leading-relaxed">{message.text}</p>
                  
                  {/* Show intent router for AI messages with detected intents */}
                  {message.sender === 'ai' && message.intents && message.intents.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-gray-200">
                      <IntentRouter 
                        intents={message.intents}
                        onNavigate={handleIntentNavigation}
                        // Pass createPageUrl and navigate if IntentRouter needs to handle actual navigation
                        createPageUrl={createPageUrl}
                        navigate={navigate}
                      />
                    </div>
                  )}
                  
                  <div className="text-xs opacity-70 mt-2">
                    {message.timestamp.toLocaleTimeString()}
                  </div>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-gray-100 rounded-2xl px-4 py-3">
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Show persistent suggested intents */}
          {suggestedIntents.length > 0 && (
            <div className="px-6 py-4 border-t border-gray-200 bg-gray-50/50">
              <IntentRouter 
                intents={suggestedIntents}
                onNavigate={handleIntentNavigation}
                // Pass createPageUrl and navigate if IntentRouter needs to handle actual navigation
                createPageUrl={createPageUrl}
                navigate={navigate}
              />
            </div>
          )}

          {/* Input Area */}
          <div className="p-6 bg-gray-50/50 border-t border-gray-200">
            <div className="flex space-x-3">
                <input
                    type="text"
                    className="flex-grow p-3 rounded-full border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition duration-150 ease-in-out"
                    placeholder="Type your message..."
                    value={currentMessage}
                    onChange={(e) => setCurrentMessage(e.target.value)}
                    onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                            handleSendMessage();
                        }
                    }}
                    disabled={isTyping}
                />
                <button
                    onClick={handleSendMessage}
                    className="bg-blue-600 text-white rounded-full p-3 flex items-center justify-center hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition duration-150 ease-in-out disabled:opacity-50"
                    disabled={isTyping || !currentMessage.trim()}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                    </svg>
                </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
