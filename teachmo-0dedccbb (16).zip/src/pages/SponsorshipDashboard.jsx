import React, { useState, useEffect } from 'react';
import { SponsorshipPartner, ReferralCode } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Plus, 
  Building, 
  Users, 
  TrendingUp, 
  DollarSign, 
  Calendar,
  Search,
  MoreVertical,
  Edit,
  Archive,
  Eye,
  Copy,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import RoleGuard from '@/components/shared/RoleGuard';
import CreateSponsorshipPartnerModal from '@/components/admin/CreateSponsorshipPartnerModal';
import GenerateReferralCodeModal from '@/components/admin/GenerateReferralCodeModal';

function SponsorshipDashboardContent() {
  const [partners, setPartners] = useState([]);
  const [referralCodes, setReferralCodes] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showCreatePartner, setShowCreatePartner] = useState(false);
  const [showGenerateCode, setShowGenerateCode] = useState(false);
  const [selectedPartner, setSelectedPartner] = useState(null);
  const [stats, setStats] = useState({
    totalPartners: 0,
    activeLicenses: 0,
    redeemedCodes: 0,
    totalRevenue: 0
  });
  
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setIsLoading(true);
      const [partnersData, codesData] = await Promise.all([
        SponsorshipPartner.list('-created_date'),
        ReferralCode.list('-created_date')
      ]);
      
      setPartners(partnersData);
      setReferralCodes(codesData);
      
      // Calculate stats
      const activePartners = partnersData.filter(p => p.is_active);
      const totalLicenses = partnersData.reduce((sum, p) => sum + (p.licenses_allocated || 0), 0);
      const totalRedeemed = codesData.reduce((sum, c) => sum + (c.redeemed_count || 0), 0);
      
      setStats({
        totalPartners: activePartners.length,
        activeLicenses: totalLicenses,
        redeemedCodes: totalRedeemed,
        totalRevenue: totalLicenses * 10 // Assuming $10 per license
      });
    } catch (error) {
      console.error('Error loading sponsorship data:', error);
      toast({
        variant: "destructive",
        title: "Loading Error",
        description: "Failed to load sponsorship data. Please try again."
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreatePartner = async (partnerData) => {
    try {
      await SponsorshipPartner.create(partnerData);
      setShowCreatePartner(false);
      loadData();
      toast({
        title: "Partner Created",
        description: "Sponsorship partner has been created successfully."
      });
    } catch (error) {
      console.error('Error creating partner:', error);
      toast({
        variant: "destructive",
        title: "Creation Failed",
        description: "Failed to create sponsorship partner."
      });
    }
  };

  const handleGenerateCode = async (codeData) => {
    try {
      await ReferralCode.create(codeData);
      setShowGenerateCode(false);
      setSelectedPartner(null);
      loadData();
      toast({
        title: "Code Generated",
        description: "Referral code has been generated successfully."
      });
    } catch (error) {
      console.error('Error generating code:', error);
      toast({
        variant: "destructive",
        title: "Generation Failed",
        description: "Failed to generate referral code."
      });
    }
  };

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: "Referral code copied to clipboard."
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Copy Failed",
        description: "Failed to copy to clipboard."
      });
    }
  };

  const togglePartnerStatus = async (partner) => {
    try {
      await SponsorshipPartner.update(partner.id, { is_active: !partner.is_active });
      loadData();
      toast({
        title: partner.is_active ? "Partner Deactivated" : "Partner Activated",
        description: `${partner.name} has been ${partner.is_active ? 'deactivated' : 'activated'}.`
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Update Failed",
        description: "Failed to update partner status."
      });
    }
  };

  const filteredPartners = partners.filter(partner =>
    partner.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    partner.contact_email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="h-24 bg-gray-200 rounded"></div>
            ))}
          </div>
          <div className="h-96 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Sponsorship Management</h1>
          <p className="text-gray-600">Manage corporate partnerships and referral programs</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setShowCreatePartner(true)} className="gap-2">
            <Plus className="w-4 h-4" />
            New Partner
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Partners</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalPartners}</p>
              </div>
              <Building className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Licenses</p>
                <p className="text-2xl font-bold text-gray-900">{stats.activeLicenses}</p>
              </div>
              <Users className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Codes Redeemed</p>
                <p className="text-2xl font-bold text-gray-900">{stats.redeemedCodes}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Revenue</p>
                <p className="text-2xl font-bold text-gray-900">${stats.totalRevenue.toLocaleString()}</p>
              </div>
              <DollarSign className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="partners" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="partners">Partners</TabsTrigger>
          <TabsTrigger value="codes">Referral Codes</TabsTrigger>
        </TabsList>

        <TabsContent value="partners" className="space-y-4">
          {/* Search */}
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search partners..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Partners List */}
          <Card>
            <CardContent className="p-0">
              {filteredPartners.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  {searchTerm ? 'No partners match your search' : 'No partners found'}
                </div>
              ) : (
                <div className="divide-y">
                  {filteredPartners.map((partner) => (
                    <div key={partner.id} className="p-6 hover:bg-gray-50 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-lg font-semibold text-gray-900">{partner.name}</h3>
                            <Badge variant={partner.is_active ? 'default' : 'secondary'}>
                              {partner.is_active ? 'Active' : 'Inactive'}
                            </Badge>
                            <Badge variant="outline" className="capitalize">
                              {partner.benefit_type.replace('_', ' ')}
                            </Badge>
                          </div>
                          <div className="text-sm text-gray-600 space-y-1">
                            <p><strong>Contact:</strong> {partner.contact_name} ({partner.contact_email})</p>
                            <p><strong>Licenses:</strong> {partner.licenses_redeemed || 0} / {partner.licenses_allocated || 0} used</p>
                            {partner.benefit_value && (
                              <p><strong>Discount:</strong> {partner.benefit_value}%</p>
                            )}
                            <p><strong>Period:</strong> {new Date(partner.start_date).toLocaleDateString()} - {new Date(partner.end_date).toLocaleDateString()}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSelectedPartner(partner);
                              setShowGenerateCode(true);
                            }}
                          >
                            Generate Code
                          </Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreVertical className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent>
                              <DropdownMenuItem>
                                <Edit className="w-4 h-4 mr-2" />
                                Edit Partner
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => togglePartnerStatus(partner)}>
                                {partner.is_active ? (
                                  <>
                                    <Archive className="w-4 h-4 mr-2" />
                                    Deactivate
                                  </>
                                ) : (
                                  <>
                                    <CheckCircle className="w-4 h-4 mr-2" />
                                    Activate
                                  </>
                                )}
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="codes" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Referral Codes</CardTitle>
            </CardHeader>
            <CardContent>
              {referralCodes.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No referral codes generated yet
                </div>
              ) : (
                <div className="space-y-4">
                  {referralCodes.map((code) => {
                    const partner = partners.find(p => p.id === code.partner_id);
                    const isExpired = code.expiration_date && new Date(code.expiration_date) < new Date();
                    const isLimitReached = code.redemption_limit && code.redeemed_count >= code.redemption_limit;
                    
                    return (
                      <div key={code.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <code className="font-mono text-lg font-semibold bg-white px-3 py-1 rounded border">
                              {code.code_string}
                            </code>
                            <Badge variant={code.is_active && !isExpired && !isLimitReached ? 'default' : 'secondary'}>
                              {!code.is_active ? 'Inactive' : isExpired ? 'Expired' : isLimitReached ? 'Limit Reached' : 'Active'}
                            </Badge>
                          </div>
                          <div className="text-sm text-gray-600">
                            <p><strong>Partner:</strong> {partner?.name || 'Unknown'}</p>
                            <p><strong>Usage:</strong> {code.redeemed_count || 0} {code.redemption_limit ? `/ ${code.redemption_limit}` : ''} redemptions</p>
                            {code.expiration_date && (
                              <p><strong>Expires:</strong> {new Date(code.expiration_date).toLocaleDateString()}</p>
                            )}
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => copyToClipboard(code.code_string)}
                          className="gap-2"
                        >
                          <Copy className="w-4 h-4" />
                          Copy
                        </Button>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Modals */}
      {showCreatePartner && (
        <CreateSponsorshipPartnerModal
          onSave={handleCreatePartner}
          onCancel={() => setShowCreatePartner(false)}
        />
      )}

      {showGenerateCode && selectedPartner && (
        <GenerateReferralCodeModal
          partner={selectedPartner}
          onSave={handleGenerateCode}
          onCancel={() => {
            setShowGenerateCode(false);
            setSelectedPartner(null);
          }}
        />
      )}
    </div>
  );
}

export default function SponsorshipDashboard() {
  return (
    <RoleGuard allowedRoles={['system_admin', 'admin']}>
      <SponsorshipDashboardContent />
    </RoleGuard>
  );
}