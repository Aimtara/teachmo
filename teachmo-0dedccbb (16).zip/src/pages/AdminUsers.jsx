
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Users,
  Search,
  Filter,
  Plus,
  Mail,
  Edit,
  Loader2,
  Trash2
} from 'lucide-react';
import { User } from '@/api/entities';
import { bulkUserManagement } from '@/api/functions';
import { useToast } from '@/components/ui/use-toast';
import { format } from 'date-fns';
import { useDebounce } from '@/components/shared/useDebounce';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

import { ImportLog } from '@/api/entities';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import UserActionsDropdown from '@/components/admin/UserActionsDropdown';
import AdminRoleGuard from '@/components/shared/AdminRoleGuard';
import BulkUserImport from '@/components/admin/BulkUserImport';
import { Skeleton } from '@/components/ui/skeleton';

export default function AdminUsersPage() {
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState(''); // Renamed from searchQuery
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [importLogs, setImportLogs] = useState([]); // New state
  const { toast } = useToast();
  const navigate = useNavigate();

  const debouncedSearch = useDebounce(searchTerm, 300);

  const loadData = useCallback(async () => {
    try {
      setIsLoading(true);
      const [usersData, logsData] = await Promise.all([
        User.list('-created_date', 50), // Changed limit to 50
        ImportLog.list('-created_date', 20) // New: fetch import logs
      ]);
      setUsers(usersData);
      setImportLogs(logsData); // Set import logs
    } catch (error) {
      console.error('Error loading data:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not load data. Please try again."
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    let filtered = users;

    if (roleFilter !== 'all') {
      filtered = filtered.filter(user => user.role === roleFilter);
    }
    if (statusFilter !== 'all') {
      filtered = filtered.filter(user => user.status === statusFilter);
    }
    if (debouncedSearch.trim()) {
      const query = debouncedSearch.toLowerCase();
      filtered = filtered.filter(user =>
        user.full_name?.toLowerCase().includes(query) ||
        user.email?.toLowerCase().includes(query)
      );
    }

    setFilteredUsers(filtered);
  }, [users, debouncedSearch, roleFilter, statusFilter]);

  const handleImportComplete = async () => {
    // Refresh users and logs
    try {
      await loadData(); // Re-fetch all data after import
      toast({
        title: "Import Finished",
        description: "User and log lists have been refreshed."
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Failed to refresh data",
        description: error.message,
      });
    }
  };

  const getRoleBadge = (role) => {
    const roles = {
      parent: 'bg-blue-100 text-blue-800',
      teacher: 'bg-green-100 text-green-800',
      school_admin: 'bg-purple-100 text-purple-800',
      district_admin: 'bg-yellow-100 text-yellow-800',
      system_admin: 'bg-red-100 text-red-800',
      admin: 'bg-red-100 text-red-800'
    };
    return <Badge className={roles[role] || 'bg-gray-100 text-gray-800'}>{role?.replace('_', ' ')}</Badge>;
  };

  const getStatusBadge = (status) => {
    const statuses = {
      active: 'bg-green-100 text-green-800',
      invited: 'bg-yellow-100 text-yellow-800',
      deactivated: 'bg-gray-200 text-gray-600'
    };
    return <Badge className={statuses[status] || 'bg-gray-100 text-gray-800'}>{status}</Badge>;
  };

  if (isLoading) {
    return (
      <AdminRoleGuard allowedRoles={['system_admin', 'admin', 'district_admin']}>
        <div className="p-6 max-w-7xl mx-auto space-y-6">
          <Skeleton className="h-96 w-full" />
        </div>
      </AdminRoleGuard>
    );
  }

  return (
    <AdminRoleGuard allowedRoles={['system_admin', 'admin', 'district_admin']}>
      <div className="max-w-7xl mx-auto p-4 md:p-6 space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <Users className="w-8 h-8 text-blue-600" />
              User Management
            </h1>
            <p className="text-gray-600 mt-1">
              Invite, view, and manage all users in the system.
            </p>
          </div>
          {/* InviteUserModal removed, functionality likely replaced by Bulk Import */}
        </div>

        <Tabs defaultValue="users">
          <TabsList>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="import">Bulk Import</TabsTrigger>
            <TabsTrigger value="logs">Import Logs</TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Users ({filteredUsers.length})</CardTitle>
                <CardDescription>
                  A list of all users in the system. You can search and manage users here.
                </CardDescription>
                <div className="pt-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Search by name or email..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 max-w-sm"
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 mb-4">
                  <Filter className="w-4 h-4 text-gray-500" />
                  <Select value={roleFilter} onValueChange={setRoleFilter}>
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder="Role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Roles</SelectItem>
                      <SelectItem value="parent">Parent</SelectItem>
                      <SelectItem value="teacher">Teacher</SelectItem>
                      <SelectItem value="school_admin">School Admin</SelectItem>
                      <SelectItem value="district_admin">District Admin</SelectItem>
                      <SelectItem value="system_admin">System Admin</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="invited">Invited</SelectItem>
                      <SelectItem value="deactivated">Deactivated</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {filteredUsers.length === 0 ? (
                  <div className="text-center py-12">
                    <Users className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900">No users match your filters</h3>
                    <p className="text-gray-600">Try adjusting your search criteria.</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-b">
                          <TableHead className="text-left py-3 px-4 font-semibold">User</TableHead>
                          <TableHead className="text-left py-3 px-4 font-semibold">Role</TableHead>
                          <TableHead className="text-left py-3 px-4 font-semibold">Status</TableHead>
                          <TableHead className="text-left py-3 px-4 font-semibold">School / District</TableHead>
                          <TableHead className="text-left py-3 px-4 font-semibold">Joined</TableHead>
                          <TableHead className="text-left py-3 px-4 font-semibold">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredUsers.map((user) => (
                          <TableRow key={user.id} className="border-b hover:bg-gray-50">
                            <TableCell className="py-4 px-4">
                              <div className="flex items-center gap-3">
                                {user.avatar_url ? (
                                  <img src={user.avatar_url} alt={user.full_name} className="w-10 h-10 rounded-full" />
                                ) : (
                                  <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center font-bold text-gray-600">
                                    {user.full_name?.[0] || user.email?.[0]}
                                  </div>
                                )}
                                <div>
                                  <div className="font-medium text-gray-900">{user.full_name || 'N/A'}</div>
                                  <div className="text-sm text-gray-600">{user.email}</div>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell className="py-4 px-4">{getRoleBadge(user.role)}</TableCell>
                            <TableCell className="py-4 px-4">{getStatusBadge(user.status)}</TableCell>
                            <TableCell className="py-4 px-4 text-sm text-gray-700">
                              {user.school_name || user.district_name || 'N/A'}
                            </TableCell>
                            <TableCell className="py-4 px-4 text-sm text-gray-700">
                              {format(new Date(user.created_date), 'MMM d, yyyy')}
                            </TableCell>
                            <TableCell className="py-4 px-4">
                              <UserActionsDropdown user={user} onUserUpdated={loadData} />
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="import" className="mt-4">
            <BulkUserImport onImportComplete={handleImportComplete} />
          </TabsContent>

          <TabsContent value="logs" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Bulk Import Logs</CardTitle>
                <CardDescription>History of recent bulk user imports.</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Total Rows</TableHead>
                      <TableHead>Successful</TableHead>
                      <TableHead>Failed</TableHead>
                      <TableHead>Imported By</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {importLogs.length > 0 ? importLogs.map(log => (
                      <TableRow key={log.id}>
                        <TableCell>{format(new Date(log.created_date), 'Pp')}</TableCell>
                        <TableCell>
                          <Badge variant={log.status === 'completed' ? 'default' : 'destructive'}>
                            {log.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{log.total_rows}</TableCell>
                        <TableCell>{log.successful_rows}</TableCell>
                        <TableCell>{log.failed_rows}</TableCell>
                        <TableCell>{log.importer_id}</TableCell>
                      </TableRow>
                    )) : (
                      <TableRow>
                        <TableCell colSpan="6" className="text-center py-4 text-gray-500">No import logs found.</TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AdminRoleGuard>
  );
}
