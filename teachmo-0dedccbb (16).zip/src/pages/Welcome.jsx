import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Loader2 } from 'lucide-react';

export default function Welcome() {
  const navigate = useNavigate();

  useEffect(() => {
    // This page now serves as a redirect to the new, unified onboarding flow.
    navigate(createPageUrl('Onboarding'), { replace: true });
  }, [navigate]);

  // Render a loader as a fallback during the redirect.
  return (
    <div className="flex justify-center items-center h-screen">
      <Loader2 className="w-8 h-8 animate-spin" />
    </div>
  );
}