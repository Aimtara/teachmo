import React, { useEffect, useState } from 'react';
import { shortsAdmin } from '@/api/functions';
import { Loader2, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import RoleGuard from '@/components/shared/RoleGuard';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

function ShortDetailContent() {
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Get ID from URL params
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get('id');

  useEffect(() => {
    if (id) {
      loadShortDetail();
    }
  }, [id]);

  const loadShortDetail = async () => {
    try {
      setIsLoading(true);
      const { data: shortData } = await shortsAdmin({ 
        endpoint: `detail/${id}`
      });
      setData(shortData);
    } catch (err) {
      console.error('Error loading short detail:', err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-center h-32">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="text-center text-red-600">
          Error loading short: {error}
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="p-6">
        <div className="text-center text-gray-500">Short not found</div>
      </div>
    );
  }

  const { short, scenes, metrics, feedback_samples } = data;

  const getStatusColor = (status) => {
    switch (status) {
      case 'published': return 'bg-green-100 text-green-800';
      case 'error': return 'bg-red-100 text-red-800';
      case 'rendering': return 'bg-blue-100 text-blue-800';
      case 'queued': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-4">
        <Link to={createPageUrl('ShortsOverview')}>
          <Button variant="outline" size="sm">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Overview
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Short Detail</h1>
          <p className="text-gray-600">Detailed view and metrics</p>
        </div>
      </div>

      {/* Short Info */}
      <Card className="shadow-sm">
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <div className="text-sm text-gray-500 font-mono mb-1">
                {short.id}
              </div>
              <h2 className="text-xl font-semibold text-gray-900 mb-2">
                {short.topic}
              </h2>
              <div className="flex items-center gap-3 text-sm text-gray-600">
                <Badge className={getStatusColor(short.status)}>
                  {short.status}
                </Badge>
                {short.duration_s && (
                  <span>{short.duration_s}s duration</span>
                )}
                <span>
                  Created {new Date(short.created_at).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>
          
          {short.pattern_tags && short.pattern_tags.length > 0 && (
            <div className="mt-4">
              <span className="text-sm text-gray-500">Patterns: </span>
              <span className="text-sm text-gray-700">
                {short.pattern_tags.join(', ')}
              </span>
            </div>
          )}

          {/* Media URLs */}
          <div className="mt-4 space-y-2 text-sm">
            {short.mp4_url && (
              <div>
                <span className="text-gray-500">MP4: </span>
                <a href={short.mp4_url} className="text-blue-600 hover:underline" target="_blank" rel="noopener noreferrer">
                  {short.mp4_url}
                </a>
              </div>
            )}
            {short.tts_url && (
              <div>
                <span className="text-gray-500">Audio: </span>
                <a href={short.tts_url} className="text-blue-600 hover:underline" target="_blank" rel="noopener noreferrer">
                  {short.tts_url}
                </a>
              </div>
            )}
            {short.captions_vtt_url && (
              <div>
                <span className="text-gray-500">Captions: </span>
                <a href={short.captions_vtt_url} className="text-blue-600 hover:underline" target="_blank" rel="noopener noreferrer">
                  {short.captions_vtt_url}
                </a>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Scenes */}
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg">Scenes</CardTitle>
          </CardHeader>
          <CardContent>
            {scenes && scenes.length > 0 ? (
              <ol className="space-y-3">
                {scenes.map((scene) => (
                  <li key={scene.ord} className="border-l-2 border-gray-200 pl-4">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-semibold text-gray-500">
                        {scene.ord}.
                      </span>
                      <Badge variant="outline" className="text-xs">
                        {scene.kind}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-700">{scene.text}</p>
                  </li>
                ))}
              </ol>
            ) : (
              <p className="text-sm text-gray-500">No scenes available</p>
            )}
          </CardContent>
        </Card>

        {/* Metrics */}
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg">Metrics (7d)</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              <li className="flex justify-between">
                <span className="text-sm text-gray-600">Helpful votes:</span>
                <span className="text-sm font-semibold">{metrics.helpful_count}</span>
              </li>
              <li className="flex justify-between">
                <span className="text-sm text-gray-600">Tried votes:</span>
                <span className="text-sm font-semibold">{metrics.tried_count}</span>
              </li>
              <li className="flex justify-between">
                <span className="text-sm text-gray-600">Completions:</span>
                <span className="text-sm font-semibold">{metrics.completes_7d}</span>
              </li>
              <li className="flex justify-between">
                <span className="text-sm text-gray-600">Avg Progress:</span>
                <span className="text-sm font-semibold">
                  {Math.round(metrics.avg_progress_7d || 0)}%
                </span>
              </li>
              <li className="flex justify-between">
                <span className="text-sm text-gray-600">Avg Dwell:</span>
                <span className="text-sm font-semibold">
                  {Math.round((metrics.dwell_ms_7d || 0) / 1000)}s
                </span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Feedback */}
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">Recent Feedback</CardTitle>
        </CardHeader>
        <CardContent>
          {feedback_samples && feedback_samples.length > 0 ? (
            <div className="space-y-3 max-h-72 overflow-y-auto">
              {feedback_samples.map((feedback, index) => (
                <div key={index} className="border-b border-gray-100 pb-3 last:border-b-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs text-gray-500">
                      {new Date(feedback.created_at).toLocaleString()}
                    </span>
                    {feedback.helpful !== null && (
                      <span className="text-sm">
                        {feedback.helpful ? '👍' : '👎'}
                      </span>
                    )}
                    {feedback.tried && (
                      <span className="text-sm">✅ Tried</span>
                    )}
                  </div>
                  {feedback.comment && (
                    <p className="text-sm text-gray-700">{feedback.comment}</p>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-500">No feedback available</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default function ShortDetail() {
  return (
    <RoleGuard allowedRoles={['admin', 'system_admin']}>
      <ShortDetailContent />
    </RoleGuard>
  );
}