import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, Star, Target, Users, Coins, TrendingUp, Award } from 'lucide-react';
import { motion } from 'framer-motion';

import PointsEconomyDashboard from '@/components/gamification/PointsEconomyDashboard';
import EnhancedAchievements from '@/components/gamification/EnhancedAchievements';
import ChallengeHub from '@/components/gamification/ChallengeHub';
import Leaderboards from '@/components/gamification/Leaderboards';
import { LoadingSpinner, EmptyState } from '@/components/shared/LoadingStates';

export default function GamificationHub() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    setIsLoading(true);
    try {
      const userData = await User.me();
      setUser(userData);
    } catch (err) {
      console.error('Failed to load user data:', err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePointsUpdate = (newPoints) => {
    setUser(prev => ({ ...prev, points: newPoints }));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="max-w-7xl mx-auto">
          <LoadingSpinner text="Loading your gamification data..." />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="max-w-7xl mx-auto">
          <EmptyState
            icon={Trophy}
            title="Unable to Load Gamification"
            description={error}
            action={
              <button onClick={loadUserData} className="text-blue-600 hover:underline">
                Try Again
              </button>
            }
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-2"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 flex items-center justify-center gap-3">
            <Trophy className="w-8 h-8 text-yellow-500" />
            Gamification Hub
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Track your progress, earn rewards, and celebrate your parenting achievements with our comprehensive gamification system.
          </p>
        </motion.div>

        {/* Quick Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-4"
        >
          <Card className="bg-gradient-to-br from-yellow-50 to-amber-50 border-yellow-200">
            <CardContent className="p-4 text-center">
              <Coins className="w-8 h-8 mx-auto mb-2 text-yellow-600" />
              <p className="text-2xl font-bold text-yellow-700">{user.points?.toLocaleString() || 0}</p>
              <p className="text-sm text-yellow-600">Total Points</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="p-4 text-center">
              <Trophy className="w-8 h-8 mx-auto mb-2 text-blue-600" />
              <p className="text-2xl font-bold text-blue-700">{user.activities_completed || 0}</p>
              <p className="text-sm text-blue-600">Activities Done</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-orange-50 to-red-50 border-orange-200">
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-8 h-8 mx-auto mb-2 text-orange-600" />
              <p className="text-2xl font-bold text-orange-700">{user.login_streak || 0}</p>
              <p className="text-sm text-orange-600">Day Streak</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-4 text-center">
              <Award className="w-8 h-8 mx-auto mb-2 text-green-600" />
              <p className="text-2xl font-bold text-green-700">
                {Math.round(((user.points || 0) / (user.point_goal || 1000)) * 100)}%
              </p>
              <p className="text-sm text-green-600">Goal Progress</p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Main Content Tabs */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Tabs defaultValue="points" className="w-full">
            <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4 mb-6">
              <TabsTrigger value="points" className="flex items-center gap-2">
                <Coins className="w-4 h-4" />
                Points & Rewards
              </TabsTrigger>
              <TabsTrigger value="achievements" className="flex items-center gap-2">
                <Trophy className="w-4 h-4" />
                Achievements
              </TabsTrigger>
              <TabsTrigger value="challenges" className="flex items-center gap-2">
                <Target className="w-4 h-4" />
                Challenges
              </TabsTrigger>
              <TabsTrigger value="leaderboards" className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                Leaderboards
              </TabsTrigger>
            </TabsList>

            <TabsContent value="points">
              <PointsEconomyDashboard 
                user={user} 
                onPointsUpdate={handlePointsUpdate}
              />
            </TabsContent>

            <TabsContent value="achievements">
              <EnhancedAchievements user={user} />
            </TabsContent>

            <TabsContent value="challenges">
              <ChallengeHub user={user} />
            </TabsContent>

            <TabsContent value="leaderboards">
              <Leaderboards currentUser={user} />
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}