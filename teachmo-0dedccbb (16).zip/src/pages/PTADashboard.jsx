
import React, { useState, useEffect } from 'react';
import { User, Poll, Task, Announcement, PTADocument } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Megaphone, ListChecks, BarChart2, Plus, Users, Clock, MoreVertical, Edit, CheckCircle, Eye, Archive } from 'lucide-react';
import RoleGuard from '@/components/shared/RoleGuard';
import { DashboardSkeleton } from '@/components/shared/ImprovedSkeletons';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from '@/components/ui/dropdown-menu';
import CreateTaskModal from '@/components/help-board/CreateTaskModal';
import CreatePollModal from '@/components/pta/CreatePollModal';

function PTADashboard() {
    const [user, setUser] = useState(null);
    const [stats, setStats] = useState({ polls: 0, tasks: 0, announcements: 0, pendingApprovals: 0, documents: 0 });
    const [polls, setPolls] = useState([]);
    const [tasks, setTasks] = useState([]);
    const [announcements, setAnnouncements] = useState([]);
    const [documents, setDocuments] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [showCreateTask, setShowCreateTask] = useState(false);
    const [showCreatePoll, setShowCreatePoll] = useState(false);
    const { toast } = useToast();

    const loadData = async () => {
        try {
            setIsLoading(true);
            const currentUser = await User.me();
            setUser(currentUser);

            if (!currentUser.school_id) {
                setIsLoading(false);
                return;
            }

            const [announcementsData, documentsData, tasksData, pollsData] = await Promise.all([
                Announcement.filter({ school_id: currentUser.school_id, audience_type: 'school' }),
                PTADocument.filter({ school_id: currentUser.school_id }),
                Task.filter({ school_id: currentUser.school_id, category: 'pta_general' }),
                Poll.filter({ school_id: currentUser.school_id })
            ]);
            
            setAnnouncements(announcementsData);
            setDocuments(documentsData);
            setTasks(tasksData);
            setPolls(pollsData);
            
            const pendingApprovals = tasksData.filter(t => t.status === 'pending_approval').length;
            setStats({ 
                polls: pollsData.length, 
                tasks: tasksData.length, 
                announcements: announcementsData.length,
                pendingApprovals,
                documents: documentsData.length
            });
        } catch (error) {
            console.error("Failed to load PTA dashboard data:", error);
            toast({ variant: 'destructive', title: 'Error', description: 'Could not load dashboard data.' });
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        loadData();
    }, [toast]);

    const handleCreateTask = async (taskData) => {
        try {
            await Task.create({
                ...taskData,
                creator_id: user?.id,
                school_id: user?.school_id,
                category: 'pta_general'
            });
            setShowCreateTask(false);
            loadData();
            toast({
                title: "Task Created",
                description: "PTA task has been created successfully."
            });
        } catch (error) {
            console.error('Error creating task:', error);
            toast({
                variant: "destructive",
                title: "Creation Failed",
                description: "Failed to create task."
            });
        }
    };

    const handleCreatePoll = async (pollData) => {
        try {
            await Poll.create({
                ...pollData,
                creator_id: user?.id,
                school_id: user?.school_id
            });
            setShowCreatePoll(false);
            loadData();
            toast({
                title: "Poll Created",
                description: "PTA poll has been created successfully."
            });
        } catch (error) {
            console.error('Error creating poll:', error);
            toast({
                variant: "destructive",
                title: "Creation Failed",
                description: "Failed to create poll."
            });
        }
    };

    if (isLoading) return <DashboardSkeleton />;

    return (
        <div className="p-4 md:p-6 space-y-6">
            <header>
                <h1 className="text-3xl font-bold text-gray-900">PTA Admin Dashboard</h1>
                <p className="text-gray-600">Manage your school's PTA activities and volunteer opportunities.</p>
            </header>

            <Tabs defaultValue="overview" className="w-full">
                <TabsList className="grid w-full grid-cols-5">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="tasks">Tasks</TabsTrigger>
                    <TabsTrigger value="polls">Polls</TabsTrigger>
                    <TabsTrigger value="announcements">Announcements</TabsTrigger>
                    <TabsTrigger value="documents">Documents</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="mt-6">
                    <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                            <Card>
                                <CardHeader className="pb-2">
                                    <CardTitle className="text-sm font-medium">Active Polls</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="text-2xl font-bold">{stats.polls}</div>
                                    <p className="text-xs text-muted-foreground">Community engagement</p>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader className="pb-2">
                                    <CardTitle className="text-sm font-medium">Volunteer Tasks</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="text-2xl font-bold">{tasks.filter(t => t.status === 'open').length}</div>
                                    <p className="text-xs text-muted-foreground">Open opportunities</p>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader className="pb-2">
                                    <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="text-2xl font-bold text-orange-600">{stats.pendingApprovals}</div>
                                    <p className="text-xs text-muted-foreground">Require attention</p>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader className="pb-2">
                                    <CardTitle className="text-sm font-medium">Announcements</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="text-2xl font-bold">{stats.announcements}</div>
                                    <p className="text-xs text-muted-foreground">Active announcements</p>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader className="pb-2">
                                    <CardTitle className="text-sm font-medium">Documents</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="text-2xl font-bold">{stats.documents}</div>
                                    <p className="text-xs text-muted-foreground">Available resources</p>
                                </CardContent>
                            </Card>
                        </div>

                        <Card>
                            <CardHeader>
                                <CardTitle>Quick Actions</CardTitle>
                            </CardHeader>
                            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                 <Button onClick={() => setShowCreatePoll(true)} size="lg" className="h-auto p-4 flex flex-col items-center gap-2">
                                     <BarChart2 className="h-8 w-8" />
                                     <div className="text-center">
                                         <div className="font-semibold">Create Poll</div>
                                         <div className="text-xs opacity-80">Get community input</div>
                                     </div>
                                 </Button>
                                 <Button onClick={() => setShowCreateTask(true)} size="lg" className="h-auto p-4 flex flex-col items-center gap-2">
                                     <ListChecks className="h-8 w-8" />
                                     <div className="text-center">
                                         <div className="font-semibold">Post Task</div>
                                         <div className="text-xs opacity-80">Request volunteers</div>
                                     </div>
                                 </Button>
                                 <Button disabled size="lg" className="h-auto p-4 flex flex-col items-center gap-2 opacity-50 cursor-not-allowed">
                                    <Megaphone className="h-8 w-8" />
                                    <div className="text-center">
                                        <div className="font-semibold">Announcement</div>
                                        <div className="text-xs opacity-80">Notify families (Coming Soon)</div>
                                    </div>
                                </Button>
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>

                <TabsContent value="tasks" className="space-y-4">
                    <div className="flex justify-between items-center">
                        <h3 className="text-lg font-semibold">PTA Tasks & Volunteering</h3>
                        <Button onClick={() => setShowCreateTask(true)} className="gap-2">
                            <Plus className="w-4 h-4" />
                            Create Task
                        </Button>
                    </div>
                    
                    <Card>
                        <CardContent className="p-0">
                            {tasks.length === 0 ? (
                                <div className="text-center py-8 text-gray-500">
                                    No PTA tasks created yet.
                                    <Button onClick={() => setShowCreateTask(true)} className="mt-4">
                                        <Plus className="w-4 h-4 mr-2" /> Create First Task
                                    </Button>
                                </div>
                            ) : (
                                <div className="divide-y">
                                    {tasks.map((task) => (
                                        <div key={task.id} className="p-6 hover:bg-gray-50 transition-colors">
                                            <div className="flex items-start justify-between">
                                                <div className="flex-1">
                                                    <div className="flex items-center gap-3 mb-2">
                                                        <h4 className="font-semibold text-gray-900">{task.title}</h4>
                                                        <Badge className={
                                                            task.status === 'open' ? 'bg-green-100 text-green-800' :
                                                            task.status === 'claimed' ? 'bg-blue-100 text-blue-800' :
                                                            task.status === 'completed' ? 'bg-gray-100 text-gray-800' :
                                                            'bg-yellow-100 text-yellow-800'
                                                        }>
                                                            {task.status.replace(/_/g, ' ')}
                                                        </Badge>
                                                        <Badge variant="outline" className="capitalize">
                                                            {task.category.replace(/_/g, ' ')}
                                                        </Badge>
                                                    </div>
                                                    <p className="text-sm text-gray-600 mb-2">{task.description}</p>
                                                    <div className="text-xs text-gray-500 space-y-1">
                                                        {task.due_date && (
                                                            <p><strong>Due:</strong> {new Date(task.due_date).toLocaleDateString()}</p>
                                                        )}
                                                        {task.location && (
                                                            <p><strong>Location:</strong> {task.location}</p>
                                                        )}
                                                        {task.time_required && (
                                                            <p><strong>Time Required:</strong> {task.time_required}</p>
                                                        )}
                                                        {task.skills_needed && task.skills_needed.length > 0 && (
                                                            <p><strong>Skills Needed:</strong> {task.skills_needed.join(', ')}</p>
                                                        )}
                                                        <p><strong>Volunteers:</strong> {task.current_volunteers || 0} / {task.max_volunteers || 1}</p>
                                                        <p><strong>Points:</strong> {task.points_reward || 5}</p>
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    {task.status === 'open' && (
                                                        <Button variant="outline" size="sm">
                                                            Claim Task
                                                        </Button>
                                                    )}
                                                    <DropdownMenu>
                                                        <DropdownMenuTrigger asChild>
                                                            <Button variant="ghost" size="sm">
                                                                <MoreVertical className="w-4 h-4" />
                                                            </Button>
                                                        </DropdownMenuTrigger>
                                                        <DropdownMenuContent>
                                                            <DropdownMenuItem>
                                                                <Edit className="w-4 h-4 mr-2" />
                                                                Edit Task
                                                            </DropdownMenuItem>
                                                            <DropdownMenuItem>
                                                                <Users className="w-4 h-4 mr-2" />
                                                                View Volunteers
                                                            </DropdownMenuItem>
                                                            <DropdownMenuItem>
                                                                <CheckCircle className="w-4 h-4 mr-2" />
                                                                Mark Complete
                                                            </DropdownMenuItem>
                                                        </DropdownMenuContent>
                                                    </DropdownMenu>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="polls" className="space-y-4">
                    <div className="flex justify-between items-center">
                        <h3 className="text-lg font-semibold">PTA Polls & Voting</h3>
                        <Button onClick={() => setShowCreatePoll(true)} className="gap-2">
                            <Plus className="w-4 h-4" />
                            Create Poll
                        </Button>
                    </div>
                    
                    <Card>
                        <CardContent className="p-0">
                            {polls.length === 0 ? (
                                <div className="text-center py-8 text-gray-500">
                                    No polls created yet.
                                    <Button onClick={() => setShowCreatePoll(true)} className="mt-4">
                                        <Plus className="w-4 h-4 mr-2" /> Create First Poll
                                    </Button>
                                </div>
                            ) : (
                                <div className="divide-y">
                                    {polls.map((poll) => (
                                        <div key={poll.id} className="p-6">
                                            <div className="flex items-start justify-between mb-4">
                                                <div className="flex-1">
                                                    <div className="flex items-center gap-3 mb-2">
                                                        <h4 className="font-semibold text-gray-900">{poll.question}</h4>
                                                        <Badge className={
                                                            poll.status === 'active' ? 'bg-green-100 text-green-800' :
                                                            poll.status === 'closed' ? 'bg-gray-100 text-gray-800' :
                                                            'bg-yellow-100 text-yellow-800'
                                                        }>
                                                            {poll.status}
                                                        </Badge>
                                                        {poll.is_anonymous && (
                                                            <Badge variant="outline">Anonymous</Badge>
                                                        )}
                                                        {poll.allow_multiple && (
                                                            <Badge variant="outline">Multiple Choice</Badge>
                                                        )}
                                                    </div>
                                                    <div className="text-xs text-gray-500 mb-4">
                                                        <p><strong>Total Votes:</strong> {poll.total_votes || 0}</p>
                                                        <p><strong>Closes:</strong> {new Date(poll.closes_at).toLocaleDateString()}</p>
                                                    </div>
                                                </div>
                                                <DropdownMenu>
                                                    <DropdownMenuTrigger asChild>
                                                        <Button variant="ghost" size="sm">
                                                            <MoreVertical className="w-4 h-4" />
                                                        </Button>
                                                    </DropdownMenuTrigger>
                                                    <DropdownMenuContent>
                                                        <DropdownMenuItem>
                                                            <Eye className="w-4 h-4 mr-2" />
                                                            View Results
                                                        </DropdownMenuItem>
                                                        <DropdownMenuItem>
                                                            <Edit className="w-4 h-4 mr-2" />
                                                            Edit Poll
                                                        </DropdownMenuItem>
                                                        <DropdownMenuItem>
                                                            <Archive className="w-4 h-4 mr-2" />
                                                            Close Poll
                                                        </DropdownMenuItem>
                                                    </DropdownMenuContent>
                                                </DropdownMenu>
                                            </div>
                                            
                                            {/* Poll Options */}
                                            <div className="space-y-2">
                                                {poll.options?.map((option, index) => {
                                                    const percentage = poll.total_votes > 0 ? (option.votes / poll.total_votes) * 100 : 0;
                                                    return (
                                                        <div key={option.id || index} className="bg-gray-50 rounded-lg p-3">
                                                            <div className="flex justify-between items-center mb-1">
                                                                <span className="text-sm font-medium">{option.text}</span>
                                                                <span className="text-xs text-gray-500">{option.votes || 0} votes</span>
                                                            </div>
                                                            <div className="w-full bg-gray-200 rounded-full h-2">
                                                                <div 
                                                                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                                                                    style={{ width: `${percentage}%` }}
                                                                ></div>
                                                            </div>
                                                            <span className="text-xs text-gray-500">{percentage.toFixed(1)}%</span>
                                                        </div>
                                                    );
                                                })}
                                            </div>

                                            {/* Vote Button */}
                                            {poll.status === 'active' && (
                                                <div className="mt-4">
                                                    <Button variant="outline" size="sm">
                                                        Vote on This Poll
                                                    </Button>
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="announcements" className="space-y-4">
                    <h3 className="text-lg font-semibold">School Announcements</h3>
                    {announcements.length === 0 ? (
                        <Card>
                            <CardContent className="p-8 text-center text-gray-500">
                                <Megaphone className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                                No school-wide announcements available.
                            </CardContent>
                        </Card>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {announcements.map((announcement) => (
                                <Card key={announcement.id}>
                                    <CardHeader>
                                        <CardTitle className="text-lg">{announcement.title}</CardTitle>
                                        <p className="text-sm text-gray-500">
                                            {new Date(announcement.created_at).toLocaleDateString()}
                                        </p>
                                    </CardHeader>
                                    <CardContent>
                                        <p className="text-sm text-gray-700 line-clamp-3">{announcement.content}</p>
                                        <Button variant="link" className="px-0 pt-2">Read More</Button>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    )}
                </TabsContent>

                <TabsContent value="documents" className="space-y-4">
                    <h3 className="text-lg font-semibold">PTA Documents & Resources</h3>
                    {documents.length === 0 ? (
                        <Card>
                            <CardContent className="p-8 text-center text-gray-500">
                                <Clock className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                                No PTA documents uploaded yet.
                            </CardContent>
                        </Card>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {documents.map((doc) => (
                                <Card key={doc.id}>
                                    <CardHeader>
                                        <CardTitle className="text-lg">{doc.title}</CardTitle>
                                        <p className="text-sm text-gray-500">
                                            {doc.type} - {new Date(doc.uploaded_at).toLocaleDateString()}
                                        </p>
                                    </CardHeader>
                                    <CardContent>
                                        <p className="text-sm text-gray-700 line-clamp-3 mb-2">{doc.description}</p>
                                        {doc.file_url && (
                                            <Button variant="outline" size="sm" asChild>
                                                <a href={doc.file_url} target="_blank" rel="noopener noreferrer">View Document</a>
                                            </Button>
                                        )}
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    )}
                </TabsContent>

            </Tabs>

            {showCreateTask && (
                <CreateTaskModal
                    onSave={handleCreateTask}
                    onCancel={() => setShowCreateTask(false)}
                    defaultCategory="pta_general"
                />
            )}

            {showCreatePoll && (
                <CreatePollModal
                    onSave={handleCreatePoll}
                    onCancel={() => setShowCreatePoll(false)}
                />
            )}
        </div>
    );
}

export default function ProtectedPTADashboard() {
    return (
        <RoleGuard allowedRoles={['parent']} ptaBoardOnly={true}>
            <PTADashboard />
        </RoleGuard>
    );
}
