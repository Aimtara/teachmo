
import React, { useState, useEffect } from 'react';
import { ModerationReport, ModerationAction, CommunityGuideline } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { 
  Shield, 
  AlertTriangle, 
  Eye, 
  CheckCircle, 
  XCircle, 
  Clock, 
  TrendingUp,
  Users,
  MessageSquare,
  Flag,
  MoreVertical,
  Archive,
  Ban,
  AlertCircle
} from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import RoleGuard from '@/components/shared/RoleGuard';
import { takeModerationAction } from '@/api/functions';

function ModerationDashboardContent() {
  const [reports, setReports] = useState([]);
  const [actions, setActions] = useState([]);
  const [guidelines, setGuidelines] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState(null);
  const [reviewModal, setReviewModal] = useState(false);
  const [moderatorNotes, setModeratorNotes] = useState('');
  const [selectedAction, setSelectedAction] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterPriority, setFilterPriority] = useState('all');
  const [stats, setStats] = useState({
    pendingReports: 0,
    resolvedToday: 0,
    activeActions: 0,
    avgResponseTime: 0
  });

  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setIsLoading(true);
      const [reportsData, actionsData, guidelinesData] = await Promise.all([
        ModerationReport.list('-created_date'),
        ModerationAction.list('-created_date'),
        CommunityGuideline.list('order')
      ]);
      
      setReports(reportsData);
      setActions(actionsData);
      setGuidelines(guidelinesData);
      
      // Calculate stats
      const pending = reportsData.filter(r => r.status === 'pending').length;
      const resolvedToday = reportsData.filter(r => 
        r.status === 'resolved' && 
        new Date(r.resolved_at).toDateString() === new Date().toDateString()
      ).length;
      const activeActions = actionsData.filter(a => a.is_active).length;
      
      setStats({
        pendingReports: pending,
        resolvedToday,
        activeActions,
        avgResponseTime: 2.4 // Mock average response time in hours
      });
    } catch (error) {
      console.error('Error loading moderation data:', error);
      toast({
        variant: "destructive",
        title: "Loading Error",
        description: "Failed to load moderation data."
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleReviewReport = (report) => {
    setSelectedReport(report);
    setModeratorNotes('');
    setSelectedAction('');
    setReviewModal(true);
  };

  const handleResolveReport = async () => {
    if (!selectedReport || !selectedAction) {
      toast({
        variant: "destructive",
        title: "Missing Information",
        description: "Please select an action to take."
      });
      return;
    }

    try {
      // NEW: Call the backend function to perform the action
      await takeModerationAction({
        reportId: selectedReport.id,
        action: selectedAction,
        notes: moderatorNotes
      });

      setReviewModal(false);
      setSelectedReport(null);
      loadData(); // This reloads all data on the dashboard
      
      toast({
        title: "Report Resolved",
        description: `The action '${selectedAction}' has been processed successfully.`
      });
    } catch (error) {
      console.error('Error resolving report:', error);
      toast({
        variant: "destructive",
        title: "Resolution Failed",
        description: "Failed to resolve the report."
      });
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'under_review': return 'bg-blue-100 text-blue-800';
      case 'resolved': return 'bg-green-100 text-green-800';
      case 'dismissed': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredReports = reports.filter(report => {
    const statusMatch = filterStatus === 'all' || report.status === filterStatus;
    const priorityMatch = filterPriority === 'all' || report.priority === filterPriority;
    return statusMatch && priorityMatch;
  });

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="h-24 bg-gray-200 rounded"></div>
            ))}          </div>
          <div className="h-96 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Content Moderation</h1>
          <p className="text-gray-600">Monitor and manage community content and user reports</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pending Reports</p>
                <p className="text-2xl font-bold text-gray-900">{stats.pendingReports}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Resolved Today</p>
                <p className="text-2xl font-bold text-gray-900">{stats.resolvedToday}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Actions</p>
                <p className="text-2xl font-bold text-gray-900">{stats.activeActions}</p>
              </div>
              <Shield className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg Response</p>
                <p className="text-2xl font-bold text-gray-900">{stats.avgResponseTime}h</p>
              </div>
              <Clock className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="reports" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="reports">Reports</TabsTrigger>
          <TabsTrigger value="actions">Actions</TabsTrigger>
          <TabsTrigger value="guidelines">Guidelines</TabsTrigger>
        </TabsList>

        <TabsContent value="reports" className="space-y-4">
          {/* Filters */}
          <div className="flex gap-4">
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="under_review">Under Review</SelectItem>
                <SelectItem value="resolved">Resolved</SelectItem>
                <SelectItem value="dismissed">Dismissed</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterPriority} onValueChange={setFilterPriority}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priority</SelectItem>
                <SelectItem value="urgent">Urgent</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Reports List */}
          <Card>
            <CardContent className="p-0">
              {filteredReports.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No reports match your filters
                </div>
              ) : (
                <div className="divide-y">
                  {filteredReports.map((report) => (
                    <div key={report.id} className="p-6 hover:bg-gray-50 transition-colors">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <Badge className={getPriorityColor(report.priority)}>
                              {report.priority}
                            </Badge>
                            <Badge className={getStatusColor(report.status)}>
                              {report.status.replace('_', ' ')}
                            </Badge>
                            <Badge variant="outline">
                              {report.content_type}
                            </Badge>
                          </div>
                          <h3 className="font-semibold text-gray-900 mb-1">
                            {report.report_reason.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                          </h3>
                          <p className="text-sm text-gray-600 mb-2">
                            {report.description || 'No additional details provided'}
                          </p>
                          <div className="text-xs text-gray-500">
                            Reported {new Date(report.created_date).toLocaleDateString()} at{' '}
                            {new Date(report.created_date).toLocaleTimeString()}
                            {report.auto_flagged && (
                              <span className="ml-2 text-blue-600">• Auto-flagged by AI</span>
                            )}
                            {report.toxicity_score && (
                              <span className="ml-2 text-red-600">
                                • Toxicity: {Math.round(report.toxicity_score * 100)}%
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleReviewReport(report)}
                            disabled={report.status === 'resolved'}
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            Review
                          </Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreVertical className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent>
                              <DropdownMenuItem>
                                <Flag className="w-4 h-4 mr-2" />
                                View Content
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Users className="w-4 h-4 mr-2" />
                                View User Profile
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Archive className="w-4 h-4 mr-2" />
                                Archive Report
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="actions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Moderation Actions</CardTitle>
            </CardHeader>
            <CardContent>
              {actions.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No moderation actions taken yet
                </div>
              ) : (
                <div className="space-y-4">
                  {actions.slice(0, 10).map((action) => (
                    <div key={action.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline">
                            {action.action_type.replace('_', ' ')}
                          </Badge>
                          <Badge variant="secondary">
                            {action.target_type}
                          </Badge>
                          {action.is_active && (
                            <Badge className="bg-green-100 text-green-800">Active</Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-600">{action.reason}</p>
                        <p className="text-xs text-gray-500">
                          {new Date(action.created_date).toLocaleDateString()}
                          {action.expires_at && (
                            <span> • Expires {new Date(action.expires_at).toLocaleDateString()}</span>
                          )}
                        </p>
                      </div>
                      {action.appeal_status !== 'none' && (
                        <Badge className={
                          action.appeal_status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                          action.appeal_status === 'approved' ? 'bg-green-100 text-green-800' :
                          'bg-red-100 text-red-800'
                        }>
                          Appeal {action.appeal_status}
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="guidelines" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Community Guidelines</CardTitle>
            </CardHeader>
            <CardContent>
              {guidelines.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No community guidelines configured
                </div>
              ) : (
                <div className="space-y-6">
                  {guidelines.map((guideline) => (
                    <div key={guideline.id} className="border-b pb-4 last:border-b-0">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-lg font-semibold text-gray-900">{guideline.title}</h3>
                        <Badge variant="outline" className="capitalize">
                          {guideline.category}
                        </Badge>
                      </div>
                      <div className="text-gray-700 prose prose-sm max-w-none">
                        {guideline.content}
                      </div>
                      <p className="text-xs text-gray-500 mt-2">
                        Last updated: {new Date(guideline.last_updated).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Review Modal */}
      <Dialog open={reviewModal} onOpenChange={setReviewModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Review Report</DialogTitle>
          </DialogHeader>
          {selectedReport && (
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Badge className={getPriorityColor(selectedReport.priority)}>
                    {selectedReport.priority}
                  </Badge>
                  <Badge variant="outline">
                    {selectedReport.content_type}
                  </Badge>
                </div>
                <h3 className="font-semibold mb-2">
                  {selectedReport.report_reason.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </h3>
                <p className="text-sm text-gray-600">
                  {selectedReport.description || 'No additional details provided'}
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Action to Take
                </label>
                <Select value={selectedAction} onValueChange={setSelectedAction}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select an action" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No Action Required / Dismiss</SelectItem>
                    <SelectItem value="content_removed">Remove Content</SelectItem>
                    <SelectItem value="user_suspended">Suspend User (Lock Account)</SelectItem>
                    <SelectItem value="user_banned">Ban User (Disable Account)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Moderator Notes
                </label>
                <Textarea
                  value={moderatorNotes}
                  onChange={(e) => setModeratorNotes(e.target.value)}
                  placeholder="Add notes about your decision..."
                  rows={3}
                />
              </div>

              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setReviewModal(false)}>
                  Cancel
                </Button>
                <Button onClick={handleResolveReport} disabled={!selectedAction}>
                  Resolve Report
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function ModerationDashboard() {
  return (
    <RoleGuard allowedRoles={['system_admin', 'admin']}>
      <ModerationDashboardContent />
    </RoleGuard>
  );
}
