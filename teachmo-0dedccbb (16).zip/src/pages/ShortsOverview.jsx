import React, { useEffect, useState } from 'react';
import ShortsKpiCard from '@/components/shorts/ShortsKpiCard';
import { shortsAdmin } from '@/api/functions';
import { Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import RoleGuard from '@/components/shared/RoleGuard';

function ShortsOverviewContent() {
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadOverviewData();
  }, []);

  const loadOverviewData = async () => {
    try {
      setIsLoading(true);
      const { data: overviewData } = await shortsAdmin({ endpoint: 'overview' });
      setData(overviewData);
    } catch (err) {
      console.error('Error loading shorts overview:', err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-center h-32">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="text-center text-red-600">
          Error loading overview: {error}
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="p-6">
        <div className="text-center text-gray-500">No data available</div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Shorts Overview</h1>
          <p className="text-gray-600">Monitor Teachmo Shorts performance and content health</p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <ShortsKpiCard 
          label="Published Today" 
          value={String(data.today_published)} 
        />
        <ShortsKpiCard 
          label="Queue Backlog" 
          value={String(data.queue_backlog)} 
        />
        <ShortsKpiCard 
          label="Error Rate" 
          value={(data.render_error_rate * 100).toFixed(1) + "%"} 
        />
        <ShortsKpiCard 
          label="Render P95" 
          value={String(Math.round(data.render_p95_ms / 1000)) + 's'} 
        />
      </div>

      {/* Topic Performance */}
      <section className="grid md:grid-cols-2 gap-6">
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg">Top Topics (7d)</CardTitle>
          </CardHeader>
          <CardContent>
            {data.top_topics && data.top_topics.length > 0 ? (
              <ul className="space-y-2">
                {data.top_topics.map((topic, index) => (
                  <li key={index} className="flex justify-between items-center">
                    <span className="text-sm text-gray-700">{topic.topic}</span>
                    <span className="text-sm font-semibold text-green-600">
                      {Math.round(topic.helpful_rate * 100)}% helpful
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-gray-500">No data available</p>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg">Low Topics (7d)</CardTitle>
          </CardHeader>
          <CardContent>
            {data.low_topics && data.low_topics.length > 0 ? (
              <ul className="space-y-2">
                {data.low_topics.map((topic, index) => (
                  <li key={index} className="flex justify-between items-center">
                    <span className="text-sm text-gray-700">{topic.topic}</span>
                    <span className="text-sm font-semibold text-orange-600">
                      {Math.round(topic.helpful_rate * 100)}% helpful
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-gray-500">No data available</p>
            )}
          </CardContent>
        </Card>
      </section>
    </div>
  );
}

export default function ShortsOverview() {
  return (
    <RoleGuard allowedRoles={['admin', 'system_admin']}>
      <ShortsOverviewContent />
    </RoleGuard>
  );
}