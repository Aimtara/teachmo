import React, { useState, useEffect } from 'react';
import { LicenseAllocation, UserLicense, User, School, District } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Plus, Calendar, DollarSign, AlertTriangle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { format, isAfter } from 'date-fns';
import RoleGuard from '../components/shared/RoleGuard';

export default function LicenseManagement() {
  const [allocations, setAllocations] = useState([]);
  const [userLicenses, setUserLicenses] = useState([]);
  const [organizations, setOrganizations] = useState([]);
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedAllocation, setSelectedAllocation] = useState('');
  const [selectedUser, setSelectedUser] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [allocationsData, userLicensesData, schoolsData, districtsData, usersData] = await Promise.all([
        LicenseAllocation.list('-purchase_date'),
        UserLicense.list('-assigned_date'),
        School.list(),
        District.list(),
        User.list()
      ]);

      setAllocations(allocationsData);
      setUserLicenses(userLicensesData);
      setOrganizations([...schoolsData, ...districtsData]);
      setUsers(usersData);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load license data."
      });
    } finally {
      setIsLoading(false);
    }
  };

  const assignLicense = async () => {
    if (!selectedAllocation || !selectedUser) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please select both an allocation and user."
      });
      return;
    }

    try {
      const allocation = allocations.find(a => a.id === selectedAllocation);
      if (allocation.used_licenses >= allocation.total_licenses) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "No licenses available in this allocation."
        });
        return;
      }

      await UserLicense.create({
        user_id: selectedUser,
        allocation_id: selectedAllocation,
        assigned_date: new Date().toISOString(),
        assigned_by: 'current_user_id' // This would be the actual current user
      });

      await LicenseAllocation.update(selectedAllocation, {
        used_licenses: allocation.used_licenses + 1
      });

      toast({
        title: "License Assigned",
        description: "License has been successfully assigned to the user."
      });

      setSelectedAllocation('');
      setSelectedUser('');
      loadData();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to assign license."
      });
    }
  };

  const revokeLicense = async (licenseId) => {
    try {
      const license = userLicenses.find(l => l.id === licenseId);
      const allocation = allocations.find(a => a.id === license.allocation_id);

      await UserLicense.delete(licenseId);
      await LicenseAllocation.update(license.allocation_id, {
        used_licenses: Math.max(0, allocation.used_licenses - 1)
      });

      toast({
        title: "License Revoked",
        description: "License has been successfully revoked."
      });

      loadData();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to revoke license."
      });
    }
  };

  const getOrganizationName = (id, type) => {
    const org = organizations.find(o => o.id === id);
    return org ? org.name : `Unknown ${type}`;
  };

  const getUserName = (userId) => {
    const user = users.find(u => u.id === userId);
    return user ? user.full_name : 'Unknown User';
  };

  const isExpiringSoon = (expiryDate) => {
    const now = new Date();
    const expiry = new Date(expiryDate);
    const thirtyDaysFromNow = new Date(now.setDate(now.getDate() + 30));
    return isAfter(thirtyDaysFromNow, expiry);
  };

  const AllocationCard = ({ allocation }) => {
    const utilizationPercentage = (allocation.used_licenses / allocation.total_licenses) * 100;
    const isExpiring = isExpiringSoon(allocation.expiry_date);

    return (
      <Card className={`${isExpiring ? 'border-orange-200 bg-orange-50' : ''}`}>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-lg">
                {getOrganizationName(allocation.organization_id, allocation.organization_type)}
              </CardTitle>
              <div className="flex items-center gap-2 mt-2">
                <Badge className={`${
                  allocation.license_tier === 'enterprise' ? 'bg-purple-100 text-purple-800' :
                  allocation.license_tier === 'premium' ? 'bg-blue-100 text-blue-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {allocation.license_tier}
                </Badge>
                <Badge variant="outline" className={`${
                  allocation.organization_type === 'district' ? 'border-green-500 text-green-700' :
                  'border-blue-500 text-blue-700'
                }`}>
                  {allocation.organization_type}
                </Badge>
                {isExpiring && (
                  <Badge className="bg-orange-100 text-orange-800">
                    <AlertTriangle className="w-3 h-3 mr-1" />
                    Expiring Soon
                  </Badge>
                )}
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-gray-900">
                {allocation.used_licenses}/{allocation.total_licenses}
              </div>
              <div className="text-sm text-gray-500">licenses used</div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Utilization</span>
                <span>{utilizationPercentage.toFixed(0)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full ${
                    utilizationPercentage >= 90 ? 'bg-red-500' :
                    utilizationPercentage >= 70 ? 'bg-yellow-500' :
                    'bg-green-500'
                  }`}
                  style={{ width: `${utilizationPercentage}%` }}
                ></div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="flex items-center gap-1 text-gray-600 mb-1">
                  <Calendar className="w-4 h-4" />
                  <span>Expires</span>
                </div>
                <div className={isExpiring ? 'text-orange-600 font-medium' : ''}>
                  {format(new Date(allocation.expiry_date), 'MMM d, yyyy')}
                </div>
              </div>
              <div>
                <div className="flex items-center gap-1 text-gray-600 mb-1">
                  <DollarSign className="w-4 h-4" />
                  <span>Cost per License</span>
                </div>
                <div>${allocation.cost_per_license}</div>
              </div>
            </div>

            <div className="text-sm text-gray-600">
              <span className="font-medium">Billing Contact: </span>
              {allocation.billing_contact}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (isLoading) {
    return <div className="p-6 text-center">Loading license management...</div>;
  }

  return (
    <RoleGuard allowedRoles={['system_admin', 'district_admin']}>
      <div className="max-w-7xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">License Management</h1>
          <p className="text-gray-600 mt-1">Manage enterprise licenses and user assignments</p>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="assign">Assign Licenses</TabsTrigger>
            <TabsTrigger value="users">User Licenses</TabsTrigger>
            <TabsTrigger value="expiring">Expiring Soon</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {allocations.map(allocation => (
                <AllocationCard key={allocation.id} allocation={allocation} />
              ))}
              {allocations.length === 0 && (
                <div className="col-span-3 text-center py-12">
                  <Users className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No license allocations</h3>
                  <p className="text-gray-600">License allocations will appear here when created.</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="assign" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Assign License to User</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">License Allocation</label>
                    <Select value={selectedAllocation} onValueChange={setSelectedAllocation}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select allocation..." />
                      </SelectTrigger>
                      <SelectContent>
                        {allocations.filter(a => a.used_licenses < a.total_licenses).map(allocation => (
                          <SelectItem key={allocation.id} value={allocation.id}>
                            {getOrganizationName(allocation.organization_id, allocation.organization_type)} 
                            ({allocation.total_licenses - allocation.used_licenses} available)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">User</label>
                    <Select value={selectedUser} onValueChange={setSelectedUser}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select user..." />
                      </SelectTrigger>
                      <SelectContent>
                        {users.filter(user => 
                          !userLicenses.some(license => license.user_id === user.id)
                        ).map(user => (
                          <SelectItem key={user.id} value={user.id}>
                            {user.full_name} ({user.email})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button onClick={assignLicense}>
                  <Plus className="w-4 h-4 mr-2" />
                  Assign License
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>User License Assignments</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Organization</TableHead>
                        <TableHead>License Tier</TableHead>
                        <TableHead>Assigned Date</TableHead>
                        <TableHead>Last Used</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {userLicenses.map(license => {
                        const allocation = allocations.find(a => a.id === license.allocation_id);
                        return (
                          <TableRow key={license.id}>
                            <TableCell>
                              <div>
                                <div className="font-medium">{getUserName(license.user_id)}</div>
                                <div className="text-sm text-gray-500">
                                  {users.find(u => u.id === license.user_id)?.email}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              {allocation && getOrganizationName(allocation.organization_id, allocation.organization_type)}
                            </TableCell>
                            <TableCell>
                              <Badge className={`${
                                allocation?.license_tier === 'enterprise' ? 'bg-purple-100 text-purple-800' :
                                allocation?.license_tier === 'premium' ? 'bg-blue-100 text-blue-800' :
                                'bg-gray-100 text-gray-800'
                              }`}>
                                {allocation?.license_tier}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {format(new Date(license.assigned_date), 'MMM d, yyyy')}
                            </TableCell>
                            <TableCell>
                              {license.last_used ? format(new Date(license.last_used), 'MMM d, yyyy') : 'Never'}
                            </TableCell>
                            <TableCell>
                              <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={() => revokeLicense(license.id)}
                              >
                                Revoke
                              </Button>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                  {userLicenses.length === 0 && (
                    <div className="text-center py-8">
                      <Users className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                      <p className="text-gray-600">No user licenses assigned yet.</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="expiring" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {allocations.filter(a => isExpiringSoon(a.expiry_date)).map(allocation => (
                <AllocationCard key={allocation.id} allocation={allocation} />
              ))}
              {allocations.filter(a => isExpiringSoon(a.expiry_date)).length === 0 && (
                <div className="col-span-3 text-center py-12">
                  <Calendar className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No licenses expiring soon</h3>
                  <p className="text-gray-600">All license allocations are current.</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </RoleGuard>
  );
}