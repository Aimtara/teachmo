
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Star, Sparkles, Crown, Zap, Heart, ArrowRight, Loader2, Ticket } from "lucide-react";
import { motion } from "framer-motion";
import { createStripeCheckout } from "@/api/functions";
import { useToast } from "@/components/ui/use-toast";
// The following imports and associated code are replaced by ReferralCodeInput component
// import { applyReferralCode } from '@/api/functions';
// import { Input } from "@/components/ui/input";

// Assuming react-router-dom is available for useNavigate
import { useNavigate } from "react-router-dom";

// NEW IMPORT
import ReferralCodeInput from '@/components/onboarding/ReferralCodeInput';

const PAYMENT_METHODS = [
  { id: 'stripe', name: 'Credit Card', icon: '💳', description: 'Visa, Mastercard, Amex' },
  { id: 'paypal', name: 'PayPal', icon: '🟦', description: 'Pay with your PayPal account' },
  { id: 'apple', name: 'Apple Pay', icon: '🍎', description: 'Quick and secure' },
  { id: 'venmo', name: 'Venmo', icon: '💙', description: 'Split with partner' },
  { id: 'amazon', name: 'Amazon Pay', icon: '📦', description: 'Use Amazon account' }
];

const PREMIUM_FEATURES = [
  { title: "Unlimited AI Recommendations", description: "Get personalized activities anytime", current: "3 per day" },
  { title: "Advanced Progress Analytics", description: "Detailed insights and growth tracking", current: "Basic stats" },
  { title: "Priority Support", description: "Get help when you need it most", current: "Community support" },
  { title: "Premium Content Library", description: "Access expert guides and resources", current: "Limited content" },
  { title: "Custom Activity Creation", description: "Create and save your own activities", current: "Not available" },
  { title: "Family Collaboration", description: "Share with partners and caregivers", current: "Single user" },
  { title: "Export & Backup", description: "Download your progress and data", current: "Not available" }
];

export default function Upgrade() {
  const [user, setUser] = useState(null);
  const [selectedPlan, setSelectedPlan] = useState('monthly'); // Kept for handleSelectPlan logic
  const [selectedPayment, setSelectedPayment] = useState('stripe');
  const [isLoading, setIsLoading] = useState(true); // New state for initial loading
  const [isProcessing, setIsProcessing] = useState(false); // Used for both payment and code application
  // Removed referralCode and codeMessage states

  // NEW STATES
  const [appliedCode, setAppliedCode] = useState(null);
  const [discountedPricing, setDiscountedPricing] = useState(null);

  const { toast } = useToast();
  const navigate = useNavigate(); // Initialize useNavigate

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (e) {
        console.error("Failed to fetch user:", e);
        // Handle error, e.g., redirect to login or show error message
      } finally {
        setIsLoading(false);
      }
    };
    fetchUser();
  }, []);

  const handleSelectPlan = async () => {
    setIsProcessing(true);

    // --- IMPORTANT ---
    // Replace these placeholder IDs with your actual Stripe Price IDs.
    // You can find these in your Stripe Dashboard under Products.
    // Note: The client-side discountedPricing is for display only.
    // Actual discount application should usually be handled server-side (e.g., via Stripe coupons).
    const priceIds = {
      monthly: 'price_YOUR_MONTHLY_PRICE_ID', // e.g., price_1L2j3k4L5j6k7L8m
      annual: 'price_YOUR_ANNUAL_PRICE_ID'   // e.g., price_1L2j3k4L5j6k7L8n
    };

    const priceId = priceIds[selectedPlan];
    
    if (priceId.includes('YOUR_')) {
        toast({
            variant: "destructive",
            title: "Stripe Not Configured",
            description: "Please replace the placeholder Stripe Price IDs in pages/Upgrade.js to enable payments.",
        });
        setIsProcessing(false);
        return;
    }

    try {
      const response = await createStripeCheckout({ priceId });
      if (response.url) {
        window.location.href = response.url;
      } else {
        throw new Error('Failed to create checkout session.');
      }
    } catch (error) {
      console.error('Stripe checkout error:', error);
      toast({
        variant: "destructive",
        title: "Payment Error",
        description: "Could not initiate payment. Please try again.",
      });
      setIsProcessing(false);
    }
  };

  const openExternalPayment = (method) => {
    const urls = {
      paypal: 'https://www.paypal.com/checkoutnow?token=mock_teachmo_premium',
      apple: 'https://apple.com/apple-pay/mock-teachmo',
      venmo: 'https://venmo.com/pay/mock-teachmo-premium',
      amazon: 'https://pay.amazon.com/mock-teachmo-premium'
    };
    
    if (urls[method]) {
      window.open(urls[method], '_blank');
    } else {
      // For 'stripe' or other non-external methods, call handleSelectPlan
      handleSelectPlan(); 
    }
  };

  // NEW FUNCTION to handle referral code application
  const handleReferralCodeApplied = (codeData) => {
    setAppliedCode(codeData);
    
    // Calculate discounted pricing based on code
    // Base prices used for calculation: Monthly $9.99, Annual $99.99
    if (codeData.benefit_type === 'discount') {
      const discount = codeData.discount_percentage || 0;
      setDiscountedPricing({
        monthly: Math.round(9.99 * (1 - discount / 100) * 100) / 100,
        yearly: Math.round(99.99 * (1 - discount / 100) * 100) / 100,
        discount: discount
      });
    } else if (codeData.benefit_type === 'free_months') {
      // Handle free months logic
      setDiscountedPricing({
        freeMonths: codeData.free_months || 1,
        description: `${codeData.free_months || 1} month(s) free`
      });
    }

    toast({
      title: "Discount Applied!",
      description: `${codeData.benefit_description} has been applied to your subscription.`,
      duration: 5000
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center" style={{ backgroundColor: 'var(--teachmo-cream)' }}>
        <Loader2 className="h-10 w-10 animate-spin text-purple-500" />
        <p className="ml-2 text-lg text-gray-700">Loading...</p>
      </div>
    );
  }

  if (user?.subscription_tier === 'premium') {
    return (
      <div className="min-h-screen p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-r from-yellow-400 to-orange-500 flex items-center justify-center">
              <Crown className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900">You're already a Premium member! 🎉</h1>
            <p className="text-lg text-gray-600">
              Thank you for supporting Teachmo™. You have access to all premium features.
            </p>
            <Button onClick={() => window.history.back()} size="lg">
              <ArrowRight className="w-5 h-5 mr-2" />
              Continue to App
            </Button>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    // Updated styling for the main container
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white mb-4">
              <Star className="w-4 h-4 mr-2" />
              Premium Features
            </Badge>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Unlock Your Parenting Potential
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Get personalized AI guidance, advanced analytics, and premium content to support your parenting journey.
            </p>
          </motion.div>
        </div>

        {/* Referral Code Section */}
        <div className="mb-8">
          <ReferralCodeInput 
            onCodeApplied={handleReferralCodeApplied}
            showAsCard={true}
          />
        </div>

        {/* Pricing Display Grid - Replaces the single pricing card */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Monthly Plan Card */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <Card className="relative overflow-hidden hover:shadow-xl transition-all duration-300 border-2 border-purple-200">
              <CardHeader className="pb-4">
                <CardTitle className="text-2xl text-center">Monthly Plan</CardTitle>
                <div className="text-center">
                  {discountedPricing && !discountedPricing.freeMonths ? (
                    <div>
                      <div className="text-3xl font-bold text-gray-400 line-through">
                        $9.99
                      </div>
                      <div className="text-4xl font-bold text-green-600">
                        ${discountedPricing.monthly}
                      </div>
                      <Badge className="bg-green-100 text-green-800 mt-2">
                        {discountedPricing.discount}% OFF
                      </Badge>
                    </div>
                  ) : (
                    <div className="text-4xl font-bold">$9.99</div>
                  )}
                  <div className="text-sm text-gray-600 mt-1">per month</div>
                  {discountedPricing?.freeMonths && (
                    <Badge className="bg-blue-100 text-blue-800 mt-2">
                      {discountedPricing.description}
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="p-8">
                <div className="space-y-6">
                  <div className="space-y-3">
                    {PREMIUM_FEATURES.map((feature, index) => (
                      <div key={index} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="font-medium text-gray-900">{feature.title}</p>
                          <p className="text-sm text-gray-600">{feature.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Button
                    onClick={() => { setSelectedPlan('monthly'); handleSelectPlan(); }}
                    size="lg"
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                    disabled={isProcessing}
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Upgrade to Monthly
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Yearly Plan Card */}
          <motion.div
            initial={{ opacity: 0, x: 20 }} // Adjusted animation for right side
            animate={{ opacity: 1, x: 0 }}
          >
            <Card className="relative overflow-hidden hover:shadow-xl transition-all duration-300 border-2 border-purple-200">
              <div className="absolute top-0 right-0 bg-purple-600 text-white px-3 py-1 text-sm font-semibold">
                BEST VALUE
              </div>
              <CardHeader className="pb-4">
                <CardTitle className="text-2xl text-center">Yearly Plan</CardTitle>
                <div className="text-center">
                  {discountedPricing && !discountedPricing.freeMonths ? (
                    <div>
                      <div className="text-3xl font-bold text-gray-400 line-through">
                        $99.99
                      </div>
                      <div className="text-4xl font-bold text-green-600">
                        ${discountedPricing.yearly}
                      </div>
                      <Badge className="bg-green-100 text-green-800 mt-2">
                        {discountedPricing.discount}% OFF
                      </Badge>
                    </div>
                  ) : (
                    <div className="text-4xl font-bold">$99.99</div>
                  )}
                  <div className="text-sm text-gray-600 mt-1">per year</div>
                  <div className="text-sm text-purple-600 font-semibold">
                    Save $20 annually
                  </div>
                  {discountedPricing?.freeMonths && (
                    <Badge className="bg-blue-100 text-blue-800 mt-2">
                      {discountedPricing.description}
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="p-8">
                <div className="space-y-6">
                  <div className="space-y-3">
                    {PREMIUM_FEATURES.map((feature, index) => (
                      <div key={index} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="font-medium text-gray-900">{feature.title}</p>
                          <p className="text-sm text-gray-600">{feature.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Button
                    onClick={() => { setSelectedPlan('annual'); handleSelectPlan(); }}
                    size="lg"
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                    disabled={isProcessing}
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Upgrade to Yearly
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* What You Get vs Free section - moved outside the main pricing grid now that there are two separate cards */}
        <motion.div
            initial={{ opacity: 0, y: 20 }} // Adjusted animation
            animate={{ opacity: 1, y: 0 }}
            className="mb-12" // Add margin bottom for spacing
        >
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>What You Get vs Free</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {PREMIUM_FEATURES.map((feature, index) => (
                    <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
                      <div>
                        <p className="font-medium text-gray-900">{feature.title}</p>
                        <p className="text-sm text-gray-500">Free: {feature.current}</p>
                      </div>
                      <Crown className="w-5 h-5 text-purple-500" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
        </motion.div>

        {/* Conditional rendering for payment methods - currently hidden as showPaymentMethods is false */}
        {/*
        {showPaymentMethods && ( 
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-2xl mx-auto"
          >
            <Card className="shadow-xl">
              <CardHeader>
                <CardTitle>Choose Payment Method</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {PAYMENT_METHODS.map((method) => (
                  <Button
                    key={method.id}
                    variant={selectedPayment === method.id ? 'default' : 'outline'}
                    className="w-full justify-start h-auto p-4"
                    onClick={() => {
                      setSelectedPayment(method.id);
                      openExternalPayment(method.id);
                    }}
                  >
                    <div className="flex items-center gap-4">
                      <span className="text-2xl">{method.icon}</span>
                      <div className="text-left">
                        <p className="font-medium">{method.name}</p>
                        <p className="text-sm opacity-70">{method.description}</p>
                      </div>
                    </div>
                  </Button>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        )}
        */}
        
        {/* The old referral code section is removed, as ReferralCodeInput replaces it */}
      </div>
    </div>
  );
}
