
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import { Check, ShieldCheck, BookOpen, Users, Heart, Bot, BarChart, Loader2, BrainCircuit, MessageSquare, GraduationCap, ArrowRight } from 'lucide-react';
import TermsModal from '@/components/shared/TermsModal';
import { Checkbox } from "@/components/ui/checkbox";

const Feature = ({ icon: Icon, title, children }) => (
  <motion.div 
    className="flex flex-col items-center p-6 text-center bg-white rounded-xl shadow-lg hover:shadow-2xl transition-shadow duration-300"
    whileHover={{ y: -5 }}
  >
    <div className="flex-shrink-0 w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-4">
      <Icon className="w-8 h-8 text-blue-600" />
    </div>
    <h3 className="text-xl font-bold mb-2 text-gray-900">{title}</h3>
    <p className="text-gray-600 leading-relaxed">{children}</p>
  </motion.div>
);

const Testimonial = ({ quote, author, role, avatar }) => (
  <blockquote className="p-8 bg-white rounded-lg shadow-md">
    <p className="text-gray-700 italic text-lg leading-relaxed">"{quote}"</p>
    <footer className="mt-6 flex items-center">
      <img src={avatar} alt={author} className="w-12 h-12 rounded-full object-cover mr-4" />
      <div>
        <p className="font-semibold text-gray-900">{author}</p>
        <p className="text-gray-500">{role}</p>
      </div>
    </footer>
  </blockquote>
);

export default function LandingPage() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [isSignInLoading, setIsSignInLoading] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);

  const handleGetStarted = async () => {
    setIsLoading(true);
    try {
      await User.loginWithRedirect(window.location.origin + createPageUrl("Welcome"));
    } catch (error) {
      console.error("Login failed", error);
      setIsLoading(false);
    }
  };

  const handleSignIn = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsSignInLoading(true);
    try {
      await User.loginWithRedirect(window.location.origin + createPageUrl("Dashboard"));
    } catch (error) {
      console.error("Sign in failed", error);
      setIsSignInLoading(false);
    }
  };

  return (
    <div className="bg-gray-50 text-gray-800">
      <style>
        {`
          .gradient-text {
            background: linear-gradient(to right, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
          }
          .hero-bg {
            background-color: #f8fafc;
            background-image: radial-gradient(#dbeafe 1.5px, transparent 1.5px);
            background-size: 30px 30px;
          }
        `}
      </style>
      
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-lg shadow-sm">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Heart className="w-8 h-8 text-blue-600" />
            <span className="text-2xl font-bold text-gray-900">Teachmo™</span>
          </div>
          <div className="hidden md:flex items-center gap-6">
            <a href="#features" className="text-sm font-medium text-gray-600 hover:text-blue-600 transition-colors">Features</a>
            <a href="#differentiators" className="text-sm font-medium text-gray-600 hover:text-blue-600 transition-colors">Why Teachmo?</a>
            <a href="#pricing" className="text-sm font-medium text-gray-600 hover:text-blue-600 transition-colors">Pricing</a>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              onClick={handleSignIn}
              disabled={isSignInLoading}
              className="hover:bg-blue-50 hover:text-blue-700"
            >
              {isSignInLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Signing In...
                </>
              ) : (
                'Sign In'
              )}
            </Button>
            <Button
              className="bg-blue-600 hover:bg-blue-700 hidden sm:inline-flex"
              onClick={handleGetStarted}
              disabled={!termsAccepted || isLoading}
            >
              Get Started Free
            </Button>
          </div>
        </nav>
      </header>

      <main>
        {/* Hero Section */}
        <section className="relative pt-32 pb-20 md:pt-48 md:pb-28 hero-bg">
          <div className="container mx-auto px-6 text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
              <Badge className="bg-blue-100 text-blue-700 py-1 px-3 rounded-full text-sm font-medium mb-4">
                The First AI-Powered Parenting Assistant
              </Badge>
              <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-gray-900">
                End the guesswork.
                <br />
                <span className="gradient-text">Enjoy parenting more.</span>
              </h1>
              <p className="mt-6 text-lg md:text-xl leading-8 text-gray-600 max-w-3xl mx-auto">
                Teachmo™ transforms everyday challenges into joyful learning moments. Get personalized, evidence-based activities and expert advice to help your child thrive, without the stress.
              </p>
              <div className="mt-10 flex flex-col items-center justify-center gap-4">
                <Button
                  size="lg"
                  className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-8 rounded-full shadow-lg transition transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                  onClick={handleGetStarted}
                  disabled={!termsAccepted || isLoading}
                >
                  {isLoading ? 'Redirecting...' : 'Start Your Free Journey'} <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="terms"
                    checked={termsAccepted}
                    onCheckedChange={setTermsAccepted}
                    aria-labelledby="terms-label"
                  />
                  <div id="terms-label" className="text-sm text-gray-600">
                    I agree to the{' '}
                    <button onClick={() => setShowTermsModal(true)} className="underline font-medium text-blue-600 hover:text-blue-800">
                      Terms & Privacy Policy
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Social Proof */}
        <div className="py-12 bg-white">
            <div className="container mx-auto px-6">
                <p className="text-center text-sm font-semibold text-gray-500 uppercase tracking-wider">
                    Trusted by parents & educators nationwide
                </p>
                <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-8 opacity-60">
                    <div className="flex justify-center items-center">
                        <span className="font-bold text-lg">Parenting Weekly</span>
                    </div>
                    <div className="flex justify-center items-center">
                        <span className="font-bold text-lg">EdTech Today</span>
                    </div>
                    <div className="flex justify-center items-center">
                        <span className="font-bold text-lg">Tech for Tots</span>
                    </div>
                    <div className="flex justify-center items-center">
                        <span className="font-bold text-lg">Modern Family Mag</span>
                    </div>
                </div>
            </div>
        </div>

        {/* Features Section */}
        <section id="features" className="py-24 sm:py-32 bg-gray-50">
          <div className="container mx-auto px-6">
            <div className="mx-auto max-w-3xl lg:text-center">
              <h2 className="text-base font-semibold leading-7 text-blue-600">HOW IT WORKS</h2>
              <p className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Your Partner in Parenting</p>
              <p className="mt-6 text-lg leading-8 text-gray-600">
                From personalized activities to real-time advice, Teachmo™ provides the tools to support every stage of your child's development.
              </p>
            </div>
            <div className="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-8 md:grid-cols-2 lg:max-w-none lg:grid-cols-3">
              <Feature icon={BrainCircuit} title="Personalized AI Guidance">
                Our smart AI understands your child's unique needs to suggest the perfect activities and advice, right when you need them.
              </Feature>
              <Feature icon={BookOpen} title="Evidence-Based Activities">
                Access a library of fun, expert-vetted activities that build critical skills and strengthen your family bond.
              </Feature>
              <Feature icon={Users} title="Home-to-School Connection">
                Bridge the gap between learning at home and at school with seamless communication tools for parents and teachers.
              </Feature>
            </div>
          </div>
        </section>
        
        {/* Differentiators Section */}
        <section id="differentiators" className="py-24 sm:py-32 bg-white">
            <div className="container mx-auto px-6">
                <div className="grid lg:grid-cols-2 gap-16 items-center">
                    <div className="prose prose-lg text-gray-600">
                        <h2 className="text-base font-semibold leading-7 text-blue-600">WHY TEACHMO™ IS DIFFERENT</h2>
                        <h3 className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">More Than Just Another Parenting App</h3>
                        <p>
                            While other apps give you generic lists, Teachmo™ provides a dynamic, supportive ecosystem. We blend the best of AI with real human expertise to act as your personal parenting assistant.
                        </p>
                        <ul className="mt-8 space-y-4">
                            <li className="flex items-start">
                                <Check className="h-6 w-6 flex-none text-blue-600 mr-4 mt-1" />
                                <span><strong className="text-gray-800">AI That Understands Context:</strong> Our AI considers your child’s mood, interests, and recent challenges—not just their age.</span>
                            </li>
                            <li className="flex items-start">
                                <Check className="h-6 w-6 flex-none text-blue-600 mr-4 mt-1" />
                                <span><strong className="text-gray-800">Focus on "Teachable Moments":</strong> We help you turn everyday situations, from tantrums to triumphs, into opportunities for growth.</span>
                            </li>
                             <li className="flex items-start">
                                <Check className="h-6 w-6 flex-none text-blue-600 mr-4 mt-1" />
                                <span><strong className="text-gray-800">Reduces Decision Fatigue:</strong> Instead of endless scrolling, get 3-5 highly relevant, actionable suggestions each day.</span>
                            </li>
                        </ul>
                    </div>
                    <div className="relative">
                        <img src="https://images.unsplash.com/photo-1544991804-d53edd37d2f9?q=80&w=1887&auto=format&fit=crop" alt="Parent and child playing together" className="rounded-2xl shadow-xl w-full" />
                    </div>
                </div>
            </div>
        </section>

        {/* Testimonials Section */}
        <section className="py-24 sm:py-32 bg-gray-50">
          <div className="container mx-auto px-6">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl text-center mb-16">Loved by Parents & Educators</h2>
            <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
              <Testimonial quote="Teachmo™ has been a game-changer. The activity suggestions are brilliant and my kids love them!" author="Sarah J." role="Parent of 2" avatar="https://i.pravatar.cc/150?img=1" />
              <Testimonial quote="As a teacher, communicating with parents through Teachmo™ has been invaluable. It creates a real home-school connection." author="David L." role="2nd Grade Teacher" avatar="https://i.pravatar.cc/150?img=3" />
              <Testimonial quote="I was overwhelmed with information online. Teachmo's AI assistant gives me clear, actionable advice I can trust." author="Maria G." role="New Parent" avatar="https://i.pravatar.cc/150?img=5" />
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section id="pricing" className="py-24 sm:py-32 bg-white">
          <div className="container mx-auto px-6">
            <div className="mx-auto max-w-2xl sm:text-center">
              <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Simple, Transparent Pricing</h2>
              <p className="mt-6 text-lg leading-8 text-gray-600">
                Start for free, and upgrade when you're ready to unlock your family's full potential.
              </p>
            </div>
            <div className="mx-auto mt-16 max-w-2xl rounded-3xl ring-2 ring-blue-600 sm:mt-20 lg:mx-0 lg:flex lg:max-w-none shadow-2xl">
              <div className="p-8 sm:p-10 lg:flex-auto">
                <h3 className="text-2xl font-bold tracking-tight text-gray-900">Teachmo™ Premium</h3>
                <p className="mt-6 text-base leading-7 text-gray-600">
                  Unlock advanced features, unlimited AI access, and in-depth analytics to supercharge your parenting journey.
                </p>
                <div className="mt-10 flex items-center gap-x-4">
                  <h4 className="flex-none text-sm font-semibold leading-6 text-blue-600">What’s included</h4>
                  <div className="h-px flex-auto bg-gray-100"></div>
                </div>
                <ul role="list" className="mt-8 grid grid-cols-1 gap-4 text-sm leading-6 text-gray-600 sm:grid-cols-2 sm:gap-6">
                  <li className="flex gap-x-3"><Check className="h-6 w-5 flex-none text-blue-600" />Unlimited AI Assistant Conversations</li>
                  <li className="flex gap-x-3"><Check className="h-6 w-5 flex-none text-blue-600" />Advanced Progress Analytics</li>
                  <li className="flex gap-x-3"><Check className="h-6 w-5 flex-none text-blue-600" />Premium Content Library</li>
                  <li className="flex gap-x-3"><Check className="h-6 w-5 flex-none text-blue-600" />Family Collaboration Tools</li>
                </ul>
              </div>
              <div className="-mt-2 p-2 lg:mt-0 lg:w-full lg:max-w-md lg:flex-shrink-0">
                <div className="rounded-2xl bg-gray-100 py-10 text-center ring-1 ring-inset ring-gray-900/5 lg:flex lg:flex-col lg:justify-center lg:py-16">
                  <div className="mx-auto max-w-xs px-8">
                    <p className="text-base font-semibold text-gray-600">Unlock everything</p>
                    <p className="mt-6 flex items-baseline justify-center gap-x-2">
                      <span className="text-5xl font-bold tracking-tight text-gray-900">$12</span>
                      <span className="text-sm font-semibold leading-6 tracking-wide text-gray-600">/month</span>
                    </p>
                    <Button
                      size="lg"
                      className="mt-10 block w-full bg-blue-600 px-3 py-2 text-center text-sm font-semibold text-white shadow-sm hover:bg-blue-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 disabled:opacity-50"
                      onClick={handleGetStarted}
                      disabled={!termsAccepted || isLoading}
                    >
                      Upgrade to Premium
                    </Button>
                    <p className="mt-6 text-xs leading-5 text-gray-600">
                      7-day free trial. Cancel anytime.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Final CTA */}
        <section className="py-24 bg-blue-600 text-white">
            <div className="container mx-auto px-6 text-center">
                <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Ready to Transform Your Parenting Journey?</h2>
                <p className="mt-6 text-lg leading-8 text-blue-100 max-w-2xl mx-auto">
                    Join thousands of parents who are building stronger bonds and raising happier, more resilient children with Teachmo™.
                </p>
                <div className="mt-10">
                    <Button
                      size="lg"
                      className="bg-white text-blue-600 hover:bg-gray-100 font-bold py-4 px-8 rounded-full shadow-lg transition transform hover:scale-105 disabled:opacity-50"
                      onClick={handleGetStarted}
                      disabled={!termsAccepted || isLoading}
                    >
                      Get Started for Free
                    </Button>
                </div>
            </div>
        </section>

      </main>
      <TermsModal open={showTermsModal} onOpenChange={setShowTermsModal} />
      
      <footer className="bg-gray-900 text-white">
        <div className="container mx-auto px-6 py-12">
            <div className="flex flex-col md:flex-row justify-between items-center">
                <div className="flex items-center gap-2 mb-6 md:mb-0">
                    <Heart className="w-8 h-8 text-blue-500" />
                    <span className="text-2xl font-bold">Teachmo™</span>
                </div>
                <div className="flex gap-6">
                    <a href="#" className="text-sm text-gray-400 hover:text-white">About</a>
                    <a href="#" className="text-sm text-gray-400 hover:text-white">Contact</a>
                    <a href="#" className="text-sm text-gray-400 hover:text-white">Privacy</a>
                </div>
            </div>
            <div className="mt-8 border-t border-gray-800 pt-8 text-center text-sm text-gray-500">
                &copy; {new Date().getFullYear()} Teachmo™, Inc. All rights reserved.
            </div>
        </div>
      </footer>
    </div>
  );
}
