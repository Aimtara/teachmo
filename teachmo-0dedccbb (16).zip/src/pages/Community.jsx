import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Plus, Users, MessageSquare, Send } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Components
import PostCard from '@/components/community/PostCard';
import CreatePostForm from '@/components/community/CreatePostForm';
import PodCard from '@/components/pods/PodCard';
import CreatePodModal from '@/components/pods/CreatePodModal';
import ConversationList from '@/components/messages/ConversationList';
import ChatWindow from '@/components/messages/ChatWindow';

// Entities
import { Post, Pod, PodMember, Conversation, User } from '@/api/entities';
import { useToast } from '@/components/ui/use-toast';

export default function CommunityPage() {
  const [activeTab, setActiveTab] = useState('feed');
  const [posts, setPosts] = useState([]);
  const [pods, setPods] = useState([]);
  const [myPods, setMyPods] = useState([]);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [showCreatePod, setShowCreatePod] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      // Load posts (public and from user's pods)
      const publicPosts = await Post.list('-created_date', 20);
      setPosts(publicPosts);

      // Load available pods
      const availablePods = await Pod.list('-member_count', 12);
      setPods(availablePods);

      // Load user's pods
      if (currentUser) {
        const userPodMemberships = await PodMember.filter({ user_id: currentUser.id });
        const userPodIds = userPodMemberships.map(m => m.pod_id);
        
        if (userPodIds.length > 0) {
          const userPodsData = await Promise.all(
            userPodIds.map(id => Pod.filter({ id }, null, 1).then(results => results[0]))
          );
          setMyPods(userPodsData.filter(Boolean));
        }
      }

    } catch (error) {
      console.error('Error loading community data:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not load community data. Please refresh the page.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handlePostCreated = (newPost) => {
    setPosts(prev => [newPost, ...prev]);
    setShowCreatePost(false);
  };

  const handlePodCreated = (newPod) => {
    setPods(prev => [newPod, ...prev]);
    setMyPods(prev => [newPod, ...prev]);
    setShowCreatePod(false);
  };

  const handlePodJoined = (podId) => {
    const joinedPod = pods.find(p => p.id === podId);
    if (joinedPod) {
      setMyPods(prev => [...prev, joinedPod]);
    }
  };

  const handleStartConversation = () => {
    // TODO: Implement new conversation logic
    toast({
      title: "Coming Soon",
      description: "Direct conversation creation will be available soon.",
    });
  };

  const isUserInPod = (podId) => {
    return myPods.some(pod => pod.id === podId);
  };

  return (
    <div className="min-h-screen" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto p-4 md:p-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Teachmo™ Village</h1>
          <p className="text-gray-600">Connect, share, and support each other on the parenting journey</p>
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="feed" className="gap-2">
              <MessageSquare className="w-4 h-4" />
              Feed
            </TabsTrigger>
            <TabsTrigger value="pods" className="gap-2">
              <Users className="w-4 h-4" />
              Support Groups ({myPods.length})
            </TabsTrigger>
            <TabsTrigger value="messages" className="gap-2">
              <Send className="w-4 h-4" />
              Messages
            </TabsTrigger>
          </TabsList>

          {/* Feed Tab */}
          <TabsContent value="feed" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Community Feed</h2>
              <Button 
                onClick={() => setShowCreatePost(true)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Share Something
              </Button>
            </div>

            <AnimatePresence>
              {showCreatePost && (
                <motion.div
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <CreatePostForm
                    onPostCreated={handlePostCreated}
                    onClose={() => setShowCreatePost(false)}
                  />
                </motion.div>
              )}
            </AnimatePresence>

            {isLoading ? (
              <div className="space-y-6">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="bg-white rounded-xl p-6 animate-pulse">
                    <div className="flex gap-3 mb-4">
                      <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/6"></div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="h-4 bg-gray-200 rounded"></div>
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : posts.length === 0 ? (
              <div className="text-center py-12">
                <MessageSquare className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-500 mb-2">No posts yet</h3>
                <p className="text-gray-400 mb-6">Be the first to share something with the community!</p>
                <Button onClick={() => setShowCreatePost(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create First Post
                </Button>
              </div>
            ) : (
              <div className="space-y-6">
                {posts.map((post) => (
                  <PostCard
                    key={post.id}
                    post={post}
                    onKudo={() => {}}
                    onComment={() => {}}
                    onReport={(post) => {
                      toast({
                        title: "Report submitted",
                        description: "Thank you for helping keep our community safe.",
                      });
                    }}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          {/* Pods Tab */}
          <TabsContent value="pods" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Support Groups</h2>
              <Button 
                onClick={() => setShowCreatePod(true)}
                className="bg-green-600 hover:bg-green-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Group
              </Button>
            </div>

            {/* My Pods */}
            {myPods.length > 0 && (
              <div>
                <h3 className="text-lg font-medium mb-4">My Groups</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                  {myPods.map((pod) => (
                    <PodCard
                      key={pod.id}
                      pod={pod}
                      isJoined={true}
                      onJoin={handlePodJoined}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Available Pods */}
            <div>
              <h3 className="text-lg font-medium mb-4">Discover Groups</h3>
              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(6)].map((_, i) => (
                    <div key={i} className="bg-white rounded-xl p-6 animate-pulse">
                      <div className="space-y-3">
                        <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                        <div className="h-20 bg-gray-200 rounded"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {pods
                    .filter(pod => !isUserInPod(pod.id))
                    .slice(0, 9)
                    .map((pod) => (
                      <PodCard
                        key={pod.id}
                        pod={pod}
                        isJoined={false}
                        onJoin={handlePodJoined}
                      />
                    ))}
                </div>
              )}
            </div>
          </TabsContent>

          {/* Messages Tab */}
          <TabsContent value="messages" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[600px]">
              <div className="lg:col-span-1">
                <ConversationList
                  onSelectConversation={setSelectedConversation}
                  selectedConversationId={selectedConversation?.id}
                  onNewConversation={handleStartConversation}
                />
              </div>
              <div className="lg:col-span-2">
                <ChatWindow
                  conversation={selectedConversation}
                  onClose={() => setSelectedConversation(null)}
                />
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Create Pod Modal */}
        <CreatePodModal
          open={showCreatePod}
          onOpenChange={setShowCreatePod}
          onPodCreated={handlePodCreated}
        />
      </div>
    </div>
  );
}