
import React, { useState, useEffect, useRef } from "react";
import { User, Child } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { AlertCircle, RefreshCw } from "lucide-react";
import { AIAssistantSkeleton } from '../components/shared/ImprovedSkeletons';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

// New imports for the updated structure
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card"; // Now importing all sub-components of Card
import { Bot, User as UserIcon, Send, BrainCircuit, Shield, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Placeholder for BreadcrumbNavigation component as per outline's usage
// In a real application, this would typically be imported from a shared UI component library.
const BreadcrumbNavigation = ({ items }) => (
  <nav aria-label="breadcrumb" className="text-sm text-gray-500 mb-4">
    <ol className="list-none p-0 inline-flex">
      {items.map((item, index) => (
        <li key={index} className="flex items-center">
          {item.url ? (
            <a href={item.url} className="text-blue-600 hover:underline">
              {item.label}
            </a>
          ) : (
            <span>{item.label}</span>
          )}
          {index < items.length - 1 && (
            <span className="mx-2 text-gray-400">/</span>
          )}
        </li>
      ))}
    </ol>
  </nav>
);

// --- MOCK API FUNCTIONS ---
// These functions simulate backend calls for conversations and LLM interactions.
// In a real application, these would be actual API client calls.
const mockConversations = [
    {
        id: "conv-1",
        title: "Introduction to Teachmo AI",
        messages: [
            { role: "assistant", content: "Hello! I'm your Teachmo AI Assistant. How can I help you support your child's learning and development today?", timestamp: "2023-01-01T10:00:00Z" },
            { role: "user", content: "What is Teachmo?", timestamp: "2023-01-01T10:01:00Z" },
            { role: "assistant", content: "Teachmo is an innovative platform designed to empower parents with AI-driven insights and resources for their children's education and development. We help you understand your child's learning patterns, suggest personalized activities, and connect you with educational tools.", timestamp: "2023-01-01T10:02:00Z" },
        ]
    },
    {
        id: "conv-2",
        title: "Tips for reading comprehension",
        messages: [
            { role: "user", content: "My child struggles with reading comprehension, any tips?", timestamp: "2023-01-02T11:00:00Z" }
        ]
    }
];

let nextConversationId = mockConversations.length + 1; // Simple incrementing ID for mocks

const Conversation = {
    list: async () => {
        // Simulate API delay
        return new Promise(resolve => setTimeout(() => resolve(mockConversations), 500));
    },
    getMessages: async (conversationId) => {
        // Simulate API delay and fetching messages for a specific conversation
        return new Promise(resolve => {
            const conv = mockConversations.find(c => c.id === conversationId);
            setTimeout(() => resolve(conv ? conv.messages : []), 300);
        });
    },
    addMessage: async (conversationId, message) => {
        // Simulate API delay and adding a message to a conversation
        return new Promise(resolve => {
            const conv = mockConversations.find(c => c.id === conversationId);
            if (conv) {
                conv.messages.push(message);
            } else {
                console.warn(`Conversation with ID ${conversationId} not found. Message not added.`);
            }
            setTimeout(() => resolve(), 100);
        });
    },
    create: async (title = `New Conversation ${nextConversationId}`) => {
        // Simulate API delay and creating a new conversation
        return new Promise(resolve => {
            const newConv = {
                id: `conv-${nextConversationId++}`,
                title: title,
                messages: [{ role: "assistant", content: "Hello! What can I help you with in this new conversation?", timestamp: new Date().toISOString() }]
            };
            mockConversations.unshift(newConv); // Add to the beginning to show new ones at the top
            setTimeout(() => resolve(newConv), 200);
        });
    }
};

const InvokeLLM = async ({ prompt, context }) => {
    // Simulate LLM API call delay and response generation
    return new Promise(resolve => {
        setTimeout(() => {
            const responses = [
                "That's an interesting question! Let me think...",
                "I'm designed to help parents like you. What specific guidance are you looking for?",
                "Based on the information I have, here's a thought...",
                "I can provide insights on that. Could you elaborate a bit more?",
                "That's a common query. Here’s what I've learned from similar situations:",
                "I understand. Let's explore some strategies together.",
                "Great question! I'm here to help you navigate these challenges.",
                "I'm processing your request. Please bear with me for a moment.",
            ];
            const randomResponse = responses[Math.floor(Math.random() * responses.length)];
            resolve(`${randomResponse} (Responding to: "${prompt.substring(0, Math.min(prompt.length, 50))}${prompt.length > 50 ? '...' : ''}")`);
        }, 1500 + Math.random() * 1000); // Simulate network delay for AI response
    });
};
// --- END MOCK API FUNCTIONS ---


export default function AIAssistant() {
  const [user, setUser] = useState(null);
  const [children, setChildren] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [retryCount, setRetryCount] = useState(0);

  // New states for the chat interface and UX
  const [conversations, setConversations] = useState([]);
  const [currentConversationId, setCurrentConversationId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [contextualNotice, setContextualNotice] = useState('');

  // New refs for managing scroll and input focus
  const endOfMessagesRef = useRef(null);
  const inputRef = useRef(null);

  // Existing useEffect for initial data loading, now also fetches conversations
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const [userData, childrenData, convsData] = await Promise.all([
          User.me(),
          Child.list(),
          Conversation.list() // Load existing conversations
        ]);
        setUser(userData);
        setChildren(childrenData);
        setConversations(convsData);
        
        if (convsData.length > 0) {
            // Set the first conversation (or latest by timestamp if available) as current
            setCurrentConversationId(convsData[0].id);
        } else {
            // If no conversations, create a new default one
            const newConv = await Conversation.create("Welcome!");
            setConversations([newConv]);
            setCurrentConversationId(newConv.id);
        }
      } catch (err) {
        console.error("Failed to load AI Assistant data:", err);
        if (err.message?.includes('429') || err.response?.status === 429) {
          setError("We're experiencing high demand right now. Please wait a moment and try again.");
        } else {
          setError("Could not load your AI Assistant. Please check your connection and try again.");
        }
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, [retryCount]);

  // Effect to load messages when the currentConversationId changes
  useEffect(() => {
      if (currentConversationId) {
          setIsThinking(true); // Indicate messages are loading for the selected conversation
          Conversation.getMessages(currentConversationId)
              .then(msgs => {
                  setMessages(msgs);
              })
              .catch(err => {
                  console.error("Failed to load messages for conversation:", err);
                  setMessages([{ role: 'assistant', content: "Error loading messages for this conversation.", isError: true, timestamp: new Date().toISOString() }]);
              })
              .finally(() => {
                  setIsThinking(false);
              });
      } else {
          setMessages([]); // Clear messages if no conversation is selected
      }
  }, [currentConversationId]);


  // Effect for auto-scrolling to the bottom of the chat
  useEffect(() => {
    if (endOfMessagesRef.current) {
      endOfMessagesRef.current.scrollIntoView({ behavior: "smooth", block: "end" });
    }
  }, [messages, isThinking]); // Scroll when messages change or thinking state changes (for the thinking bubble)

  // Effect to focus the input field when the assistant is not thinking
  useEffect(() => {
    if (!isThinking && inputRef.current) {
        inputRef.current.focus();
    }
  }, [isThinking]);


  // Function to generate a personalized contextual notice based on user and child data
  const generateContextualNotice = (childData, userData) => {
      let notice = "My responses are personalized based on ";
      const parts = [];
      if (childData && childData.length > 0) {
          const ages = childData.map(c => c.age).join(', '); // Assuming 'age' property exists for Child
          parts.push(`your children's ages (${ages})`);
      }
      if (userData?.parenting_style) { // Assuming 'parenting_style' property exists for User
          parts.push(`your ${userData.parenting_style} parenting style`);
      }
      if (parts.length === 0) return '';
      notice += parts.join(' and ') + ".";
      return notice;
  };

  // Effect to set the contextual notice once user and children data are loaded
  useEffect(() => {
      if(user) {
          setContextualNotice(generateContextualNotice(children, user));
      }
  }, [user, children]); // Re-run if user or children data changes


  const handleRetry = () => {
    setRetryCount(c => c + 1);
  };

  // Function to handle sending a new message
  const handleSendMessage = async (e) => {
      e.preventDefault();
      if (!input.trim() || isThinking || !currentConversationId) return;

      const userMessage = { role: 'user', content: input.trim(), timestamp: new Date().toISOString() };
      
      // Optimistically update UI with user's message
      setMessages(prevMessages => [...prevMessages, userMessage]); 
      await Conversation.addMessage(currentConversationId, userMessage); // Persist user message to mock backend

      setInput(''); // Clear input field
      setIsThinking(true); // Show thinking indicator

      try {
          const llmResponse = await InvokeLLM({
              prompt: userMessage.content,
              // Pass relevant context for a more informed AI response
              context: { 
                  userId: user?.id, 
                  children: children, 
                  conversationId: currentConversationId, 
                  history: messages.slice(-5) // Send last 5 messages as history
              } 
          });
          
          const aiMessage = { role: 'assistant', content: llmResponse, timestamp: new Date().toISOString() };
          setMessages(prevMessages => [...prevMessages, aiMessage]); // Update with AI response
          await Conversation.addMessage(currentConversationId, aiMessage); // Persist AI response
          
      } catch (error) {
          console.error("Error invoking LLM:", error);
          const errorMessage = { role: 'assistant', content: "I'm sorry, I encountered an error. Please try again.", timestamp: new Date().toISOString(), isError: true };
          setMessages(prevMessages => [...prevMessages, errorMessage]); // Update with error message
          await Conversation.addMessage(currentConversationId, errorMessage); // Persist error message
      } finally {
          setIsThinking(false); // Hide thinking indicator
      }
  };

  // Function to handle starting a new conversation
  const handleNewConversation = async () => {
      if (isThinking) return; // Prevent creating new conversations while AI is busy
      setIsThinking(true); // Indicate activity
      try {
          const newConv = await Conversation.create();
          setConversations(prev => [newConv, ...prev]); // Add new conversation to the top of the list
          setCurrentConversationId(newConv.id); // Set it as the current conversation
          setMessages(newConv.messages); // Load initial message for the new conversation
      } catch (error) {
          console.error("Error creating new conversation:", error);
          alert("Failed to start a new conversation. Please try again.");
      } finally {
          setIsThinking(false);
      }
  };


  // --- Render Logic for Initial Loading and Error States ---
  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-6" style={{ backgroundColor: 'var(--teachmo-cream)' }}>
        <AIAssistantSkeleton />
      </div>
    );
  }

  // Show full-page error if initial user/children data could not be loaded
  if (error) {
    return (
      <div className="min-h-screen p-4 md:p-6 flex items-center justify-center" style={{ backgroundColor: 'var(--teachmo-cream)' }}>
        <Alert variant="destructive" className="max-w-md bg-white">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error Loading Assistant</AlertTitle>
          <AlertDescription>
            {error}
          </AlertDescription>
          <Button onClick={handleRetry} variant="outline" className="mt-4">
            <RefreshCw className="w-4 h-4 mr-2" />
            Try Again
          </Button>
        </Alert>
      </div>
    );
  }

  // If loading is complete and no error, but user/children are still null/empty (defensive check)
  if (!user || children === null) {
    return (
      <div className="min-h-screen p-4 md:p-6 flex items-center justify-center" style={{ backgroundColor: 'var(--teachmo-cream)' }}>
        <Alert variant="info" className="max-w-md bg-white">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Data Unavailable</AlertTitle>
          <AlertDescription>
            User or child data could not be retrieved. Please try again.
          </AlertDescription>
          <Button onClick={handleRetry} variant="outline" className="mt-4">
            <RefreshCw className="w-4 h-4 mr-2" />
            Try Again
          </Button>
        </Alert>
      </div>
    );
  }
  // --- End Render Logic for Initial Loading and Error States ---


  // Main chat UI rendering
  return (
    // Outer container for the full chat interface, adjusts height to fit screen minus typical header height
    <div className="flex h-[calc(100vh-80px)] bg-gray-100">
        {/* Conversation list sidebar */}
        <aside className="w-64 bg-white border-r p-4 flex flex-col shadow-sm">
            <h2 className="text-lg font-semibold mb-4 text-gray-800">Conversations</h2>
            <div className="flex-grow overflow-y-auto space-y-2">
                {conversations.length === 0 && !isLoading && (
                    <p className="text-sm text-gray-500">No conversations yet.</p>
                )}
                {conversations.map(conv => (
                    <button
                        key={conv.id}
                        className={`block w-full text-left p-2 rounded-md transition-colors duration-200 
                                    ${currentConversationId === conv.id ? 'bg-blue-500 text-white' : 'hover:bg-gray-100 text-gray-700'}`}
                        onClick={() => setCurrentConversationId(conv.id)}
                        disabled={isThinking} // Disable switching conversations while AI is busy
                    >
                        {conv.title || `Conversation ${conv.id.substring(0, 8)}...`}
                    </button>
                ))}
            </div>
            <Button 
                className="mt-4 w-full" 
                onClick={handleNewConversation} 
                disabled={isThinking} // Disable creating new conversation while AI is busy
            >
                <Bot className="w-4 h-4 mr-2" />
                New Conversation
            </Button>
        </aside>

        {/* Main chat area */}
        <main className="flex-1 flex flex-col bg-slate-50 relative">
            {/* Breadcrumb Navigation - placed at the top of the main content area */}
            <div className="px-6 pt-6 pb-2">
                <BreadcrumbNavigation items={[{ label: 'AI Assistant' }]} />
            </div>

            {/* Messages display area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
                <AnimatePresence>
                    {messages.map((message, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.3 }}
                            className={`flex items-start gap-3 ${message.role === 'user' ? 'justify-end' : ''}`}
                        >
                            {message.role === 'assistant' && (
                                <div className="w-8 h-8 rounded-full bg-blue-500 text-white flex items-center justify-center flex-shrink-0">
                                    <Bot size={20} />
                                </div>
                            )}
                            <div className={`rounded-lg p-3 max-w-lg shadow-sm ${message.role === 'user' ? 'bg-blue-500 text-white' : 'bg-white'}`}>
                                {message.content}
                                {message.isError && (
                                    <span className="text-red-300 text-xs ml-2"> (Error)</span>
                                )}
                            </div>
                            {message.role === 'user' && (
                                <div className="w-8 h-8 rounded-full bg-gray-600 text-white flex items-center justify-center flex-shrink-0">
                                    <UserIcon size={20} />
                                </div>
                            )}
                        </motion.div>
                    ))}
                    {isThinking && (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-start gap-3">
                            <div className="w-8 h-8 rounded-full bg-blue-500 text-white flex items-center justify-center flex-shrink-0">
                                <Bot size={20} />
                            </div>
                            <div className="bg-white rounded-lg p-3 max-w-lg shadow-sm">
                                <div className="flex items-center gap-2 text-sm text-gray-500">
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                    <span>Thinking...</span>
                                </div>
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
                <div ref={endOfMessagesRef} /> {/* Empty div for auto-scrolling to */}
            </div>
            
            {/* Input area and disclaimers */}
            <div className="p-4 border-t bg-white shadow-md">
                {contextualNotice && (
                    <div className="text-xs text-center text-gray-500 mb-2 flex items-center justify-center gap-2">
                        <BrainCircuit className="w-3 h-3" />
                        {contextualNotice}
                    </div>
                )}
                <form onSubmit={handleSendMessage} className="flex gap-2">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="Ask me anything about your child's learning..."
                        className="flex-1 p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100 disabled:cursor-not-allowed"
                        disabled={isThinking} // Disable input while AI is thinking
                        ref={inputRef} // Ref for auto-focus
                    />
                    <Button type="submit" disabled={!input.trim() || isThinking}>
                        <Send className="w-5 h-5" />
                        <span className="sr-only">Send</span>
                    </Button>
                </form>
                <p className="text-xs text-center text-gray-400 mt-2">
                    <Shield className="w-3 h-3 inline-block mr-1" />
                    AI guidance is for informational purposes only and is not a substitute for professional advice.
                </p>
            </div>
        </main>
    </div>
  );
}
