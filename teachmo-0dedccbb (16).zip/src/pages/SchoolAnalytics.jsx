import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { getAdminAnalytics } from '@/api/functions';
import { PageLoadingSkeleton, ErrorState } from '@/components/shared/LoadingStates';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';
import { Users, Activity, MessageSquare, BookOpen } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';

const StatCard = ({ title, value, icon: Icon, change }) => (
  <Card>
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      <Icon className="h-4 w-4 text-muted-foreground" />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
      {change && (
        <p className={`text-xs ${change > 0 ? 'text-green-600' : 'text-red-600'}`}>
          {change > 0 ? '+' : ''}{change}% from last month
        </p>
      )}
    </CardContent>
  </Card>
);

export default function SchoolAnalytics() {
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchParams] = useSearchParams();
  const schoolId = searchParams.get('school_id');
  const schoolName = searchParams.get('school_name');

  useEffect(() => {
    const fetchAnalytics = async () => {
      if (!schoolId) {
        setError({ message: "No school specified." });
        setLoading(false);
        return;
      }
      setLoading(true);
      try {
        const { data } = await getAdminAnalytics({ level: 'school', scope_id: schoolId });
        setAnalytics(data);
      } catch (err) {
        setError(err);
      } finally {
        setLoading(false);
      }
    };
    fetchAnalytics();
  }, [schoolId]);

  if (loading) {
    return <PageLoadingSkeleton />;
  }

  if (error) {
    return <ErrorState error={error} onRetry={() => window.location.reload()} />;
  }

  if (!analytics) {
    return <p>No analytics data available for this school.</p>;
  }

  const { overview, userMetrics, engagement, drillDownData } = analytics;
  const { usersByRole, activityEngagement, topTeachersByEngagement } = drillDownData;

  const userRoleData = Object.entries(usersByRole || {}).map(([name, value]) => ({ name, users: value }));
  const activityData = Object.entries(activityEngagement || {}).map(([name, value]) => ({ name, count: value }));

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Analytics for {schoolName || 'School'}</h1>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Total Users" value={overview.totalUsers} icon={Users} />
        <StatCard title="Completed Activities" value={engagement.completedActivities} icon={Activity} />
        <StatCard title="Total Posts" value={overview.totalPosts} icon={MessageSquare} />
        <StatCard title="Premium Users" value={userMetrics.premiumUsers} icon={BookOpen} />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>User Roles</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={userRoleData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="users" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Activity Engagement</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
               <BarChart data={activityData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="count" fill="#82ca9d" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

       <Card>
        <CardHeader>
          <CardTitle>Top Engaging Teachers</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Teacher</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Engagement Score</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Completed Activities</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {(topTeachersByEngagement || []).map((teacher) => (
                  <tr key={teacher.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{teacher.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{teacher.engagementScore}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{teacher.completedActivities}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}