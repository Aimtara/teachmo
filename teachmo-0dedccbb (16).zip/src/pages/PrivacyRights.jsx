import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { Shield, Download, Trash2, Eye, CheckCircle } from 'lucide-react';
import { User, PrivacyRequest } from '@/api/entities';

function PrivacyRightsPage() {
  const [formData, setFormData] = useState({
    requestType: '',
    userEmail: '',
    details: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.requestType || !formData.userEmail) {
      toast({
        variant: "destructive",
        title: "Missing Information",
        description: "Please select a request type and provide your email address."
      });
      return;
    }

    setIsSubmitting(true);
    try {
      // Get current user if available
      let userId = null;
      try {
        const user = await User.me();
        userId = user.id;
      } catch {
        // User not logged in - that's okay for privacy requests
      }

      await PrivacyRequest.create({
        user_id: userId,
        user_email: formData.userEmail,
        request_type: formData.requestType,
        details: formData.details
      });

      setIsSubmitted(true);
      toast({
        title: "Request Submitted",
        description: "Your privacy request has been submitted successfully. We will respond within 30 days."
      });
    } catch (error) {
      console.error('Error submitting privacy request:', error);
      toast({
        variant: "destructive",
        title: "Submission Failed",
        description: "Failed to submit your privacy request. Please try again."
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          <Card className="border-green-200 bg-green-50">
            <CardContent className="p-8 text-center">
              <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-green-900 mb-2">Request Submitted</h2>
              <p className="text-green-700 mb-6">
                Your privacy request has been successfully submitted. We will review your request and respond within 30 business days as required by applicable privacy laws.
              </p>
              <p className="text-sm text-green-600">
                You will receive a confirmation email at {formData.userEmail} with your request details and reference number.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <Shield className="w-12 h-12 text-blue-600 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-gray-900">Privacy Rights Request</h1>
          <p className="text-gray-600 mt-2">
            Exercise your privacy rights under applicable data protection laws
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Submit a Privacy Request</CardTitle>
            <p className="text-sm text-gray-600">
              Under various privacy laws (CCPA, GDPR, etc.), you have the right to know what personal information we collect, request deletion of your data, or opt-out of certain data processing activities.
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="requestType">Type of Request *</Label>
                <Select value={formData.requestType} onValueChange={(value) => setFormData(prev => ({ ...prev, requestType: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select request type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="access">
                      <div className="flex items-center gap-2">
                        <Eye className="w-4 h-4" />
                        Access - Request a copy of my personal data
                      </div>
                    </SelectItem>
                    <SelectItem value="deletion">
                      <div className="flex items-center gap-2">
                        <Trash2 className="w-4 h-4" />
                        Deletion - Delete my personal data
                      </div>
                    </SelectItem>
                    <SelectItem value="do_not_sell">
                      <div className="flex items-center gap-2">
                        <Shield className="w-4 h-4" />
                        Do Not Sell - Opt out of data sales
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="userEmail">Email Address *</Label>
                <Input
                  id="userEmail"
                  type="email"
                  placeholder="your.email@example.com"
                  value={formData.userEmail}
                  onChange={(e) => setFormData(prev => ({ ...prev, userEmail: e.target.value }))}
                  required
                />
                <p className="text-xs text-gray-500 mt-1">
                  This should be the email address associated with your Teachmo account
                </p>
              </div>

              <div>
                <Label htmlFor="details">Additional Details</Label>
                <Textarea
                  id="details"
                  placeholder="Please provide any additional information about your request..."
                  value={formData.details}
                  onChange={(e) => setFormData(prev => ({ ...prev, details: e.target.value }))}
                  rows={4}
                />
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-semibold text-blue-900 mb-2">What happens next?</h3>
                <ul className="text-sm text-blue-700 space-y-1">
                  <li>• We will verify your identity before processing your request</li>
                  <li>• You will receive a confirmation email within 24 hours</li>
                  <li>• We will fulfill your request within 30 business days</li>
                  <li>• You may be contacted if we need additional information</li>
                </ul>
              </div>

              <Button type="submit" disabled={isSubmitting} className="w-full">
                {isSubmitting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                    Submitting Request...
                  </>
                ) : (
                  'Submit Privacy Request'
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="mt-8 text-center">
          <p className="text-sm text-gray-600">
            For questions about your privacy rights, contact us at{' '}
            <a href="mailto:privacy@teachmo.com" className="text-blue-600 hover:underline">
              privacy@teachmo.com
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}

export default PrivacyRightsPage;