import React, { useState, useEffect } from 'react';
import { User, District } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';
import RoleGuard from '@/components/shared/RoleGuard';

function DistrictSettingsPage() {
    const [district, setDistrict] = useState(null);
    const [settings, setSettings] = useState({});
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const { toast } = useToast();

    useEffect(() => {
        const fetchDistrictData = async () => {
            try {
                const currentUser = await User.me();
                if (currentUser && currentUser.district_id) {
                    const districtData = await District.get(currentUser.district_id);
                    setDistrict(districtData);
                    setSettings(districtData.settings || {
                        sso_enabled: false,
                        require_teacher_verification: true,
                        enable_district_analytics: true
                    });
                }
            } catch (error) {
                toast({ variant: 'destructive', title: 'Error', description: 'Failed to load district data.' });
            } finally {
                setIsLoading(false);
            }
        };
        fetchDistrictData();
    }, [toast]);

    const handleSettingChange = (key, value) => {
        setSettings(prev => ({ ...prev, [key]: value }));
    };

    const handleSaveChanges = async () => {
        if (!district) return;
        setIsSaving(true);
        try {
            await District.update(district.id, { settings });
            toast({ title: 'Settings Saved', description: 'Your district settings have been updated.' });
        } catch (error) {
            toast({ variant: 'destructive', title: 'Save Failed', description: 'Could not save district settings.' });
        } finally {
            setIsSaving(false);
        }
    };

    if (isLoading) {
        return <div className="p-6"><Loader2 className="animate-spin" /></div>;
    }

    if (!district) {
        return <div className="p-6">You are not associated with a district.</div>;
    }

    return (
        <div className="p-4 md:p-6">
            <Card>
                <CardHeader>
                    <CardTitle>District Settings for {district.name}</CardTitle>
                    <CardDescription>Manage global configurations for all schools in your district.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                        <Label htmlFor="sso" className="flex flex-col space-y-1">
                            <span>Enable Single Sign-On (SSO)</span>
                            <span className="font-normal leading-snug text-muted-foreground">
                                Allow users to log in with district credentials.
                            </span>
                        </Label>
                        <Switch
                            id="sso"
                            checked={settings.sso_enabled}
                            onCheckedChange={(value) => handleSettingChange('sso_enabled', value)}
                            disabled={isSaving}
                        />
                    </div>
                     <div className="flex items-center justify-between p-4 border rounded-lg">
                        <Label htmlFor="analytics" className="flex flex-col space-y-1">
                            <span>Enable District-wide Analytics</span>
                            <span className="font-normal leading-snug text-muted-foreground">
                                Aggregate and view analytics for all schools in the district.
                            </span>
                        </Label>
                        <Switch
                            id="analytics"
                            checked={settings.enable_district_analytics}
                            onCheckedChange={(value) => handleSettingChange('enable_district_analytics', value)}
                            disabled={isSaving}
                        />
                    </div>
                    <div className="flex justify-end mt-6">
                        <Button onClick={handleSaveChanges} disabled={isSaving}>
                            {isSaving ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : 'Save Changes'}
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}

export default function DistrictSettings() {
    return (
        <RoleGuard allowedRoles={['district_admin', 'admin', 'system_admin']}>
            <DistrictSettingsPage />
        </RoleGuard>
    )
}