import React, { useState, useEffect } from 'react';
import { UserContent, User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Upload, Star, Users, Eye, Heart } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import UserContentForm from '../components/content/UserContentForm';

export default function UserContentHub() {
  const [content, setContent] = useState([]);
  const [myContent, setMyContent] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showSubmissionForm, setShowSubmissionForm] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [userData, allContent] = await Promise.all([
        User.me(),
        UserContent.filter({ status: 'published' }, '-created_date')
      ]);
      
      setUser(userData);
      setContent(allContent);
      
      // Load user's own content
      const userContent = await UserContent.filter({ 
        submitter_id: userData.id 
      }, '-created_date');
      setMyContent(userContent);
      
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load content."
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleContentSubmit = async (contentData) => {
    try {
      await UserContent.create({
        ...contentData,
        submitter_id: user.id,
        status: 'pending'
      });
      
      toast({
        title: "Content Submitted!",
        description: "Your content has been submitted for review."
      });
      
      setShowSubmissionForm(false);
      loadData();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to submit content."
      });
    }
  };

  const ContentCard = ({ item, showStatus = false }) => (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg">{item.title}</CardTitle>
            <div className="flex items-center gap-2 mt-2">
              <Badge variant="outline">{item.content_type}</Badge>
              <Badge className="bg-blue-100 text-blue-800">{item.category}</Badge>
              {showStatus && (
                <Badge 
                  className={
                    item.status === 'published' ? 'bg-green-100 text-green-800' :
                    item.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }
                >
                  {item.status}
                </Badge>
              )}
            </div>
          </div>
          {item.rating > 0 && (
            <div className="flex items-center gap-1 text-sm">
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <span>{item.rating.toFixed(1)}</span>
              <span className="text-gray-500">({item.rating_count})</span>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-gray-600 mb-4">{item.description}</p>
        
        {item.age_range && (
          <div className="mb-3">
            <span className="text-sm font-medium text-gray-700">Age Range: </span>
            <span className="text-sm text-gray-600">
              {item.age_range.min_age}-{item.age_range.max_age} years
            </span>
          </div>
        )}
        
        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <Eye className="w-4 h-4" />
              <span>{item.usage_count}</span>
            </div>
            <div className="flex items-center gap-1">
              <Heart className="w-4 h-4" />
              <span>{item.rating_count}</span>
            </div>
          </div>
          <Button variant="outline" size="sm">
            View Details
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  if (isLoading) {
    return <div className="p-6 text-center">Loading content...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Community Content Hub</h1>
          <p className="text-gray-600 mt-1">Discover and share activities created by our community</p>
        </div>
        <Button onClick={() => setShowSubmissionForm(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Submit Content
        </Button>
      </div>

      <Tabs defaultValue="browse" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="browse">Browse Content</TabsTrigger>
          <TabsTrigger value="my-content">My Submissions</TabsTrigger>
          <TabsTrigger value="favorites">My Favorites</TabsTrigger>
        </TabsList>

        <TabsContent value="browse" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {content.map(item => (
              <ContentCard key={item.id} item={item} />
            ))}
            {content.length === 0 && (
              <div className="col-span-3 text-center py-12">
                <Users className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No published content yet</h3>
                <p className="text-gray-600">Be the first to share your activities with the community!</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="my-content" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myContent.map(item => (
              <ContentCard key={item.id} item={item} showStatus />
            ))}
            {myContent.length === 0 && (
              <div className="col-span-3 text-center py-12">
                <Upload className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No submissions yet</h3>
                <p className="text-gray-600">Share your favorite activities with other parents!</p>
                <Button 
                  className="mt-4" 
                  onClick={() => setShowSubmissionForm(true)}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Submit Your First Activity
                </Button>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="favorites" className="mt-6">
          <div className="text-center py-12">
            <Heart className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Coming Soon</h3>
            <p className="text-gray-600">Save your favorite community content for easy access.</p>
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={showSubmissionForm} onOpenChange={setShowSubmissionForm}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Submit Community Content</DialogTitle>
          </DialogHeader>
          <UserContentForm 
            onSubmit={handleContentSubmit}
            onCancel={() => setShowSubmissionForm(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}