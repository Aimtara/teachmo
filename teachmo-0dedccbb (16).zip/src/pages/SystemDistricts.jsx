
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Plus, 
  Search, 
  Building, 
  Users, 
  GraduationCap, 
  MoreVertical,
  Edit,
  Archive,
  School as SchoolIcon,
  PlusCircle // Added PlusCircle import
} from 'lucide-react';
import { District, School } from '@/api/entities';
import RoleGuard from '@/components/shared/RoleGuard';
import { ListSkeleton } from '@/components/shared/ImprovedSkeletons';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import CreateDistrictModal from '@/components/admin/CreateDistrictModal';
import CreateSchoolModal from '@/components/admin/CreateSchoolModal';
import AssignSchoolModal from '@/components/admin/AssignSchoolModal';

export default function SystemDistricts() { // Renamed from SystemDistrictsPage and made default export
  const [districts, setDistricts] = useState([]);
  const [independentSchools, setIndependentSchools] = useState([]);
  const [pilotSchools, setPilotSchools] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  // Removed: const [showCreateDistrict, setShowCreateDistrict] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false); // New state for CreateDistrictModal
  const [showCreateSchool, setShowCreateSchool] = useState(false);
  const [showAssignSchool, setShowAssignSchool] = useState(false);
  const [selectedSchool, setSelectedSchool] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [districtsData, schoolsData] = await Promise.all([
        District.list('-created_date'),
        School.list('-created_date')
      ]);
      
      setDistricts(districtsData);
      
      // Separate schools by status
      const independent = schoolsData.filter(school => 
        school.status === 'independent' || (!school.district_id && school.status !== 'pilot')
      );
      const pilot = schoolsData.filter(school => school.status === 'pilot');
      
      setIndependentSchools(independent);
      setPilotSchools(pilot);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateComplete = () => { // New handler for CreateDistrictModal completion
    setIsCreateModalOpen(false); // Close the modal
    loadData(); // Reload all data
  };

  // Removed handleCreateDistrict as its logic is now managed by the modal's onComplete prop

  const handleCreateSchool = async (schoolData) => {
    try {
      await School.create({
        ...schoolData,
        status: schoolData.status || 'pilot'
      });
      setShowCreateSchool(false);
      loadData();
    } catch (error) {
      console.error('Error creating school:', error);
    }
  };

  const handleAssignSchool = async (districtId) => {
    try {
      await School.update(selectedSchool.id, {
        district_id: districtId,
        status: 'district_member'
      });
      setShowAssignSchool(false);
      setSelectedSchool(null);
      loadData();
    } catch (error) {
      console.error('Error assigning school:', error);
    }
  };

  const filteredDistricts = districts.filter(district =>
    district.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredIndependentSchools = independentSchools.filter(school =>
    school.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredPilotSchools = pilotSchools.filter(school =>
    school.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="p-4 md:p-6 space-y-6">
        <Card>
          <CardHeader>
            <div className="h-8 w-48 bg-gray-200 rounded animate-pulse" />
          </CardHeader>
          <CardContent>
            <ListSkeleton count={5} />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <RoleGuard allowedRoles={['system_admin', 'admin']}>
      <div className="p-4 md:p-6 space-y-6">
        {/* Header - Updated */}
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Districts</h1>
          <Button onClick={() => setIsCreateModalOpen(true)}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add District
          </Button>
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search districts and schools..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Districts */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building className="w-5 h-5" />
              Districts ({filteredDistricts.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {filteredDistricts.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                {searchTerm ? 'No districts match your search' : 'No districts created yet'}
              </div>
            ) : (
              <div className="space-y-3">
                {filteredDistricts.map((district) => (
                  <div key={district.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{district.name}</h3>
                      <div className="flex items-center gap-4 text-sm text-gray-600 mt-1">
                        <span className="flex items-center gap-1">
                          <SchoolIcon className="w-4 h-4" />
                          {district.school_count || 0} schools
                        </span>
                        <span className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          {district.student_count || 0} students
                        </span>
                        <Badge variant={district.is_active ? 'default' : 'secondary'}>
                          {district.is_active ? 'Active' : 'Inactive'}
                        </Badge>
                        <Badge variant="outline">{district.subscription_tier}</Badge>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem>
                          <Edit className="w-4 h-4 mr-2" />
                          Edit District
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <SchoolIcon className="w-4 h-4 mr-2" />
                          View Schools
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Archive className="w-4 h-4 mr-2" />
                          Archive
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pilot Schools */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-orange-500" />
              Pilot Schools ({filteredPilotSchools.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {filteredPilotSchools.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                {searchTerm ? 'No pilot schools match your search' : 'No pilot schools'}
              </div>
            ) : (
              <div className="space-y-3">
                {filteredPilotSchools.map((school) => (
                  <div key={school.id} className="flex items-center justify-between p-4 bg-orange-50 rounded-lg border border-orange-200">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{school.name}</h3>
                      <div className="flex items-center gap-4 text-sm text-gray-600 mt-1">
                        <span>{school.school_type}</span>
                        <span>{school.student_count || 0} students</span>
                        <Badge className="bg-orange-100 text-orange-800">Pilot</Badge>
                        {school.pilot_end_date && (
                          <span className="text-xs">
                            Pilot ends: {new Date(school.pilot_end_date).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        onClick={() => {
                          setSelectedSchool(school);
                          setShowAssignSchool(true);
                        }}
                      >
                        Assign to District
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          <DropdownMenuItem>
                            <Edit className="w-4 h-4 mr-2" />
                            Edit School
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Archive className="w-4 h-4 mr-2" />
                            Archive
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Independent Schools */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <SchoolIcon className="w-5 h-5 text-blue-500" />
              Independent Schools ({filteredIndependentSchools.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {filteredIndependentSchools.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                {searchTerm ? 'No independent schools match your search' : 'No independent schools'}
              </div>
            ) : (
              <div className="space-y-3">
                {filteredIndependentSchools.map((school) => (
                  <div key={school.id} className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{school.name}</h3>
                      <div className="flex items-center gap-4 text-sm text-gray-600 mt-1">
                        <span>{school.school_type}</span>
                        <span>{school.student_count || 0} students</span>
                        <Badge className="bg-blue-100 text-blue-800">Independent</Badge>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem>
                          <Edit className="w-4 h-4 mr-2" />
                          Edit School
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => {
                            setSelectedSchool(school);
                            setShowAssignSchool(true);
                          }}
                        >
                          <Building className="w-4 h-4 mr-2" />
                          Assign to District
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Archive className="w-4 h-4 mr-2" />
                          Archive
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Modals - Updated CreateDistrictModal */}
        <CreateDistrictModal
          open={isCreateModalOpen}
          onOpenChange={setIsCreateModalOpen}
          onComplete={handleCreateComplete}
        />

        {showCreateSchool && (
          <CreateSchoolModal
            onSave={handleCreateSchool}
            onCancel={() => setShowCreateSchool(false)}
          />
        )}

        {showAssignSchool && selectedSchool && (
          <AssignSchoolModal
            school={selectedSchool}
            districts={districts}
            onAssign={handleAssignSchool}
            onCancel={() => {
              setShowAssignSchool(false);
              setSelectedSchool(null);
            }}
          />
        )}
      </div>
    </RoleGuard>
  );
}
