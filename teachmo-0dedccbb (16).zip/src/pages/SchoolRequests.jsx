import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  School, 
  User, 
  Clock, 
  CheckCircle, 
  XCircle, 
  Search, 
  Filter,
  ExternalLink,
  Mail,
  Calendar,
  MessageSquare,
  Eye,
  Plus,
  AlertTriangle,
  Building,
  Globe
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { useToast } from '@/components/ui/use-toast';
import { SchoolParticipationRequest, SchoolDirectory, User as UserEntity } from '@/api/entities';
import { manageSchoolRequests } from '@/api/functions';
import RoleGuard from '@/components/shared/RoleGuard';
import { DashboardSkeleton } from '@/components/shared/ImprovedSkeletons';

const statusConfig = {
  new: { label: 'New', color: 'bg-blue-100 text-blue-800', icon: Clock },
  in_review: { label: 'In Review', color: 'bg-yellow-100 text-yellow-800', icon: Eye },
  added: { label: 'Added', color: 'bg-green-100 text-green-800', icon: CheckCircle },
  rejected: { label: 'Rejected', color: 'bg-red-100 text-red-800', icon: XCircle }
};

function RequestCard({ request, onSelect, onProcess, isProcessing }) {
  const config = statusConfig[request.status];
  const IconComponent = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-lg border border-gray-200 hover:border-gray-300 transition-colors"
    >
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Building className="w-4 h-4 text-gray-500" />
                <CardTitle className="text-lg">{request.school_name}</CardTitle>
                <Badge className={config.color}>
                  <IconComponent className="w-3 h-3 mr-1" />
                  {config.label}
                </Badge>
              </div>
              {request.school_domain && (
                <div className="flex items-center gap-1 text-sm text-gray-600 mb-2">
                  <Globe className="w-3 h-3" />
                  {request.school_domain}
                </div>
              )}
              <div className="flex items-center gap-1 text-sm text-gray-500">
                <Mail className="w-3 h-3" />
                {request.contact_email || 'No contact email'}
              </div>
            </div>
            <div className="flex flex-col items-end gap-2">
              <span className="text-xs text-gray-500">
                <Calendar className="w-3 h-3 inline mr-1" />
                {format(new Date(request.requested_at), 'MMM d, yyyy')}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onSelect(request)}
                className="text-xs"
              >
                <Eye className="w-3 h-3 mr-1" />
                View Details
              </Button>
            </div>
          </div>
        </CardHeader>
        {request.additional_notes && (
          <CardContent className="pt-0">
            <p className="text-sm text-gray-600 line-clamp-2">
              {request.additional_notes}
            </p>
          </CardContent>
        )}
        {request.status === 'new' && (
          <CardContent className="pt-0">
            <div className="flex gap-2">
              <Button
                size="sm"
                onClick={() => onProcess(request.id, 'review')}
                disabled={isProcessing}
                className="bg-yellow-600 hover:bg-yellow-700"
              >
                Start Review
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onProcess(request.id, 'approve')}
                disabled={isProcessing}
                className="border-green-600 text-green-600 hover:bg-green-50"
              >
                Quick Approve
              </Button>
            </div>
          </CardContent>
        )}
      </Card>
    </motion.div>
  );
}

function RequestDetailModal({ request, onClose, onProcess, isProcessing }) {
  const [adminNote, setAdminNote] = useState('');
  const config = statusConfig[request.status];
  const IconComponent = config.icon;

  const handleAction = (action) => {
    onProcess(request.id, action, adminNote);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
      >
        <div className="p-6">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">{request.school_name}</h2>
              <Badge className={config.color}>
                <IconComponent className="w-3 h-3 mr-1" />
                {config.label}
              </Badge>
            </div>
            <Button variant="ghost" onClick={onClose}>×</Button>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700">School Domain</label>
                <p className="text-sm text-gray-900">{request.school_domain || 'Not provided'}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Contact Email</label>
                <p className="text-sm text-gray-900">{request.contact_email || 'Not provided'}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Requested Date</label>
                <p className="text-sm text-gray-900">
                  {format(new Date(request.requested_at), 'PPP')}
                </p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Status</label>
                <p className="text-sm text-gray-900">{config.label}</p>
              </div>
            </div>

            {request.additional_notes && (
              <div>
                <label className="text-sm font-medium text-gray-700">Additional Notes</label>
                <p className="text-sm text-gray-900 bg-gray-50 p-3 rounded-md">
                  {request.additional_notes}
                </p>
              </div>
            )}

            {request.support_letter_url && (
              <div>
                <label className="text-sm font-medium text-gray-700">Support Letter</label>
                <a 
                  href={request.support_letter_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-800 text-sm flex items-center gap-1"
                >
                  <ExternalLink className="w-3 h-3" />
                  View Support Letter
                </a>
              </div>
            )}

            {request.admin_notes && (
              <div>
                <label className="text-sm font-medium text-gray-700">Admin Notes</label>
                <p className="text-sm text-gray-600 bg-yellow-50 p-3 rounded-md">
                  {request.admin_notes}
                </p>
              </div>
            )}

            <div>
              <label className="text-sm font-medium text-gray-700">Admin Notes</label>
              <Textarea
                value={adminNote}
                onChange={(e) => setAdminNote(e.target.value)}
                placeholder="Add internal notes about this request..."
                className="mt-1"
              />
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={onClose}>Close</Button>
              {request.status === 'new' && (
                <>
                  <Button
                    onClick={() => handleAction('review')}
                    disabled={isProcessing}
                    className="bg-yellow-600 hover:bg-yellow-700"
                  >
                    Mark as In Review
                  </Button>
                  <Button
                    onClick={() => handleAction('approve')}
                    disabled={isProcessing}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Approve & Add School
                  </Button>
                  <Button
                    onClick={() => handleAction('reject')}
                    disabled={isProcessing}
                    variant="destructive"
                  >
                    Reject Request
                  </Button>
                </>
              )}
              {request.status === 'in_review' && (
                <>
                  <Button
                    onClick={() => handleAction('approve')}
                    disabled={isProcessing}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Approve & Add School
                  </Button>
                  <Button
                    onClick={() => handleAction('reject')}
                    disabled={isProcessing}
                    variant="destructive"
                  >
                    Reject Request
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default function SchoolRequests() {
  const [requests, setRequests] = useState([]);
  const [filteredRequests, setFilteredRequests] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('new');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [stats, setStats] = useState({
    new: 0,
    in_review: 0,
    added: 0,
    rejected: 0
  });

  const { toast } = useToast();

  useEffect(() => {
    loadRequests();
  }, []);

  useEffect(() => {
    filterRequests();
  }, [requests, activeTab, searchTerm]);

  const loadRequests = async () => {
    try {
      setIsLoading(true);
      const fetchedRequests = await SchoolParticipationRequest.list('-requested_at');
      
      const newStats = {
        new: fetchedRequests.filter(r => r.status === 'new').length,
        in_review: fetchedRequests.filter(r => r.status === 'in_review').length,
        added: fetchedRequests.filter(r => r.status === 'added').length,
        rejected: fetchedRequests.filter(r => r.status === 'rejected').length
      };

      setRequests(fetchedRequests);
      setStats(newStats);
    } catch (error) {
      console.error('Error loading school requests:', error);
      toast({
        variant: "destructive",
        title: "Error Loading Requests",
        description: "Could not load school participation requests. Please try again."
      });
    } finally {
      setIsLoading(false);
    }
  };

  const filterRequests = () => {
    let filtered = requests.filter(request => {
      if (activeTab !== 'all' && request.status !== activeTab) return false;
      if (searchTerm && 
          !request.school_name.toLowerCase().includes(searchTerm.toLowerCase()) &&
          !request.contact_email?.toLowerCase().includes(searchTerm.toLowerCase()) &&
          !request.school_domain?.toLowerCase().includes(searchTerm.toLowerCase())) {
        return false;
      }
      return true;
    });

    setFilteredRequests(filtered);
  };

  const handleProcessRequest = async (requestId, action, adminNotes = '') => {
    setIsProcessing(true);
    try {
      const { data } = await manageSchoolRequests({
        action: action,
        request_ids: [requestId],
        admin_notes: adminNotes
      });

      if (data.success) {
        toast({
          title: `Request ${action}d successfully!`,
          description: data.message || `School participation request has been ${action}d.`
        });

        await loadRequests();
        setSelectedRequest(null);
      } else {
        throw new Error(data.error || `Failed to ${action} request`);
      }
    } catch (error) {
      console.error(`Error ${action}ing request:`, error);
      toast({
        variant: "destructive",
        title: `Error ${action}ing Request`,
        description: error.message || `Could not ${action} the request. Please try again.`
      });
    } finally {
      setIsProcessing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <DashboardSkeleton />
      </div>
    );
  }

  return (
    <RoleGuard allowedRoles={['system_admin', 'admin', 'district_admin']}>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">School Participation Requests</h1>
            <p className="text-gray-600 mt-1">
              Manage requests from parents to add their schools to Teachmo
            </p>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-4 gap-4">
          {Object.entries(stats).map(([status, count]) => {
            const config = statusConfig[status];
            const IconComponent = config.icon;
            return (
              <Card key={status} className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">{config.label}</p>
                    <p className="text-2xl font-bold">{count}</p>
                  </div>
                  <IconComponent className="w-8 h-8 text-gray-400" />
                </div>
              </Card>
            );
          })}
        </div>

        {/* Filters */}
        <div className="flex items-center gap-4">
          <div className="flex-1">
            <Input
              placeholder="Search schools, domains, or emails..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-md"
            />
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="all">All ({requests.length})</TabsTrigger>
            <TabsTrigger value="new">New ({stats.new})</TabsTrigger>
            <TabsTrigger value="in_review">In Review ({stats.in_review})</TabsTrigger>
            <TabsTrigger value="added">Added ({stats.added})</TabsTrigger>
            <TabsTrigger value="rejected">Rejected ({stats.rejected})</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="mt-6">
            {filteredRequests.length === 0 ? (
              <Card className="p-8 text-center">
                <School className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  No {activeTab === 'all' ? '' : activeTab} requests found
                </h3>
                <p className="text-gray-600">
                  {searchTerm ? 'Try adjusting your search terms.' : 'Check back later for new requests.'}
                </p>
              </Card>
            ) : (
              <div className="grid gap-4">
                <AnimatePresence>
                  {filteredRequests.map((request) => (
                    <RequestCard
                      key={request.id}
                      request={request}
                      onSelect={setSelectedRequest}
                      onProcess={handleProcessRequest}
                      isProcessing={isProcessing}
                    />
                  ))}
                </AnimatePresence>
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Detail Modal */}
        <AnimatePresence>
          {selectedRequest && (
            <RequestDetailModal
              request={selectedRequest}
              onClose={() => setSelectedRequest(null)}
              onProcess={handleProcessRequest}
              isProcessing={isProcessing}
            />
          )}
        </AnimatePresence>
      </div>
    </RoleGuard>
  );
}