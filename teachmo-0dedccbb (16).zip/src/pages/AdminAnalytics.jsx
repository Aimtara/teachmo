import React, { useState, useEffect } from 'react';
import { getAdminAnalytics } from '@/api/functions';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Building, School, Activity, AlertCircle, UserCheck, FileText } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import RoleGuard from '@/components/shared/RoleGuard';
import { DashboardSkeleton } from '@/components/shared/ImprovedSkeletons';
import { User } from '@/api/entities';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-2 border rounded-lg shadow-sm">
        <p className="font-bold">{label}</p>
        <p className="text-sm" style={{ color: payload[0].color }}>{`${payload[0].name}: ${payload[0].value}`}</p>
      </div>
    );
  }
  return null;
};

// Component for System-level view
const SystemAnalyticsView = ({ metrics }) => {
  const usersByRoleData = Object.entries(metrics.drillDownData.usersByRole).map(([name, value]) => ({ name: name.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()), value }));
  return (
    <div className="space-y-6">
       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.overview.totalUsers.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">{`+${metrics.userMetrics.newUsersLast30Days} in last 30 days`}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Districts</CardTitle>
            <Building className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.overview.totalDistricts.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Schools</CardTitle>
            <School className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.overview.totalSchools.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Activity Completion</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.engagement.activityCompletionRate}%</div>
            <p className="text-xs text-muted-foreground">{metrics.overview.completedActivities.toLocaleString()} activities completed</p>
          </CardContent>
        </Card>
      </div>
       <Card>
        <CardHeader>
          <CardTitle>Users by Role</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={usersByRoleData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="value" name="Users" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
};

// Component for District-level view
const DistrictAnalyticsView = ({ metrics }) => {
    const schoolData = metrics.schoolBreakdown.map(school => ({
        name: school.name,
        Students: school.studentCount,
        Teachers: school.teacherCount,
    }));
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Schools</CardTitle>
            <School className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.overview.totalSchools.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.overview.totalUsers.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Parent Engagement</CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.engagement.parentEngagementRate}%</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Teacher Engagement</CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.engagement.teacherEngagementRate}%</div>
          </CardContent>
        </Card>
      </div>
      <Card>
        <CardHeader>
            <CardTitle>School Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
            <ResponsiveContainer width="100%" height={300}>
                <BarChart data={schoolData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} interval={0} angle={-45} textAnchor="end" height={80} />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="Students" fill="#8884d8" />
                    <Bar dataKey="Teachers" fill="#82ca9d" />
                </BarChart>
            </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
};

// Component for School-level view
const SchoolAnalyticsView = ({ metrics }) => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Teachers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.overview.totalTeachers.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Parents</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.overview.totalParents.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Students</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.overview.totalStudents.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Assignment Completion</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.performance.assignmentCompletionRate}%</div>
          </CardContent>
        </Card>
      </div>
       <Card>
          <CardHeader>
              <CardTitle>Courses Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Total Courses</p>
                <p className="text-xl font-bold">{metrics.overview.totalCourses}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Assignments</p>
                <p className="text-xl font-bold">{metrics.overview.totalAssignments}</p>
              </div>
            </div>
          </CardContent>
      </Card>
    </div>
  );
};


function AdminAnalyticsPage() {
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const fetchUserAndMetrics = async () => {
      try {
        setLoading(true);
        const currentUser = await User.me();
        setUser(currentUser);

        const userRole = currentUser.user_type || currentUser.role;
        let level = '';
        let scope_id = null;

        switch (userRole) {
          case 'system_admin':
          case 'admin':
            level = 'system';
            break;
          case 'district_admin':
            level = 'district';
            scope_id = currentUser.district_id;
            break;
          case 'school_admin':
            level = 'school';
            scope_id = currentUser.school_id;
            break;
          default:
            throw new Error("User does not have a valid admin role for analytics.");
        }

        if (!level) {
          setError("Could not determine analytics level for your role.");
          setLoading(false);
          return;
        }
        
        const { data } = await getAdminAnalytics({ level, scope_id });
        setMetrics(data);
      } catch (err) {
        console.error("Failed to fetch analytics:", err);
        setError("Could not load analytics data. Please try again later.");
      } finally {
        setLoading(false);
      }
    };
    fetchUserAndMetrics();
  }, []);

  const renderAnalyticsByRole = () => {
    if (!metrics || !user) return null;
    const userRole = user.user_type || user.role;

    switch (userRole) {
      case 'system_admin':
      case 'admin':
        return <SystemAnalyticsView metrics={metrics} />;
      case 'district_admin':
        return <DistrictAnalyticsView metrics={metrics} />;
      case 'school_admin':
        return <SchoolAnalyticsView metrics={metrics} />;
      default:
        return <p>No analytics view available for your role.</p>;
    }
  };
  
  const getPageTitle = () => {
      if (!user) return "Admin Analytics";
      const userRole = user.user_type || user.role;
      switch (userRole) {
        case 'system_admin':
        case 'admin':
          return "System-Wide Analytics";
        case 'district_admin':
          return `District Analytics: ${metrics?.overview?.districtName || ''}`;
        case 'school_admin':
          return `School Analytics: ${metrics?.overview?.schoolName || ''}`;
        default:
          return "Admin Analytics";
      }
  }

  if (loading) return <DashboardSkeleton />;
  if (error) return (
    <div className="p-4 md:p-6 flex items-center justify-center">
      <AlertCircle className="w-8 h-8 text-red-500 mr-4" />
      <p className="text-red-700">{error}</p>
    </div>
  );
  if (!metrics) return <div className="p-4 md:p-6">No analytics data available.</div>;

  return (
    <div className="p-4 md:p-6 space-y-6">
      <header>
        <h1 className="text-3xl font-bold text-gray-900">{getPageTitle()}</h1>
        <p className="text-gray-600">Engagement and administrative metrics for your scope.</p>
      </header>
      {renderAnalyticsByRole()}
    </div>
  );
}

export default function ProtectedAdminAnalytics() {
    return (
        <RoleGuard allowedRoles={['system_admin', 'district_admin', 'school_admin', 'admin']}>
            <AdminAnalyticsPage />
        </RoleGuard>
    );
}