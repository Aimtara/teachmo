import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { 
  Shield, 
  Settings, 
  Users, 
  BarChart3, 
  Globe,
  AlertTriangle,
  Database
} from 'lucide-react';
import { User } from '@/api/entities';
import { useToast } from '@/components/ui/use-toast';
import EnterpriseAdminDashboard from '../components/enterprise/EnterpriseAdminDashboard';
import SSOConfiguration from '../components/enterprise/SSOConfiguration';

export default function EnterpriseAdmin() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const userData = await User.me();
      
      // Check if user has enterprise admin permissions
      if (!['system_admin', 'admin', 'district_admin'].includes(userData.role)) {
        toast({
          variant: "destructive",
          title: "Access Denied",
          description: "You don't have permission to access enterprise administration."
        });
        return;
      }
      
      setUser(userData);
    } catch (error) {
      console.error('Failed to load user data:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load user information."
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen p-6">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!user || !['system_admin', 'admin', 'district_admin'].includes(user.role)) {
    return (
      <div className="min-h-screen p-6 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-12 h-12 mx-auto mb-4 text-red-500" />
            <h2 className="text-xl font-semibold mb-2">Access Denied</h2>
            <p className="text-gray-600">
              You don't have permission to access enterprise administration features.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const organizationId = user.district_id || user.school_id;
  const organizationType = user.district_id ? 'district' : 'school';

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Enterprise Administration</h1>
          <p className="text-gray-600 mt-2">
            Manage enterprise-grade features, security, and compliance for your organization.
          </p>
        </div>

        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="sso" className="flex items-center gap-2">
              <Globe className="w-4 h-4" />
              SSO & Security
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              User Management
            </TabsTrigger>
            <TabsTrigger value="compliance" className="flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Compliance
            </TabsTrigger>
            <TabsTrigger value="system" className="flex items-center gap-2">
              <Database className="w-4 h-4" />
              System Health
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="mt-6">
            <EnterpriseAdminDashboard 
              user={user}
              organizationId={organizationId}
              organizationType={organizationType}
            />
          </TabsContent>

          <TabsContent value="sso" className="mt-6">
            <SSOConfiguration 
              organizationId={organizationId}
              user={user}
            />
          </TabsContent>

          <TabsContent value="users" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Bulk User Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Users className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-600">Enterprise user management features coming soon.</p>
                  <p className="text-sm text-gray-500 mt-2">
                    This will include SCIM provisioning, bulk imports, and automated role management.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="compliance" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Compliance Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Shield className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-600">Comprehensive compliance management coming soon.</p>
                  <p className="text-sm text-gray-500 mt-2">
                    This will include GDPR/CCPA compliance tools, audit reports, and data retention management.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="system" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>System Health & Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Database className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-600">Advanced system monitoring coming soon.</p>
                  <p className="text-sm text-gray-500 mt-2">
                    This will include real-time performance metrics, uptime monitoring, and capacity planning.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}