import React, { useState, useEffect } from 'react';
import { School, District } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Building, 
  Search, 
  Plus, 
  MoreVertical, 
  Edit, 
  Trash2, 
  Users, 
  MapPin,
  Globe,
  Phone,
  Mail
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/components/ui/use-toast';
import CreateSchoolModal from '@/components/admin/CreateSchoolModal';
import RoleGuard from '@/components/shared/RoleGuard';

function SystemSchoolsContent() {
  const [schools, setSchools] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedSchool, setSelectedSchool] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setIsLoading(true);
      const [schoolsData, districtsData] = await Promise.all([
        School.list('-created_date'),
        District.list()
      ]);
      setSchools(schoolsData);
      setDistricts(districtsData);
    } catch (error) {
      console.error('Error loading schools:', error);
      toast({
        variant: "destructive",
        title: "Loading Failed",
        description: "Failed to load schools data."
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateSchool = () => {
    setSelectedSchool(null);
    setShowCreateModal(true);
  };

  const handleEditSchool = (school) => {
    setSelectedSchool(school);
    setShowCreateModal(true);
  };

  const handleDeleteSchool = async (school) => {
    if (window.confirm(`Are you sure you want to delete ${school.name}? This action cannot be undone.`)) {
      try {
        await School.delete(school.id);
        toast({
          title: "School Deleted",
          description: `${school.name} has been deleted.`
        });
        loadData();
      } catch (error) {
        console.error('Error deleting school:', error);
        toast({
          variant: "destructive",
          title: "Delete Failed",
          description: "Failed to delete the school."
        });
      }
    }
  };

  const filteredSchools = schools.filter(school =>
    school.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    school.district_id && districts.find(d => d.id === school.district_id)?.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getDistrictName = (districtId) => {
    const district = districts.find(d => d.id === districtId);
    return district ? district.name : 'Independent';
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pilot': return 'bg-blue-100 text-blue-800';
      case 'district_member': return 'bg-green-100 text-green-800';
      case 'independent': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="h-48 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">All Schools</h1>
          <p className="text-gray-600">
            Manage all schools in the platform ({schools.length} total)
          </p>
        </div>
        <Button onClick={handleCreateSchool} className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Add School
        </Button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <Input
          placeholder="Search schools or districts..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Schools Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSchools.map((school) => (
          <Card key={school.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Building className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{school.name}</CardTitle>
                    <p className="text-sm text-gray-600">{getDistrictName(school.district_id)}</p>
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem onClick={() => handleEditSchool(school)}>
                      <Edit className="w-4 h-4 mr-2" />
                      Edit
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => handleDeleteSchool(school)}
                      className="text-red-600"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <Badge className={getStatusColor(school.status)}>
                  {school.status?.replace('_', ' ')}
                </Badge>
                <Badge variant="outline">
                  {school.school_type}
                </Badge>
              </div>
              
              {school.address && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="w-4 h-4" />
                  <span className="truncate">{school.address}</span>
                </div>
              )}
              
              {school.website && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Globe className="w-4 h-4" />
                  <span className="truncate">{school.website}</span>
                </div>
              )}
              
              {school.phone && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Phone className="w-4 h-4" />
                  <span>{school.phone}</span>
                </div>
              )}
              
              {school.email && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Mail className="w-4 h-4" />
                  <span className="truncate">{school.email}</span>
                </div>
              )}
              
              <div className="flex justify-between text-sm text-gray-500 pt-2 border-t">
                <span className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  {school.student_count || 0} students
                </span>
                <span>{school.teacher_count || 0} teachers</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredSchools.length === 0 && (
        <div className="text-center py-12">
          <Building className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No schools found</h3>
          <p className="text-gray-600">
            {searchQuery ? 'Try adjusting your search criteria.' : 'Get started by adding your first school.'}
          </p>
          {!searchQuery && (
            <Button onClick={handleCreateSchool} className="mt-4">
              <Plus className="w-4 h-4 mr-2" />
              Add School
            </Button>
          )}
        </div>
      )}

      {/* Create/Edit Modal */}
      <CreateSchoolModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onSchoolCreated={loadData}
        editingSchool={selectedSchool}
        districts={districts}
      />
    </div>
  );
}

export default function SystemSchools() {
  return (
    <RoleGuard allowedRoles={['system_admin', 'admin']}>
      <SystemSchoolsContent />
    </RoleGuard>
  );
}