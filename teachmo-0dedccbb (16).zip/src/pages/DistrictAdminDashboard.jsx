import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  GraduationCap, 
  TrendingUp, 
  MessageSquare,
  BarChart3,
  Settings,
  AlertTriangle,
  ChevronRight,
  Activity,
  UserCheck,
  Building2
} from 'lucide-react';
import { getAdminAnalytics } from '@/api/functions';
import RoleGuard from '@/components/shared/RoleGuard';

function ClickableMetricCard({ title, value, icon: Icon, linkTo, subtitle, trend, trendDirection }) {
  const CardWrapper = linkTo ? Link : 'div';
  const cardProps = linkTo ? { to: linkTo } : {};

  return (
    <CardWrapper {...cardProps}>
      <Card className={`transition-all duration-200 ${linkTo ? 'hover:shadow-lg hover:scale-105 cursor-pointer' : ''}`}>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-gray-600">{title}</p>
                {linkTo && <ChevronRight className="w-4 h-4 text-gray-400" />}
              </div>
              <div className="flex items-center gap-2 mt-1">
                <p className="text-2xl font-bold text-gray-900">{value}</p>
                {trend && (
                  <Badge variant={trendDirection === 'up' ? 'default' : 'secondary'} className="text-xs">
                    {trendDirection === 'up' ? '↗' : '→'} {trend}
                  </Badge>
                )}
              </div>
              {subtitle && <p className="text-xs text-gray-500 mt-1">{subtitle}</p>}
            </div>
            <div className="ml-4">
              <Icon className="w-8 h-8 text-blue-600" />
            </div>
          </div>
        </CardContent>
      </Card>
    </CardWrapper>
  );
}

function DistrictAdminDashboardContent({ user }) {
  const [analytics, setAnalytics] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadAnalytics();
  }, [user]);

  const loadAnalytics = async () => {
    try {
      setIsLoading(true);
      const response = await getAdminAnalytics({ 
        level: 'district', 
        scope_id: user?.district_id 
      });
      setAnalytics(response.data);
    } catch (err) {
      console.error('Failed to load analytics:', err);
      setError('Failed to load district analytics');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center">
            <AlertTriangle className="w-5 h-5 text-red-600 mr-2" />
            <p className="text-red-800">{error}</p>
          </div>
          <Button onClick={loadAnalytics} className="mt-3" variant="outline">
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">District Dashboard</h1>
          <p className="text-gray-600 mt-1">{analytics?.overview?.districtName || 'District Overview'}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={loadAnalytics}>
            <Activity className="w-4 h-4 mr-2" />
            Refresh Data
          </Button>
          <Link to={createPageUrl('DistrictSchools')}>
            <Button>
              <GraduationCap className="w-4 h-4 mr-2" />
              Manage Schools
            </Button>
          </Link>
        </div>
      </div>

      {/* Primary Metrics - Clickable */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <ClickableMetricCard
          title="Schools"
          value={analytics?.overview?.totalSchools?.toLocaleString() || '0'}
          icon={GraduationCap}
          linkTo={createPageUrl('DistrictSchools')}
          subtitle="Active schools in district"
        />
        
        <ClickableMetricCard
          title="Total Users"
          value={analytics?.overview?.totalUsers?.toLocaleString() || '0'}
          icon={Users}
          linkTo={createPageUrl('DistrictUsers')}
          subtitle="All district users"
        />
        
        <ClickableMetricCard
          title="Teachers"
          value={analytics?.overview?.totalTeachers?.toLocaleString() || '0'}
          icon={UserCheck}
          linkTo={createPageUrl('DistrictUsers', 'role=teacher')}
          subtitle={`${analytics?.engagement?.teacherEngagementRate || 0}% active`}
        />
        
        <ClickableMetricCard
          title="Parents"
          value={analytics?.overview?.totalParents?.toLocaleString() || '0'}
          icon={Users}
          linkTo={createPageUrl('DistrictUsers', 'role=parent')}
          subtitle={`${analytics?.engagement?.parentEngagementRate || 0}% engaged`}
        />
      </div>

      {/* Secondary Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <ClickableMetricCard
          title="Announcements"
          value={analytics?.overview?.totalAnnouncements?.toLocaleString() || '0'}
          icon={MessageSquare}
          linkTo={createPageUrl('Announcements')}
          subtitle="District communications"
        />
        
        <ClickableMetricCard
          title="Completed Activities"
          value={analytics?.overview?.completedActivities?.toLocaleString() || '0'}
          icon={Activity}
          linkTo={createPageUrl('DistrictAnalytics')}
          subtitle={`${analytics?.engagement?.activityCompletionRate || 0}% completion rate`}
        />
        
        <ClickableMetricCard
          title="Analytics"
          value="View Details"
          icon={BarChart3}
          linkTo={createPageUrl('DistrictAnalytics')}
          subtitle="Detailed district metrics"
        />
      </div>

      {/* Schools in District */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Schools in District</CardTitle>
          <Link to={createPageUrl('DistrictSchools')}>
            <Button variant="ghost" size="sm">
              Manage All <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {analytics?.schoolBreakdown?.slice(0, 8).map((school) => (
              <Link 
                key={school.id} 
                to={createPageUrl('SchoolAnalytics', `school_id=${school.id}`)}
                className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{school.name}</p>
                    <p className="text-sm text-gray-500">
                      {school.teacherCount} teachers • {school.studentCount} students
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={school.isActive ? 'default' : 'secondary'}>
                    {school.isActive ? 'Active' : 'Inactive'}
                  </Badge>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </div>
              </Link>
            ))}
            {analytics?.schoolBreakdown?.length > 8 && (
              <div className="text-center pt-3">
                <Link to={createPageUrl('DistrictSchools')} className="text-blue-600 hover:underline text-sm">
                  View {analytics.schoolBreakdown.length - 8} more schools
                </Link>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recent Announcements */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Recent Announcements</CardTitle>
          <Link to={createPageUrl('Announcements')}>
            <Button variant="ghost" size="sm">
              View All <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {analytics?.drillDownData?.recentAnnouncements?.map((announcement) => (
              <div key={announcement.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{announcement.title}</p>
                  <p className="text-sm text-gray-500">
                    {new Date(announcement.createdDate).toLocaleDateString()}
                  </p>
                </div>
                {announcement.isUrgent && (
                  <Badge variant="destructive">Urgent</Badge>
                )}
              </div>
            ))}
            {(!analytics?.drillDownData?.recentAnnouncements || analytics.drillDownData.recentAnnouncements.length === 0) && (
              <p className="text-gray-500 text-center py-4">No recent announcements</p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link to={createPageUrl('DistrictUsers')}>
              <Button variant="outline" className="w-full justify-start">
                <Users className="w-4 h-4 mr-2" />
                Manage Users
              </Button>
            </Link>
            <Link to={createPageUrl('DistrictSchools')}>
              <Button variant="outline" className="w-full justify-start">
                <GraduationCap className="w-4 h-4 mr-2" />
                Manage Schools
              </Button>
            </Link>
            <Link to={createPageUrl('DistrictAnalytics')}>
              <Button variant="outline" className="w-full justify-start">
                <BarChart3 className="w-4 h-4 mr-2" />
                View Analytics
              </Button>
            </Link>
            <Link to={createPageUrl('DistrictSettings')}>
              <Button variant="outline" className="w-full justify-start">
                <Settings className="w-4 h-4 mr-2" />
                District Settings
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function DistrictAdminDashboard() {
  return (
    <RoleGuard allowedRoles={['district_admin', 'system_admin', 'admin']}>
      <DistrictAdminDashboardContent />
    </RoleGuard>
  );
}