import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Users, MessageSquare, Compass, ShieldAlert } from 'lucide-react';
import CommunityFeed from '@/components/community/CommunityFeed';
import CommunityPods from '@/components/community/CommunityPods';
import CommunityMessages from '@/components/community/CommunityMessages';
import ReportConcernModal from '@/components/community/ReportConcernModal';

export default function UnifiedCommunity() {
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b bg-white flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Community</h1>
          <p className="text-sm text-gray-500">Connect, share, and learn with other parents.</p>
        </div>
        <Button variant="outline" onClick={() => setIsReportModalOpen(true)}>
          <ShieldAlert className="mr-2 h-4 w-4" />
          Report a Concern
        </Button>
      </div>
      
      <Tabs defaultValue="feed" className="flex-1 flex flex-col">
        <div className="px-4 pt-2 bg-white border-b">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="feed">
              <Compass className="w-4 h-4 mr-2" />
              Feed
            </TabsTrigger>
            <TabsTrigger value="pods">
              <Users className="w-4 h-4 mr-2" />
              Pods
            </TabsTrigger>
            <TabsTrigger value="messages">
              <MessageSquare className="w-4 h-4 mr-2" />
              Messages
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="feed" className="flex-1 bg-gray-50 overflow-y-auto">
          <CommunityFeed />
        </TabsContent>
        <TabsContent value="pods" className="flex-1 bg-gray-50 overflow-y-auto">
          <CommunityPods />
        </TabsContent>
        <TabsContent value="messages" className="flex-1 bg-gray-50 overflow-y-auto">
          <CommunityMessages />
        </TabsContent>
      </Tabs>
      
      <ReportConcernModal
        open={isReportModalOpen}
        onOpenChange={setIsReportModalOpen}
        contentType="general"
        contentId="community_space"
        reportedUserId="system"
      />
    </div>
  );
}