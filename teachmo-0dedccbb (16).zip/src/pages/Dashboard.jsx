
import React, { useState, useEffect, useCallback } from "react";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User, Child, Activity, ParentingTip, Achievement, UserAchievement, JournalEntry, Assignment, StudentParentLink } from "@/api/entities";
import { Loader2, Plus, Target, TrendingUp, Calendar, Users, BookOpen, Sparkles, ArrowRight, CheckCircle, Clock, Bot, AlertCircle, RefreshCw, MessageSquare, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format, isToday, startOfWeek, endOfWeek, parseISO, isYesterday } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

import EmotionalCheckIn from "../components/dashboard/EmotionalCheckIn";
import { usePremium } from "../components/shared/usePremium";
import QuickChildSetup from "../components/dashboard/QuickChildSetup";
import { DashboardSkeleton } from "../components/shared/ImprovedSkeletons";
import { SkipLink } from "../components/shared/SkipLink";
import { useAccessibility } from "../components/shared/AccessibilityProvider";
import QuickTips from "../components/tour/QuickTips";
import ProgressCelebration from "../components/tour/ProgressCelebration";
import { fetchWithRetry, retryAuthCall, checkNetworkStatus, withGracefulDegradation } from "@/components/shared/apiUtils";
import { useToast } from "@/components/ui/use-toast";
import TodaysFocus from "../components/dashboard/TodaysFocus";
import QuickActionBar from "../components/dashboard/QuickActionBar";
import OffersCarousel from "../components/offers/OffersCarousel";
import PersonalizedInsights from "../components/dashboard/PersonalizedInsights";
import PersonalizedDashboard from "../components/dashboard/PersonalizedDashboard";

import { useDashboardData } from '@/components/hooks/useDashboardData';
import { useDashboardPersonalization } from "../components/shared/SmartDefaults";

import { EmptyState, NetworkStatus } from '@/components/shared/LoadingStates';
import { ApiProvider } from '@/components/shared/ApiProvider';
import BreadcrumbNavigation from '@/components/shared/BreadcrumbNavigation';

import InteractiveOnboardingTour from '../components/tour/InteractiveOnboardingTour';
import FeedbackSystem from '../components/shared/FeedbackSystem';
import UniversalEmptyState from '../components/shared/UniversalEmptyState';

export default function Dashboard() {
  // Use the new custom hook for data fetching and state management
  const { data, isLoading, error, reload: loadDashboardData } = useDashboardData();
  
  // Destructure with safe defaults to prevent undefined errors
  const { 
    user = null, 
    children = [], 
    activities = [], 
    tips = [], 
    weeklyStats = {
      activitiesCompleted: 0,
      activitiesPlanned: 0,
      streak: 0,
      tipProgress: 0,
      totalTips: 0
    }
  } = data || {};

  // Local UI state remains in the component
  const [showCelebration, setShowCelebration] = useState(false);
  const [celebrationData, setCelebrationData] = useState(null);
  const [showOnboardingTour, setShowOnboardingTour] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  
  const { isPremium } = usePremium();
  const { announceToScreenReader } = useAccessibility();
  const { toast } = useToast();
  const { layout: dashboardLayout, isSimpleMode, toggleSimpleMode } = useDashboardPersonalization();

  // Network status monitoring remains the same
  const [networkStatus, setNetworkStatus] = useState(checkNetworkStatus());
  useEffect(() => {
    const handleOnline = () => {
      const newStatus = checkNetworkStatus();
      setNetworkStatus(newStatus);
      if (newStatus.online && error) { // Only attempt reload if there was a previous error
        announceToScreenReader("Connection restored. Reloading data.");
        loadDashboardData();
      }
    };

    const handleOffline = () => {
      const newStatus = checkNetworkStatus();
      setNetworkStatus(newStatus);
      announceToScreenReader("Connection lost. Some features may not work properly.");
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [announceToScreenReader, error, loadDashboardData]);
  
  // Logic for triggering achievements now depends on the data from the hook
  useEffect(() => {
    if (!user || isLoading) return;

    const userAchievements = user.tutorial_progress?.achievements || [];

    // Check for first activity completion
    if (activities.some(a => a.status === 'completed') && 
        !userAchievements.includes('first_activity')) {
      triggerAchievement('first_activity');
    }

    // Check for activity streak
    if (weeklyStats.activitiesCompleted >= 3 && 
        !userAchievements.includes('activity_streak_3')) {
      triggerAchievement('activity_streak_3');
    }
  }, [user, activities, weeklyStats.activitiesCompleted, isLoading]);

  // Check if user should see onboarding tour (enhanced logic)
  useEffect(() => {
    if (user && !user.has_seen_dashboard_tour && !user.tutorial_progress?.hasSeenTutorial) {
      // Only show if they haven't explicitly dismissed it or completed it
      if (!user.tutorial_progress?.isDismissed) {
        setShowOnboardingTour(true);
      }
    }
  }, [user]);

  const handleTourComplete = async () => {
    setShowOnboardingTour(false);
    try {
      await User.updateMyUserData({ 
        has_seen_dashboard_tour: true, // Legacy flag
        tutorial_progress: {
          ...(user.tutorial_progress || {}),
          hasSeenTutorial: true,
          isDismissed: false, // Ensure not dismissed if completed
          completedAt: new Date().toISOString()
        }
      });
      loadDashboardData(); // Reload to update user data
    } catch (error) {
      console.error('Error updating tour status:', error);
      toast({
        variant: "destructive",
        title: "Tour Update Failed",
        description: "Could not save your tour progress. Please try again.",
      });
    }
  };

  const handleTourSkip = async () => {
    setShowOnboardingTour(false);
    try {
      await User.updateMyUserData({ 
        has_seen_dashboard_tour: true, // Legacy flag
        tutorial_progress: {
          ...(user.tutorial_progress || {}),
          hasSeenTutorial: false, // Not completed
          isDismissed: true // Marked as dismissed
        }
      });
    } catch (error) {
      console.error('Error updating tour status:', error);
      toast({
        variant: "destructive",
        title: "Tour Update Failed",
        description: "Could not save your tour skip preference. Please try again.",
      });
    }
  };

  const triggerAchievement = async (achievementType) => {
    try {
      const currentAchievements = user?.tutorial_progress?.achievements || [];
      if (currentAchievements.includes(achievementType)) return;

      const updatedTutorialProgress = {
        ...(user?.tutorial_progress || {}),
        achievements: [...currentAchievements, achievementType]
      };

      await User.updateMyUserData({
        tutorial_progress: updatedTutorialProgress
      });
      
      // No need to call setUser locally, the hook's data will be the source of truth on next reload
      
      setCelebrationData({ type: achievementType });
      setShowCelebration(true);
      
      toast({
        title: "🎉 Achievement Unlocked!",
        description: `You've earned the "${achievementType.replace(/_/g, ' ')}" badge.`,
      });

      announceToScreenReader(`Achievement unlocked: ${achievementType.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}`);
    } catch (error) {
      console.error('Error saving achievement:', error);
      toast({
        variant: "destructive",
        title: "Oh no!",
        description: "There was a problem saving your achievement.",
      });
      announceToScreenReader("Failed to unlock achievement.");
    }
  };

  const handleMoodUpdate = async (newMood) => {
    try {
      await User.updateMyUserData({
        current_mood: newMood,
        last_mood_checkin: new Date().toISOString()
      });
      
      // Reload dashboard data to get fresh user object
      loadDashboardData();

      announceToScreenReader(`Mood updated to ${newMood}`);
    } catch (error) {
      announceToScreenReader("Failed to update mood");
      toast({
        variant: "destructive",
        title: "Mood Update Failed",
        description: "Could not update your mood. Please try again.",
      });
    }
  };

  const handleChildAdded = async () => {
    // Reload all dashboard data to reflect new child
    loadDashboardData();
    toast({
      title: "Child Added!",
      description: "Your child's profile has been successfully added.",
    });
  };

  // Calculate derived state with safe checks
  const hasChildren = Array.isArray(children) && children.length > 0;
  const hasPlannedActivities = Array.isArray(activities) && activities.some(a => a && a.status === 'planned');
  
  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="max-w-7xl mx-auto">
          <DashboardSkeleton />
        </div>
      </div>
    );
  }

  // Error states are now simpler, relying on the hook's error object
  if (error) {
    return (
      <div className="min-h-screen p-4 md:p-6 flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <Alert variant="destructive" className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="space-y-3">
            <p>{error.message || 'Unable to load your dashboard.'}</p>
            <Button onClick={loadDashboardData} variant="outline" className="w-full">
              <RefreshCw className="w-4 h-4 mr-2" />
              Retry Loading
            </Button>
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <ApiProvider>
      <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <SkipLink />
        <BreadcrumbNavigation />

        {/* Enhanced Network Status */}
        {!networkStatus.online && (
          <Alert className="mb-4 border-yellow-300 bg-yellow-50">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              You're currently offline. Some features may not work properly.
            </AlertDescription>
          </Alert>
        )}
        
        {/* Quick Tips for contextual help */}
        <QuickTips currentPage="Dashboard" />
        
        {/* Achievement Celebration */}
        <ProgressCelebration
          achievement={celebrationData}
          show={showCelebration}
          onClose={() => setShowCelebration(false)}
        />

        {/* Interactive Onboarding Tour */}
        {showOnboardingTour && (
          <InteractiveOnboardingTour
            user={user}
            onComplete={handleTourComplete}
            onSkip={handleTourSkip}
          />
        )}

        {/* Feedback System */}
        <FeedbackSystem
          isOpen={showFeedback}
          onClose={() => setShowFeedback(false)}
          context="dashboard"
          user={user}
        />

        <main id="main-content" className="max-w-7xl mx-auto space-y-6">
          {/* Enhanced Header with safe user access */}
          <header className="mb-6 flex justify-between items-start">
            <div>
              <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">
                {new Date().getHours() < 12 ? 'Good morning' : new Date().getHours() < 17 ? 'Good afternoon' : 'Good evening'}, {user?.full_name?.split(' ')[0] || 'Parent'}! 
              </h1>
              {weeklyStats?.streak > 0 && (
                <div className="flex items-center gap-2 text-orange-600 font-medium" aria-label={`${weeklyStats.streak} day login streak`}>
                  <span role="img" aria-label="Fire emoji">🔥</span> 
                  <span>{weeklyStats.streak} day streak</span>
                </div>
              )}
            </div>
            <div className="flex items-center space-x-2 pt-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setShowFeedback(true)}
                className="text-gray-600 hover:text-gray-800"
              >
                <MessageSquare className="w-4 h-4 mr-1" />
                Feedback
              </Button>
              <div className="flex items-center space-x-2">
                <Label htmlFor="simple-mode-switch" className="text-sm font-medium text-gray-600">Simple View</Label>
                <Switch
                  id="simple-mode-switch"
                  checked={isSimpleMode}
                  onCheckedChange={toggleSimpleMode}
                  aria-label="Toggle simple dashboard view"
                />
              </div>
            </div>
          </header>

          {/* Enhanced Empty State for No Children with safe checks */}
          {!hasChildren && user && (
            <UniversalEmptyState 
              context="no-children" 
              userType={user.user_type}
              size="large"
              onActionClick={loadDashboardData}
            />
          )}

          {/* Rest of dashboard content, only visible if hasChildren */}
          {hasChildren && user && (
            <>
              {/* Main Dashboard Layout */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                
                {/* Main Content Column */}
                <div className="lg:col-span-8 space-y-8">
                  {/* TODAY'S FOCUS with safe props */}
                  <div data-tour="todays-focus">
                    <TodaysFocus
                      user={user}
                      activities={activities}
                      schoolAssignments={[]}
                      messages={[]}
                      onUpdate={loadDashboardData}
                    />
                  </div>

                  {/* QUICK ACTION BAR with safe props */}
                  <QuickActionBar 
                    user={user}
                    children={children}
                    hasChildren={hasChildren}
                    hasPlannedActivities={hasPlannedActivities}
                    hasPremium={isPremium}
                  />
                  
                  <AnimatePresence>
                    {!isSimpleMode && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="space-y-8 overflow-hidden"
                      >
                        {/* EMOTIONAL CHECK-IN with safe user prop */}
                        <div data-tour="emotional-check-in">
                          <EmotionalCheckIn user={user} onMoodUpdate={handleMoodUpdate} />
                        </div>

                        {/* AD/OFFER CAROUSEL */}
                        <OffersCarousel />

                        {/* PERSONALIZED INSIGHTS with safe props */}
                        <PersonalizedInsights 
                          user={user}
                          children={children} 
                          activities={activities} 
                          assignments={[]}
                          schoolAssignments={[]}
                          tips={tips}
                          onUpdate={loadDashboardData}
                        />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Right Sidebar Column */}
                <div className="lg:col-span-4 space-y-8">
                  {/* PARENTING TIP CARD with safe array access */}
                  {Array.isArray(tips) && tips.length > 0 && (
                    <Card className="shadow-lg" data-tour="parenting-tip">
                      <CardHeader>
                        <CardTitle className="text-xl flex items-center justify-between">
                          <span>Parenting Tip of the Day</span>
                          <BookOpen className="w-5 h-5 text-purple-600" />
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-700 mb-4">{tips[0].title}</p>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <Link to={createPageUrl("Tips")} className="flex-1">
                            <Button variant="outline" className="w-full">
                              All Tips
                            </Button>
                          </Link>
                          <Link to={createPageUrl("UnifiedDiscover", {tab: 'activities'})} className="flex-1">
                            <Button variant="default" className="w-full bg-purple-600 hover:bg-purple-700">
                              Related Activities <ArrowRight className="ml-2 h-4 w-4" />
                            </Button>
                          </Link>
                        </div>
                        {!isPremium && (
                          <div className="mt-4 text-center text-sm text-gray-500">
                            Unlock more personalized tips with <Link to={createPageUrl("Premium")} className="text-purple-600 font-semibold hover:underline">Premium</Link>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}

                  <AnimatePresence>
                    {!isSimpleMode && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="space-y-8 overflow-hidden"
                      >
                        {/* WEEKLY STATS CARD with safe weeklyStats access */}
                        <Card className="shadow-lg" data-tour="weekly-stats">
                          <CardHeader>
                            <CardTitle className="text-xl flex items-center justify-between">
                              <span>Your Weekly Progress</span>
                              <TrendingUp className="w-5 h-5 text-green-600" />
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            <div className="flex items-center justify-between">
                              <span className="text-gray-700">Activities Completed:</span>
                              <Badge variant="secondary" className="bg-green-100 text-green-700 text-base py-1 px-3">
                                {weeklyStats?.activitiesCompleted || 0}
                              </Badge>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-gray-700">Planned Activities:</span>
                              <Badge variant="secondary" className="bg-blue-100 text-blue-700 text-base py-1 px-3">
                                {weeklyStats?.activitiesPlanned || 0}
                              </Badge>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-gray-700">Login Streak:</span>
                              <Badge variant="secondary" className="bg-orange-100 text-orange-700 text-base py-1 px-3">
                                {weeklyStats?.streak || 0} Days 🔥
                              </Badge>
                            </div>
                            {(weeklyStats?.totalTips || 0) > 0 && (
                              <div>
                                <div className="flex items-center justify-between text-gray-700 mb-2">
                                  <span>Tips Read:</span>
                                  <span>{weeklyStats?.tipProgress || 0}/{weeklyStats?.totalTips || 0}</span>
                                </div>
                                <Progress value={((weeklyStats?.tipProgress || 0) / (weeklyStats?.totalTips || 1)) * 100} className="h-2" />
                              </div>
                            )}
                          </CardContent>
                        </Card>

                        {/* CHILD CARDS with safe children array access */}
                        <Card className="shadow-lg" data-tour="child-overview">
                          <CardHeader className="flex flex-row items-center justify-between pb-2">
                            <CardTitle className="text-xl">Your Children</CardTitle>
                            <Link to={createPageUrl("Children")}>
                              <Button variant="ghost" size="sm">
                                Manage All
                              </Button>
                            </Link>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-4">
                              {children.slice(0, 3).map(child => (
                                <div key={child?.id} className="flex items-center justify-between py-2 border-b last:border-b-0">
                                  <div className="flex items-center gap-3">
                                    <span className="text-2xl" role="img" aria-label="Child avatar">{child?.avatar || '👶'}</span>
                                    <div>
                                      <p className="font-semibold text-gray-800">{child?.name || 'Unnamed Child'}</p>
                                      <p className="text-sm text-gray-500">{child?.age || 0} years old</p>
                                    </div>
                                  </div>
                                  <Link to={createPageUrl("ChildProfile", { childId: child?.id })}>
                                    <Button variant="outline" size="sm">View</Button>
                                  </Link>
                                </div>
                              ))}
                              {children.length > 3 && (
                                <div className="text-center pt-2">
                                  <Link to={createPageUrl("Children")} className="text-blue-600 hover:underline text-sm">
                                    View {children.length - 3} more children
                                  </Link>
                                </div>
                              )}
                              <Link to={createPageUrl("ChildSetup")}>
                                <Button variant="ghost" className="w-full mt-2 border border-dashed">
                                  <Plus className="mr-2 h-4 w-4" /> Add New Child
                                </Button>
                              </Link>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>

              <AnimatePresence>
                {!isSimpleMode && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    {/* PERSONALIZED DASHBOARD with safe props */}
                    <PersonalizedDashboard
                      user={user}
                      children={children}
                      activities={activities}
                      schoolAssignments={[]}
                      weeklyStats={weeklyStats}
                      onMoodUpdate={handleMoodUpdate}
                      tips={tips}
                      isPremium={isPremium}
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </>
          )}
        </main>
      </div>
    </ApiProvider>
  );
}
