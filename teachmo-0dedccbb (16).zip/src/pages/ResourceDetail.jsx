import React, { useState, useEffect } from "react";
import { LibraryResource, UserActivity, UserBookmark } from "@/api/entities";
import { useLocation, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Clock, Users, BookOpen, FileText, Video, User as UserIcon, AlertTriangle, Bookmark, BookmarkCheck, Share2 } from "lucide-react";
import { motion } from "framer-motion";
import { Breadcrumb } from "@/components/ui/breadcrumb";
import ResourceCard from "../components/library/ResourceCard";

const typeIcons = {
  article: FileText,
  video: Video,
  guide: BookOpen,
  research: Users
};

const categoryColors = {
  communication: "bg-blue-100 text-blue-800",
  discipline: "bg-red-100 text-red-800",
  development: "bg-green-100 text-green-800",
  education: "bg-purple-100 text-purple-800",
  health: "bg-pink-100 text-pink-800",
  creativity: "bg-orange-100 text-orange-800",
  social_skills: "bg-indigo-100 text-indigo-800",
  emotional_intelligence: "bg-teal-100 text-teal-800",
  independence: "bg-yellow-100 text-yellow-800",
  confidence: "bg-emerald-100 text-emerald-800",
  safety: "bg-gray-100 text-gray-800",
  nutrition: "bg-lime-100 text-lime-800"
};

const getEmbedUrl = (url) => {
  if (!url) return null;
  let videoId;
  
  if (url.includes("youtube.com/watch")) {
    videoId = url.split('v=')[1];
    const ampersandPosition = videoId.indexOf('&');
    if (ampersandPosition !== -1) {
      videoId = videoId.substring(0, ampersandPosition);
    }
    return `https://www.youtube.com/embed/${videoId}`;
  }
  
  if (url.includes("youtu.be")) {
    videoId = url.split('youtu.be/')[1];
    const queryParamPosition = videoId.indexOf('?');
    if (queryParamPosition !== -1) {
      videoId = videoId.substring(0, queryParamPosition);
    }
    return `https://www.youtube.com/embed/${videoId}`;
  }

  if (url.includes("vimeo.com")) {
    const vimeoId = url.substring(url.lastIndexOf('/') + 1);
    return `https://player.vimeo.com/video/${vimeoId}`;
  }

  return null;
};

export default function ResourceDetail() {
  const [resource, setResource] = useState(null);
  const [relatedResources, setRelatedResources] = useState([]);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const resourceId = params.get('id');

    if (resourceId && resourceId !== 'undefined' && resourceId !== 'null') {
      loadResource(resourceId);
    } else {
      setError("No valid resource ID was provided.");
      setIsLoading(false);
    }
  }, [location.search]);

  const loadResource = async (id) => {
    setIsLoading(true);
    setError(null);
    try {
      const resourceData = await LibraryResource.get(id);
      setResource(resourceData);
      
      if (id && resourceData) {
        await UserActivity.create({
          resource_id: id,
          resource_type: 'library_resource',
          action: 'viewed'
        });

        const bookmarks = await UserBookmark.filter({ resource_id: id });
        setIsBookmarked(bookmarks.length > 0);

        const related = await LibraryResource.filter(
          { category: resourceData.category },
          '-created_date',
          4
        );
        setRelatedResources(related.filter(r => r.id !== id).slice(0, 3));
      }

    } catch (error) {
      console.error("Error loading resource:", error);
      setError("Could not load the resource. It may have been removed.");
      setResource(null);
    }
    setIsLoading(false);
  };
  
  const handleBookmarkToggle = async () => {
    if (!resource) return;
    const isCurrentlyBookmarked = isBookmarked;
    setIsBookmarked(!isCurrentlyBookmarked);
    try {
      if (isCurrentlyBookmarked) {
        const bookmarks = await UserBookmark.filter({ resource_id: resource.id });
        if (bookmarks.length > 0) {
            await UserBookmark.delete(bookmarks[0].id);
        }
      } else {
        await UserBookmark.create({
          resource_id: resource.id,
          resource_type: 'library_resource'
        });
      }
    } catch(err) {
        console.error("Failed to toggle bookmark", err);
        setIsBookmarked(isCurrentlyBookmarked);
    }
  };

  const handleShare = () => {
    if(resource && navigator.share) {
        navigator.share({
            title: resource.title,
            text: resource.description,
            url: window.location.href,
        }).catch((error) => console.error('Error sharing:', error));
    } else if (resource) {
        navigator.clipboard.writeText(window.location.href);
        alert('Link copied to clipboard!');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="max-w-4xl mx-auto">
          <Skeleton className="h-6 w-64 mb-4" />
          <Skeleton className="h-8 w-1/4 mb-6" />
          <Skeleton className="h-12 w-3/4 mb-4" />
          <div className="flex gap-4 mb-6">
            <Skeleton className="h-6 w-24" />
            <Skeleton className="h-6 w-24" />
          </div>
          <Skeleton className="h-4 w-full mb-2" />
          <Skeleton className="h-4 w-full mb-2" />
          <Skeleton className="h-4 w-5/6" />
        </div>
      </div>
    );
  }

  if (!resource || error) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="text-center bg-white p-8 rounded-lg shadow-md">
          <AlertTriangle className="w-12 h-12 mx-auto mb-4 text-red-500" />
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Resource Not Found</h2>
          <p className="text-gray-600 mb-6 max-w-sm">
            {error || "The resource you're looking for doesn't exist or has been removed."}
          </p>
          <Link to={createPageUrl("Library")}>
            <Button>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Library
            </Button>
          </Link>
        </div>
      </div>
    );
  }
  
  const TypeIcon = typeIcons[resource.type] || FileText;
  const embedUrl = getEmbedUrl(resource.video_url);
  
  // Fix: Add safe handling for category
  const categoryDisplay = resource.category ? resource.category.replace(/_/g, ' ') : "Resource";
  
  const breadcrumbItems = [
    { label: "Library", href: createPageUrl("Library") },
    { label: categoryDisplay },
    { label: resource.title }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen p-4 md:p-8"
      style={{backgroundColor: 'var(--teachmo-cream)'}}
    >
      <div className="max-w-4xl mx-auto">
        <Breadcrumb items={breadcrumbItems} />
        
        <article className="bg-white/90 backdrop-blur-sm p-6 md:p-10 rounded-2xl shadow-lg">
          <header className="mb-8">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 mb-4">
                  <TypeIcon className="w-6 h-6" style={{color: 'var(--teachmo-sage)'}} />
                  <Badge className={categoryColors[resource.category] || "bg-gray-100 text-gray-800"}>
                    {categoryDisplay}
                  </Badge>
                </div>
                <div className="flex items-center gap-2">
                    <Button variant="ghost" size="icon" onClick={handleBookmarkToggle} aria-label={isBookmarked ? "Remove from bookmarks" : "Add to bookmarks"}>
                        {isBookmarked ? <BookmarkCheck className="w-5 h-5 text-purple-600" /> : <Bookmark className="w-5 h-5 text-gray-500" />}
                    </Button>
                    <Button variant="ghost" size="icon" onClick={handleShare} aria-label="Share resource">
                        <Share2 className="w-5 h-5 text-gray-500" />
                    </Button>
                </div>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 leading-tight">{resource.title}</h1>
            <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-gray-600">
              {resource.author && (
                <div className="flex items-center gap-2">
                  <UserIcon className="w-4 h-4" />
                  <span>By {resource.author}</span>
                </div>
              )}
              {resource.duration && (
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  <span>{resource.duration}</span>
                </div>
              )}
              {resource.age_range && (
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  <span>Ages {resource.age_range.min_age}-{resource.age_range.max_age}</span>
                </div>
              )}
            </div>
          </header>

          {resource.type === 'video' && embedUrl && (
            <div className="mb-6 rounded-lg overflow-hidden shadow-lg" style={{ position: 'relative', paddingBottom: '56.25%', height: 0 }}>
              <iframe
                src={embedUrl}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="w-full h-full"
                style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' }}
              ></iframe>
            </div>
          )}
          
          <div className="prose prose-lg max-w-none text-gray-800">
            <p className="lead text-xl text-gray-700 mb-6">{resource.description}</p>
            <div dangerouslySetInnerHTML={{ __html: (resource.content || '').replace(/\n/g, '<br />') }} />
          </div>
          
          {resource.tags && resource.tags.length > 0 && (
            <footer className="mt-10 pt-6 border-t border-gray-200">
              <h3 className="font-semibold text-gray-700 mb-3">Related Topics:</h3>
              <div className="flex flex-wrap gap-2">
                {resource.tags.map((tag, index) => (
                  <Badge key={index} variant="outline" className="text-sm bg-gray-50">
                    {tag}
                  </Badge>
                ))}
              </div>
            </footer>
          )}
        </article>

        {relatedResources.length > 0 && (
          <section className="mt-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Related Resources</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {relatedResources.map(related => (
                <ResourceCard 
                  key={related.id}
                  resource={related}
                  onBookmark={() => { /* No-op for related resources here */ }} 
                  onView={() => { /* No-op for related resources here */ }}
                />
              ))}
            </div>
          </section>
        )}
      </div>
    </motion.div>
  );
}