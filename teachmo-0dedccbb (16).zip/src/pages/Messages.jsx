import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, Send, User, Search, Plus, ArrowLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { useSupabase } from '@/components/shared/SupabaseProvider';
import { User as TeachmoUser } from '@/api/entities';
import ConversationList from '@/components/messages/ConversationList';
import ChatWindow from '@/components/messages/ChatWindow';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function Messages() {
  const [user, setUser] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [activeConversation, setActiveConversation] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const { supabase, isConfigured, user: supabaseUser } = useSupabase();

  useEffect(() => {
    const loadUserData = async () => {
      try {
        const userData = await TeachmoUser.me();
        setUser(userData);
        
        if (isConfigured && supabase) {
          await loadConversations();
        }
      } catch (err) {
        console.error('Failed to load user data:', err);
        setError('Failed to load messaging data');
      } finally {
        setIsLoading(false);
      }
    };

    loadUserData();
  }, [isConfigured, supabase]);

  const loadConversations = async () => {
    if (!supabase || !user) return;

    try {
      const { data: threads, error } = await supabase
        .from('message_threads')
        .select(`
          *,
          messages (
            id,
            content,
            created_at,
            sender_id
          )
        `)
        .eq('participants', user.id)
        .order('updated_at', { ascending: false });

      if (error) throw error;

      setConversations(threads || []);
    } catch (err) {
      console.error('Failed to load conversations:', err);
      setError('Failed to load conversations');
    }
  };

  const handleSendMessage = async (content) => {
    if (!supabase || !activeConversation || !user) return;

    try {
      const { data: message, error } = await supabase
        .from('messages')
        .insert({
          thread_id: activeConversation.id,
          sender_id: user.id,
          content: content,
          created_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) throw error;

      // Update the conversation's updated_at timestamp
      await supabase
        .from('message_threads')
        .update({ updated_at: new Date().toISOString() })
        .eq('id', activeConversation.id);

      // Reload conversations to reflect the new message
      await loadConversations();
    } catch (err) {
      console.error('Failed to send message:', err);
    }
  };

  const startNewConversation = async () => {
    if (!supabase || !user) return;

    try {
      const { data: thread, error } = await supabase
        .from('message_threads')
        .insert({
          participants: [user.id],
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) throw error;

      setActiveConversation(thread);
      await loadConversations();
    } catch (err) {
      console.error('Failed to create conversation:', err);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-6 flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="text-center">
          <MessageSquare className="w-16 h-16 mx-auto mb-4 text-gray-400 animate-pulse" />
          <p className="text-gray-600">Loading your messages...</p>
        </div>
      </div>
    );
  }

  if (!isConfigured) {
    return (
      <div className="min-h-screen p-4 md:p-6 flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <Alert className="max-w-md">
          <MessageSquare className="h-4 w-4" />
          <AlertDescription>
            Messaging requires Supabase configuration. Please set up your Supabase environment variables in the Base44 dashboard.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen p-4 md:p-6 flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <Alert variant="destructive" className="max-w-md">
          <MessageSquare className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto p-4 md:p-6">
        <div className="flex h-[calc(100vh-120px)] bg-white rounded-xl shadow-lg overflow-hidden">
          {/* Conversations Sidebar */}
          <div className={`${activeConversation ? 'hidden md:flex' : 'flex'} w-full md:w-1/3 flex-col border-r`}>
            <div className="p-4 border-b">
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-xl font-bold text-gray-900">Messages</h1>
                <Button onClick={startNewConversation} size="sm">
                  <Plus className="w-4 h-4 mr-2" />
                  New
                </Button>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search conversations..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <ConversationList
              conversations={conversations}
              activeConversation={activeConversation}
              onSelectConversation={setActiveConversation}
              searchQuery={searchQuery}
            />
          </div>

          {/* Chat Area */}
          <div className={`${activeConversation ? 'flex' : 'hidden md:flex'} flex-1 flex-col`}>
            {activeConversation ? (
              <>
                {/* Mobile back button */}
                <div className="md:hidden p-4 border-b flex items-center">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setActiveConversation(null)}
                    className="mr-3"
                  >
                    <ArrowLeft className="w-4 h-4" />
                  </Button>
                  <h2 className="font-semibold">Conversation</h2>
                </div>
                <ChatWindow
                  conversation={activeConversation}
                  currentUser={user}
                  onSendMessage={handleSendMessage}
                />
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <MessageSquare className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No conversation selected</h3>
                  <p className="text-gray-600">Choose a conversation to start messaging</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}