import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  School, 
  Search, 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  Users,
  AlertTriangle,
  CheckCircle,
  Globe,
  Database,
  Activity,
  RefreshCw,
  Filter,
  BarChart3
} from 'lucide-react';
import { schoolDirectoryMonitoring } from '@/api/functions';
import RoleGuard from '@/components/shared/RoleGuard';
import { useToast } from '@/components/ui/use-toast';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

function MonitoringDashboard() {
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('7d');
  const [lastUpdated, setLastUpdated] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    loadMetrics();
  }, [timeRange]);

  const loadMetrics = async () => {
    try {
      setLoading(true);
      const { data } = await schoolDirectoryMonitoring({ 
        range: timeRange,
        details: 'true'
      });
      
      if (data.success) {
        setMetrics(data);
        setLastUpdated(new Date());
      } else {
        throw new Error(data.error || 'Failed to load metrics');
      }
    } catch (error) {
      console.error('Error loading monitoring metrics:', error);
      toast({
        variant: "destructive",
        title: "Monitoring Error",
        description: "Could not load school directory metrics."
      });
    } finally {
      setLoading(false);
    }
  };

  const getTrendIcon = (value) => {
    if (value > 0) return <TrendingUp className="w-4 h-4 text-green-600" />;
    if (value < 0) return <TrendingDown className="w-4 h-4 text-red-600" />;
    return <Activity className="w-4 h-4 text-gray-600" />;
  };

  const getTrendColor = (value) => {
    if (value > 0) return 'text-green-600';
    if (value < 0) return 'text-red-600';
    return 'text-gray-600';
  };

  const getAlertIcon = (type) => {
    switch (type) {
      case 'error': return <AlertTriangle className="w-4 h-4 text-red-600" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-orange-600" />;
      case 'info': return <CheckCircle className="w-4 h-4 text-blue-600" />;
      default: return <CheckCircle className="w-4 h-4 text-gray-600" />;
    }
  };

  const getAlertColor = (type) => {
    switch (type) {
      case 'error': return 'bg-red-50 border-red-200 text-red-800';
      case 'warning': return 'bg-orange-50 border-orange-200 text-orange-800';
      case 'info': return 'bg-blue-50 border-blue-200 text-blue-800';
      default: return 'bg-gray-50 border-gray-200 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="p-4 md:p-6">
        <div className="space-y-6">
          <div className="h-8 w-64 bg-gray-200 rounded animate-pulse" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <div className="h-24 bg-gray-200 rounded animate-pulse" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!metrics) return null;

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">School Directory Monitoring</h1>
          <p className="text-gray-600">
            Real-time analytics for autocomplete success and directory health
          </p>
          {lastUpdated && (
            <p className="text-sm text-gray-500 mt-1">
              Last updated: {lastUpdated.toLocaleTimeString()}
            </p>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1d">Last 24h</SelectItem>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={loadMetrics} variant="outline" size="sm">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Alerts */}
      {metrics.alerts && metrics.alerts.length > 0 && (
        <div className="space-y-3">
          <h2 className="text-lg font-semibold">Alerts & Issues</h2>
          {metrics.alerts.map((alert, index) => (
            <div key={index} className={`p-4 rounded-lg border ${getAlertColor(alert.type)}`}>
              <div className="flex items-start gap-3">
                {getAlertIcon(alert.type)}
                <div className="flex-1">
                  <p className="font-medium">{alert.message}</p>
                  <p className="text-sm mt-1 opacity-80">{alert.action}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Key Metrics */}
      <div>
        <h2 className="text-lg font-semibold mb-4">Key Performance Indicators</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Directory Health */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Schools</p>
                  <div className="flex items-center gap-2">
                    <p className="text-2xl font-bold">{metrics.directory_health.total_schools.toLocaleString()}</p>
                    {metrics.trends.directory_growth && (
                      <Badge className={getTrendColor(metrics.trends.directory_growth.trend)}>
                        {getTrendIcon(metrics.trends.directory_growth.trend)}
                        {Math.abs(metrics.trends.directory_growth.trend).toFixed(1)}%
                      </Badge>
                    )}
                  </div>
                </div>
                <School className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          {/* Search Success Rate */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Search Success Rate</p>
                  <div className="flex items-center gap-2">
                    <p className="text-2xl font-bold">{metrics.search_analytics.success_rate.toFixed(1)}%</p>
                    {metrics.trends.success_rate && (
                      <Badge className={getTrendColor(metrics.trends.success_rate.trend)}>
                        {getTrendIcon(metrics.trends.success_rate.trend)}
                        {Math.abs(metrics.trends.success_rate.trend).toFixed(1)}%
                      </Badge>
                    )}
                  </div>
                </div>
                <Search className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          {/* Response Time */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Avg Response Time</p>
                  <p className="text-2xl font-bold">{metrics.performance_metrics.avg_autocomplete_time.toFixed(0)}ms</p>
                  <Progress 
                    value={Math.min((metrics.performance_metrics.avg_autocomplete_time / 100) * 100, 100)} 
                    className="h-2 mt-2"
                  />
                </div>
                <Clock className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>

          {/* Pending Requests */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Pending Requests</p>
                  <p className="text-2xl font-bold">{metrics.request_analytics.requests_by_status.new}</p>
                  <p className="text-sm text-gray-600 mt-1">
                    {metrics.request_analytics.recent_requests} this week
                  </p>
                </div>
                <Users className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Directory Composition */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              Directory Composition
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Public Schools</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm">{metrics.directory_health.schools_by_type.public.toLocaleString()}</span>
                  <div className="w-32 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full" 
                      style={{
                        width: `${(metrics.directory_health.schools_by_type.public / metrics.directory_health.total_schools) * 100}%`
                      }}
                    />
                  </div>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Private Schools</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm">{metrics.directory_health.schools_by_type.private.toLocaleString()}</span>
                  <div className="w-32 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-purple-600 h-2 rounded-full" 
                      style={{
                        width: `${(metrics.directory_health.schools_by_type.private / metrics.directory_health.total_schools) * 100}%`
                      }}
                    />
                  </div>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Charter Schools</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm">{metrics.directory_health.schools_by_type.charter.toLocaleString()}</span>
                  <div className="w-32 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-green-600 h-2 rounded-full" 
                      style={{
                        width: `${(metrics.directory_health.schools_by_type.charter / metrics.directory_health.total_schools) * 100}%`
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Top Requested Schools
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {Object.entries(metrics.request_analytics.top_requested_schools).slice(0, 5).map(([school, count]) => (
                <div key={school} className="flex items-center justify-between">
                  <span className="text-sm font-medium truncate">{school}</span>
                  <Badge variant="outline">{count} requests</Badge>
                </div>
              ))}
              {Object.keys(metrics.request_analytics.top_requested_schools).length === 0 && (
                <p className="text-sm text-gray-500">No recent requests</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recommendations */}
      {metrics.recommendations && metrics.recommendations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="w-5 h-5" />
              Optimization Recommendations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {metrics.recommendations.map((rec, index) => (
                <div key={index} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-medium">{rec.title}</h4>
                        <Badge className={
                          rec.priority === 'high' ? 'bg-red-100 text-red-800' :
                          rec.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-gray-100 text-gray-800'
                        }>
                          {rec.priority} priority
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">{rec.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default function ProtectedSchoolDirectoryMonitoring() {
  return (
    <RoleGuard allowedRoles={['system_admin', 'admin', 'district_admin', 'school_admin']}>
      <MonitoringDashboard />
    </RoleGuard>
  );
}