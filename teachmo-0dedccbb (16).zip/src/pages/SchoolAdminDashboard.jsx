import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  UserCheck, 
  GraduationCap, 
  MessageSquare,
  Calendar,
  BarChart3,
  Settings,
  AlertTriangle,
  ChevronRight,
  Activity,
  BookOpen,
  ClipboardList
} from 'lucide-react';
import { getAdminAnalytics } from '@/api/functions';
import RoleGuard from '@/components/shared/RoleGuard';

function ClickableMetricCard({ title, value, icon: Icon, linkTo, subtitle, trend, trendDirection }) {
  const CardWrapper = linkTo ? Link : 'div';
  const cardProps = linkTo ? { to: linkTo } : {};

  return (
    <CardWrapper {...cardProps}>
      <Card className={`transition-all duration-200 ${linkTo ? 'hover:shadow-lg hover:scale-105 cursor-pointer' : ''}`}>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-gray-600">{title}</p>
                {linkTo && <ChevronRight className="w-4 h-4 text-gray-400" />}
              </div>
              <div className="flex items-center gap-2 mt-1">
                <p className="text-2xl font-bold text-gray-900">{value}</p>
                {trend && (
                  <Badge variant={trendDirection === 'up' ? 'default' : 'secondary'} className="text-xs">
                    {trendDirection === 'up' ? '↗' : '→'} {trend}
                  </Badge>
                )}
              </div>
              {subtitle && <p className="text-xs text-gray-500 mt-1">{subtitle}</p>}
            </div>
            <div className="ml-4">
              <Icon className="w-8 h-8 text-blue-600" />
            </div>
          </div>
        </CardContent>
      </Card>
    </CardWrapper>
  );
}

function SchoolAdminDashboardContent({ user }) {
  const [analytics, setAnalytics] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadAnalytics();
  }, [user]);

  const loadAnalytics = async () => {
    try {
      setIsLoading(true);
      const response = await getAdminAnalytics({ 
        level: 'school', 
        scope_id: user?.school_id 
      });
      setAnalytics(response.data);
    } catch (err) {
      console.error('Failed to load analytics:', err);
      setError('Failed to load school analytics');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center">
            <AlertTriangle className="w-5 h-5 text-red-600 mr-2" />
            <p className="text-red-800">{error}</p>
          </div>
          <Button onClick={loadAnalytics} className="mt-3" variant="outline">
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">School Dashboard</h1>
          <p className="text-gray-600 mt-1">{analytics?.overview?.schoolName || 'School Overview'}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={loadAnalytics}>
            <Activity className="w-4 h-4 mr-2" />
            Refresh Data
          </Button>
          <Link to={createPageUrl('SchoolUsers')}>
            <Button>
              <Users className="w-4 h-4 mr-2" />
              Manage Users
            </Button>
          </Link>
        </div>
      </div>

      {/* Primary Metrics - Clickable */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <ClickableMetricCard
          title="Teachers"
          value={analytics?.overview?.totalTeachers?.toLocaleString() || '0'}
          icon={UserCheck}
          linkTo={createPageUrl('SchoolUsers', 'role=teacher')}
          subtitle={`${analytics?.performance?.teacherActivityRate || 0}% active`}
        />
        
        <ClickableMetricCard
          title="Parents"
          value={analytics?.overview?.totalParents?.toLocaleString() || '0'}
          icon={Users}
          linkTo={createPageUrl('SchoolUsers', 'role=parent')}
          subtitle={`${analytics?.performance?.parentEngagementRate || 0}% engaged`}
        />
        
        <ClickableMetricCard
          title="Students"
          value={analytics?.overview?.totalStudents?.toLocaleString() || '0'}
          icon={GraduationCap}
          linkTo={createPageUrl('SchoolUsers', 'role=student')}
          subtitle="Enrolled students"
        />
        
        <ClickableMetricCard
          title="Courses"
          value={analytics?.overview?.totalCourses?.toLocaleString() || '0'}
          icon={BookOpen}
          linkTo={createPageUrl('SchoolCourses')}
          subtitle="Active courses"
        />
      </div>

      {/* Secondary Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <ClickableMetricCard
          title="Assignments"
          value={analytics?.overview?.totalAssignments?.toLocaleString() || '0'}
          icon={ClipboardList}
          linkTo={createPageUrl('SchoolAssignments')}
          subtitle={`${analytics?.performance?.assignmentCompletionRate || 0}% completed`}
        />
        
        <ClickableMetricCard
          title="Announcements"
          value={analytics?.overview?.totalAnnouncements?.toLocaleString() || '0'}
          icon={MessageSquare}
          linkTo={createPageUrl('Announcements')}
          subtitle="School communications"
        />
        
        <ClickableMetricCard
          title="Upcoming Events"
          value={analytics?.overview?.upcomingEvents?.toLocaleString() || '0'}
          icon={Calendar}
          linkTo={createPageUrl('SchoolEvents')}
          subtitle="This month"
        />
      </div>

      {/* Teachers Breakdown */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Teachers</CardTitle>
          <Link to={createPageUrl('SchoolUsers', 'role=teacher')}>
            <Button variant="ghost" size="sm">
              View All <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {analytics?.drillDownData?.teacherBreakdown?.slice(0, 6).map((teacher) => (
              <Link 
                key={teacher.id} 
                to={createPageUrl('AdminUserEdit', `user_id=${teacher.id}`)}
                className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                    <UserCheck className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{teacher.name}</p>
                    <p className="text-sm text-gray-500">{teacher.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={teacher.lastLogin ? 'default' : 'secondary'}>
                    {teacher.lastLogin ? 'Active' : 'Inactive'}
                  </Badge>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </div>
              </Link>
            ))}
            {analytics?.drillDownData?.teacherBreakdown?.length > 6 && (
              <div className="text-center pt-3">
                <Link to={createPageUrl('SchoolUsers', 'role=teacher')} className="text-blue-600 hover:underline text-sm">
                  View {analytics.drillDownData.teacherBreakdown.length - 6} more teachers
                </Link>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Parent Engagement */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Parent Engagement</CardTitle>
          <Link to={createPageUrl('SchoolUsers', 'role=parent')}>
            <Button variant="ghost" size="sm">
              View All <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {analytics?.drillDownData?.parentBreakdown?.slice(0, 6).map((parent) => (
              <div key={parent.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                    <Users className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{parent.name}</p>
                    <p className="text-sm text-gray-500">{parent.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={
                    parent.engagementLevel === 'High' ? 'default' : 
                    parent.engagementLevel === 'Medium' ? 'secondary' : 'outline'
                  }>
                    {parent.engagementLevel}
                  </Badge>
                </div>
              </div>
            ))}
            {(!analytics?.drillDownData?.parentBreakdown || analytics.drillDownData.parentBreakdown.length === 0) && (
              <p className="text-gray-500 text-center py-4">No parent data available</p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recent Announcements */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Recent Announcements</CardTitle>
          <Link to={createPageUrl('Announcements')}>
            <Button variant="ghost" size="sm">
              View All <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {analytics?.drillDownData?.recentAnnouncements?.map((announcement) => (
              <div key={announcement.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{announcement.title}</p>
                  <p className="text-sm text-gray-500">
                    {new Date(announcement.createdDate).toLocaleDateString()}
                  </p>
                </div>
                {announcement.isUrgent && (
                  <Badge variant="destructive">Urgent</Badge>
                )}
              </div>
            ))}
            {(!analytics?.drillDownData?.recentAnnouncements || analytics.drillDownData.recentAnnouncements.length === 0) && (
              <p className="text-gray-500 text-center py-4">No recent announcements</p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link to={createPageUrl('SchoolUsers')}>
              <Button variant="outline" className="w-full justify-start">
                <Users className="w-4 h-4 mr-2" />
                Manage Users
              </Button>
            </Link>
            <Link to={createPageUrl('Announcements')}>
              <Button variant="outline" className="w-full justify-start">
                <MessageSquare className="w-4 h-4 mr-2" />
                Send Announcement
              </Button>
            </Link>
            <Link to={createPageUrl('SchoolAnalytics')}>
              <Button variant="outline" className="w-full justify-start">
                <BarChart3 className="w-4 h-4 mr-2" />
                View Analytics
              </Button>
            </Link>
            <Link to={createPageUrl('SchoolSettings')}>
              <Button variant="outline" className="w-full justify-start">
                <Settings className="w-4 h-4 mr-2" />
                School Settings
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function SchoolAdminDashboard() {
  return (
    <RoleGuard allowedRoles={['school_admin', 'district_admin', 'system_admin', 'admin']}>
      <SchoolAdminDashboardContent />
    </RoleGuard>
  );
}