import React, { useState, useEffect } from 'react';
import { CurriculumStandard, Activity } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Search, BookOpen, Target, Plus } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

export default function CurriculumAlignment() {
  const [standards, setStandards] = useState([]);
  const [activities, setActivities] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('all');
  const [selectedGrade, setSelectedGrade] = useState('all');
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [standardsData, activitiesData] = await Promise.all([
        CurriculumStandard.list(),
        Activity.list()
      ]);
      setStandards(standardsData);
      setActivities(activitiesData);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load curriculum data."
      });
    } finally {
      setIsLoading(false);
    }
  };

  const filteredStandards = standards.filter(standard => {
    const matchesSearch = standard.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         standard.code.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSubject = selectedSubject === 'all' || standard.subject === selectedSubject;
    const matchesGrade = selectedGrade === 'all' || standard.grade_level === selectedGrade;
    
    return matchesSearch && matchesSubject && matchesGrade;
  });

  const getAlignedActivities = (standardId) => {
    return activities.filter(activity => 
      activity.curriculum_standards && 
      activity.curriculum_standards.includes(standardId)
    );
  };

  if (isLoading) {
    return <div className="p-6 text-center">Loading curriculum alignment...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Curriculum Alignment</h1>
        <p className="text-gray-600">Align activities with curriculum standards to support classroom learning.</p>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search standards..."
                  className="pl-9"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <Select value={selectedSubject} onValueChange={setSelectedSubject}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Subject" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Subjects</SelectItem>
                <SelectItem value="math">Math</SelectItem>
                <SelectItem value="ela">English Language Arts</SelectItem>
                <SelectItem value="science">Science</SelectItem>
                <SelectItem value="social_studies">Social Studies</SelectItem>
                <SelectItem value="arts">Arts</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedGrade} onValueChange={setSelectedGrade}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Grade Level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Grades</SelectItem>
                <SelectItem value="K">Kindergarten</SelectItem>
                <SelectItem value="1">1st Grade</SelectItem>
                <SelectItem value="2">2nd Grade</SelectItem>
                <SelectItem value="3">3rd Grade</SelectItem>
                <SelectItem value="4">4th Grade</SelectItem>
                <SelectItem value="5">5th Grade</SelectItem>
                <SelectItem value="6-8">Middle School</SelectItem>
                <SelectItem value="9-12">High School</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Standards List */}
      <div className="grid gap-6">
        {filteredStandards.map(standard => {
          const alignedActivities = getAlignedActivities(standard.id);
          
          return (
            <Card key={standard.id} className="border-l-4 border-l-blue-500">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg">{standard.code}</CardTitle>
                    <h3 className="font-semibold text-gray-900 mt-1">{standard.title}</h3>
                    <p className="text-gray-600 mt-2">{standard.description}</p>
                  </div>
                  <div className="flex flex-col gap-2 ml-4">
                    <Badge variant="outline">{standard.subject}</Badge>
                    <Badge variant="secondary">Grade {standard.grade_level}</Badge>
                    <Badge className="bg-green-100 text-green-800">
                      {standard.curriculum_type}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Target className="w-4 h-4" />
                    <span>{alignedActivities.length} aligned activities</span>
                  </div>
                  <Button variant="outline" size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Align Activities
                  </Button>
                </div>
                
                {alignedActivities.length > 0 && (
                  <div className="mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {alignedActivities.slice(0, 6).map(activity => (
                      <div key={activity.id} className="p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          <BookOpen className="w-4 h-4 text-blue-500" />
                          <span className="font-medium text-sm">{activity.title}</span>
                        </div>
                        <p className="text-xs text-gray-600 line-clamp-2">{activity.description}</p>
                      </div>
                    ))}
                    {alignedActivities.length > 6 && (
                      <div className="p-3 bg-gray-100 rounded-lg flex items-center justify-center">
                        <span className="text-sm text-gray-600">+{alignedActivities.length - 6} more</span>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
        
        {filteredStandards.length === 0 && (
          <Card className="text-center py-12">
            <CardContent>
              <BookOpen className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No standards found</h3>
              <p className="text-gray-600">Try adjusting your search criteria or filters.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}