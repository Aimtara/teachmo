import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { Save, Shield, Users, Settings, BarChart3, MessageSquare } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import RoleGuard from '@/components/shared/RoleGuard';

const PERMISSION_DEFINITIONS = {
  canManageUsers: {
    label: 'Manage Users',
    description: 'Create, edit, and deactivate user accounts',
    icon: Users,
    roles: ['school_admin', 'district_admin']
  },
  canManageContent: {
    label: 'Manage Content',
    description: 'Create and edit school resources, announcements, and events',
    icon: MessageSquare,
    roles: ['school_admin', 'district_admin']
  },
  canManageSettings: {
    label: 'Manage Settings',
    description: 'Configure school and district settings',
    icon: Settings,
    roles: ['school_admin', 'district_admin']
  },
  canViewAnalytics: {
    label: 'View Analytics',
    description: 'Access usage analytics and reports',
    icon: BarChart3,
    roles: ['school_admin', 'district_admin']
  },
  canModerateCommunity: {
    label: 'Moderate Community',
    description: 'Review reports and take moderation actions',
    icon: Shield,
    roles: ['school_admin', 'district_admin']
  }
};

function AdminPermissionsPage() {
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [rolePermissions, setRolePermissions] = useState({
    school_admin: {},
    district_admin: {}
  });
  const { toast } = useToast();

  useEffect(() => {
    loadDefaultPermissions();
  }, []);

  const loadDefaultPermissions = () => {
    // Set default permissions for each role
    const defaults = {
      school_admin: {
        canManageUsers: true,
        canManageContent: true,
        canManageSettings: true,
        canViewAnalytics: true,
        canModerateCommunity: true
      },
      district_admin: {
        canManageUsers: true,
        canManageContent: true,
        canManageSettings: true,
        canViewAnalytics: true,
        canModerateCommunity: true
      }
    };
    setRolePermissions(defaults);
    setIsLoading(false);
  };

  const handlePermissionChange = (role, permission, enabled) => {
    setRolePermissions(prev => ({
      ...prev,
      [role]: {
        ...prev[role],
        [permission]: enabled
      }
    }));
  };

  const handleSavePermissions = async () => {
    setIsSaving(true);
    try {
      // In a real implementation, this would update a global permissions configuration
      // For now, we'll just simulate the save
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "Permissions Updated",
        description: "Role permissions have been successfully updated."
      });
    } catch (error) {
      console.error('Error saving permissions:', error);
      toast({
        variant: "destructive",
        title: "Save Failed",
        description: "Failed to update permissions. Please try again."
      });
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-8 w-64" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Skeleton className="h-96 w-full" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  return (
    <RoleGuard allowedRoles={['system_admin']}>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Admin Permissions</h1>
            <p className="text-gray-600 mt-2">
              Configure granular permissions for administrative roles
            </p>
          </div>
          <Button onClick={handleSavePermissions} disabled={isSaving}>
            {isSaving ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                Saving...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </>
            )}
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {Object.entries(rolePermissions).map(([role, permissions]) => (
            <Card key={role} className="shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="capitalize">{role.replace('_', ' ')}</span>
                  <Badge variant="outline">
                    {Object.values(permissions).filter(Boolean).length} of {Object.keys(PERMISSION_DEFINITIONS).length} enabled
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {Object.entries(PERMISSION_DEFINITIONS).map(([key, config]) => {
                  if (!config.roles.includes(role)) return null;
                  
                  const Icon = config.icon;
                  const isEnabled = permissions[key];
                  
                  return (
                    <div key={key} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Icon className={`w-5 h-5 ${isEnabled ? 'text-green-600' : 'text-gray-400'}`} />
                        <div>
                          <p className="font-medium text-gray-900">{config.label}</p>
                          <p className="text-sm text-gray-600">{config.description}</p>
                        </div>
                      </div>
                      <Switch
                        checked={isEnabled}
                        onCheckedChange={(checked) => handlePermissionChange(role, key, checked)}
                      />
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <h3 className="font-medium text-blue-900">Permission Management</h3>
                <p className="text-sm text-blue-700 mt-1">
                  These settings control the default permissions for new administrators. 
                  Individual user permissions can still be customized on a per-user basis.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </RoleGuard>
  );
}

export default AdminPermissionsPage;