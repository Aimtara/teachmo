import React, { useState, useEffect, Suspense } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { BarChart, LineChart, PieChart, Bar, Line, Pie, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import { getUXAnalytics } from '@/api/functions';
import { Loader2, TrendingUp, Users, AlertTriangle, ArrowRight, MessageSquare, BookOpen } from 'lucide-react';
import { Alert, AlertTitle } from '@/components/ui/alert';

const StatCard = ({ title, value, icon: Icon, change, changeType }) => (
    <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{title}</CardTitle>
            <Icon className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
            <div className="text-2xl font-bold">{value}</div>
            {change && (
                <p className={`text-xs ${changeType === 'increase' ? 'text-green-600' : 'text-red-600'}`}>
                    {change} vs last week
                </p>
            )}
        </CardContent>
    </Card>
);

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

export default function AdminUXDashboard() {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                setLoading(true);
                const response = await getUXAnalytics();
                setData(response.data);
            } catch (e) {
                setError('Failed to load UX analytics data.');
                console.error(e);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    if (loading) {
        return <div className="flex justify-center items-center h-64"><Loader2 className="h-8 w-8 animate-spin" /></div>;
    }

    if (error) {
        return (
            <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <CardDescription>{error}</CardDescription>
            </Alert>
        );
    }

    if (!data) return null;

    return (
        <div className="p-4 md:p-6 space-y-6">
            <h1 className="text-3xl font-bold">UX Analytics Dashboard</h1>
            
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <StatCard title="Active Users (24h)" value={data.activeUsers24h} icon={Users} change={data.activeUserChange} changeType={data.activeUserChangeType} />
                <StatCard title="Avg. Session (min)" value={data.avgSessionDuration} icon={TrendingUp} change={data.sessionDurationChange} changeType={data.sessionDurationChangeType} />
                <StatCard title="New Feedback" value={data.newFeedbackCount} icon={MessageSquare} />
                <StatCard title="Feature Adoption Rate" value={`${Math.round(data.featureAdoptionRate * 100)}%`} icon={BookOpen} />
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
                <Card>
                    <CardHeader>
                        <CardTitle>Onboarding Funnel</CardTitle>
                        <CardDescription>Percentage of users completing each step.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={data.onboardingFunnel} layout="vertical" margin={{ left: 20 }}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis type="number" domain={[0, 100]} unit="%" />
                                <YAxis type="category" dataKey="step" width={120} />
                                <Tooltip formatter={(value) => `${value}%`} />
                                <Bar dataKey="completionRate" fill="#8884d8" background={{ fill: '#eee' }} />
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle>Top Drop-off Pages</CardTitle>
                         <CardDescription>Pages where users most frequently end their session.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                           <PieChart>
                                <Pie data={data.topDropOffPages} dataKey="count" nameKey="page" cx="50%" cy="50%" outerRadius={100} fill="#82ca9d" label>
                                    {data.topDropOffPages.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip />
                                <Legend />
                            </PieChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            </div>
            
            <Card>
                <CardHeader>
                    <CardTitle>Feature Adoption Over Time</CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={data.featureAdoptionTimeline}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="date" />
                            <YAxis unit="%" />
                            <Tooltip />
                            <Legend />
                            <Line type="monotone" dataKey="aiAssistant" stroke="#8884d8" name="AI Assistant" />
                            <Line type="monotone" dataKey="calendar" stroke="#82ca9d" name="Calendar" />
                            <Line type="monotone" dataKey="community" stroke="#ffc658" name="Community" />
                        </LineChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>
        </div>
    );
}