import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

import RoleBasedWelcome from '@/components/onboarding/RoleBasedWelcome';
import ProgressiveOnboarding from '@/components/onboarding/ProgressiveOnboarding';
import ReferralCodeInput from '@/components/onboarding/ReferralCodeInput';

const OnboardingStep = ({ currentStep, step, children }) => (
  <AnimatePresence>
    {currentStep === step && (
      <motion.div
        key={step}
        initial={{ opacity: 0, x: 50 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -50 }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
        className="w-full"
      >
        {children}
      </motion.div>
    )}
  </AnimatePresence>
);

export default function Onboarding() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [step, setStep] = useState(1); // 1: Welcome & Referral, 2: Role, 3: Progressive
  const navigate = useNavigate();
  const { toast } = useToast();

  const TOTAL_STEPS = 3;

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const userData = await User.me();
        setUser(userData);

        // Logic to determine starting step
        if (userData.onboarding_completed) {
          navigate(createPageUrl('Dashboard'));
        } else if (!userData.role || userData.role === 'user' || userData.onboarding_step < 1) {
          setStep(1); // Start at the beginning
        } else if (userData.role === 'parent' && !userData.onboarding_completed) {
          setStep(3); // Jump to parent progressive onboarding
        } else {
          setStep(2); // Default to role selection if they have a user object but no role
        }
      } catch (e) {
        console.error("Failed to fetch user in Onboarding page", e);
        navigate(createPageUrl('Landing'));
      } finally {
        setIsLoading(false);
      }
    };
    fetchUser();
  }, [navigate]);

  const handleNextStep = (updatedUser) => {
    setUser(updatedUser || user);
    setStep(prev => prev + 1);
  };
  
  const handleOnboardingComplete = () => {
    navigate(createPageUrl('Dashboard'));
    window.location.reload();
  };
  
  const handleReferralApplied = (codeData) => {
    toast({
      title: "Welcome Bonus!",
      description: `Great! You've unlocked ${codeData.benefit_description}. Let's continue!`,
    });
    // No need to change step, just show a success message
  };

  if (isLoading || !user) {
    return (
      <div className="flex justify-center items-center h-screen bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl mx-auto bg-white p-8 rounded-2xl shadow-lg border border-gray-200">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-extrabold text-gray-900">
            Welcome to Teachmo!
          </h1>
          <p className="mt-3 text-lg text-gray-600">
            Let's get you set up in just a few quick steps.
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-10">
          <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
            <span>Step {step} of {TOTAL_STEPS}</span>
            <span>{Math.round((step / TOTAL_STEPS) * 100)}% Complete</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <motion.div
              className="bg-gradient-to-r from-green-400 to-blue-500 h-2.5 rounded-full"
              initial={{ width: '0%' }}
              animate={{ width: `${(step / TOTAL_STEPS) * 100}%` }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
            />
          </div>
        </div>

        {/* Dynamic Content Area */}
        <div className="flex justify-center min-h-[300px]">
          <OnboardingStep currentStep={step} step={1}>
            <div className="text-center max-w-lg mx-auto">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Have a Referral Code?</h2>
              <p className="text-gray-600 mb-6">If you have a referral code from a partner or school, enter it here to unlock special benefits.</p>
              <ReferralCodeInput onCodeApplied={handleReferralApplied} showAsCard={false} />
              <Button variant="outline" className="mt-4" onClick={() => setStep(2)}>
                Skip and Continue
              </Button>
            </div>
          </OnboardingStep>
          
          <OnboardingStep currentStep={step} step={2}>
            <RoleBasedWelcome user={user} onNextStep={handleNextStep} />
          </OnboardingStep>
          
          <OnboardingStep currentStep={step} step={3}>
            {user.role === 'parent' ? (
              <ProgressiveOnboarding onComplete={handleOnboardingComplete} />
            ) : (
              <div className="text-center">
                <h2 className="text-2xl font-bold text-gray-800 mb-4">All Set!</h2>
                <p className="text-gray-600 mb-6">Your account is ready. Let's get you to your dashboard.</p>
                <Button onClick={handleOnboardingComplete}>Go to Dashboard</Button>
              </div>
            )}
          </OnboardingStep>
        </div>
      </div>
    </div>
  );
}