import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { getAdminAnalytics } from '@/api/functions';
import { PageLoadingSkeleton, ErrorState } from '@/components/shared/LoadingStates';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Users, Building, Activity, Shield } from 'lucide-react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const StatCard = ({ title, value, icon: Icon }) => (
  <Card>
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      <Icon className="h-4 w-4 text-muted-foreground" />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
    </CardContent>
  </Card>
);

export default function DistrictAnalytics() {
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const districtId = searchParams.get('district_id');
  const districtName = searchParams.get('district_name');

  useEffect(() => {
    const fetchAnalytics = async () => {
      if (!districtId) {
        setError({ message: "No district specified." });
        setLoading(false);
        return;
      }
      setLoading(true);
      try {
        const { data } = await getAdminAnalytics({ level: 'district', scope_id: districtId });
        setAnalytics(data);
      } catch (err) {
        setError(err);
      } finally {
        setLoading(false);
      }
    };
    fetchAnalytics();
  }, [districtId]);

  const handleSchoolClick = (school) => {
    navigate(createPageUrl(`SchoolAnalytics?school_id=${school.id}&school_name=${school.name}`));
  };

  if (loading) {
    return <PageLoadingSkeleton />;
  }

  if (error) {
    return <ErrorState error={error} onRetry={() => window.location.reload()} />;
  }

  if (!analytics) {
    return <p>No analytics data available for this district.</p>;
  }

  const { overview, engagement, drillDownData } = analytics;
  const { engagementBySchool } = drillDownData;

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Analytics for {districtName || 'District'}</h1>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Total Schools" value={overview.totalSchools} icon={Building} />
        <StatCard title="Total Users" value={overview.totalUsers} icon={Users} />
        <StatCard title="Completed Activities" value={engagement.completedActivities} icon={Activity} />
        <StatCard title="Moderation Reports" value={overview.totalReports || 0} icon={Shield} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Engagement by School</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={engagementBySchool}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="activeUsers" fill="#8884d8" name="Active Users" />
              <Bar dataKey="completedActivities" fill="#82ca9d" name="Completed Activities" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Schools in District</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">School Name</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Active Users</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Engagement Score</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"></th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {(engagementBySchool || []).map((school) => (
                  <tr key={school.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{school.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{school.activeUsers}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{school.engagementScore}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <Button variant="link" onClick={() => handleSchoolClick(school)}>View Details</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}