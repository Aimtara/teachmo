

import React, { useState, useEffect, Suspense } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import {
  Home,
  Search,
  Users,
  Calendar,
  MessageCircle,
  Settings,
  BookOpen,
  Target,
  Award,
  Bot,
  Menu,
  X,
  Building2,
  UserCheck,
  Shield,
  BarChart3,
  School,
  GraduationCap,
  Bell,
  FileText
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';
import { Toaster } from '@/components/ui/toaster';
import ErrorBoundary from '@/components/shared/ErrorBoundary';
import GlobalSearch from '@/components/shared/GlobalSearch';
import FeedbackWidget from '@/components/shared/FeedbackWidget';
import { PageVisit } from '@/api/entities';
import { PageLoadingSkeleton } from '@/components/shared/LoadingStates';

// Session tracking
let session_id = null;
const generateSimpleId = () => Date.now().toString(36) + Math.random().toString(36).substring(2);


export default function Layout({ children, currentPageName }) {
  const [user, setUser] = useState(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const location = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    // Initialize session ID if it doesn't exist
    if (!session_id) {
      session_id = generateSimpleId();
    }

    let pageStartTime = Date.now();
    let currentPath = window.location.pathname;

    const logVisit = () => {
      const duration_ms = Date.now() - pageStartTime;
      if (user?.id) {
        PageVisit.create({
          user_id: user.id,
          session_id,
          page_path: currentPath,
          duration_ms,
          timestamp: new Date().toISOString()
        }).catch(console.error); // Fire and forget, don't block UI
      }
    };

    const handleRouteChange = () => {
      // Log the visit for the previous page
      logVisit();
      // Reset for the new page
      currentPath = window.location.pathname;
      pageStartTime = Date.now();
    };

    // Listen for browser's back/forward button navigation
    window.addEventListener('popstate', handleRouteChange);

    // This effect runs on mount and whenever `currentPageName` or `user` changes.
    // When `currentPageName` changes (i.e., a React Router navigation),
    // the cleanup function for the *previous* render will be called,
    // logging the duration of the page that was just left.
    // Then the effect re-runs for the new page.
    return () => {
      logVisit(); // Log visit when component unmounts or before re-running effect
      window.removeEventListener('popstate', handleRouteChange);
    };
  }, [user, currentPageName]); // Depend on currentPageName to re-trigger on route changes

  useEffect(() => {
    const fetchUser = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (err) {
        if (!err.message?.includes('not authenticated')) {
          console.error('Error fetching user:', err);
          setError(err.message);
          toast({
            variant: "destructive",
            title: "Could not load your profile",
            description: "Please check your network connection and try again.",
          });
        }
      } finally {
        setIsLoading(false);
      }
    };

    fetchUser();
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const getNavigationItems = () => {
    if (!user) return [];

    const baseItems = [
      { name: 'Dashboard', href: createPageUrl('Dashboard'), icon: Home, current: currentPageName === 'Dashboard' },
      { name: 'Discover', href: createPageUrl('UnifiedDiscover'), icon: Search, current: currentPageName === 'UnifiedDiscover' },
      { name: 'Calendar', href: createPageUrl('Calendar'), icon: Calendar, current: currentPageName === 'Calendar' },
      { name: 'Community', href: createPageUrl('UnifiedCommunity'), icon: Users, current: currentPageName === 'UnifiedCommunity' },
      { name: 'AI Assistant', href: createPageUrl('AIAssistant'), icon: Bot, current: currentPageName === 'AIAssistant' },
      { name: 'Messages', href: createPageUrl('Messages'), icon: MessageCircle, current: currentPageName === 'Messages' },
    ];

    const roleSpecificItems = [];

    // Parent-specific items
    if (user.user_type === 'parent') {
      roleSpecificItems.push(
        { name: 'Progress', href: createPageUrl('Progress'), icon: Target, current: currentPageName === 'Progress' },
        { name: 'Achievements', href: createPageUrl('Achievements'), icon: Award, current: currentPageName === 'Achievements' },
        { name: 'Journal', href: createPageUrl('Journal'), icon: BookOpen, current: currentPageName === 'Journal' }
      );
    }

    // Teacher-specific items
    if (user.user_type === 'teacher') {
      roleSpecificItems.push(
        { name: 'My Classes', href: createPageUrl('TeacherClasses'), icon: GraduationCap, current: currentPageName === 'TeacherClasses' },
        { name: 'Assignments', href: createPageUrl('TeacherAssignments'), icon: FileText, current: currentPageName === 'TeacherAssignments' },
        { name: 'Teacher Messages', href: createPageUrl('TeacherMessages'), icon: MessageCircle, current: currentPageName === 'TeacherMessages' }
      );
    }

    // Consolidated Admin Portal
    if (['school_admin', 'district_admin', 'system_admin'].includes(user.user_type)) {
      const adminSubItems = [];

      // Add role-specific admin items
      if (user.user_type === 'school_admin') {
        adminSubItems.push(
          { name: 'School Dashboard', href: createPageUrl('SchoolAdminDashboard'), icon: School, current: currentPageName === 'SchoolAdminDashboard' },
          { name: 'School Users', href: createPageUrl('SchoolUsers'), icon: UserCheck, current: currentPageName === 'SchoolUsers' },
          { name: 'School Content', href: createPageUrl('SchoolContent'), icon: FileText, current: currentPageName === 'SchoolContent' },
          { name: 'Announcements', href: createPageUrl('Announcements'), icon: Bell, current: currentPageName === 'Announcements' }
        );
      }

      if (user.user_type === 'district_admin') {
        adminSubItems.push(
          { name: 'District Dashboard', href: createPageUrl('DistrictAdminDashboard'), icon: Building2, current: currentPageName === 'DistrictAdminDashboard' },
          { name: 'District Users', href: createPageUrl('DistrictUsers'), icon: UserCheck, current: currentPageName === 'DistrictUsers' },
          { name: 'District Schools', href: createPageUrl('DistrictSchools'), icon: School, current: currentPageName === 'DistrictSchools' }
        );
      }

      if (user.user_type === 'system_admin') {
        adminSubItems.push(
          { name: 'System Dashboard', href: createPageUrl('SystemAdminDashboard'), icon: Shield, current: currentPageName === 'SystemAdminDashboard' },
          { name: 'System Users', href: createPageUrl('SystemUsers'), icon: UserCheck, current: currentPageName === 'SystemUsers' },
          { name: 'Districts', href: createPageUrl('SystemDistricts'), icon: Building2, current: currentPageName === 'SystemDistricts' },
          { name: 'Schools', href: createPageUrl('SystemSchools'), icon: School, current: currentPageName === 'SystemSchools' },
          { name: 'Permissions', href: createPageUrl('AdminPermissions'), icon: Shield, current: currentPageName === 'AdminPermissions' },
          { name: 'Moderation', href: createPageUrl('ModerationDashboard'), icon: Shield, current: currentPageName === 'ModerationDashboard' }
        );
      }

      // Common admin items
      adminSubItems.push(
        { name: 'Analytics', href: createPageUrl('AdminAnalytics'), icon: BarChart3, current: currentPageName === 'AdminAnalytics' }
      );

      roleSpecificItems.push({
        name: 'Admin Portal',
        icon: Shield,
        isCollapsible: true,
        isOpen: true, // Default open for easier access
        subItems: adminSubItems,
        current: adminSubItems.some(item => item.current)
      });
    }

    const settingsItems = [
      { name: 'Settings', href: createPageUrl('Settings'), icon: Settings, current: currentPageName === 'Settings' },
      { name: 'Notifications', href: createPageUrl('Notifications'), icon: Bell, current: currentPageName === 'Notifications' }
    ];

    return [...baseItems, ...roleSpecificItems, ...settingsItems];
  };

  const handleLogout = async () => {
    try {
      await User.logout();
      setUser(null);
      window.location.href = '/';
    } catch (error) {
      console.error('Logout error:', error);
      toast({
        variant: "destructive",
        title: "Logout failed",
        description: "Please try again.",
      });
    }
  };

  const Sidebar = ({ mobile = false }) => {
    const [collapsedItems, setCollapsedItems] = useState({});

    // Initialize collapsed state for collapsible items
    useEffect(() => {
      const initialCollapsedState = {};
      getNavigationItems().forEach(item => {
        if (item.isCollapsible) {
          initialCollapsedState[item.name] = !item.isOpen; // Set true if not open
        }
      });
      setCollapsedItems(initialCollapsedState);
    }, [user, currentPageName]); // Re-initialize if user or current page changes (e.g. on user role change)

    const toggleCollapse = (itemName) => {
      setCollapsedItems(prev => ({
        ...prev,
        [itemName]: !prev[itemName]
      }));
    };

    return (
      <div className={`flex flex-col h-full ${mobile ? 'w-full' : 'w-64'} bg-white border-r border-gray-200 dark:bg-gray-800 dark:border-gray-700`}>
        {/* Logo */}
        <div className="flex items-center justify-center h-16 px-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded flex items-center justify-center">
              <span className="text-white font-bold text-sm">T</span>
            </div>
            <span className="font-bold text-xl text-gray-900 dark:text-gray-100">Teachmo</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-4 space-y-2 overflow-y-auto">
          {getNavigationItems().map((item) => (
            <div key={item.name}>
              {item.isCollapsible ? (
                <div>
                  <button
                    onClick={() => toggleCollapse(item.name)}
                    className={`w-full flex items-center justify-between px-3 py-2 text-sm font-medium rounded-md ${
                      item.current
                        ? 'bg-blue-100 text-blue-700 dark:bg-blue-700 dark:text-white'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-gray-100'
                    }`}
                  >
                    <div className="flex items-center">
                      <item.icon className="mr-3 h-5 w-5" />
                      {item.name}
                    </div>
                    <span className={`transform transition-transform ${
                      collapsedItems[item.name] ? 'rotate-0' : 'rotate-90'
                    }`}>
                      ▶
                    </span>
                  </button>

                  <AnimatePresence>
                    {!collapsedItems[item.name] && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="ml-6 mt-1 space-y-1"
                      >
                        {item.subItems?.map((subItem) => (
                          <Link
                            key={subItem.name}
                            to={subItem.href}
                            className={`flex items-center px-3 py-2 text-sm rounded-md ${
                              subItem.current
                                ? 'bg-blue-100 text-blue-700 dark:bg-blue-700 dark:text-white'
                                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-gray-100'
                            }`}
                          >
                            <subItem.icon className="mr-3 h-4 w-4" />
                            {subItem.name}
                          </Link>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <Link
                  to={item.href}
                  className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                    item.current
                      ? 'bg-blue-100 text-blue-700 dark:bg-blue-700 dark:text-white'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-gray-100'
                  }`}
                >
                  <item.icon className="mr-3 h-5 w-5" />
                  {item.name}
                </Link>
              )}
            </div>
          ))}
        </nav>

        {/* User Profile */}
        {user && (
          <div className="border-t border-gray-200 p-4 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center dark:bg-gray-600">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-200">
                    {user.full_name?.charAt(0) || 'U'}
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-gray-900 truncate dark:text-gray-100">
                    {user.full_name || 'User'}
                  </p>
                  <p className="text-xs text-gray-500 truncate dark:text-gray-400">{user.email}</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                className="text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300"
              >
                <span className="sr-only">Sign out</span>
                <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
              </Button>
            </div>
          </div>
        )}
      </div>
    );
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50 dark:bg-gray-950">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // Error state (but still show layout for non-auth errors)
  if (error && error.includes('not authenticated')) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50 dark:bg-gray-950">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4 dark:text-gray-100">Authentication Required</h1>
          <p className="text-gray-600 mb-6 dark:text-gray-300">Please sign in to access Teachmo.</p>
          <Button onClick={() => User.login()}>
            Sign In
          </Button>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="flex h-screen bg-gray-100 dark:bg-gray-900">
        {/* Desktop Sidebar */}
        <div className="hidden md:block">
          <Sidebar />
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ x: '-100%' }} // Start off-screen to the left
              animate={{ x: '0%' }}   // Slide in
              exit={{ x: '-100%' }}   // Slide out
              transition={{ type: "tween", duration: 0.2 }}
              className="fixed inset-0 z-50 md:hidden bg-white dark:bg-gray-800"
            >
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between p-4 bg-white border-b border-gray-200 dark:bg-gray-800 dark:border-gray-700">
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded flex items-center justify-center">
                      <span className="text-white font-bold text-sm">T</span>
                    </div>
                    <span className="font-bold text-xl text-gray-900 dark:text-gray-100">Teachmo</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="dark:text-gray-300 dark:hover:bg-gray-700"
                  >
                    <X className="h-6 w-6" />
                  </Button>
                </div>
                <div className="flex-1 overflow-hidden">
                  <Sidebar mobile />
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Global Search in Header for larger screens */}
          <div className="hidden md:block bg-white border-b border-gray-200 px-6 py-3 dark:bg-gray-800 dark:border-gray-700">
            <div className="max-w-md">
              <GlobalSearch user={user} placeholder="Search activities, events, users..." />
            </div>
          </div>

          {/* Mobile Header */}
          <div className="md:hidden bg-white border-b border-gray-200 px-4 py-2 dark:bg-gray-800 dark:border-gray-700">
            <div className="flex items-center justify-between mb-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMobileMenuOpen(true)}
                className="dark:text-gray-300 dark:hover:bg-gray-700"
              >
                <Menu className="h-5 w-5" />
              </Button>
              <div className="flex items-center space-x-2">
                <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-purple-600 rounded flex items-center justify-center">
                  <span className="text-white font-bold text-xs">T</span>
                </div>
                <span className="font-bold text-lg text-gray-900 dark:text-gray-100">Teachmo</span>
              </div>
              <div className="w-10"></div> {/* Spacer to balance menu button */}
            </div>
            {/* Mobile Search */}
            <GlobalSearch user={user} placeholder="Search..." className="w-full" />
          </div>

          {/* Page Content */}
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 dark:bg-gray-900 p-4 md:p-6">
            <Suspense fallback={<PageLoadingSkeleton />}>
              {children}
            </Suspense>
          </main>
        </div>

        <Toaster />
        <FeedbackWidget />
      </div>
    </ErrorBoundary>
  );
}

