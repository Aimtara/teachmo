import React from 'react';
import OfficeHours from '@/components/calendar/OfficeHours';
import { SupabaseProvider } from '@/components/shared/SupabaseProvider';

export default function OfficeHoursPage() {
  return (
    <SupabaseProvider>
      <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Office Hours</h1>
            <p className="text-gray-600">
              Book one-on-one sessions for personalized guidance and support.
            </p>
          </div>
          
          <OfficeHours />
        </div>
      </div>
    </SupabaseProvider>
  );
}