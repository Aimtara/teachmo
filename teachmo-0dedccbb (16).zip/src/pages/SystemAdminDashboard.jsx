
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { createPageUrl } from '@/utils';
import { User, District, School, SponsorshipPartner } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Users,
  Building,
  GraduationCap,
  TrendingUp,
  Shield,
  Briefcase,
  BarChart3,
  Settings,
  AlertTriangle,
  ChevronRight,
  Activity,
  MessageSquare,
  Play,
  BarChart,
  Clock,
  Accessibility,
  BarChart2, // Added BarChart2 for UX Analytics
  BookOpen // Added BookOpen for UX Design Guide
} from 'lucide-react';
import { getAdminAnalytics } from '@/api/functions';
import RoleGuard from '@/components/shared/RoleGuard';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';

function ClickableMetricCard({ title, value, icon: Icon, linkTo, subtitle, trend, trendDirection }) {
  const CardWrapper = linkTo ? Link : 'div';
  const cardProps = linkTo ? { to: linkTo } : {};

  return (
    <CardWrapper {...cardProps}>
      <Card className={`transition-all duration-200 ${linkTo ? 'hover:shadow-lg hover:scale-105 cursor-pointer' : ''}`}>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-gray-600">{title}</p>
                {linkTo && <ChevronRight className="w-4 h-4 text-gray-400" />}
              </div>
              <div className="flex items-center gap-2 mt-1">
                <p className="text-2xl font-bold text-gray-900">{value}</p>
                {trend && (
                  <Badge variant={trendDirection === 'up' ? 'default' : 'secondary'} className="text-xs">
                    {trendDirection === 'up' ? '↗' : '→'} {trend}
                  </Badge>
                )}
              </div>
              {subtitle && <p className="text-xs text-gray-500 mt-1">{subtitle}</p>}
            </div>
            <div className="ml-4">
              <Icon className="w-8 h-8 text-blue-600" />
            </div>
          </div>
        </CardContent>
      </Card>
    </CardWrapper>
  );
}

function SystemAdminDashboardContent() {
  const [analytics, setAnalytics] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    try {
      setIsLoading(true);
      const response = await getAdminAnalytics({ level: 'system' });
      setAnalytics(response.data);
    } catch (err) {
      console.error('Failed to load analytics:', err);
      setError('Failed to load analytics data');
    } finally {
      setIsLoading(false);
    }
  };

  // KPI Cards and Admin Tools based on the outline, mapped to existing analytics data
  const kpiCards = [
    { title: "Total Users", value: analytics?.overview?.totalUsers?.toLocaleString() || '0', icon: Users, link: createPageUrl("SystemUsers") },
    { title: "Total Schools", value: analytics?.overview?.totalSchools?.toLocaleString() || '0', icon: BarChart, link: createPageUrl("SystemSchools") },
    { title: "Total Districts", value: analytics?.overview?.totalDistricts?.toLocaleString() || '0', icon: BarChart, link: createPageUrl("SystemDistricts") },
    { title: "Open Moderation Reports", value: analytics?.moderation?.openReports?.toLocaleString() || '0', icon: Shield, link: createPageUrl("ModerationDashboard") },
  ];

  const adminTools = [
    { name: "User Management", href: createPageUrl("SystemUsers"), icon: Users },
    { name: "School Management", href: createPageUrl("SystemSchools"), icon: BarChart },
    { name: "District Management", href: createPageUrl("SystemDistricts"), icon: BarChart },
    { name: "Moderation Queue", href: createPageUrl("ModerationDashboard"), icon: Shield },
    { name: "Sponsorships", href: createPageUrl("SponsorshipDashboard"), icon: Settings },
    { name: "Shorts Admin", href: createPageUrl("ShortsOverview"), icon: Settings },
    { name: "Role Permissions", href: createPageUrl("AdminPermissions"), icon: Settings },
    { name: "Accessibility Audit", href: createPageUrl("AccessibilityAudit"), icon: Accessibility },
  ];

  // Assuming analytics.shorts will contain the data needed for the Shorts tab
  const systemShortsStats = analytics?.shorts || {
    totalShorts: 0,
    publishedShorts: 0,
    renderingShorts: 0,
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center">
            <AlertTriangle className="w-5 h-5 text-red-600 mr-2" />
            <p className="text-red-800">{error}</p>
          </div>
          <Button onClick={loadAnalytics} className="mt-3" variant="outline">
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">System Administration</h1>
          <p className="text-gray-600 mt-1">Platform overview and management</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={loadAnalytics}>
            <Activity className="w-4 h-4 mr-2" />
            Refresh Data
          </Button>
          <Link to={createPageUrl('SystemUsers')}>
            <Button>
              <Users className="w-4 h-4 mr-2" />
              Manage Users
            </Button>
          </Link>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="content">Content</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="shorts">Shorts</TabsTrigger>
        </TabsList>

        {/* Overview Tab Content (Modified based on outline) */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {kpiCards.map((card, index) => (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Link to={card.link}>
                  <Card className="hover:shadow-lg transition-shadow">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
                      <card.icon className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{card.value}</div>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
            {/* New UX Cards */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: kpiCards.length * 0.1 }}
            >
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">UX Analytics</CardTitle>
                  <BarChart2 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">Analyze user behavior and flows.</p>
                  <Link to={createPageUrl('AdminUXDashboard')}>
                    <Button variant="outline" size="sm">View UX Dashboard</Button>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: (kpiCards.length + 1) * 0.1 }}
            >
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">UX Design Guide</CardTitle>
                  <BookOpen className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">Review our core design principles.</p>
                  <Link to={createPageUrl('UXReviewGuide')}>
                    <Button variant="outline" size="sm">Open Guide</Button>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Administrative Tools</CardTitle>
                <CardDescription>Quick links to key management areas.</CardDescription>
              </CardHeader>
              <CardContent className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {adminTools.map((tool) => (
                  <Link to={tool.href} key={tool.name}>
                    <Button variant="outline" className="w-full h-20 flex flex-col gap-2">
                      <tool.icon className="h-6 w-6" />
                      <span>{tool.name}</span>
                    </Button>
                  </Link>
                ))}
              </CardContent>
            </Card>
            {/* Preserved existing "Top Districts" card */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Top Districts</CardTitle>
                <Link to={createPageUrl('SystemDistricts')}>
                  <Button variant="ghost" size="sm">
                    View All <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {analytics?.drillDownData?.topDistricts?.slice(0, 5).map((district) => (
                    <Link
                      key={district.id}
                      to={createPageUrl('DistrictAnalytics', `district_id=${district.id}`)}
                      className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer"
                    >
                      <div>
                        <p className="font-medium text-gray-900">{district.name}</p>
                        <p className="text-sm text-gray-500">
                          {district.schoolCount} schools • {district.studentCount} students
                        </p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-gray-400" />
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          {/* Preserved existing "Top Schools" card */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Top Schools</CardTitle>
              <Link to={createPageUrl('SystemSchools')}>
                <Button variant="ghost" size="sm">
                  View All <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {analytics?.drillDownData?.topSchools?.slice(0, 5).map((school) => (
                  <Link
                    key={school.id}
                    to={createPageUrl('SchoolAnalytics', `school_id=${school.id}`)}
                    className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer"
                  >
                    <div>
                      <p className="font-medium text-gray-900">{school.name}</p>
                      <p className="text-sm text-gray-500">
                        {school.teacherCount} teachers • {school.studentCount} students
                      </p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </Link>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Users Tab Content (Placeholder) */}
        <TabsContent value="users" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>User Management</CardTitle>
              <CardDescription>View and manage all users on the platform.</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Detailed user analytics and management tools will appear here.</p>
              <div className="mt-4">
                <Link to={createPageUrl('SystemUsers')}>
                  <Button>
                    <Users className="w-4 h-4 mr-2" />
                    Go to User List
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Content Tab Content (Placeholder) */}
        <TabsContent value="content" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Content Management</CardTitle>
              <CardDescription>Manage educational content, curricula, and activities.</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Tools for content creation, approval, and distribution will be available here.</p>
              <div className="mt-4">
                <Button variant="outline">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  View Content Library
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analytics Tab Content (Placeholder) */}
        <TabsContent value="analytics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Platform Analytics</CardTitle>
              <CardDescription>Deep dive into platform performance and user engagement.</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Comprehensive reports and dashboards for platform analytics.</p>
              <div className="mt-4">
                <Link to={createPageUrl('SystemAnalytics')}>
                  <Button>
                    <BarChart3 className="w-4 h-4 mr-2" />
                    View Detailed Analytics
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Settings Tab Content (Placeholder) */}
        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>System Settings</CardTitle>
              <CardDescription>Configure global platform settings and parameters.</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Administrative settings, integrations, and configuration options.</p>
              <div className="mt-4">
                <Link to={createPageUrl('Settings')}>
                  <Button>
                    <Settings className="w-4 h-4 mr-2" />
                    Go to System Settings
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Shorts Tab Content */}
        <TabsContent value="shorts" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Play className="w-5 h-5" />
                Teachmo Shorts Management
              </CardTitle>
              <CardDescription>
                Monitor and manage the Shorts content system
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">
                    {systemShortsStats.totalShorts || '0'}
                  </div>
                  <div className="text-sm text-blue-600">Total Shorts</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">
                    {systemShortsStats.publishedShorts || '0'}
                  </div>
                  <div className="text-sm text-green-600">Published</div>
                </div>
                <div className="text-center p-4 bg-yellow-50 rounded-lg">
                  <div className="text-2xl font-bold text-yellow-600">
                    {systemShortsStats.renderingShorts || '0'}
                  </div>
                  <div className="text-sm text-yellow-600">In Queue</div>
                </div>
              </div>

              <div className="flex gap-2">
                <Link to={createPageUrl('ShortsOverview')}>
                  <Button>
                    <BarChart className="w-4 h-4 mr-2" />
                    View Shorts Dashboard
                  </Button>
                </Link>
                <Link to={createPageUrl('ShortsQueues')}>
                  <Button variant="outline">
                    <Clock className="w-4 h-4 mr-2" />
                    Monitor Queue
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function SystemAdminDashboard() {
  return (
    <RoleGuard allowedRoles={['system_admin', 'admin']}>
      <SystemAdminDashboardContent />
    </RoleGuard>
  );
}
