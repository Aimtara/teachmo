import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Pod, PodMember, Post, PodChallenge, User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Loader2, Users, ArrowLeft, PlusCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { createPageUrl } from '@/utils';
import PostCard from '@/components/community/PostCard';
import CreatePostForm from '@/components/community/CreatePostForm';
import PodChallengeCard from '@/components/community/PodChallengeCard';
import CreatePodChallengeModal from '@/components/community/CreatePodChallengeModal';

export default function PodDetail() {
  const { podId } = useParams();
  const [pod, setPod] = useState(null);
  const [members, setMembers] = useState([]);
  const [posts, setPosts] = useState([]);
  const [challenges, setChallenges] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showCreateChallenge, setShowCreateChallenge] = useState(false);
  const { toast } = useToast();

  const isPodOwner = currentUser && pod && currentUser.id === pod.owner_id;

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const [podData, membersData, postsData, challengesData, userData] = await Promise.all([
        Pod.get(podId),
        PodMember.filter({ pod_id: podId }),
        Post.filter({ pod_id: podId }, '-created_date', 20),
        PodChallenge.filter({ pod_id: podId }, '-created_date'),
        User.me()
      ]);
      setPod(podData);
      setMembers(membersData || []);
      setPosts(postsData || []);
      setChallenges(challengesData || []);
      setCurrentUser(userData);
    } catch (error) {
      console.error('Failed to fetch pod details:', error);
      toast({ variant: 'destructive', title: 'Error', description: 'Could not load pod details.' });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [podId]);

  const handlePostCreated = () => {
    // Refetch posts to show the new one
    Post.filter({ pod_id: podId }, '-created_date', 20).then(setPosts);
  };
  
  const handleChallengeCreated = () => {
    // Refetch challenges
    PodChallenge.filter({ pod_id: podId }, '-created_date').then(setChallenges);
    setShowCreateChallenge(false);
  };

  if (isLoading) {
    return <div className="flex justify-center items-center h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;
  }

  if (!pod) {
    return <div className="text-center py-10">Pod not found.</div>;
  }

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-8">
      <Link to={createPageUrl('UnifiedCommunity')} className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900">
        <ArrowLeft className="w-4 h-4" />
        Back to Community
      </Link>
      <header>
        <h1 className="text-3xl font-bold text-gray-900">{pod.name}</h1>
        <p className="text-gray-600 mt-1">{pod.description}</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          <CreatePostForm onPostCreated={handlePostCreated} currentUser={currentUser} />
          
          <h2 className="text-xl font-bold">Recent Posts</h2>
          <div className="space-y-4">
            {posts.length > 0 ? (
              posts.map(post => <PostCard key={post.id} post={post} currentUser={currentUser} />)
            ) : (
              <p>No posts yet. Be the first to start a conversation!</p>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Members ({members.length})
                <Users className="w-5 h-5 text-gray-500" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              {/* Member list - can be expanded */}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Challenges
                {isPodOwner && (
                  <Button variant="ghost" size="sm" onClick={() => setShowCreateChallenge(true)}>
                    <PlusCircle className="w-4 h-4 mr-2" />
                    New Challenge
                  </Button>
                )}
              </CardTitle>
              <CardDescription>Work together to earn rewards!</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {challenges.length > 0 ? (
                challenges.map(challenge => <PodChallengeCard key={challenge.id} challenge={challenge} />)
              ) : (
                <p className="text-sm text-gray-500">No active challenges right now.</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
      
      <CreatePodChallengeModal
        isOpen={showCreateChallenge}
        onClose={() => setShowCreateChallenge(false)}
        podId={podId}
        onChallengeCreated={handleChallengeCreated}
      />
    </div>
  );
}