
import React, { useState, useEffect } from 'react';
import { CommunityGuideline } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, Heart, Users, Lock, AlertTriangle, Flag, BookOpen } from 'lucide-react';

const CATEGORY_ICONS = {
  respect: Heart,
  safety: Shield,
  content_standards: BookOpen,
  privacy: Lock,
  consequences: AlertTriangle,
  reporting: Flag
};

const CATEGORY_COLORS = {
  respect: 'bg-pink-100 text-pink-800',
  safety: 'bg-green-100 text-green-800',
  content_standards: 'bg-blue-100 text-blue-800',
  privacy: 'bg-purple-100 text-purple-800',
  consequences: 'bg-orange-100 text-orange-800',
  reporting: 'bg-red-100 text-red-800'
};

export default function CommunityGuidelines() {
  const [guidelines, setGuidelines] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null); // Added error state

  useEffect(() => {
    loadGuidelines();
  }, []);

  const loadGuidelines = async () => {
    try {
      setError(null); // Clear any previous errors
      const data = await CommunityGuideline.filter({ is_active: true }, 'order');
      setGuidelines(data);
    } catch (error) {
      console.error('Error loading guidelines:', error);
      setError('Failed to load community guidelines. Please try again later.'); // Set a user-friendly error message
    }
    setIsLoading(false);
  };

  const groupedGuidelines = guidelines.reduce((acc, guideline) => {
    if (!acc[guideline.category]) {
      acc[guideline.category] = [];
    }
    acc[guideline.category].push(guideline);
    return acc;
  }, {});

  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-6 flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="text-center">
          <BookOpen className="w-12 h-12 mx-auto mb-4 text-gray-400 animate-pulse" />
          <p className="text-gray-600">Loading community guidelines...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen p-4 md:p-6 flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="text-center p-6 bg-red-100 border border-red-400 text-red-700 rounded-lg shadow-md">
          <AlertTriangle className="w-12 h-12 mx-auto mb-4 text-red-500" />
          <p className="text-lg font-semibold mb-2">Error Loading Guidelines</p>
          <p className="text-red-700">{error}</p>
          <button
            onClick={loadGuidelines}
            className="mt-4 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-12">
          <div className="inline-block p-4 rounded-2xl bg-gradient-to-r from-blue-500 to-purple-500 mb-4">
            <Shield className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900">Teachmo™ Community Guidelines</h1>
          <p className="mt-4 text-lg text-gray-600">
            Welcome! Our guidelines are here to ensure Teachmo™ is a safe, supportive, and welcoming space for every parent and educator.
          </p>
        </header>

        {/* Welcome Message */}
        <Card className="mb-8 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <CardContent className="p-8">
            <div className="flex items-start gap-4">
              <Heart className="w-8 h-8 text-blue-600 flex-shrink-0 mt-1" />
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-3">Our Mission</h2>
                <p className="text-gray-700 text-lg leading-relaxed">
                  Teachmo exists to support parents and educators in raising happy, confident, and capable children. 
                  Every interaction in our community should reflect our values of kindness, respect, and constructive support. 
                  Together, we create a space where everyone feels valued and heard.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Guidelines by Category */}
        <div className="space-y-8">
          {Object.entries(groupedGuidelines).map(([category, categoryGuidelines]) => {
            const IconComponent = CATEGORY_ICONS[category] || BookOpen;
            const colorClass = CATEGORY_COLORS[category] || 'bg-gray-100 text-gray-800';
            
            return (
              <Card key={category} className="overflow-hidden">
                <CardHeader className="bg-gray-50">
                  <CardTitle className="flex items-center gap-3">
                    <IconComponent className="w-6 h-6 text-gray-700" />
                    <span className="capitalize">{category.replace('_', ' ')}</span>
                    <Badge className={colorClass}>
                      {categoryGuidelines.length} guideline{categoryGuidelines.length > 1 ? 's' : ''}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-6">
                    {categoryGuidelines.map((guideline) => (
                      <div key={guideline.id}>
                        <h3 className="text-xl font-semibold text-gray-900 mb-3">
                          {guideline.title}
                        </h3>
                        <div 
                          className="prose prose-gray max-w-none text-gray-700 leading-relaxed"
                          dangerouslySetInnerHTML={{ __html: guideline.content }}
                        />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Footer Message */}
        <Card className="mt-12 bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
          <CardContent className="p-8 text-center">
            <Shield className="w-12 h-12 mx-auto mb-4 text-green-600" />
            <h2 className="text-2xl font-bold text-gray-900 mb-3">Questions or Concerns?</h2>
            <p className="text-gray-700 text-lg mb-4">
              If you have questions about these guidelines or need to report something that doesn't 
              feel right, we're here to help. Our moderation team reviews all reports promptly and fairly.
            </p>
            <div className="text-sm text-gray-600">
              Last updated: {new Date().toLocaleDateString()}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
