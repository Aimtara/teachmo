import { create } from 'zustand';

/**
 * useGlobalStore is a lightweight Zustand-based store for managing
 * application-wide state such as the authenticated user and UI theme.
 *
 * Components can import this hook and access or update the state:
 *   const { user, setUser } = useGlobalStore();
 */
const useGlobalStore = create((set) => ({
  // The currently authenticated user.  This can be populated via
  // data fetched from the backend (e.g. via React Query) and shared
  // across the app.
  user: null,
  setUser: (user) => set({ user }),

  // The current UI theme.  Default to 'light'; this can be toggled
  // between 'light' and 'dark' or any custom themes supported by the app.
  theme: 'light',
  setTheme: (theme) => set({ theme }),
}));

export default useGlobalStore;