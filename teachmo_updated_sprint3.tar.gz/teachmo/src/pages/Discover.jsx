
import React, { useState, useEffect } from "react";
import { Activity, Child, UserBookmark, UserActivity, User } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Search, Sparkles, Calendar, MapPin, Filter, Loader2, Plus, Target, AlertTriangle, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

import ActivityCard from "../components/activities/ActivityCard";
import ActivityDetailModal from "../components/activities/ActivityDetailModal";
import LocalEventsView from "../components/discover/LocalEventsView";
import { usePremium } from "../components/shared/usePremium";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function Discover() {
  const [activeTab, setActiveTab] = useState("activities");
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [user, setUser] = useState(null);
  const [children, setChildren] = useState([]);
  
  // Unified content states
  const [activities, setActivities] = useState([]);
  const [bookmarks, setBookmarks] = useState([]);
  const [selectedActivity, setSelectedActivity] = useState(null);
  
  // Age-appropriate filtering
  const [ageFilter, setAgeFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");

  const { isPremium, getRemainingFreeRecommendations } = usePremium();

  useEffect(() => {
    loadAllContent();
  }, []);

  const loadAllContent = async () => {
    setIsLoading(true);
    try {
      const [userData, childrenData, activitiesData, bookmarksData] = await Promise.all([
        User.me(),
        Child.list('-created_date'),
        Activity.list('-created_date', 50),
        UserBookmark.filter({}, '-created_date')
      ]);

      setUser(userData);
      setChildren(childrenData);
      setActivities(activitiesData);
      setBookmarks(bookmarksData);
    } catch (error) {
      console.error("Error loading content:", error);
    }
    setIsLoading(false);
  };

  const generatePersonalizedContent = async () => {
    if (!children.length) return;
    
    setIsLoading(true);
    const primaryChild = children[0];
    
    try {
      const response = await InvokeLLM({
        prompt: `Create 3 personalized activities for ${primaryChild.name}, age ${primaryChild.age}, interested in ${primaryChild.interests?.join(', ') || 'general activities'}. Focus on age-appropriate content that develops key skills.`,
        response_json_schema: {
          type: "object",
          properties: {
            activities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  description: { type: "string" },
                  category: { type: "string", enum: ["creative", "educational", "physical", "social", "emotional"] },
                  duration: { type: "string" },
                  materials_needed: { type: "array", items: { type: "string" } },
                  instructions: { type: "array", items: { type: "string" } },
                  learning_objectives: { type: "array", items: { type: "string" } },
                  why_it_matters: { type: "string" },
                  teachmo_tip: { type: "string" }
                }
              }
            }
          }
        }
      });

      if (response.activities) {
        const newActivities = response.activities.map(activity => ({
          ...activity,
          child_id: primaryChild.id,
          age_range: { min_age: Math.max(0, primaryChild.age - 1), max_age: primaryChild.age + 1 },
          status: 'suggested',
          is_personalized: true
        }));
        
        await Activity.bulkCreate(newActivities);
        await loadAllContent();
      }
    } catch (error) {
      console.error("Error generating content:", error);
    }
    setIsLoading(false);
  };

  const handleSearch = (query) => {
    setSearchQuery(query);
  };

  const getFilteredContent = (contentType) => {
    let content = [];
    
    switch (contentType) {
      case 'activities':
        content = activities;
        break;
      case 'events':
        return []; // Events are handled by the LocalEventsView component
      default:
        return [];
    }

    // Apply search filter
    if (searchQuery.trim()) {
      content = content.filter(item =>
        item.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Apply age filter
    if (ageFilter !== "all" && children.length > 0) {
      const targetChild = children.find(c => c.id === ageFilter);
      if (targetChild) {
        content = content.filter(item => {
          if (!item.age_range) return true;
          const age = typeof targetChild.age === 'object' ? targetChild.age.years : targetChild.age;
          return age >= item.age_range.min_age && age <= item.age_range.max_age;
        });
      }
    }

    // Apply category filter
    if (categoryFilter !== "all") {
      content = content.filter(item => item.category === categoryFilter);
    }

    return content;
  };

  const isBookmarked = (itemId) => {
    return bookmarks.some(b => b.resource_id === itemId);
  };

  const handleBookmark = async (itemId, itemType, isCurrentlyBookmarked) => {
    try {
      if (isCurrentlyBookmarked) {
        const bookmark = bookmarks.find(b => b.resource_id === itemId);
        if (bookmark) {
          await UserBookmark.delete(bookmark.id);
          setBookmarks(bookmarks.filter(b => b.id !== bookmark.id));
        }
      } else {
        const newBookmark = await UserBookmark.create({
          resource_id: itemId,
          resource_type: itemType
        });
        setBookmarks([...bookmarks, newBookmark]);
      }
    } catch (error) {
      console.error("Error handling bookmark:", error);
    }
  };

  // Age-appropriate categories
  const getCategories = () => {
    const hasTeens = children.some(c => c.age >= 13);
    const hasYoungKids = children.some(c => c.age <= 8);
    
    if (hasTeens && !hasYoungKids) {
      return ["academic", "career", "leadership", "social", "creative"];
    } else if (hasYoungKids) {
      return ["creative", "educational", "physical", "social", "emotional"];
    } else {
      return ["creative", "educational", "physical", "social", "emotional", "academic"];
    }
  };

  const selectedChild = children.find(c => c.id === ageFilter);

  const getActiveFiltersCount = () => {
    let count = 0;
    if (ageFilter !== "all") count++;
    if (categoryFilter !== "all") count++;
    if (searchQuery.trim() !== "") count++; // Added search query to count
    return count;
  };

  const clearFilter = (filterType) => {
    if (filterType === 'age') setAgeFilter('all');
    if (filterType === 'category') setCategoryFilter('all');
  };

  const clearAllFilters = () => {
    setAgeFilter('all');
    setCategoryFilter('all');
    setSearchQuery('');
  };

  return (
    <div className="min-h-screen p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto">
        {/* Enhanced Header with Better Guidance */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Discover & Learn</h1>
            <p className="text-gray-600">
              {children.length > 0 
                ? `Personalized activities and resources for ${children.map(c => c.name).join(' and ')}`
                : "Activities, resources, and events to support your parenting journey"
              }
            </p>
          </div>
          
          <Button 
            onClick={generatePersonalizedContent}
            disabled={isLoading || !children.length}
            style={{backgroundColor: 'var(--teachmo-sage)'}}
            className="gap-2"
          >
            <Sparkles className="w-4 h-4" />
            Get AI Suggestions
          </Button>
        </div>

        {/* STICKY FILTER BAR - Enhanced */}
        <div className="sticky top-0 z-10 bg-white/95 backdrop-blur-sm border border-gray-200 rounded-xl p-4 mb-6 shadow-sm">
          <div className="flex flex-col gap-4">
            {/* Search Bar */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search activities & resources..."
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                className="pl-10 pr-10" // Added pr-10 for clear button space
              />
              {searchQuery && (
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8"
                  onClick={() => setSearchQuery('')}
                >
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>
            
            {/* Filter Controls */}
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <span className="text-sm font-medium text-gray-700">Filters:</span>
              </div>
              
              <select
                value={ageFilter}
                onChange={(e) => setAgeFilter(e.target.value)}
                className="px-3 py-2 border rounded-lg bg-white text-sm"
              >
                <option value="all">All Children</option>
                {children.map(child => (
                  <option key={child.id} value={child.id}>For {child.name} ({child.age}yo)</option>
                ))}
              </select>
              
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="px-3 py-2 border rounded-lg bg-white text-sm"
              >
                <option value="all">All Categories</option>
                {getCategories().map(category => (
                  <option key={category} value={category}>
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </option>
                ))}
              </select>

              {getActiveFiltersCount() > 0 && (
                <Button variant="outline" size="sm" onClick={clearAllFilters} className="gap-1">
                  Clear all ({getActiveFiltersCount()})
                  <X className="w-3 h-3" />
                </Button>
              )}
            </div>

            {/* FILTER CHIPS - Visual representation */}
            {(ageFilter !== "all" || categoryFilter !== "all" || searchQuery) && (
              <div className="flex flex-wrap gap-2">
                {searchQuery && (
                  <div className="flex items-center gap-1 bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                    Search: "{searchQuery}"
                    <Button variant="ghost" size="sm" className="h-4 w-4 p-0 ml-1" onClick={() => setSearchQuery('')}>
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                )}
                {ageFilter !== "all" && (
                  <div className="flex items-center gap-1 bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm">
                    For {children.find(c => c.id === ageFilter)?.name}
                    <Button variant="ghost" size="sm" className="h-4 w-4 p-0 ml-1" onClick={() => clearFilter('age')}>
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                )}
                {categoryFilter !== "all" && (
                  <div className="flex items-center gap-1 bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
                    {categoryFilter.charAt(0).toUpperCase() + categoryFilter.slice(1)}
                    <Button variant="ghost" size="sm" className="h-4 w-4 p-0 ml-1" onClick={() => clearFilter('category')}>
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Guidance for New Users */}
        {!isLoading && activities.length === 0 && !searchQuery && (
          <div className="text-center py-8 mb-6">
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 max-w-md mx-auto">
              <Sparkles className="w-12 h-12 mx-auto mb-3 text-blue-500" />
              <h3 className="text-lg font-semibold text-blue-900 mb-2">Ready to get started?</h3>
              <p className="text-blue-700 mb-4">I can create personalized activities tailored to your child's interests and development stage.</p>
              <Button onClick={generatePersonalizedContent} style={{backgroundColor: 'var(--teachmo-sage)'}}>
                <Plus className="w-4 h-4 mr-2" />
                Generate My First Activities
              </Button>
            </div>
          </div>
        )}

        {/* Tabbed Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="activities" className="gap-2">
              <Target className="w-4 h-4" />
              Activities ({getFilteredContent('activities').length})
            </TabsTrigger>
            <TabsTrigger value="events" className="gap-2">
              <Calendar className="w-4 h-4" />
              Local Events
            </TabsTrigger>
          </TabsList>

          {/* Activities Tab */}
          <TabsContent value="activities" className="space-y-6">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-white rounded-lg p-6 space-y-4">
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                      <div className="h-3 bg-gray-200 rounded"></div>
                      <div className="h-3 bg-gray-200 rounded w-5/6"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <AnimatePresence>
                  {getFilteredContent('activities').map((activity) => (
                    <ActivityCard
                      key={activity.id}
                      activity={activity}
                      child={children.find(c => c.id === activity.child_id)}
                      onStatusChange={async (activityId, newStatus) => {
                        await Activity.update(activityId, { status: newStatus });
                        await loadAllContent();
                      }}
                      onRating={async (activityId, rating) => {
                        await Activity.update(activityId, { rating });
                        await loadAllContent();
                      }}
                      onBookmark={(isCurrentlyBookmarked) => handleBookmark(activity.id, 'activity', isCurrentlyBookmarked)}
                      onView={() => setSelectedActivity(activity)}
                      isPersonalized={activity.is_personalized}
                      isBookmarked={isBookmarked(activity.id)}
                    />
                  ))}
                </AnimatePresence>
              </div>
            )}
          </TabsContent>
          
          {/* Events Tab - NOW DYNAMIC */}
          <TabsContent value="events" className="space-y-6">
            {user ? (
                <LocalEventsView 
                    user={user} 
                    selectedChild={selectedChild} 
                    generalCategoryFilter={categoryFilter}
                />
            ) : (
                <div className="text-center py-12">
                    <Loader2 className="w-8 h-8 animate-spin mx-auto text-gray-400" />
                    <p className="mt-2 text-gray-500">Loading user data for event search...</p>
                </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Empty States */}
        {!isLoading && getFilteredContent(activeTab).length === 0 && activeTab !== 'events' && !searchQuery && (
          <div className="text-center py-12">
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gray-100 flex items-center justify-center">
              {activeTab === 'activities' && <Target className="w-12 h-12 text-gray-400" />}
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              No {activeTab} found
            </h3>
            <p className="text-gray-600 mb-6">
              No {activeTab} available yet.
            </p>
            {activeTab === 'activities' && (
              <Button onClick={generatePersonalizedContent} style={{backgroundColor: 'var(--teachmo-sage)'}}>
                <Plus className="w-4 h-4 mr-2" />
                Generate Content
              </Button>
            )}
          </div>
        )}

        {/* Enhanced Empty States with Better Guidance (for search results) */}
        {!isLoading && getFilteredContent(activeTab).length === 0 && activeTab !== 'events' && searchQuery && (
          <div className="text-center py-12">
            <div className="bg-white rounded-xl p-8 shadow-sm max-w-md mx-auto">
              <Target className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No matches found</h3>
              <p className="text-gray-600 mb-6">
                We couldn't find any {activeTab} matching "{searchQuery}"
                {(ageFilter !== 'all' || categoryFilter !== 'all') && ' with your current filters'}.
              </p>
              <div className="space-y-3">
                <Button variant="outline" onClick={clearAllFilters}>
                  Clear all filters
                </Button>
                {activeTab === 'activities' && (
                  <Button onClick={generatePersonalizedContent} style={{backgroundColor: 'var(--teachmo-sage)'}} className="w-full">
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate Custom Activities Instead
                  </Button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Activity Detail Modal */}
      <AnimatePresence>
        {selectedActivity && (
          <ActivityDetailModal
            activity={selectedActivity}
            child={children.find(c => c.id === selectedActivity.child_id)}
            onClose={() => setSelectedActivity(null)}
            onStatusChange={async (activityId, newStatus) => {
              await Activity.update(activityId, { status: newStatus });
              await loadAllContent();
            }}
            onRating={async (activityId, rating) => {
              await Activity.update(activityId, { rating });
              await loadAllContent();
            }}
            isBookmarked={isBookmarked(selectedActivity.id)}
            onBookmark={(isCurrentlyBookmarked) => handleBookmark(selectedActivity.id, 'activity', isCurrentlyBookmarked)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
