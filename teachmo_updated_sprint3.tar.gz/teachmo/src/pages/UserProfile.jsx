import React, { useState, useEffect } from 'react';
import { useLocation, useParams } from 'react-router-dom';
import { User, UserProfile as UserProfileEntity, Post, Follow, CommunityVisibility } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  MessageSquare, 
  UserPlus, 
  UserCheck, 
  MapPin, 
  Calendar, 
  Heart,
  Star,
  Users,
  Settings,
  Shield
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import PostCard from '../components/feed/PostCard';
import { createPageUrl } from '@/utils';
import { useNavigate } from 'react-router-dom';

export default function UserProfile() {
  const { userId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [visibility, setVisibility] = useState(null);
  const [posts, setPosts] = useState([]);
  const [isFollowing, setIsFollowing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('posts');

  useEffect(() => {
    const loadProfile = async () => {
      try {
        setIsLoading(true);
        
        // Get current user
        const currentUserData = await User.me();
        setCurrentUser(currentUserData);

        // Get target user
        const userData = await User.get(userId);
        if (!userData) {
          throw new Error('User not found');
        }

        // Get user's community visibility settings
        const visibilityData = await CommunityVisibility.filter({ user_id: userId });
        const userVisibility = visibilityData[0] || { is_discoverable: true, show_real_name: true };
        
        // Check if current user can view this profile
        const canView = checkVisibilityPermissions(userData, userVisibility, currentUserData);
        if (!canView) {
          throw new Error('You do not have permission to view this profile');
        }

        setUser(userData);
        setVisibility(userVisibility);

        // Get or create user profile
        let profileData = await UserProfileEntity.filter({ user_id: userId });
        if (profileData.length === 0) {
          // Create default profile
          profileData = [await UserProfileEntity.create({
            user_id: userId,
            display_name: userVisibility.show_real_name ? userData.full_name : (userVisibility.anonymous_handle || 'Community Member'),
            bio: '',
            joined_date: new Date().toISOString().split('T')[0]
          })];
        }
        setProfile(profileData[0]);

        // Get user's posts
        const userPosts = await Post.filter({ user_id: userId }, '-created_date', 20);
        setPosts(userPosts);

        // Check if following
        if (currentUserData.id !== userId) {
          const followData = await Follow.filter({ 
            follower_id: currentUserData.id, 
            following_id: userId 
          });
          setIsFollowing(followData.length > 0);
        }

      } catch (error) {
        console.error('Error loading profile:', error);
        // Handle error - maybe redirect or show error message
      } finally {
        setIsLoading(false);
      }
    };

    if (userId) {
      loadProfile();
    }
  }, [userId]);

  const checkVisibilityPermissions = (targetUser, visibility, currentUser) => {
    if (!visibility.is_discoverable && currentUser.id !== targetUser.id) {
      return false;
    }

    switch (visibility.visibility_scope) {
      case 'private':
        return currentUser.id === targetUser.id;
      case 'school':
        return currentUser.school_id && currentUser.school_id === targetUser.school_id;
      case 'district':
        return currentUser.district_id && currentUser.district_id === targetUser.district_id;
      case 'global':
      default:
        return true;
    }
  };

  const handleFollow = async () => {
    if (!currentUser || currentUser.id === userId) return;

    try {
      if (isFollowing) {
        const followData = await Follow.filter({ 
          follower_id: currentUser.id, 
          following_id: userId 
        });
        if (followData.length > 0) {
          await Follow.delete(followData[0].id);
        }
        setIsFollowing(false);
      } else {
        await Follow.create({
          follower_id: currentUser.id,
          following_id: userId
        });
        setIsFollowing(true);
      }

      // Update profile follower counts
      const currentFollowers = profile.followers_count || 0;
      await UserProfileEntity.update(profile.id, {
        followers_count: isFollowing ? currentFollowers - 1 : currentFollowers + 1
      });
      
    } catch (error) {
      console.error('Error updating follow status:', error);
    }
  };

  const handleMessage = () => {
    navigate(createPageUrl('Messages'), { 
      state: { startConversation: userId } 
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-48 bg-gray-200 rounded-xl"></div>
            <div className="h-32 bg-gray-200 rounded-xl"></div>
            <div className="h-64 bg-gray-200 rounded-xl"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!user || !profile) {
    return (
      <div className="min-h-screen p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="max-w-4xl mx-auto text-center">
          <Card>
            <CardContent className="p-8">
              <Shield className="w-16 h-16 mx-auto mb-4 text-gray-400" />
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Profile Not Available</h2>
              <p className="text-gray-600">This user profile is not accessible or does not exist.</p>
              <Button 
                onClick={() => navigate(createPageUrl('UnifiedCommunity'))}
                className="mt-4"
              >
                Back to Community
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const isOwnProfile = currentUser?.id === userId;
  const displayName = visibility?.show_real_name ? user.full_name : (visibility?.anonymous_handle || profile.display_name);

  return (
    <div className="min-h-screen p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Cover/Header Section */}
        <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm overflow-hidden">
          {profile.cover_image_url && (
            <div className="h-48 bg-cover bg-center" style={{backgroundImage: `url(${profile.cover_image_url})`}} />
          )}
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
              <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
                <AvatarImage src={profile.profile_image_url || user.avatar_url} />
                <AvatarFallback className="text-2xl font-bold">
                  {displayName[0]}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 min-w-0">
                <div className="flex flex-col md:flex-row md:items-center gap-4 mb-4">
                  <div>
                    <h1 className="text-3xl font-bold text-gray-900">{displayName}</h1>
                    {!visibility?.show_real_name && (
                      <p className="text-sm text-gray-500 flex items-center gap-1">
                        <Shield className="w-4 h-4" />
                        Anonymous Profile
                      </p>
                    )}
                  </div>
                  
                  {!isOwnProfile && (
                    <div className="flex gap-3">
                      <Button
                        onClick={handleFollow}
                        variant={isFollowing ? 'outline' : 'default'}
                        className={!isFollowing ? 'bg-blue-600 hover:bg-blue-700' : ''}
                      >
                        {isFollowing ? (
                          <>
                            <UserCheck className="w-4 h-4 mr-2" />
                            Following
                          </>
                        ) : (
                          <>
                            <UserPlus className="w-4 h-4 mr-2" />
                            Follow
                          </>
                        )}
                      </Button>
                      
                      {visibility?.allow_direct_messages && (
                        <Button onClick={handleMessage} variant="outline">
                          <MessageSquare className="w-4 h-4 mr-2" />
                          Message
                        </Button>
                      )}
                    </div>
                  )}
                  
                  {isOwnProfile && (
                    <Button 
                      onClick={() => navigate(createPageUrl('Settings'))}
                      variant="outline"
                    >
                      <Settings className="w-4 h-4 mr-2" />
                      Edit Profile
                    </Button>
                  )}
                </div>
                
                {profile.bio && (
                  <p className="text-gray-700 mb-4">{profile.bio}</p>
                )}
                
                <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                  {visibility?.show_location && user.location && (
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {user.location}
                    </div>
                  )}
                  
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    Joined {formatDistanceToNow(new Date(profile.joined_date), { addSuffix: true })}
                  </div>
                  
                  <div className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    {profile.followers_count || 0} followers
                  </div>
                  
                  <div className="flex items-center gap-1">
                    <Heart className="w-4 h-4" />
                    {profile.helpful_votes || 0} helpful votes
                  </div>
                </div>
                
                {profile.badges?.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-4">
                    {profile.badges.map((badge, index) => (
                      <Badge key={index} className="bg-purple-100 text-purple-800">
                        <Star className="w-3 h-3 mr-1" />
                        {badge}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Profile Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="posts">Posts ({profile.posts_count || 0})</TabsTrigger>
            <TabsTrigger value="about">About</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>
          
          <TabsContent value="posts" className="space-y-4">
            {posts.length > 0 ? (
              posts.map(post => (
                <PostCard
                  key={post.id}
                  post={post}
                  currentUser={currentUser}
                />
              ))
            ) : (
              <Card>
                <CardContent className="p-8 text-center text-gray-500">
                  <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No posts yet</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="about" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>About {displayName}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {profile.interests?.length > 0 && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Interests</h4>
                    <div className="flex flex-wrap gap-2">
                      {profile.interests.map((interest, index) => (
                        <Badge key={index} variant="outline">
                          {interest}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
                
                {profile.parenting_stage && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Parenting Stage</h4>
                    <Badge className="capitalize">
                      {profile.parenting_stage.replace('_', ' ')}
                    </Badge>
                  </div>
                )}
                
                {visibility?.show_children_info && user.role === 'parent' && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Family</h4>
                    <p className="text-gray-600">Parent in the Teachmo community</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="activity" className="space-y-4">
            <Card>
              <CardContent className="p-8 text-center text-gray-500">
                <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Activity timeline coming soon</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}