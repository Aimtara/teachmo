
import React, { useEffect, useState } from 'react';
import { User } from '@/api/entities';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import RoleBasedWelcome from '@/components/onboarding/RoleBasedWelcome';
import ProgressiveOnboarding from '@/components/onboarding/ProgressiveOnboarding';
import { Loader2 } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

export default function Welcome() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  const handleNextStep = (updatedUser) => {
    setUser(updatedUser);
  };
  
  const handleOnboardingComplete = () => {
    navigate(createPageUrl('Dashboard'));
    window.location.reload(); // Force a refresh to ensure layout and data are current
  };

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const userData = await User.me();
        setUser(userData);
      } catch (e) {
        console.error("Failed to fetch user in Welcome page", e);
        // If user is not authenticated or fails to load, redirect to landing
        navigate(createPageUrl('Landing'));
      } finally {
        setIsLoading(false);
      }
    };
    fetchUser();
  }, [navigate]); // Added navigate to dependency array for useEffect safety

  if (isLoading || !user) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  // Determine the correct onboarding path
  const needsRoleSelection = !user.role || user.role === 'user' || user.onboarding_step < 1;
  const isParentOnboarding = user.role === 'parent' && !user.onboarding_completed;

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <AnimatePresence mode="wait">
        <motion.div
          key={user.role || 'role_selection'}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className="w-full max-w-lg" // Added max-width to contain content
        >
          {needsRoleSelection ? (
            <RoleBasedWelcome user={user} onNextStep={handleNextStep} />
          ) : isParentOnboarding ? (
            <ProgressiveOnboarding onComplete={handleOnboardingComplete} />
          ) : (
            // Fallback for non-parent roles or if something is misconfigured
            // This will typically lead to the dashboard via handleNextStep after a state update
            // or the user is already configured to be redirected to dashboard on page load.
            // For now, redirect to dashboard immediately for non-onboarding users if no specific next step.
            // Consider if a RoleBasedWelcome is truly a fallback or if it should navigate to dashboard directly.
            // Assuming for now, if user has a role and isn't a parent needing progressive onboarding, they're done.
            // The handleNextStep will update user, but if no further steps, might be stuck.
            // A better fallback here might be to immediately navigate to dashboard.
            // However, following the outline, we'll keep RoleBasedWelcome.
            <RoleBasedWelcome user={user} onNextStep={handleNextStep} />
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
