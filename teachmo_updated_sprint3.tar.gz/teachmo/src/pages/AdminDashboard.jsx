import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Users,
  TrendingUp,
  Activity,
  School,
  FileText,
  BarChart,
  Loader2
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { getAdminAnalytics } from '@/api/functions';

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    newUsersLast30Days: 0,
    dailyActiveUsers: 0,
    completedActivitiesCount: 0,
    schoolRequestsCount: 0,
    roleCounts: {}
  });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        setIsLoading(true);
        setError(null);
        const { data, error: apiError } = await getAdminAnalytics();
        if (apiError || !data.success) {
          throw new Error(apiError?.error || 'Failed to fetch analytics');
        }
        setStats(data.data);
      } catch (err) {
        setError(err.message);
        console.error("Error fetching admin analytics:", err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchAnalytics();
  }, []);

  const formattedRoleData = Object.entries(stats.roleCounts).map(([name, value]) => ({
    name: name.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
    count: value
  }));

  const StatCard = ({ title, value, icon: Icon, link, linkText }) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        {isLoading ? (
            <Loader2 className="h-6 w-6 animate-spin text-gray-500" />
        ) : (
            <div className="text-2xl font-bold">{value.toLocaleString()}</div>
        )}
        {link && (
            <Link to={link} className="text-xs text-muted-foreground hover:underline">
                {linkText}
            </Link>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="p-4 md:p-8 space-y-6">
      <h1 className="text-3xl font-bold">Admin Dashboard</h1>
      {error && (
        <Card className="border-red-200 bg-red-50 text-red-700">
            <CardContent className="p-4 flex items-center gap-2">
                <FileText className="h-5 w-5" />
                <p>Error: {error}</p>
            </CardContent>
        </Card>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Total Users" value={stats.totalUsers} icon={Users} link={createPageUrl('SystemUsers')} linkText="Manage users" />
        <StatCard title="New Users (30d)" value={stats.newUsersLast30Days} icon={TrendingUp} />
        <StatCard title="Activities Completed" value={stats.completedActivitiesCount} icon={Activity} />
        <StatCard title="School Requests" value={stats.schoolRequestsCount} icon={School} link={createPageUrl('SchoolRequests')} linkText="View requests" />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>User Roles</CardTitle>
          </CardHeader>
          <CardContent className="pl-2">
            {isLoading ? <Loader2 className="h-6 w-6 animate-spin mx-auto text-gray-500"/> :
                <ResponsiveContainer width="100%" height={350}>
                  <RechartsBarChart data={formattedRoleData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="count" fill="#8884d8" name="User Count" />
                  </RechartsBarChart>
                </ResponsiveContainer>
            }
          </CardContent>
        </Card>
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <p className="text-sm text-muted-foreground">Overview of platform actions.</p>
          </CardHeader>
          <CardContent>
            <div className="text-center text-gray-500 py-10">
                Activity feed coming soon...
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}