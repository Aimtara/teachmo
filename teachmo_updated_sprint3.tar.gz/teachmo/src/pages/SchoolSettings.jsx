
import React, { useState, useEffect } from 'react';
import { User, School } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Settings, Save, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { withAdminGuard } from '@/components/shared/AdminRoleGuard';

function SchoolSettings() {
  const [school, setSchool] = useState(null);
  const [formData, setFormData] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  const { toast } = useToast();

  useEffect(() => {
    const fetchSchoolSettings = async () => {
      try {
        const currentUser = await User.me();
        if (!currentUser.school_id) {
          throw new Error('User is not associated with a school');
        }

        const schoolData = await School.get(currentUser.school_id);
        setSchool(schoolData);
        setFormData({
          ...schoolData,
          settings: schoolData.settings || {
            enable_parent_teacher_messaging: true,
            enable_assignment_sync: true,
            enable_calendar_integration: true,
            require_parent_verification: true
          }
        });
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error loading school settings",
          description: error.message
        });
        console.error('School settings fetch error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchSchoolSettings();
  }, [toast]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSettingChange = (settingName, value) => {
    setFormData(prev => ({
      ...prev,
      settings: { ...prev.settings, [settingName]: value }
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await School.update(school.id, formData);
      toast({
        title: "Settings saved",
        description: "School settings have been updated successfully."
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Save failed",
        description: "An error occurred while saving settings."
      });
      console.error('Settings save error:', error);
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="p-4 md:p-8 space-y-6">
        <Skeleton className="h-10 w-1/3" />
        <Card><CardContent className="p-6 space-y-4">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}</CardContent></Card>
      </div>
    );
  }

  if (!school) {
    return (
      <div className="p-4 md:p-8">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-gray-600">School information not found.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-6 flex items-center gap-3">
          <Settings className="w-8 h-8" style={{color: 'var(--teachmo-sage)'}} />
          School Settings
        </h1>

        <div className="space-y-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">School Name</Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name || ''}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <Label htmlFor="school_type">School Type</Label>
                  <Select value={formData.school_type || ''} onValueChange={(value) => handleSelectChange('school_type', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select school type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="elementary">Elementary</SelectItem>
                      <SelectItem value="middle">Middle School</SelectItem>
                      <SelectItem value="high">High School</SelectItem>
                      <SelectItem value="k12">K-12</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="address">Address</Label>
                <Textarea
                  id="address"
                  name="address"
                  value={formData.address || ''}
                  onChange={handleInputChange}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    name="phone"
                    value={formData.phone || ''}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email || ''}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="website">Website</Label>
                <Input
                  id="website"
                  name="website"
                  type="url"
                  value={formData.website || ''}
                  onChange={handleInputChange}
                />
              </div>
            </CardContent>
          </Card>

          {/* Feature Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Feature Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">Parent-Teacher Messaging</h4>
                  <p className="text-sm text-gray-600">Allow parents and teachers to communicate directly</p>
                </div>
                <Switch
                  checked={formData.settings?.enable_parent_teacher_messaging || false}
                  onCheckedChange={(checked) => handleSettingChange('enable_parent_teacher_messaging', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">Assignment Sync</h4>
                  <p className="text-sm text-gray-600">Sync assignments from external systems</p>
                </div>
                <Switch
                  checked={formData.settings?.enable_assignment_sync || false}
                  onCheckedChange={(checked) => handleSettingChange('enable_assignment_sync', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">Calendar Integration</h4>
                  <p className="text-sm text-gray-600">Integrate with external calendar systems</p>
                </div>
                <Switch
                  checked={formData.settings?.enable_calendar_integration || false}
                  onCheckedChange={(checked) => handleSettingChange('enable_calendar_integration', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">Parent Verification Required</h4>
                  <p className="text-sm text-gray-600">Require verification before connecting parents to students</p>
                </div>
                <Switch
                  checked={formData.settings?.require_parent_verification || false}
                  onCheckedChange={(checked) => handleSettingChange('require_parent_verification', checked)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Save Button */}
          <div className="flex justify-end">
            <Button onClick={handleSave} disabled={isSaving}>
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Save Settings
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default withAdminGuard(SchoolSettings, {
  requiredRoles: ['school_admin', 'district_admin', 'system_admin', 'admin']
});
