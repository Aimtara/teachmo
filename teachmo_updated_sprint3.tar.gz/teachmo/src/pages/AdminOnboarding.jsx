import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User, School, District } from "@/api/entities";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Building2, Users, Settings, CheckCircle, ArrowRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function AdminOnboarding() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(true);
  const [schools, setSchools] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [formData, setFormData] = useState({
    school_id: '',
    district_id: '',
    employee_id: '',
    department: '',
    admin_focus: 'general'
  });

  const steps = [
    {
      id: 1,
      title: "Welcome to Teachmo Administration!",
      description: "Let's set up your administrative profile",
      component: "welcome"
    },
    {
      id: 2,
      title: "School Assignment",
      description: "Which school or district are you managing?",
      component: "assignment"
    },
    {
      id: 3,
      title: "Administrative Preferences",
      description: "How would you like to manage your responsibilities?",
      component: "preferences"
    }
  ];

  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const userData = await User.me();
        setUser(userData);
        
        if (userData.admin_onboarding_completed) {
          const dashboardMap = {
            school_admin: 'SchoolAdminDashboard',
            district_admin: 'DistrictAdminDashboard',
            system_admin: 'SystemAdminDashboard'
          };
          navigate(createPageUrl(dashboardMap[userData.role] || 'Dashboard'));
          return;
        }

        // Fetch schools and districts for selection
        const [schoolsData, districtsData] = await Promise.all([
          School.list(),
          District.list()
        ]);
        setSchools(schoolsData);
        setDistricts(districtsData);
        
        if (userData.admin_onboarding_step) {
          setCurrentStep(userData.admin_onboarding_step);
        }
      } catch (error) {
        console.error("Error fetching user:", error);
        navigate(createPageUrl("Landing"));
      }
      setIsLoading(false);
    };
    
    fetchInitialData();
  }, [navigate]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleNext = async () => {
    if (currentStep < steps.length) {
      const nextStep = currentStep + 1;
      await User.updateMyUserData({
        admin_onboarding_step: nextStep,
        ...formData
      });
      setCurrentStep(nextStep);
    } else {
      // Complete onboarding
      await User.updateMyUserData({
        admin_onboarding_completed: true,
        admin_onboarding_step: steps.length + 1,
        ...formData
      });
      
      const dashboardMap = {
        school_admin: 'SchoolAdminDashboard',
        district_admin: 'DistrictAdminDashboard',
        system_admin: 'SystemAdminDashboard'
      };
      navigate(createPageUrl(dashboardMap[user.role] || 'Dashboard'));
    }
  };

  const handleSkip = async () => {
    await User.updateMyUserData({
      admin_onboarding_completed: true,
      admin_onboarding_step: steps.length + 1
    });
    
    const dashboardMap = {
      school_admin: 'SchoolAdminDashboard',
      district_admin: 'DistrictAdminDashboard',
      system_admin: 'SystemAdminDashboard'
    };
    navigate(createPageUrl(dashboardMap[user.role] || 'Dashboard'));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="text-center">
          <Building2 className="w-12 h-12 animate-pulse mx-auto mb-4" style={{color: 'var(--teachmo-sage)'}} />
          <p className="text-gray-600">Setting up your administrative dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-3xl mx-auto p-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{background: 'linear-gradient(135deg, var(--teachmo-sage), var(--teachmo-sage-light))'}}>
              <Building2 className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Teachmo Administration</h1>
          </div>

          {/* Progress Indicator */}
          <div className="flex justify-center items-center gap-4 mb-8">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                  currentStep > step.id 
                    ? 'bg-green-500 text-white' 
                    : currentStep === step.id 
                      ? 'bg-blue-500 text-white' 
                      : 'bg-gray-200 text-gray-600'
                }`}>
                  {currentStep > step.id ? (
                    <CheckCircle className="w-5 h-5" />
                  ) : (
                    <span className="font-semibold">{step.id}</span>
                  )}
                </div>
                {index < steps.length - 1 && (
                  <div className={`w-12 h-1 mx-2 transition-all ${
                    currentStep > step.id ? 'bg-green-500' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Step Content */}
        <AnimatePresence mode="wait">
          {currentStep === 1 && (
            <motion.div
              key="welcome"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm">
                <CardContent className="p-8">
                  <div className="text-center mb-8">
                    <Settings className="w-16 h-16 mx-auto mb-4 text-blue-500" />
                    <h2 className="text-3xl font-bold text-gray-900 mb-4">
                      Welcome, {user?.full_name?.split(' ')[0] || 'Administrator'}!
                    </h2>
                    <p className="text-lg text-gray-700 leading-relaxed">
                      As a {user?.role?.replace('_', ' ')} on Teachmo, you'll have powerful tools to manage users, communications, and insights across your {user?.role === 'district_admin' ? 'district' : 'school'}.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <Users className="w-8 h-8 mx-auto mb-3 text-blue-600" />
                      <h3 className="font-semibold text-gray-900 mb-2">User Management</h3>
                      <p className="text-sm text-gray-600">Add and manage teachers, students, and families</p>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <Building2 className="w-8 h-8 mx-auto mb-3 text-green-600" />
                      <h3 className="font-semibold text-gray-900 mb-2">Communication Hub</h3>
                      <p className="text-sm text-gray-600">Send announcements and facilitate connections</p>
                    </div>
                    <div className="text-center p-4 bg-purple-50 rounded-lg">
                      <Settings className="w-8 h-8 mx-auto mb-3 text-purple-600" />
                      <h3 className="font-semibold text-gray-900 mb-2">Analytics & Insights</h3>
                      <p className="text-sm text-gray-600">Monitor engagement and platform usage</p>
                    </div>
                  </div>

                  <div className="flex justify-center gap-4">
                    <Button onClick={handleNext} size="lg" style={{backgroundColor: 'var(--teachmo-sage)'}}>
                      Get Started
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                    <Button onClick={handleSkip} variant="outline" size="lg">
                      Skip Setup
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {currentStep === 2 && (
            <motion.div
              key="assignment"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm">
                <CardContent className="p-8">
                  <div className="text-center mb-8">
                    <Building2 className="w-16 h-16 mx-auto mb-4 text-green-500" />
                    <h2 className="text-3xl font-bold text-gray-900 mb-4">
                      School Assignment
                    </h2>
                    <p className="text-lg text-gray-700 leading-relaxed">
                      Let's connect you to the {user?.role === 'district_admin' ? 'district' : 'school'} you'll be managing.
                    </p>
                  </div>

                  <div className="space-y-6">
                    {user?.role === 'district_admin' && (
                      <div>
                        <Label htmlFor="district_id">Select District</Label>
                        <Select value={formData.district_id} onValueChange={(value) => handleInputChange('district_id', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Choose your district" />
                          </SelectTrigger>
                          <SelectContent>
                            {districts.map(district => (
                              <SelectItem key={district.id} value={district.id}>
                                {district.name} - {district.state}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    {user?.role === 'school_admin' && (
                      <div>
                        <Label htmlFor="school_id">Select School</Label>
                        <Select value={formData.school_id} onValueChange={(value) => handleInputChange('school_id', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Choose your school" />
                          </SelectTrigger>
                          <SelectContent>
                            {schools.map(school => (
                              <SelectItem key={school.id} value={school.id}>
                                {school.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    <div>
                      <Label htmlFor="employee_id">Employee ID (Optional)</Label>
                      <Input
                        id="employee_id"
                        value={formData.employee_id}
                        onChange={(e) => handleInputChange('employee_id', e.target.value)}
                        placeholder="Your employee identification number"
                      />
                    </div>

                    <div>
                      <Label htmlFor="department">Department/Role</Label>
                      <Input
                        id="department"
                        value={formData.department}
                        onChange={(e) => handleInputChange('department', e.target.value)}
                        placeholder="e.g., Principal, Vice Principal, IT Administrator"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-4 mt-8">
                    <Button onClick={handleSkip} variant="outline">Skip</Button>
                    <Button onClick={handleNext} style={{backgroundColor: 'var(--teachmo-sage)'}}>
                      Continue
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {currentStep === 3 && (
            <motion.div
              key="preferences"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm">
                <CardContent className="p-8">
                  <div className="text-center mb-8">
                    <Settings className="w-16 h-16 mx-auto mb-4 text-purple-500" />
                    <h2 className="text-3xl font-bold text-gray-900 mb-4">
                      Administrative Focus
                    </h2>
                    <p className="text-lg text-gray-700 leading-relaxed">
                      What's your primary administrative focus? This helps us customize your dashboard.
                    </p>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <Label>Primary Administrative Focus</Label>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
                        {[
                          { value: 'user_management', label: 'User Management', desc: 'Focus on managing teachers, students, and families' },
                          { value: 'communication', label: 'Communications', desc: 'Emphasize announcements and messaging' },
                          { value: 'analytics', label: 'Analytics & Reporting', desc: 'Data-driven insights and performance tracking' },
                          { value: 'general', label: 'General Administration', desc: 'Balanced approach to all admin functions' }
                        ].map((option) => (
                          <button
                            key={option.value}
                            onClick={() => handleInputChange('admin_focus', option.value)}
                            className={`p-4 rounded-lg border-2 text-left transition-all ${
                              formData.admin_focus === option.value
                                ? 'border-blue-500 bg-blue-50'
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                          >
                            <h4 className="font-medium">{option.label}</h4>
                            <p className="text-sm text-gray-600">{option.desc}</p>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end gap-4 mt-8">
                    <Button onClick={handleSkip} variant="outline">Skip</Button>
                    <Button onClick={handleNext} style={{backgroundColor: 'var(--teachmo-sage)'}}>
                      Complete Setup
                      <CheckCircle className="w-5 h-5 ml-2" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-sm text-gray-600">
            Step {currentStep} of {steps.length} • Takes less than 3 minutes
          </p>
        </div>
      </div>
    </div>
  );
}