
import React, { useState, useEffect } from 'react';
import { Partner, PartnerEvent, PartnerResource } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { 
  Building2, Search, Check, X, Eye, MessageSquare, 
  Users, Calendar, FileText, Filter, Loader2, Tag
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';

export default function PartnerAdmin() {
  const [user, setUser] = useState(null);
  const [partners, setPartners] = useState([]);
  const [pendingEvents, setPendingEvents] = useState([]);
  const [pendingResources, setPendingResources] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const { toast } = useToast();

  useEffect(() => {
    loadAdminData();
  }, []);

  const loadAdminData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);

      if (!['admin', 'system_admin'].includes(userData.role)) {
        toast({
          variant: 'destructive',
          title: 'Access Denied',
          description: 'You do not have permission to access this page.'
        });
        return;
      }

      const [partnersData, eventsData, resourcesData] = await Promise.all([
        Partner.list('-created_date'),
        PartnerEvent.filter({ status: 'pending_review' }),
        PartnerResource.filter({ status: 'pending_review' })
      ]);

      setPartners(partnersData);
      setPendingEvents(eventsData);
      setPendingResources(resourcesData);
    } catch (error) {
      console.error('Failed to load admin data:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to load admin data.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handlePartnerApproval = async (partnerId, status) => {
    try {
      await Partner.update(partnerId, {
        status,
        approved_by: user.id,
        approved_date: new Date().toISOString()
      });

      toast({
        title: status === 'approved' ? 'Partner Approved' : 'Partner Rejected',
        description: `Partnership has been ${status}.`
      });

      loadAdminData();
    } catch (error) {
      console.error('Failed to update partner status:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to update partner status.'
      });
    }
  };

  const handleEventApproval = async (eventId, status, rejectionReason = '') => {
    try {
      await PartnerEvent.update(eventId, {
        status,
        reviewed_by: user.id,
        reviewed_date: new Date().toISOString(),
        rejection_reason: rejectionReason
      });

      toast({
        title: status === 'approved' ? 'Event Approved' : 'Event Rejected',
        description: `Event has been ${status}.`
      });

      loadAdminData();
    } catch (error) {
      console.error('Failed to update event status:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to update event status.'
      });
    }
  };

  const handleResourceApproval = async (resourceId, status, rejectionReason = '') => {
    try {
      await PartnerResource.update(resourceId, {
        status,
        reviewed_by: user.id,
        reviewed_date: new Date().toISOString(),
        rejection_reason: rejectionReason
      });

      toast({
        title: status === 'approved' ? 'Resource Approved' : 'Resource Rejected',
        description: `Resource has been ${status}.`
      });

      loadAdminData();
    } catch (error) {
      console.error('Failed to update resource status:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to update resource status.'
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  const filteredPartners = partners.filter(partner => {
    const matchesSearch = partner.organization_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         partner.contact_name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || partner.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="flex items-center gap-3 mb-8">
        <Building2 className="w-8 h-8 text-blue-600" />
        <div>
          <h1 className="text-3xl font-bold">Partner Administration</h1>
          <p className="text-gray-600">Manage partnerships, review content, and monitor performance</p>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Partners</p>
                <p className="text-2xl font-bold">{partners.length}</p>
              </div>
              <Users className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pending Reviews</p>
                <p className="text-2xl font-bold">{pendingEvents.length + pendingResources.length}</p>
              </div>
              <Eye className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Partners</p>
                <p className="text-2xl font-bold">{partners.filter(p => p.status === 'approved').length}</p>
              </div>
              <Check className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pro Partners</p>
                <p className="text-2xl font-bold">{partners.filter(p => p.subscription_tier === 'pro').length}</p>
              </div>
              <Building2 className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="partners" className="space-y-6">
        <TabsList>
          <TabsTrigger value="partners">Partners</TabsTrigger>
          <TabsTrigger value="events">
            Event Reviews ({pendingEvents.length})
          </TabsTrigger>
          <TabsTrigger value="resources">
            Resource Reviews ({pendingResources.length})
          </TabsTrigger>
          <TabsTrigger value="offers">Offers</TabsTrigger>
        </TabsList>

        <TabsContent value="partners">
          <Card>
            <CardHeader>
              <CardTitle>Partner Management</CardTitle>
              <div className="flex gap-4">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="Search partners..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                    <SelectItem value="suspended">Suspended</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredPartners.map(partner => (
                  <div key={partner.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold text-lg">{partner.organization_name}</h3>
                          <Badge className={
                            partner.status === 'approved' ? 'bg-green-100 text-green-800' :
                            partner.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                            partner.status === 'rejected' ? 'bg-red-100 text-red-800' :
                            'bg-gray-100 text-gray-800'
                          }>
                            {partner.status}
                          </Badge>
                          {partner.subscription_tier === 'pro' && (
                            <Badge className="bg-purple-100 text-purple-800">Pro</Badge>
                          )}
                        </div>
                        <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-600">
                          <div>Contact: {partner.contact_name}</div>
                          <div>Email: {partner.contact_email}</div>
                          <div>Type: {partner.organization_type}</div>
                          <div>Location: {partner.location}</div>
                        </div>
                        {partner.description && (
                          <p className="text-sm text-gray-600 mt-2">{partner.description}</p>
                        )}
                      </div>

                      {partner.status === 'pending' && (
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            onClick={() => handlePartnerApproval(partner.id, 'approved')}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <Check className="w-4 h-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="destructive"
                            onClick={() => handlePartnerApproval(partner.id, 'rejected')}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="events">
          <Card>
            <CardHeader>
              <CardTitle>Event Reviews</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pendingEvents.map(event => (
                  <EventReviewCard 
                    key={event.id} 
                    event={event} 
                    onApprove={handleEventApproval}
                    partners={partners}
                  />
                ))}
                {pendingEvents.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No events pending review</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="resources">
          <Card>
            <CardHeader>
              <CardTitle>Resource Reviews</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pendingResources.map(resource => (
                  <ResourceReviewCard 
                    key={resource.id} 
                    resource={resource} 
                    onApprove={handleResourceApproval}
                    partners={partners}
                  />
                ))}
                {pendingResources.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No resources pending review</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="offers">
          <Card>
            <CardHeader>
              <CardTitle>Offer Reviews</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* This would be populated similar to events/resources */}
                <div className="text-center py-8 text-gray-500">
                  <Tag className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Offer review functionality would be implemented here</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Event Review Component
function EventReviewCard({ event, onApprove, partners }) {
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');

  const partner = partners.find(p => p.id === event.partner_id);

  const handleReject = () => {
    onApprove(event.id, 'rejected', rejectionReason);
    setShowRejectDialog(false);
    setRejectionReason('');
  };

  return (
    <div className="border rounded-lg p-4">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <h3 className="font-semibold text-lg mb-2">{event.title}</h3>
          <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-600 mb-3">
            <div>Partner: {partner?.organization_name}</div>
            <div>Category: {event.category}</div>
            <div>Date: {new Date(event.start_time).toLocaleDateString()}</div>
            <div>Location: {event.is_virtual ? 'Virtual' : event.location_name}</div>
          </div>
          <p className="text-sm text-gray-700">{event.description}</p>
        </div>

        <div className="flex gap-2">
          <Button 
            size="sm" 
            onClick={() => onApprove(event.id, 'approved')}
            className="bg-green-600 hover:bg-green-700"
          >
            <Check className="w-4 h-4 mr-2" />
            Approve
          </Button>
          
          <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
            <DialogTrigger asChild>
              <Button size="sm" variant="destructive">
                <X className="w-4 h-4 mr-2" />
                Reject
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Reject Event</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <p>Please provide a reason for rejecting this event:</p>
                <Textarea
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder="Explain why this event is being rejected..."
                  rows={4}
                />
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowRejectDialog(false)}>
                    Cancel
                  </Button>
                  <Button variant="destructive" onClick={handleReject}>
                    Reject Event
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </div>
  );
}

// Resource Review Component  
function ResourceReviewCard({ resource, onApprove, partners }) {
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');

  const partner = partners.find(p => p.id === resource.partner_id);

  const handleReject = () => {
    onApprove(resource.id, 'rejected', rejectionReason);
    setShowRejectDialog(false);
    setRejectionReason('');
  };

  return (
    <div className="border rounded-lg p-4">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <h3 className="font-semibold text-lg mb-2">{resource.title}</h3>
          <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-600 mb-3">
            <div>Partner: {partner?.organization_name}</div>
            <div>Type: {resource.type}</div>
            <div>Category: {resource.category}</div>
            {resource.age_range && (
              <div>Ages: {resource.age_range.min_age}-{resource.age_range.max_age}</div>
            )}
          </div>
          <p className="text-sm text-gray-700 mb-3">{resource.description}</p>
          <div className="p-3 bg-gray-50 rounded text-sm">
            <strong>Content Preview:</strong>
            <p className="mt-1">{resource.content.substring(0, 200)}...</p>
          </div>
        </div>

        <div className="flex gap-2">
          <Button 
            size="sm" 
            onClick={() => onApprove(resource.id, 'approved')}
            className="bg-green-600 hover:bg-green-700"
          >
            <Check className="w-4 h-4 mr-2" />
            Approve
          </Button>
          
          <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
            <DialogTrigger asChild>
              <Button size="sm" variant="destructive">
                <X className="w-4 h-4 mr-2" />
                Reject
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Reject Resource</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <p>Please provide a reason for rejecting this resource:</p>
                <Textarea
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder="Explain why this resource is being rejected..."
                  rows={4}
                />
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowRejectDialog(false)}>
                    Cancel
                  </Button>
                  <Button variant="destructive" onClick={handleReject}>
                    Reject Resource
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </div>
  );
}
