
import React, { useState, useEffect } from 'react';
import { User, School } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertTitle } from '@/components/ui/alert';
import { BookOpen, Plus, Edit, Loader2, Users, AlertCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { withAdminGuard } from '@/components/shared/AdminRoleGuard';

function DistrictSchoolsPage({ user: adminUser }) { // adminUser is passed from the guard
  const [schools, setSchools] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [editingSchool, setEditingSchool] = useState(null);
  const [formData, setFormData] = useState({});

  const { toast } = useToast();

  useEffect(() => {
    if (adminUser?.district_id) {
      fetchData();
    } else {
        setIsLoading(false);
    }
  }, [adminUser]);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const [schoolsData, usersData] = await Promise.all([
        School.filter({ district_id: adminUser.district_id }),
        User.filter({ district_id: adminUser.district_id })
      ]);
      setSchools(schoolsData);
      setAllUsers(usersData);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Failed to load data",
        description: "Could not fetch schools and users for your district."
      });
      console.error("Data fetch error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const getUserCount = (schoolId, role) => {
    return allUsers.filter(user => user.school_id === schoolId && user.role === role).length;
  };

  const handleOpenDialog = (school = null) => {
    setEditingSchool(school);
    setFormData(school ? { ...school } : {
      name: '',
      address: '',
      phone: '',
      website: '',
      school_type: 'elementary',
      is_active: true,
      district_id: adminUser.district_id // Automatically assign to the admin's district
    });
    setShowDialog(true);
  };

  const handleSave = async () => {
    if (!formData.name) {
      toast({ variant: "destructive", title: "School name is required" });
      return;
    }

    setIsSaving(true);
    try {
      if (editingSchool) {
        await School.update(editingSchool.id, formData);
        toast({ title: "School Updated", description: `${formData.name} has been successfully updated.` });
      } else {
        await School.create(formData);
        toast({ title: "School Created", description: `${formData.name} has been successfully created.` });
      }
      setShowDialog(false);
      fetchData(); // Refresh data
    } catch (error) {
      toast({ variant: "destructive", title: "Save Failed", description: "An error occurred while saving the school." });
      console.error("Save error:", error);
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleInputChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };
  
  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  if (isLoading) {
    return (
      <div className="p-4 md:p-8 space-y-6">
        <Skeleton className="h-10 w-1/3" />
        <Card><CardHeader><Skeleton className="h-8 w-1/4" /></CardHeader><CardContent><Skeleton className="h-48 w-full" /></CardContent></Card>
      </div>
    );
  }

  if (!adminUser?.district_id) {
     return (
        <div className="p-4 md:p-8">
            <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <p>Your account is not associated with a district. Please contact a system administrator.</p>
            </Alert>
        </div>
     );
  }

  return (
    <div className="p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto">
        <header className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <BookOpen className="w-8 h-8" style={{color: 'var(--teachmo-sage)'}} />
            Schools Management
          </h1>
          <Button onClick={() => handleOpenDialog()}>
            <Plus className="mr-2 h-4 w-4" /> Add School
          </Button>
        </header>

        <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm">
          <CardHeader>
            <CardTitle>Your District's Schools</CardTitle>
            <CardDescription>View, create, and manage all schools within your district.</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>School Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Teachers</TableHead>
                  <TableHead>Parents</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {schools.map(school => (
                  <TableRow key={school.id}>
                    <TableCell className="font-medium">{school.name}</TableCell>
                    <TableCell className="capitalize">{school.school_type}</TableCell>
                    <TableCell>{getUserCount(school.id, 'teacher')}</TableCell>
                    <TableCell>{getUserCount(school.id, 'parent')}</TableCell>
                    <TableCell>
                      <Badge variant={school.is_active ? "default" : "destructive"} className={school.is_active ? 'bg-green-500' : ''}>
                        {school.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(school)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>{editingSchool ? 'Edit School' : 'Create New School'}</DialogTitle>
              <DialogDescription>
                {editingSchool ? `Update details for ${editingSchool.name}.` : 'Fill in the details for the new school.'}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">Name *</Label>
                <Input id="name" name="name" value={formData.name || ''} onChange={handleInputChange} className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="address" className="text-right">Address</Label>
                <Input id="address" name="address" value={formData.address || ''} onChange={handleInputChange} className="col-span-3" />
              </div>
               <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="school_type" className="text-right">Type</Label>
                <Select name="school_type" value={formData.school_type || 'elementary'} onValueChange={(v) => handleSelectChange('school_type', v)}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="elementary">Elementary</SelectItem>
                    <SelectItem value="middle">Middle</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="k12">K-12</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
               <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="is_active" className="text-right">Status</Label>
                <Select name="is_active" value={String(formData.is_active)} onValueChange={(v) => handleSelectChange('is_active', v === 'true')}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="true">Active</SelectItem>
                    <SelectItem value="false">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowDialog(false)}>Cancel</Button>
              <Button onClick={handleSave} disabled={isSaving}>
                {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Save
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}

export default withAdminGuard(DistrictSchoolsPage, {
  requiredRoles: ['district_admin', 'system_admin', 'admin']
});
