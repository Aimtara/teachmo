import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Achievement, UserAchievement, User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Trophy,
  Award,
  Lock,
  Baby,
  Rocket,
  GraduationCap,
  MessageSquareHeart,
  CalendarCheck,
  Flag,
  PartyPopper,
  Star,
  ClipboardCheck,
  Edit,
  Save,
  Loader2,
  HelpCircle,
  CheckCircle2,
  Filter,
  Search,
  Share2,
  Calendar,
  Target,
  Zap,
  Crown,
  Flame,
  TrendingUp,
  Users,
  Sparkles
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { format, differenceInDays } from "date-fns";
import { Alert, AlertDescription } from "@/components/ui/alert";

const iconComponents = {
  Baby,
  Rocket,
  GraduationCap,
  MessageSquareHeart,
  CalendarCheck,
  Flag,
  PartyPopper,
  Star,
  ClipboardCheck,
  Award, // Fallback
  Trophy,
  Crown,
  Flame,
  Target,
  Users
};

const ACHIEVEMENT_CATEGORIES = [
  { value: 'all', label: 'All Badges', icon: Trophy },
  { value: 'onboarding', label: 'Getting Started', icon: Rocket },
  { value: 'consistency', label: 'Daily Habits', icon: Flame },
  { value: 'activities', label: 'Learning & Growth', icon: GraduationCap },
  { value: 'community', label: 'Community', icon: Users },
  { value: 'learning', label: 'Knowledge', icon: Star }
];

export default function AchievementsPage() {
  const [achievements, setAchievements] = useState([]);
  const [userAchievements, setUserAchievements] = useState([]);
  const [user, setUser] = useState(null);
  const [pointGoalInput, setPointGoalInput] = useState("");
  const [isEditingGoal, setIsEditingGoal] = useState(false);
  const [isSavingGoal, setIsSavingGoal] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [showCelebration, setShowCelebration] = useState(null);
  const [sortBy, setSortBy] = useState("category");

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    // Check for newly earned achievements and show celebration
    const recentAchievements = userAchievements.filter(ua => {
      const earnedDate = new Date(ua.date_earned);
      const daysSinceEarned = differenceInDays(new Date(), earnedDate);
      return daysSinceEarned <= 1; // Show celebration for achievements earned in last 24 hours
    });

    if (recentAchievements.length > 0) {
      const recentAchievement = achievements.find(a => a.id === recentAchievements[0].achievement_id);
      if (recentAchievement) {
        setTimeout(() => setShowCelebration(recentAchievement), 1000);
      }
    }
  }, [userAchievements, achievements]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      setPointGoalInput(currentUser.point_goal?.toString() || "1000");

      const [allAchievements, earnedAchievements] = await Promise.all([
        Achievement.list(),
        UserAchievement.filter({ user_id: currentUser.id })
      ]);
      setAchievements(allAchievements);
      setUserAchievements(earnedAchievements);
    } catch (error) {
      console.error("Error loading achievements data:", error);
    }
    setIsLoading(false);
  };

  const handleSaveGoal = async () => {
    setIsSavingGoal(true);
    const newGoal = parseInt(pointGoalInput, 10);
    if (!isNaN(newGoal) && newGoal > 0) {
      try {
        await User.updateMyUserData({ point_goal: newGoal });
        setUser(prev => ({ ...prev, point_goal: newGoal }));
        setIsEditingGoal(false);
      } catch (error) {
        console.error("Error saving point goal:", error);
      }
    }
    setIsSavingGoal(false);
  };

  const isEarned = (achievementId) => {
    return userAchievements.some(ua => ua.achievement_id === achievementId);
  };

  const getEarnedDate = (achievementId) => {
    const userAchievement = userAchievements.find(ua => ua.achievement_id === achievementId);
    return userAchievement ? new Date(userAchievement.date_earned) : null;
  };

  const getAchievementIcon = (iconName) => {
    const IconComponent = iconComponents[iconName] || Award;
    return <IconComponent className="w-10 h-10" />;
  };

  const getFilteredAchievements = () => {
    let filtered = achievements;

    // Filter by category
    if (selectedCategory !== "all") {
      filtered = filtered.filter(a => a.category === selectedCategory);
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(a => 
        a.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        a.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Sort achievements
    filtered.sort((a, b) => {
      const aEarned = isEarned(a.id);
      const bEarned = isEarned(b.id);
      
      if (sortBy === "earned") {
        if (aEarned && !bEarned) return -1;
        if (!aEarned && bEarned) return 1;
      } else if (sortBy === "points") {
        return b.points_reward - a.points_reward;
      } else if (sortBy === "category") {
        if (a.category !== b.category) {
          return a.category.localeCompare(b.category);
        }
      }
      
      return a.name.localeCompare(b.name);
    });

    return filtered;
  };

  const handleShare = async (achievement) => {
    const shareText = `🏆 I just earned the "${achievement.name}" badge on Teachmo! ${achievement.description} #ParentingWin #Teachmo`;
    
    if (navigator.share) {
      await navigator.share({
        title: `Achievement Unlocked: ${achievement.name}`,
        text: shareText,
      });
    } else {
      await navigator.clipboard.writeText(shareText);
      alert("Achievement details copied to clipboard!");
    }
  };

  const pointProgress = user ? Math.round(((user.points || 0) / (user.point_goal || 1000)) * 100) : 0;
  const earnedCount = userAchievements.length;
  const totalCount = achievements.length;
  const completionRate = totalCount > 0 ? Math.round((earnedCount / totalCount) * 100) : 0;

  const AchievementCard = ({ achievement, index }) => {
    const earned = isEarned(achievement.id);
    const earnedDate = getEarnedDate(achievement.id);
    const isNew = earnedDate && differenceInDays(new Date(), earnedDate) <= 7;

    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: index * 0.05 }}
        className="h-full"
      >
        <Card
          className={`border-2 h-full transition-all duration-300 flex flex-col relative overflow-hidden ${
            earned
              ? 'border-yellow-400 bg-gradient-to-br from-yellow-50 via-amber-50 to-orange-50 shadow-lg hover:shadow-xl'
              : `bg-gray-50 border-gray-200 ${achievement.link_to ? 'hover:border-blue-300 hover:bg-blue-50/50 cursor-pointer' : ''}`
          }`}
          onClick={achievement.link_to && !earned ? () => window.location.href = createPageUrl(achievement.link_to) : undefined}
        >
          {isNew && (
            <div className="absolute top-2 right-2 z-10">
              <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white text-xs animate-pulse">
                <Sparkles className="w-3 h-3 mr-1" />
                New!
              </Badge>
            </div>
          )}

          <CardContent className="p-6 text-center flex flex-col flex-grow items-center justify-center">
            <div
              className={`w-24 h-24 mx-auto mb-4 rounded-full flex items-center justify-center transition-all duration-500 relative ${
                earned
                  ? 'bg-gradient-to-br from-yellow-400 via-amber-500 to-orange-500 text-white shadow-lg animate-pulse'
                  : 'bg-gray-200 text-gray-400'
              }`}
            >
              {earned ? getAchievementIcon(achievement.icon) : <Lock className="w-10 h-10" />}
              {earned && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -right-1 bg-white p-1 rounded-full shadow-lg"
                >
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                </motion.div>
              )}
            </div>

            <h3 className={`font-bold text-lg mb-2 ${earned ? 'text-amber-900' : 'text-gray-700'}`}>
              {achievement.name}
            </h3>
            
            <p className={`text-sm mb-4 flex-grow ${earned ? 'text-amber-800' : 'text-gray-500'}`}>
              {achievement.description}
            </p>

            <div className="space-y-3 w-full">
              <Badge
                variant="outline"
                className={`font-bold ${earned ? 'border-amber-300 bg-white text-amber-900' : 'border-gray-300 bg-gray-200 text-gray-600'}`}
              >
                <Star className="w-3 h-3 mr-1" />
                {achievement.points_reward} Points
              </Badge>

              {earned && earnedDate && (
                <div className="text-xs text-amber-700 bg-amber-100 rounded-full px-3 py-1">
                  <Calendar className="w-3 h-3 inline mr-1" />
                  Earned {format(earnedDate, 'MMM d, yyyy')}
                </div>
              )}

              {earned && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleShare(achievement);
                  }}
                  className="w-full mt-2 text-amber-700 border-amber-300 hover:bg-amber-100"
                >
                  <Share2 className="w-3 h-3 mr-1" />
                  Share Achievement
                </Button>
              )}

              {!earned && achievement.link_to && (
                <div className="text-xs text-blue-600 bg-blue-100 rounded-full px-3 py-1">
                  <Target className="w-3 h-3 inline mr-1" />
                  Go to {achievement.link_to}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  };

  return (
    <div className="min-h-screen p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto">
        <div className="mb-6 md:mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2 flex items-center gap-2 md:gap-3">
            <Trophy style={{color: 'var(--teachmo-sage)'}} className="w-6 h-6 md:w-8 md:h-8" />
            <span className="truncate">Your Achievements</span>
          </h1>
          <p className="text-sm md:text-base text-gray-600">
            Celebrate your parenting milestones and track your progress!
          </p>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <Loader2 className="w-8 h-8 md:w-12 md:h-12 mx-auto animate-spin mb-4" style={{color: 'var(--teachmo-sage)'}} />
            <p className="text-gray-600 text-sm md:text-base">Loading your badges...</p>
          </div>
        ) : (
          <>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="overview" className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" />
                  Overview
                </TabsTrigger>
                <TabsTrigger value="collection" className="flex items-center gap-2">
                  <Trophy className="w-4 h-4" />
                  Badge Collection
                </TabsTrigger>
              </TabsList>

              <TabsContent value="overview">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                  {/* Points Progress */}
                  <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-indigo-100">
                    <CardHeader className="pb-4">
                      <CardTitle className="flex items-center justify-between text-lg">
                        <span className="flex items-center gap-2">
                          <Star style={{color: 'var(--teachmo-sage)'}} className="w-5 h-5" />
                          Points Progress
                        </span>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger>
                              <HelpCircle className="w-4 h-4 text-gray-400" />
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="max-w-xs text-sm">Earn points by completing activities, reading tips, and earning badges!</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-baseline">
                        <span className="text-3xl font-bold text-indigo-900">{user?.points || 0}</span>
                        <span className="text-gray-600 text-sm ml-2">/ {user?.point_goal || 1000}</span>
                      </div>
                      <Progress value={pointProgress} className="h-3" />
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">{pointProgress}% to goal</span>
                        {isEditingGoal ? (
                          <div className="flex items-center gap-2">
                            <Input
                              type="number"
                              value={pointGoalInput}
                              onChange={(e) => setPointGoalInput(e.target.value)}
                              className="w-20 text-sm"
                              min="1"
                            />
                            <Button onClick={handleSaveGoal} disabled={isSavingGoal} size="sm" className="px-2">
                              {isSavingGoal ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                            </Button>
                          </div>
                        ) : (
                          <Button variant="ghost" size="sm" onClick={() => setIsEditingGoal(true)}>
                            <Edit className="w-3 h-3 mr-1" />
                            Edit Goal
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Achievement Stats */}
                  <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-emerald-100">
                    <CardHeader className="pb-4">
                      <CardTitle className="flex items-center gap-2 text-lg">
                        <Trophy className="w-5 h-5 text-emerald-600" />
                        Badge Progress
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-baseline">
                        <span className="text-3xl font-bold text-emerald-900">{earnedCount}</span>
                        <span className="text-gray-600 text-sm ml-2">/ {totalCount}</span>
                      </div>
                      <Progress value={completionRate} className="h-3" />
                      <div className="text-sm text-gray-600">{completionRate}% completed</div>
                    </CardContent>
                  </Card>

                  {/* Recent Achievement */}
                  {userAchievements.length > 0 && (
                    <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-50 to-pink-100">
                      <CardHeader className="pb-4">
                        <CardTitle className="flex items-center gap-2 text-lg">
                          <Zap className="w-5 h-5 text-purple-600" />
                          Latest Achievement
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        {(() => {
                          const latestUserAchievement = userAchievements
                            .sort((a, b) => new Date(b.date_earned) - new Date(a.date_earned))[0];
                          const latestAchievement = achievements.find(a => a.id === latestUserAchievement.achievement_id);
                          return latestAchievement ? (
                            <div className="space-y-2">
                              <div className="flex items-center gap-3">
                                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center">
                                  {getAchievementIcon(latestAchievement.icon)}
                                </div>
                                <div>
                                  <h4 className="font-semibold text-purple-900">{latestAchievement.name}</h4>
                                  <p className="text-xs text-purple-700">
                                    {format(new Date(latestUserAchievement.date_earned), 'MMM d, yyyy')}
                                  </p>
                                </div>
                              </div>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleShare(latestAchievement)}
                                className="w-full text-purple-700 border-purple-300 hover:bg-purple-100"
                              >
                                <Share2 className="w-3 h-3 mr-1" />
                                Share This Win
                              </Button>
                            </div>
                          ) : null;
                        })()}
                      </CardContent>
                    </Card>
                  )}
                </div>

                {/* Motivation Section */}
                <Alert className="mb-8 bg-gradient-to-r from-amber-50 to-yellow-50 border-amber-200">
                  <PartyPopper className="h-4 w-4 text-amber-600" />
                  <AlertDescription className="text-amber-800">
                    <strong>Keep going!</strong> You're doing amazing work as a parent. Every small step counts toward your child's bright future.
                    {earnedCount < 3 && " Complete a few activities to earn your first badges!"}
                    {earnedCount >= 3 && earnedCount < 10 && " You're building great habits - keep it up!"}
                    {earnedCount >= 10 && " You're a badge-collecting superstar! 🌟"}
                  </AlertDescription>
                </Alert>
              </TabsContent>

              <TabsContent value="collection">
                {/* Filters and Search */}
                <div className="flex flex-col sm:flex-row gap-4 mb-6">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      placeholder="Search achievements..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger className="w-48">
                        <Filter className="w-4 h-4 mr-2" />
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {ACHIEVEMENT_CATEGORIES.map(cat => (
                          <SelectItem key={cat.value} value={cat.value}>
                            <div className="flex items-center gap-2">
                              <cat.icon className="w-4 h-4" />
                              {cat.label}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={sortBy} onValueChange={setSortBy}>
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="category">Category</SelectItem>
                        <SelectItem value="earned">Earned First</SelectItem>
                        <SelectItem value="points">Points</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Achievement Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
                  <AnimatePresence>
                    {getFilteredAchievements().map((achievement, index) => (
                      <AchievementCard key={achievement.id} achievement={achievement} index={index} />
                    ))}
                  </AnimatePresence>
                </div>

                {getFilteredAchievements().length === 0 && (
                  <div className="text-center py-12 bg-white/80 rounded-lg shadow-md">
                    <Trophy className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                    <h3 className="text-lg font-semibold text-gray-800">No achievements found</h3>
                    <p className="text-gray-600 mt-2">
                      Try adjusting your search or filter criteria.
                    </p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </>
        )}
      </div>

      {/* Achievement Celebration Modal */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowCelebration(null)}
          >
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.5, opacity: 0 }}
              className="bg-white rounded-2xl p-8 max-w-md w-full text-center shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center animate-bounce">
                {getAchievementIcon(showCelebration.icon)}
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">🎉 Achievement Unlocked!</h2>
              <h3 className="text-xl font-semibold text-amber-900 mb-4">{showCelebration.name}</h3>
              <p className="text-gray-600 mb-6">{showCelebration.description}</p>
              <div className="flex gap-3">
                <Button
                  onClick={() => handleShare(showCelebration)}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500"
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setShowCelebration(null)}
                  className="flex-1"
                >
                  Continue
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}