
import React, { useState, useEffect } from 'react';
import { User, District, School } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Building2, Users, BookOpen, Plus, BarChart3 } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { RoleGuard } from '@/components/shared/RoleGuard';

function DistrictAdminDashboard() {
  const [stats, setStats] = useState({});
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);

        const [district, schools, users] = await Promise.all([
          District.get(currentUser.district_id),
          School.filter({ district_id: currentUser.district_id }),
          User.filter({ district_id: currentUser.district_id })
        ]);

        setStats({
          district,
          totalSchools: schools.length,
          totalUsers: users.length,
          totalTeachers: users.filter(u => u.role === 'teacher').length,
          totalParents: users.filter(u => u.role === 'parent').length,
          activeUsers: users.filter(u => u.status === 'active').length,
          recentSchools: schools.slice(0, 5)
        });

      } catch (error) {
        console.error('Dashboard data fetch error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  if (isLoading) {
    return (
      <div className="p-4 md:p-8 space-y-6">
        <Skeleton className="h-10 w-1/3" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i}><CardContent className="p-6"><Skeleton className="h-16 w-full" /></CardContent></Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">District Administration</h1>
            {stats.district && (
              <p className="text-gray-600">{stats.district.name} - {stats.district.state}</p>
            )}
          </div>
          <div className="flex gap-2">
            <Link to={createPageUrl("DistrictSchools")}>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                New School
              </Button>
            </Link>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Schools</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.totalSchools}</p>
                </div>
                <Building2 className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Users</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.totalUsers}</p>
                </div>
                <Users className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Teachers</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.totalTeachers}</p>
                </div>
                <BookOpen className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Parents</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.totalParents}</p>
                </div>
                <Users className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Schools Overview */}
          <Card>
            <CardHeader>
              <CardTitle>Schools in District</CardTitle>
            </CardHeader>
            <CardContent>
              {stats.recentSchools?.length > 0 ? (
                <div className="space-y-3">
                  {stats.recentSchools.map((school) => (
                    <div key={school.id} className="flex justify-between items-center p-3 border rounded-lg">
                      <div>
                        <h4 className="font-medium">{school.name}</h4>
                        <p className="text-sm text-gray-600">{school.school_type} • {school.grade_levels?.join(', ')}</p>
                      </div>
                      <Badge variant={school.is_active ? 'default' : 'secondary'}>
                        {school.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-600">No schools found in this district.</p>
              )}
            </CardContent>
          </Card>

          {/* Subscription Info */}
          <Card>
            <CardHeader>
              <CardTitle>Subscription Details</CardTitle>
            </CardHeader>
            <CardContent>
              {stats.district && (
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Current Plan:</span>
                    <Badge className="capitalize">{stats.district.subscription_tier}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Status:</span>
                    <Badge variant={stats.district.is_active ? 'default' : 'destructive'}>
                      {stats.district.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                  {stats.district.subscription_end_date && (
                    <div className="flex justify-between">
                      <span>Expires:</span>
                      <span className="text-sm">{new Date(stats.district.subscription_end_date).toLocaleDateString()}</span>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Link to={createPageUrl("DistrictSchools")}>
                <Button variant="outline" className="w-full justify-start">
                  <Building2 className="w-4 h-4 mr-2" />
                  Manage Schools
                </Button>
              </Link>
              <Link to={createPageUrl("DistrictUsers")}>
                <Button variant="outline" className="w-full justify-start">
                  <Users className="w-4 h-4 mr-2" />
                  Manage Users
                </Button>
              </Link>
              <Link to={createPageUrl("DistrictAnalytics")}>
                <Button variant="outline" className="w-full justify-start">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  View Analytics
                </Button>
              </Link>
              <Link to={createPageUrl("DistrictSettings")}>
                <Button variant="outline" className="w-full justify-start">
                  <Building2 className="w-4 h-4 mr-2" />
                  District Settings
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default function ProtectedDistrictAdminDashboard() {
  return (
    <RoleGuard allowedRoles={['district_admin', 'system_admin', 'admin']}>
      <DistrictAdminDashboard />
    </RoleGuard>
  );
}
