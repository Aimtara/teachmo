import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { User as UserIcon, ArrowLeft, Loader2, Save, Trash2, School, Globe } from 'lucide-react';
import { User, SchoolDirectory, District } from '@/api/entities';
import { bulkUserManagement } from '@/api/functions';
import { useToast } from '@/components/ui/use-toast';
import RoleGuard from '@/components/shared/RoleGuard';
import { createPageUrl } from '@/utils';
import SchoolAutoComplete from '@/components/onboarding/SchoolAutoComplete'; // Using this for selection

export default function AdminUserEdit() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState({});
  const [selectedSchool, setSelectedSchool] = useState(null);
  const [districts, setDistricts] = useState([]);
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();

  const userId = new URLSearchParams(location.search).get('userId');

  useEffect(() => {
    if (!userId) {
      navigate(createPageUrl('AdminUsers'));
      return;
    }

    const loadData = async () => {
      try {
        setIsLoading(true);
        const [userData, districtData] = await Promise.all([
          User.get(userId),
          District.list()
        ]);
        
        setUser(userData);
        setFormData({
          full_name: userData.full_name || '',
          email: userData.email,
          role: userData.role,
          status: userData.status,
          school_id: userData.school_id || '',
          district_id: userData.district_id || ''
        });

        if (userData.school_id) {
          try {
            const school = await SchoolDirectory.get(userData.school_id);
            setSelectedSchool(school);
          } catch {
             setSelectedSchool({school_id: userData.school_id, school_name: 'Unknown/Custom School'})
          }
        }
        
        setDistricts(districtData);
      } catch (error) {
        console.error("Error loading user data:", error);
        toast({
          variant: 'destructive',
          title: 'Error',
          description: 'Could not load user data.'
        });
        navigate(createPageUrl('AdminUsers'));
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [userId, navigate, toast]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };
  
  const handleSchoolSelect = (school) => {
    setSelectedSchool(school);
    setFormData(prev => ({
        ...prev,
        school_id: school?.school_id || null
    }));
  };

  const handleSaveChanges = async () => {
    setIsSaving(true);
    try {
      const { data } = await bulkUserManagement({
        action: 'update',
        updates: [{
          id: userId,
          ...formData
        }]
      });

      if (data.success) {
        toast({
          title: 'User Updated',
          description: `${user.email}'s profile has been updated.`
        });
        navigate(createPageUrl('AdminUsers'));
      } else {
        throw new Error(data.error || 'Failed to update user');
      }
    } catch (error) {
      console.error("Error saving user data:", error);
      toast({
        variant: 'destructive',
        title: 'Save Failed',
        description: error.message
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteUser = async () => {
    if (!window.confirm(`Are you sure you want to delete user ${user.email}? This action cannot be undone.`)) {
      return;
    }
    setIsSaving(true);
    try {
       const { data } = await bulkUserManagement({
        action: 'delete',
        user_ids: [userId]
      });

       if (data.success) {
        toast({
          title: 'User Deleted',
          description: `${user.email} has been permanently deleted.`
        });
        navigate(createPageUrl('AdminUsers'));
      } else {
        throw new Error(data.error || 'Failed to delete user');
      }
    } catch (error) {
      console.error("Error deleting user:", error);
      toast({
        variant: 'destructive',
        title: 'Delete Failed',
        description: error.message
      });
    } finally {
      setIsSaving(false);
    }
  };


  if (isLoading) {
    return <div className="p-6"><Loader2 className="animate-spin" /></div>;
  }

  return (
    <RoleGuard allowedRoles={['system_admin', 'admin', 'district_admin']}>
      <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-6">
        <Button variant="outline" onClick={() => navigate(createPageUrl('AdminUsers'))}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to All Users
        </Button>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <UserIcon className="w-6 h-6" />
              Edit User: {user.full_name || user.email}
            </CardTitle>
            <CardDescription>
              Modify user details, role, and associations.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="full_name">Full Name</Label>
                <Input id="full_name" value={formData.full_name} onChange={(e) => handleInputChange('full_name', e.target.value)} />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" value={formData.email} disabled />
              </div>
              <div>
                <Label htmlFor="role">Role</Label>
                <Select value={formData.role} onValueChange={(val) => handleInputChange('role', val)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="parent">Parent</SelectItem>
                    <SelectItem value="teacher">Teacher</SelectItem>
                    <SelectItem value="school_admin">School Admin</SelectItem>
                    <SelectItem value="district_admin">District Admin</SelectItem>
                    <SelectItem value="system_admin">System Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="status">Status</Label>
                <Select value={formData.status} onValueChange={(val) => handleInputChange('status', val)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="invited">Invited</SelectItem>
                    <SelectItem value="deactivated">Deactivated</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="school">School</Label>
                <SchoolAutoComplete onSelect={handleSchoolSelect} selectedSchool={selectedSchool} />
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="district">District</Label>
                 <Select value={formData.district_id} onValueChange={(val) => handleInputChange('district_id', val)}>
                  <SelectTrigger><SelectValue placeholder="Select a district" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>None</SelectItem>
                    {districts.map(d => (
                      <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex justify-between items-center pt-6 border-t">
              <Button variant="destructive" onClick={handleDeleteUser} disabled={isSaving}>
                <Trash2 className="w-4 h-4 mr-2" />
                Delete User
              </Button>
              <Button onClick={handleSaveChanges} disabled={isSaving}>
                {isSaving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </RoleGuard>
  );
}