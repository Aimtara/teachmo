
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Star, Sparkles, Crown, Zap, Heart, ArrowRight, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { createStripeCheckout } from "@/api/functions";
import { useToast } from "@/components/ui/use-toast";

const PAYMENT_METHODS = [
  { id: 'stripe', name: 'Credit Card', icon: '💳', description: 'Visa, Mastercard, Amex' },
  { id: 'paypal', name: 'PayPal', icon: '🟦', description: 'Pay with your PayPal account' },
  { id: 'apple', name: 'Apple Pay', icon: '🍎', description: 'Quick and secure' },
  { id: 'venmo', name: 'Venmo', icon: '💙', description: 'Split with partner' },
  { id: 'amazon', name: 'Amazon Pay', icon: '📦', description: 'Use Amazon account' }
];

const PREMIUM_FEATURES = [
  { title: "Unlimited AI Recommendations", description: "Get personalized activities anytime", current: "3 per day" },
  { title: "Advanced Progress Analytics", description: "Detailed insights and growth tracking", current: "Basic stats" },
  { title: "Priority Support", description: "Get help when you need it most", current: "Community support" },
  { title: "Premium Content Library", description: "Access expert guides and resources", current: "Limited content" },
  { title: "Custom Activity Creation", description: "Create and save your own activities", current: "Not available" },
  { title: "Family Collaboration", description: "Share with partners and caregivers", current: "Single user" },
  { title: "Export & Backup", description: "Download your progress and data", current: "Not available" }
];

export default function UpgradePage() {
  const [user, setUser] = useState(null);
  const [selectedPlan, setSelectedPlan] = useState('monthly');
  const [selectedPayment, setSelectedPayment] = useState('stripe');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPaymentMethods, setShowPaymentMethods] = useState(false); // Note: This state might not be accessible from UI after changes

  const { toast } = useToast();

  useEffect(() => {
    User.me().then(setUser);
  }, []);

  const handleUpgrade = async () => {
    setIsProcessing(true);

    // --- IMPORTANT ---
    // Replace these placeholder IDs with your actual Stripe Price IDs.
    // You can find these in your Stripe Dashboard under Products.
    const priceIds = {
      monthly: 'price_YOUR_MONTHLY_PRICE_ID', // e.g., price_1L2j3k4L5j6k7L8m
      annual: 'price_YOUR_ANNUAL_PRICE_ID'   // e.g., price_1L2j3k4L5j6k7L8n
    };

    const priceId = priceIds[selectedPlan];
    
    if (priceId.includes('YOUR_')) {
        toast({
            variant: "destructive",
            title: "Stripe Not Configured",
            description: "Please replace the placeholder Stripe Price IDs in pages/Upgrade.js to enable payments.",
        });
        setIsProcessing(false);
        return;
    }

    try {
      const response = await createStripeCheckout({ priceId });
      if (response.url) {
        window.location.href = response.url;
      } else {
        throw new Error('Failed to create checkout session.');
      }
    } catch (error) {
      console.error('Stripe checkout error:', error);
      toast({
        variant: "destructive",
        title: "Payment Error",
        description: "Could not initiate payment. Please try again.",
      });
      setIsProcessing(false);
    }
  };

  const openExternalPayment = (method) => {
    const urls = {
      paypal: 'https://www.paypal.com/checkoutnow?token=mock_teachmo_premium',
      apple: 'https://apple.com/apple-pay/mock-teachmo',
      venmo: 'https://venmo.com/pay/mock-teachmo-premium',
      amazon: 'https://pay.amazon.com/mock-teachmo-premium'
    };
    
    if (urls[method]) {
      window.open(urls[method], '_blank');
    } else {
      // For 'stripe' or other non-external methods, call handleUpgrade
      handleUpgrade(); 
    }
  };

  if (user?.subscription_tier === 'premium') {
    return (
      <div className="min-h-screen p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-r from-yellow-400 to-orange-500 flex items-center justify-center">
              <Crown className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900">You're already a Premium member! 🎉</h1>
            <p className="text-lg text-gray-600">
              Thank you for supporting Teachmo. You have access to all premium features.
            </p>
            <Button onClick={() => window.history.back()} size="lg">
              <ArrowRight className="w-5 h-5 mr-2" />
              Continue to App
            </Button>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white mb-4">
              <Star className="w-4 h-4 mr-2" />
              Premium Features
            </Badge>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Unlock Your Parenting Potential
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Get personalized AI guidance, advanced analytics, and premium content to support your parenting journey.
            </p>
          </motion.div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <Card className="border-2 border-purple-200 shadow-xl">
              <CardHeader className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                <CardTitle className="text-2xl flex items-center gap-2">
                  <Crown className="w-6 h-6" />
                  Teachmo Premium
                </CardTitle>
              </CardHeader>
              <CardContent className="p-8">
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Button
                          variant={selectedPlan === 'monthly' ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => setSelectedPlan('monthly')}
                        >
                          Monthly
                        </Button>
                        <Button
                          variant={selectedPlan === 'annual' ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => setSelectedPlan('annual')}
                        >
                          Annual
                          <Badge className="ml-2 bg-green-500">Save 20%</Badge>
                        </Button>
                      </div>
                      <div className="text-3xl font-bold">
                        ${selectedPlan === 'monthly' ? '9.99' : '95.99'}
                        <span className="text-lg text-gray-500">/{selectedPlan === 'monthly' ? 'month' : 'year'}</span>
                      </div>
                      {selectedPlan === 'annual' && (
                        <p className="text-sm text-green-600">Save $24/year compared to monthly</p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-3">
                    {PREMIUM_FEATURES.map((feature, index) => (
                      <div key={index} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="font-medium text-gray-900">{feature.title}</p>
                          <p className="text-sm text-gray-600">{feature.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Button
                    onClick={handleUpgrade}
                    size="lg"
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                    disabled={isProcessing}
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Upgrade to Premium
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>What You Get vs Free</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {PREMIUM_FEATURES.map((feature, index) => (
                    <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
                      <div>
                        <p className="font-medium text-gray-900">{feature.title}</p>
                        <p className="text-sm text-gray-500">Free: {feature.current}</p>
                      </div>
                      <Crown className="w-5 h-5 text-purple-500" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {showPaymentMethods && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-2xl mx-auto"
          >
            <Card className="shadow-xl">
              <CardHeader>
                <CardTitle>Choose Payment Method</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {PAYMENT_METHODS.map((method) => (
                  <Button
                    key={method.id}
                    variant={selectedPayment === method.id ? 'default' : 'outline'}
                    className="w-full justify-start h-auto p-4"
                    onClick={() => {
                      setSelectedPayment(method.id);
                      openExternalPayment(method.id);
                    }}
                  >
                    <div className="flex items-center gap-4">
                      <span className="text-2xl">{method.icon}</span>
                      <div className="text-left">
                        <p className="font-medium">{method.name}</p>
                        <p className="text-sm opacity-70">{method.description}</p>
                      </div>
                    </div>
                  </Button>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}
