import React, { useState } from 'react';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/components/ui/use-toast';
import { Shield, Check, X, Info } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

export default function DoNotSellPage() {
  const [user, setUser] = useState(null);
  const [preferences, setPreferences] = useState({
    doNotSell: false,
    limitDataSharing: false,
    optOutTargeting: false
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  React.useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      // Load existing preferences (in production, these would be stored in user profile)
      setPreferences({
        doNotSell: userData.privacy_preferences?.doNotSell || false,
        limitDataSharing: userData.privacy_preferences?.limitDataSharing || false,
        optOutTargeting: userData.privacy_preferences?.optOutTargeting || false
      });
    } catch (error) {
      console.error('Failed to load user data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSavePreferences = async () => {
    setIsSaving(true);
    try {
      await User.updateMyUserData({
        privacy_preferences: {
          ...user.privacy_preferences,
          ...preferences,
          lastUpdated: new Date().toISOString()
        }
      });
      
      toast({
        title: 'Preferences Updated',
        description: 'Your privacy preferences have been saved successfully.'
      });
    } catch (error) {
      console.error('Failed to save preferences:', error);
      toast({
        variant: 'destructive',
        title: 'Save Failed',
        description: 'Failed to save your preferences. Please try again.'
      });
    } finally {
      setIsSaving(false);
    }
  };

  const updatePreference = (key, value) => {
    setPreferences(prev => ({
      ...prev,
      [key]: value
    }));
  };

  return (
    <div className="max-w-3xl mx-auto p-6 space-y-8">
      <div className="text-center">
        <Shield className="w-12 h-12 mx-auto mb-4 text-blue-600" />
        <h1 className="text-3xl font-bold mb-2">Do Not Sell My Personal Information</h1>
        <p className="text-gray-600">
          Control how your personal information is shared and used
        </p>
      </div>

      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          Under the California Consumer Privacy Act (CCPA), you have the right to opt-out of the 
          sale of your personal information. Teachmo does not sell personal information to third parties.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle>Current Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center gap-3">
              <Check className="w-5 h-5 text-green-600" />
              <div>
                <p className="font-medium text-green-900">We Don't Sell Your Data</p>
                <p className="text-sm text-green-700">
                  Teachmo does not sell personal information to third parties
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Privacy Controls</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label htmlFor="do-not-sell" className="text-base font-medium">
                Do Not Sell My Information
              </Label>
              <p className="text-sm text-gray-600">
                Prevent any potential sale of your personal information
              </p>
            </div>
            <Switch
              id="do-not-sell"
              checked={preferences.doNotSell}
              onCheckedChange={(checked) => updatePreference('doNotSell', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label htmlFor="limit-sharing" className="text-base font-medium">
                Limit Data Sharing
              </Label>
              <p className="text-sm text-gray-600">
                Restrict sharing of your data with service providers beyond what's necessary for app functionality
              </p>
            </div>
            <Switch
              id="limit-sharing"
              checked={preferences.limitDataSharing}
              onCheckedChange={(checked) => updatePreference('limitDataSharing', checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label htmlFor="opt-out-targeting" className="text-base font-medium">
                Opt-out of Targeted Features
              </Label>
              <p className="text-sm text-gray-600">
                Disable personalized recommendations based on your activity patterns
              </p>
            </div>
            <Switch
              id="opt-out-targeting"
              checked={preferences.optOutTargeting}
              onCheckedChange={(checked) => updatePreference('optOutTargeting', checked)}
            />
          </div>

          <div className="pt-4 border-t">
            <Button onClick={handleSavePreferences} disabled={isSaving} className="w-full">
              {isSaving ? 'Saving...' : 'Save Privacy Preferences'}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>What This Means</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-sm">
            <div>
              <h4 className="font-medium mb-1">We Don't Sell Your Information</h4>
              <p className="text-gray-600">
                Teachmo has never sold and will never sell your personal information to advertisers, 
                data brokers, or other third parties.
              </p>
            </div>
            
            <div>
              <h4 className="font-medium mb-1">Limited Data Sharing</h4>
              <p className="text-gray-600">
                We only share data with trusted service providers who help us operate the app 
                (like hosting and analytics), and they are contractually bound to protect your privacy.
              </p>
            </div>
            
            <div>
              <h4 className="font-medium mb-1">Your Rights</h4>
              <p className="text-gray-600">
                You can change these preferences at any time. Changes take effect immediately and 
                will be applied to future data processing.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}