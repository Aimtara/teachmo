import React, { useState, useEffect } from 'react';
import { Partner, PartnerEvent, PartnerResource, PartnerOffer } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { 
  Building2, Plus, Eye, MousePointer, Users, Calendar,
  FileText, BarChart3, Settings, Crown, Loader2
} from 'lucide-react';
import { motion } from 'framer-motion';
import PartnerEventForm from '../components/partner/PartnerEventForm';
import PartnerResourceForm from '../components/partner/PartnerResourceForm';
import PartnerOfferForm from '../components/partner/PartnerOfferForm';
import PartnerProfile from '../components/partner/PartnerProfile';
import PartnerAnalytics from '../components/partner/PartnerAnalytics';

export default function PartnerDashboard() {
  const [user, setUser] = useState(null);
  const [partner, setPartner] = useState(null);
  const [events, setEvents] = useState([]);
  const [resources, setResources] = useState([]);
  const [offers, setOffers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const { toast } = useToast();

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);

      // Find partner record for this user
      const partners = await Partner.filter({ created_by: userData.email });
      if (partners.length > 0) {
        const partnerData = partners[0];
        setPartner(partnerData);

        // Load partner's events, resources, and offers
        const [eventsData, resourcesData, offersData] = await Promise.all([
          PartnerEvent.filter({ partner_id: partnerData.id }),
          PartnerResource.filter({ partner_id: partnerData.id }),
          PartnerOffer.filter({ partner_id: partnerData.id })
        ]);

        setEvents(eventsData);
        setResources(resourcesData);
        setOffers(offersData);
      }
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to load dashboard data.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const variants = {
      pending: 'bg-yellow-100 text-yellow-800',
      approved: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800',
      suspended: 'bg-gray-100 text-gray-800'
    };
    return <Badge className={variants[status]}>{status}</Badge>;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  if (!partner) {
    return (
      <div className="text-center py-12">
        <Building2 className="w-16 h-16 mx-auto mb-4 text-gray-400" />
        <h2 className="text-2xl font-bold mb-2">No Partner Account Found</h2>
        <p className="text-gray-600 mb-4">You don't have a partner account yet.</p>
        <Button onClick={() => window.location.href = '/partner-signup'}>
          Apply for Partnership
        </Button>
      </div>
    );
  }

  const totalImpressions = partner.total_impressions || 0;
  const totalClicks = partner.total_clicks || 0;
  const totalRsvps = partner.total_rsvps || 0;
  const clickRate = totalImpressions > 0 ? ((totalClicks / totalImpressions) * 100).toFixed(1) : 0;

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="flex justify-between items-start mb-8">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <Building2 className="w-8 h-8 text-blue-600" />
            <h1 className="text-3xl font-bold">{partner.organization_name}</h1>
            {getStatusBadge(partner.status)}
          </div>
          <p className="text-gray-600">{partner.location}</p>
        </div>
        
        <div className="flex items-center gap-3">
          {partner.subscription_tier === 'pro' && (
            <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
              <Crown className="w-4 h-4 mr-1" />
              Pro Partner
            </Badge>
          )}
          <Button variant="outline" onClick={() => setActiveTab('settings')}>
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </Button>
        </div>
      </div>

      {partner.status === 'pending' && (
        <Card className="mb-6 border-yellow-200 bg-yellow-50">
          <CardContent className="pt-6">
            <p className="text-yellow-800">
              <strong>Application Under Review:</strong> Your partnership application is being reviewed. 
              You'll be able to submit events and resources once approved.
            </p>
          </CardContent>
        </Card>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-6 w-full max-w-2xl">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="events">Events</TabsTrigger>
          <TabsTrigger value="resources">Resources</TabsTrigger>
          <TabsTrigger value="offers">Offers</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="settings">Profile</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Events</p>
                    <p className="text-2xl font-bold">{events.length}</p>
                  </div>
                  <Calendar className="w-8 h-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Impressions</p>
                    <p className="text-2xl font-bold">{totalImpressions.toLocaleString()}</p>
                  </div>
                  <Eye className="w-8 h-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Click Rate</p>
                    <p className="text-2xl font-bold">{clickRate}%</p>
                  </div>
                  <MousePointer className="w-8 h-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">RSVPs</p>
                    <p className="text-2xl font-bold">{totalRsvps}</p>
                  </div>
                  <Users className="w-8 h-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Recent Events</CardTitle>
                <Button size="sm" onClick={() => setActiveTab('events')}>
                  View All
                </Button>
              </CardHeader>
              <CardContent>
                {events.slice(0, 3).map(event => (
                  <div key={event.id} className="flex justify-between items-center py-2 border-b last:border-0">
                    <div>
                      <p className="font-medium">{event.title}</p>
                      <p className="text-sm text-gray-600">{new Date(event.start_time).toLocaleDateString()}</p>
                    </div>
                    <Badge className={
                      event.status === 'approved' ? 'bg-green-100 text-green-800' :
                      event.status === 'pending_review' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-gray-100 text-gray-800'
                    }>
                      {event.status}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Recent Resources</CardTitle>
                <Button size="sm" onClick={() => setActiveTab('resources')}>
                  View All
                </Button>
              </CardHeader>
              <CardContent>
                {resources.slice(0, 3).map(resource => (
                  <div key={resource.id} className="flex justify-between items-center py-2 border-b last:border-0">
                    <div>
                      <p className="font-medium">{resource.title}</p>
                      <p className="text-sm text-gray-600">{resource.type}</p>
                    </div>
                    <Badge className={
                      resource.status === 'approved' ? 'bg-green-100 text-green-800' :
                      resource.status === 'pending_review' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-gray-100 text-gray-800'
                    }>
                      {resource.status}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="events">
          <PartnerEventForm 
            partner={partner} 
            events={events}
            onUpdate={loadDashboardData}
          />
        </TabsContent>

        <TabsContent value="resources">
          <PartnerResourceForm 
            partner={partner}
            resources={resources}
            onUpdate={loadDashboardData}
          />
        </TabsContent>

        <TabsContent value="offers">
          <PartnerOfferForm 
            partner={partner}
            offers={offers}
            onUpdate={loadDashboardData}
          />
        </TabsContent>

        <TabsContent value="analytics">
          <PartnerAnalytics partner={partner} events={events} resources={resources} />
        </TabsContent>

        <TabsContent value="settings">
          <PartnerProfile partner={partner} onUpdate={loadDashboardData} />
        </TabsContent>
      </Tabs>
    </div>
  );
}