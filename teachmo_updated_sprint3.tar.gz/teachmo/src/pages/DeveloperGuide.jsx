import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  BookOpen, 
  Code, 
  Settings, 
  Users, 
  Lightbulb,
  GitBranch,
  TestTube,
  Palette,
  Shield,
  Zap
} from 'lucide-react';
import UXAuditDashboard from '../components/shared/UXAuditDashboard';
import UXOptimizationPlan from '../components/shared/UXOptimizationPlan';

const CodeBlock = ({ children, language = 'javascript' }) => (
  <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto text-sm">
    <code>{children}</code>
  </pre>
);

export default function DeveloperGuide() {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Teachmo Developer Guide</h1>
          <p className="text-gray-600">
            Comprehensive development documentation, UX guidelines, and project conventions
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5 lg:grid-cols-8">
            <TabsTrigger value="overview" className="text-xs">
              <BookOpen className="w-4 h-4 mr-1" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="architecture" className="text-xs">
              <Code className="w-4 h-4 mr-1" />
              Architecture
            </TabsTrigger>
            <TabsTrigger value="setup" className="text-xs">
              <Settings className="w-4 h-4 mr-1" />
              Setup
            </TabsTrigger>
            <TabsTrigger value="conventions" className="text-xs">
              <Palette className="w-4 h-4 mr-1" />
              Style Guide
            </TabsTrigger>
            <TabsTrigger value="contributing" className="text-xs">
              <GitBranch className="w-4 h-4 mr-1" />
              Contributing
            </TabsTrigger>
            <TabsTrigger value="testing" className="text-xs">
              <TestTube className="w-4 h-4 mr-1" />
              Testing
            </TabsTrigger>
            <TabsTrigger value="ux-audit" className="text-xs">
              <Shield className="w-4 h-4 mr-1" />
              UX Audit
            </TabsTrigger>
            <TabsTrigger value="roadmap" className="text-xs">
              <Zap className="w-4 h-4 mr-1" />
              UX Plan
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Project Overview</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold mb-2">What is Teachmo?</h3>
                    <p className="text-gray-700">
                      Teachmo is a comprehensive AI-powered parenting platform that connects parents, teachers, and children 
                      in a unified ecosystem. Built on the Base44 platform, it provides personalized activities, expert guidance, 
                      and seamless school-home communication.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Key Features</h3>
                    <ul className="list-disc pl-5 space-y-1 text-gray-700">
                      <li>AI-powered parenting coach with personalized recommendations</li>
                      <li>Activity suggestions tailored to child development stages</li>
                      <li>Parent-teacher messaging and school integration</li>
                      <li>Progress tracking and milestone celebrations</li>
                      <li>Community features and peer support</li>
                      <li>Premium subscription with advanced features</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Technology Stack</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-medium">Frontend</h4>
                        <ul className="text-sm text-gray-600 mt-1">
                          <li>• React 18 with Hooks</li>
                          <li>• React Router for navigation</li>
                          <li>• Tailwind CSS for styling</li>
                          <li>• Framer Motion for animations</li>
                          <li>• Lucide React for icons</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-medium">Backend & Infrastructure</h4>
                        <ul className="text-sm text-gray-600 mt-1">
                          <li>• Base44 platform (entities, auth)</li>
                          <li>• Deno Deploy for functions</li>
                          <li>• Google OAuth authentication</li>
                          <li>• Stripe for payments</li>
                          <li>• OpenAI for AI features</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Quick Links</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <a href="#setup" onClick={() => setActiveTab('setup')}>
                      <Settings className="w-4 h-4 mr-2" />
                      Development Setup
                    </a>
                  </Button>
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <a href="#architecture" onClick={() => setActiveTab('architecture')}>
                      <Code className="w-4 h-4 mr-2" />
                      Project Architecture
                    </a>
                  </Button>
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <a href="#conventions" onClick={() => setActiveTab('conventions')}>
                      <Palette className="w-4 h-4 mr-2" />
                      Code Style Guide
                    </a>
                  </Button>
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <a href="#contributing" onClick={() => setActiveTab('contributing')}>
                      <GitBranch className="w-4 h-4 mr-2" />
                      Contributing Guidelines
                    </a>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Architecture Tab */}
          <TabsContent value="architecture">
            <Card>
              <CardHeader>
                <CardTitle>Project Architecture</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">File Structure</h3>
                  <CodeBlock>{`teachmo/
├── components/           # Reusable UI components
│   ├── ui/              # Base UI components (shadcn/ui)
│   ├── shared/          # Common components across pages
│   ├── dashboard/       # Dashboard-specific components
│   ├── activities/      # Activity-related components
│   ├── onboarding/      # Onboarding flow components
│   └── ...
├── pages/               # Page components (routes)
├── entities/            # Data entities (JSON schemas)
├── functions/           # Backend functions (Deno Deploy)
├── Layout.js           # Main app layout with navigation
└── globals.css         # Global styles and CSS variables`}</CodeBlock>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Component Architecture</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium mb-2">Pages</h4>
                      <p className="text-sm text-gray-700">
                        Top-level route components that represent full screens. Should be kept lean 
                        and delegate to smaller components.
                      </p>
                      <CodeBlock language="javascript">{`// pages/Dashboard.js
export default function Dashboard() {
  return (
    <div>
      <DashboardHeader />
      <QuickStats />
      <ActivityFeed />
    </div>
  );
}`}</CodeBlock>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2">Components</h4>
                      <p className="text-sm text-gray-700">
                        Reusable UI building blocks. Should be focused on a single responsibility 
                        and accept props for customization.
                      </p>
                      <CodeBlock language="javascript">{`// components/activities/ActivityCard.jsx
export default function ActivityCard({ 
  activity, 
  onSchedule, 
  onComplete 
}) {
  return (
    <Card>
      <CardHeader>
        <h3>{activity.title}</h3>
      </CardHeader>
      <CardContent>
        {/* Activity content */}
      </CardContent>
    </Card>
  );
}`}</CodeBlock>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Data Flow</h3>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <ol className="list-decimal pl-5 space-y-2 text-sm">
                      <li><strong>Entities:</strong> Define data structure using JSON schemas</li>
                      <li><strong>API Layer:</strong> Base44 entities provide CRUD operations</li>
                      <li><strong>Components:</strong> Fetch data using entity methods</li>
                      <li><strong>State Management:</strong> Local state with React hooks</li>
                      <li><strong>User Interactions:</strong> Trigger entity updates</li>
                      <li><strong>UI Updates:</strong> Re-render based on state changes</li>
                    </ol>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Role-Based Access</h3>
                  <div className="grid md:grid-cols-4 gap-4">
                    <div className="bg-green-50 p-3 rounded-lg">
                      <h4 className="font-medium text-green-800">Parents</h4>
                      <ul className="text-xs text-green-700 mt-1 space-y-1">
                        <li>• Activities & Tips</li>
                        <li>• AI Assistant</li>
                        <li>• Child Progress</li>
                        <li>• Teacher Messages</li>
                      </ul>
                    </div>
                    <div className="bg-blue-50 p-3 rounded-lg">
                      <h4 className="font-medium text-blue-800">Teachers</h4>
                      <ul className="text-xs text-blue-700 mt-1 space-y-1">
                        <li>• Class Management</li>
                        <li>• Parent Messages</li>
                        <li>• Student Progress</li>
                        <li>• Assignments</li>
                      </ul>
                    </div>
                    <div className="bg-purple-50 p-3 rounded-lg">
                      <h4 className="font-medium text-purple-800">School Admin</h4>
                      <ul className="text-xs text-purple-700 mt-1 space-y-1">
                        <li>• User Management</li>
                        <li>• School Analytics</li>
                        <li>• Announcements</li>
                        <li>• Settings</li>
                      </ul>
                    </div>
                    <div className="bg-red-50 p-3 rounded-lg">
                      <h4 className="font-medium text-red-800">System Admin</h4>
                      <ul className="text-xs text-red-700 mt-1 space-y-1">
                        <li>• Platform Management</li>
                        <li>• District Oversight</li>
                        <li>• System Analytics</li>
                        <li>• Developer Tools</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* UX Audit Tab */}
          <TabsContent value="ux-audit">
            <UXAuditDashboard />
          </TabsContent>

          {/* UX Optimization Plan Tab */}
          <TabsContent value="roadmap">
            <UXOptimizationPlan />
          </TabsContent>

          {/* Setup Tab */}
          <TabsContent value="setup">
            <Card>
              <CardHeader>
                <CardTitle>Development Setup</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">Prerequisites</h3>
                  <ul className="list-disc pl-5 space-y-1 text-gray-700">
                    <li>Node.js 18+ and npm</li>
                    <li>Git for version control</li>
                    <li>VS Code (recommended) with extensions:
                      <ul className="list-disc pl-5 mt-1 text-sm">
                        <li>ES7+ React/Redux/React-Native snippets</li>
                        <li>Tailwind CSS IntelliSense</li>
                        <li>ESLint extension</li>
                        <li>Prettier - Code formatter</li>
                      </ul>
                    </li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Getting Started</h3>
                  <CodeBlock language="bash">{`# Clone the repository (simulated)
git clone https://github.com/teachmo/teachmo-app.git
cd teachmo-app

# Install dependencies
npm install

# Start development server
npm run dev

# The app will be available at http://localhost:3000`}</CodeBlock>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Environment Configuration</h3>
                  <p className="text-gray-700 mb-3">
                    Base44 platform handles most configuration automatically, but you may need to set up:
                  </p>
                  <CodeBlock language="bash">{`# Environment variables (if needed)
VITE_APP_BASE44_API_URL=https://api.base44.com
VITE_APP_ENVIRONMENT=development

# These are managed by Base44:
# - Database connection
# - Authentication (Google OAuth)
# - API keys (OpenAI, Stripe)`}</CodeBlock>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Development Commands</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <CodeBlock language="bash">{`# Development
npm run dev          # Start dev server
npm run build        # Build for production
npm run preview      # Preview production build

# Code Quality
npm run lint         # Run ESLint
npm run lint:fix     # Fix linting issues
npm run format       # Format with Prettier`}</CodeBlock>
                    </div>
                    <div>
                      <CodeBlock language="bash">{`# Testing
npm test             # Run tests
npm run test:watch   # Run tests in watch mode
npm run test:coverage # Generate coverage report

# Security
npm audit            # Check for vulnerabilities
npm audit fix        # Fix vulnerabilities`}</CodeBook>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Style Guide Tab */}
          <TabsContent value="conventions">
            <Card>
              <CardHeader>
                <CardTitle>Code Style Guide</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">Component Conventions</h3>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">File Naming</h4>
                      <ul className="list-disc pl-5 text-sm text-gray-700 space-y-1">
                        <li>Components: PascalCase (e.g., <code>ActivityCard.jsx</code>)</li>
                        <li>Pages: PascalCase (e.g., <code>Dashboard.jsx</code>)</li>
                        <li>Utilities: camelCase (e.g., <code>dateHelpers.js</code>)</li>
                        <li>Constants: UPPER_SNAKE_CASE (e.g., <code>API_ENDPOINTS.js</code>)</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-medium mb-2">Component Structure</h4>
                      <CodeBlock language="javascript">{`// Standard component template
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Activity } from '@/api/entities';

export default function ActivityCard({ 
  activity, 
  onSchedule, 
  className = '' 
}) {
  const [isLoading, setIsLoading] = useState(false);

  // Handlers
  const handleSchedule = async () => {
    setIsLoading(true);
    try {
      await onSchedule(activity);
    } catch (error) {
      console.error('Failed to schedule activity:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className={className}>
      {/* Component content */}
    </Card>
  );
}`}</CodeBlock>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Styling Conventions</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium mb-2">Tailwind Usage</h4>
                      <ul className="list-disc pl-5 text-sm text-gray-700 space-y-1">
                        <li>Use semantic class names when possible</li>
                        <li>Prefer component variants over inline styles</li>
                        <li>Use CSS variables for theme colors</li>
                        <li>Group related classes together</li>
                      </ul>
                      <CodeBlock language="javascript">{`// Good
<Button 
  className="w-full bg-primary hover:bg-primary/90 
             text-white font-medium py-2 px-4 rounded-lg
             transition-colors duration-200" 
>
  Schedule Activity
</Button>

// Better - use component variants
<Button variant="primary" size="lg" className="w-full">
  Schedule Activity  
</Button>`}</CodeBlock>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2">Responsive Design</h4>
                      <ul className="list-disc pl-5 text-sm text-gray-700 space-y-1">
                        <li>Mobile-first approach</li>
                        <li>Use consistent breakpoints</li>
                        <li>Test on actual devices</li>
                        <li>Consider touch targets (min 44px)</li>
                      </ul>
                      <CodeBlock language="javascript">{`// Mobile-first responsive design
<div className="
  grid grid-cols-1           // Mobile: 1 column
  md:grid-cols-2            // Tablet: 2 columns  
  lg:grid-cols-3            // Desktop: 3 columns
  gap-4 md:gap-6            // Responsive gaps
  p-4 md:p-6 lg:p-8        // Responsive padding
">
  {activities.map(activity => (
    <ActivityCard key={activity.id} activity={activity} />
  ))}
</div>`}</CodeBlock>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Accessibility Guidelines</h3>
                  <div className="bg-blue-50 p-4 rounded-lg space-y-2">
                    <h4 className="font-medium">WCAG 2.1 AA Compliance</h4>
                    <ul className="list-disc pl-5 text-sm space-y-1">
                      <li>All interactive elements must be keyboard accessible</li>
                      <li>Color contrast ratio must be at least 4.5:1</li>
                      <li>All images must have descriptive alt text</li>
                      <li>Form inputs must have proper labels</li>
                      <li>Focus indicators must be visible and clear</li>
                      <li>Content must be screen reader friendly</li>
                    </ul>
                  </div>

                  <CodeBlock language="javascript">{`// Accessible component example
<button
  className="px-4 py-2 bg-blue-600 text-white rounded-lg 
             hover:bg-blue-700 focus:outline-none focus:ring-2 
             focus:ring-blue-500 focus:ring-offset-2
             disabled:opacity-50 disabled:cursor-not-allowed"
  onClick={handleSubmit}
  disabled={isLoading}
  aria-label={isLoading ? 'Saving...' : 'Save changes'}
  aria-describedby="save-help"
>
  {isLoading ? 'Saving...' : 'Save Changes'}
</button>
<p id="save-help" className="sr-only">
  This will save your changes and cannot be undone
</p>`}</CodeBlock>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Contributing Tab */}
          <TabsContent value="contributing">
            <Card>
              <CardHeader>
                <CardTitle>Contributing Guidelines</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">Development Workflow</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium mb-2">Branch Naming</h4>
                      <ul className="list-disc pl-5 text-sm text-gray-700 space-y-1">
                        <li><code>feature/</code> - New features</li>
                        <li><code>fix/</code> - Bug fixes</li>
                        <li><code>docs/</code> - Documentation updates</li>
                        <li><code>refactor/</code> - Code refactoring</li>
                        <li><code>test/</code> - Test additions/updates</li>
                      </ul>
                      <CodeBlock language="bash">{`# Examples
git checkout -b feature/activity-scheduler
git checkout -b fix/mobile-navigation
git checkout -b docs/api-documentation`}</CodeBlock>
                    </div>
                    
                    <div>
                      <h4 className="font-medium mb-2">Commit Messages</h4>
                      <p className="text-sm text-gray-700 mb-2">Follow conventional commits format:</p>
                      <CodeBlock language="bash">{`# Format: type(scope): description
feat(dashboard): add activity quick actions
fix(auth): resolve login redirect issue
docs(readme): update setup instructions
style(ui): improve button focus states
refactor(api): simplify error handling
test(activities): add activity card tests`}</CodeBlock>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Pull Request Process</h3>
                  <div className="space-y-4">
                    <div className="bg-green-50 p-4 rounded-lg">
                      <h4 className="font-medium mb-2">Before Submitting</h4>
                      <ul className="list-disc pl-5 text-sm space-y-1">
                        <li>Run <code>npm run lint</code> and fix all issues</li>
                        <li>Run <code>npm test</code> and ensure all tests pass</li>
                        <li>Test functionality on both desktop and mobile</li>
                        <li>Verify accessibility with keyboard navigation</li>
                        <li>Update documentation if needed</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-medium mb-2">PR Template</h4>
                      <CodeBlock>{`## Description
Brief description of changes made

## Type of Change
- [ ] Bug fix
- [ ] New feature  
- [ ] Breaking change
- [ ] Documentation update

## Testing
- [ ] Tested on desktop
- [ ] Tested on mobile
- [ ] Keyboard navigation tested
- [ ] Screen reader tested (if applicable)

## Screenshots/Videos
(If applicable)

## Additional Notes
Any additional context or considerations`}</CodeBlock>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Code Review Guidelines</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium mb-2">For Reviewers</h4>
                      <ul className="list-disc pl-5 text-sm text-gray-700 space-y-1">
                        <li>Check code follows style guide</li>
                        <li>Verify accessibility compliance</li>
                        <li>Test functionality thoroughly</li>
                        <li>Look for potential security issues</li>
                        <li>Ensure proper error handling</li>
                        <li>Check mobile responsiveness</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2">For Authors</h4>
                      <ul className="list-disc pl-5 text-sm text-gray-700 space-y-1">
                        <li>Provide clear PR descriptions</li>
                        <li>Respond promptly to feedback</li>
                        <li>Keep PRs focused and small</li>
                        <li>Include screenshots for UI changes</li>
                        <li>Document complex logic</li>
                        <li>Update tests when needed</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Quality Standards</h3>
                  <div className="bg-yellow-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Definition of Done</h4>
                    <ul className="list-disc pl-5 text-sm space-y-1">
                      <li>✅ Code follows established patterns and conventions</li>
                      <li>✅ All linting and formatting rules pass</li>
                      <li>✅ Unit tests added/updated and passing</li>
                      <li>✅ Feature works on all supported browsers</li>
                      <li>✅ Mobile responsiveness verified</li>
                      <li>✅ Accessibility requirements met</li>
                      <li>✅ Error handling implemented</li>
                      <li>✅ Performance impact assessed</li>
                      <li>✅ Documentation updated (if needed)</li>
                      <li>✅ Code reviewed and approved</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Testing Tab */}
          <TabsContent value="testing">
            <Card>
              <CardHeader>
                <CardTitle>Testing Guidelines</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">Testing Philosophy</h3>
                  <p className="text-gray-700 mb-4">
                    We follow a testing pyramid approach with emphasis on integration tests that verify 
                    user flows and component interactions.
                  </p>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="bg-green-50 p-4 rounded-lg text-center">
                      <h4 className="font-medium text-green-800">Unit Tests</h4>
                      <p className="text-sm text-green-700 mt-1">
                        Individual functions and utilities
                      </p>
                      <div className="text-2xl font-bold text-green-600 mt-2">30%</div>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-lg text-center">
                      <h4 className="font-medium text-blue-800">Integration Tests</h4>
                      <p className="text-sm text-blue-700 mt-1">
                        Component interactions and user flows
                      </p>
                      <div className="text-2xl font-bold text-blue-600 mt-2">60%</div>
                    </div>
                    <div className="bg-purple-50 p-4 rounded-lg text-center">
                      <h4 className="font-medium text-purple-800">E2E Tests</h4>
                      <p className="text-sm text-purple-700 mt-1">
                        Critical user journeys
                      </p>
                      <div className="text-2xl font-bold text-purple-600 mt-2">10%</div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Test Organization</h3>
                  <CodeBlock>{`components/
├── testing/
│   ├── setup.js              # Test configuration
│   ├── Dashboard.test.jsx    # Dashboard integration tests
│   ├── UserAuthentication.test.jsx
│   ├── ChildManagement.test.jsx
│   ├── ActivityManagement.test.jsx
│   ├── Messaging.test.jsx
│   └── README.md            # Testing guidelines`}</CodeBlock>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Writing Good Tests</h3>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">Test Naming</h4>
                      <CodeBlock language="javascript">{`// Good test names describe the behavior
describe('ActivityCard', () => {
  test('displays activity title and description', () => {
    // Test implementation
  });

  test('calls onSchedule when schedule button is clicked', () => {
    // Test implementation  
  });

  test('shows loading state during scheduling', () => {
    // Test implementation
  });

  test('displays error message when scheduling fails', () => {
    // Test implementation
  });
});`}</CodeBlock>
                    </div>

                    <div>
                      <h4 className="font-medium mb-2">Test Structure (AAA Pattern)</h4>
                      <CodeBlock language="javascript">{`test('schedules activity when button clicked', async () => {
  // Arrange - Set up test data and mocks
  const mockActivity = {
    id: '1',
    title: 'Reading Time',
    description: 'Daily reading practice'
  };
  const mockOnSchedule = jest.fn();
  
  // Act - Perform the action being tested
  render(<ActivityCard activity={mockActivity} onSchedule={mockOnSchedule} />);
  const scheduleButton = screen.getByRole('button', { name: /schedule/i });
  await user.click(scheduleButton);
  
  // Assert - Verify the expected outcome
  expect(mockOnSchedule).toHaveBeenCalledWith(mockActivity);
  expect(mockOnSchedule).toHaveBeenCalledTimes(1);
});`}</CodeBlock>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Accessibility Testing</h3>
                  <div className="bg-blue-50 p-4 rounded-lg space-y-2">
                    <h4 className="font-medium">Automated Accessibility Testing</h4>
                    <CodeBlock language="javascript">{`import { render, screen } from '@testing-library/react';
import { axe, toHaveNoViolations } from 'jest-axe';
import ActivityCard from '../ActivityCard';

expect.extend(toHaveNoViolations);

test('ActivityCard has no accessibility violations', async () => {
  const { container } = render(
    <ActivityCard activity={mockActivity} onSchedule={jest.fn()} />
  );
  
  const results = await axe(container);
  expect(results).toHaveNoViolations();
});`}</CodeBlock>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Running Tests</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium mb-2">Development</h4>
                      <CodeBlock language="bash">{`# Run all tests
npm test

# Run tests in watch mode
npm run test:watch

# Run specific test file
npm test ActivityCard

# Run tests with coverage
npm run test:coverage`}</CodeBlock>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2">CI/CD</h4>
                      <CodeBlock language="bash">{`# Production test run
npm run test:ci

# Accessibility audit
npm run test:a11y

# Performance testing
npm run test:performance

# Visual regression testing  
npm run test:visual`}</CodeBlock>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}