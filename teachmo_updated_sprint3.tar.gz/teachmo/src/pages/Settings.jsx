
import React, { useState, useEffect, Suspense } from 'react';
import { User } from '@/api/entities'; // User is an entity for API calls
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
// Icons for various sections and tabs
import { Loader2, User as UserIcon, Bell, Palette, Shield, Star, BookOpen, Repeat, Lock, Briefcase, Users, Edit, Plus } from 'lucide-react';
import AvatarUploader from '@/components/profile/AvatarUploader';
import GamificationSettings from '@/components/profile/GamificationSettings';
import TourManagement from '@/components/profile/TourManagement';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import CommunityPrivacySettings from '@/components/community/CommunityPrivacySettings';
import { Slider } from "@/components/ui/slider";
import { Switch } from '@/components/ui/switch'; // Added for notification preferences
import { Child } from '@/api/entities'; // New import for child entity
import EnhancedChildProfile from '@/components/onboarding/EnhancedChildProfile'; // New import for child profile component
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'; // New imports for dialog
import { Badge } from '@/components/ui/badge'; // New import for badges
import { useApi, useEntityCrud } from '@/components/hooks/useApi'; // New import
import { ProgressiveLoader, FormLoadingSkeleton } from '@/components/shared/LoadingStates'; // New import
import EmptyState from '@/components/shared/EmptyState'; // New import for improved UX

const LazyParentingStyleQuiz = React.lazy(() => import('@/components/profile/ParentingStyleQuiz'));

export default function Settings() {
  // Replace useState with standardized API hook
  const userApi = useEntityCrud(User, {
    context: 'user settings',
    showToastOnSuccess: true,
    showToastOnError: true
  });
  
  const childrenApi = useEntityCrud(Child, {
    context: 'children management',
    showToastOnSuccess: true,
    showToastOnError: true
  });

  const [children, setChildren] = useState([]);
  const [showChildModal, setShowChildModal] = useState(false);
  const [editingChild, setEditingChild] = useState(null);
  const [formData, setFormData] = useState({
    full_name: '',
    username: '',
    location: '',
  });

  const { toast } = useToast(); // Keep toast for direct messages not covered by useEntityCrud

  // Dummy functions for navigation and URL creation as they are not defined in this standalone file context
  const navigate = (url) => {
    console.log(`Navigating to: ${url}`);
    // In a real application, you would use a router's navigation function here,
    // e.g., from 'next/navigation' or 'react-router-dom'.
    // Example: const router = useRouter(); router.push(url);
  };

  const createPageUrl = (pageName) => {
    // Dummy URL creation based on page name
    if (pageName === "Upgrade") {
      return "/upgrade";
    }
    return `/${pageName.toLowerCase().replace(/\s/g, '-')}`;
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Use standardized API calls with automatic error handling
        const [userData, childrenData] = await Promise.all([
          userApi.get('me'),
          childrenApi.list('-created_date')
        ]);

        // Set user data with proper defaults
        const userWithDefaults = {
          ...userData,
          notification_preferences: userData.notification_preferences || {},
          privacy_preferences: userData.privacy_preferences || {},
        };
        
        userApi.setData(userWithDefaults);
        setChildren(childrenData);
        
        setFormData({
          full_name: userData.full_name || '',
          username: userData.username || '',
          location: userData.location || '',
        });
      } catch (error) {
        // Error handling is automatically managed by the API hooks
        console.error("Failed to fetch settings data:", error);
      }
    };
    
    fetchData();
  }, []); // Empty dependency array as effects that don't depend on external props/state often run once

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData((prev) => ({ ...prev, [id]: value }));
  };

  const handleUpdateUser = async (data) => {
    try {
      const updatedUser = await userApi.update('me', data, 'Settings updated successfully');
      
      // Update local state by merging the changes from the API response
      // userApi.update usually updates the internal data state directly,
      // but explicitly merging here ensures consistency with complex objects.
      userApi.setData(prev => {
        const updated = { ...prev };
        for (const key in data) {
          if (typeof data[key] === 'object' && data[key] !== null && !Array.isArray(data[key]) && updated[key] && typeof updated[key] === 'object') {
            updated[key] = { ...updated[key], ...data[key] };
          } else {
            updated[key] = data[key];
          }
        }
        return updated;
      });
    } catch (error) {
      // Error is automatically handled by the API hook (showToastOnError: true)
      console.error('Failed to update user data:', error);
    }
  };

  const handleAvatarUpload = async (url) => {
    await handleUpdateUser({ avatar_url: url });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await handleUpdateUser(formData);
  };

  const handleChildComplete = async (childData) => {
    try {
      // Refetch children list after a child is added or updated
      const updatedChildren = await childrenApi.list('-created_date', null, editingChild ? "Child updated successfully!" : "Child added successfully!");
      setChildren(updatedChildren);
      setShowChildModal(false); // Close the modal
      setEditingChild(null); // Clear editing state

    } catch (error) {
      // Error handling is managed by childrenApi hook (showToastOnError: true)
      console.error('Error refreshing children:', error);
    }
  };

  const handleEditChild = (child) => {
    setEditingChild(child); // Set the child to be edited
    setShowChildModal(true); // Open the modal
  };

  const handleAddChild = () => {
    setEditingChild(null); // Clear editing state for new child
    setShowChildModal(true); // Open the modal
  };

  const handlePrivacyChange = (key, value) => {
    const updatedPreferences = { ...userApi.data?.privacy_preferences, [key]: value };
    handleUpdateUser({ privacy_preferences: updatedPreferences });
  };

  const handleNotificationChange = (key, value) => {
    const updatedPreferences = { ...userApi.data?.notification_preferences, [key]: value };
    handleUpdateUser({ notification_preferences: updatedPreferences });
  };

  const user = userApi.data;
  const isLoading = userApi.isLoading() || childrenApi.isLoading();
  const hasError = userApi.hasError() || childrenApi.hasError();

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-600 mt-1">Manage your account, profile, and notification preferences.</p>
      </header>

      <ProgressiveLoader
        isLoading={isLoading}
        error={userApi.getError() || childrenApi.getError()}
        onRetry={() => {
          userApi.get('me');
          childrenApi.list('-created_date');
        }}
        fallback={() => <FormLoadingSkeleton fields={6} />}
      >
        <Tabs defaultValue="account" className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-6"> {/* Adjusted grid-cols to 6 */}
            <TabsTrigger value="account"><UserIcon className="w-4 h-4 mr-2" />Account</TabsTrigger>
            <TabsTrigger value="children"><Users className="w-4 h-4 mr-2" />Children</TabsTrigger> {/* New Children tab */}
            <TabsTrigger value="notifications"><Bell className="w-4 h-4 mr-2" />Notifications</TabsTrigger>
            <TabsTrigger value="preferences"><Palette className="w-4 h-4 mr-2" />Preferences</TabsTrigger>
            <TabsTrigger value="privacy"><Lock className="w-4 h-4 mr-2" />Community Privacy</TabsTrigger>
            <TabsTrigger value="subscription"><Briefcase className="w-4 h-4 mr-2" />Subscription</TabsTrigger>
          </TabsList>

          <TabsContent value="account" className="mt-6 space-y-8">
            {/* Profile Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><UserIcon className="w-5 h-5" /> Profile Information</CardTitle>
                <CardDescription>Update your personal details.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="flex items-center gap-6">
                    <AvatarUploader
                      currentAvatar={user?.avatar_url}
                      onUpload={handleAvatarUpload}
                      isSaving={userApi.isLoading('update')}
                      userName={user?.full_name}
                    />
                    <div className="flex-1 grid gap-4">
                      <div>
                        <Label htmlFor="full_name">Full Name</Label>
                        <Input id="full_name" value={formData.full_name} onChange={handleInputChange} />
                      </div>
                      <div>
                        <Label htmlFor="username">Username</Label>
                        <Input id="username" placeholder="@your_username" value={formData.username} onChange={handleInputChange} />
                      </div>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="location">Location (City, State/Country)</Label>
                    <Input id="location" placeholder="e.g., Brooklyn, NY" value={formData.location} onChange={handleInputChange} />
                    <p className="text-xs text-gray-500 mt-1">Used for finding local events and resources.</p>
                  </div>
                  <div className="flex justify-end">
                    <Button 
                      type="submit" 
                      disabled={userApi.isLoading('update')}
                    >
                      {userApi.isLoading('update') && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      Save Changes
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>

            {/* Account Security */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Shield className="w-5 h-5" /> Security</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Email</Label>
                  <p className="text-sm text-gray-700">{user?.email}</p>
                </div>
                <Button variant="outline">Change Password</Button>
              </CardContent>
            </Card>

            {/* Guided Tour and Checklist */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><BookOpen className="w-5 h-5" /> Guided Tour & Checklist</CardTitle>
                <CardDescription>Review features or restart the guided tour to get reacquainted with Teachmo.</CardDescription>
              </CardHeader>
              <CardContent>
                <TourManagement user={user} />
              </CardContent>
            </Card>

            {/* Parenting Style Quiz */}
            {user?.role === 'parent' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><Star className="w-5 h-5" /> Parenting Style</CardTitle>
                  <CardDescription>Discover or update your parenting style to get more tailored advice and activities.</CardDescription>
                </CardHeader>
                <CardContent>
                  <Suspense fallback={<div className="flex justify-center p-8"><Loader2 className="w-6 h-6 animate-spin" /></div>}>
                    <LazyParentingStyleQuiz />
                  </Suspense>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Children Tab Content */}
          <TabsContent value="children" className="mt-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    Children & School Information
                  </CardTitle>
                  <CardDescription>
                    Manage your children's profiles and school connections for personalized activities and school updates.
                  </CardDescription>
                </div>
                <Button 
                  onClick={handleAddChild} 
                  className="bg-green-600 hover:bg-green-700"
                  disabled={childrenApi.isLoading()}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Child
                </Button>
              </CardHeader>
              <CardContent>
                {children.length === 0 ? (
                  <EmptyState
                    icon={Users}
                    title="No children added yet"
                    description="Add your first child to get personalized activities, track progress, and connect with their school."
                    action={
                      <Button 
                        onClick={handleAddChild} 
                        className="bg-green-600 hover:bg-green-700"
                        disabled={childrenApi.isLoading()}
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Your First Child
                      </Button>
                    }
                  />
                ) : (
                  <div className="space-y-4">
                    {children.map((child) => (
                      <div key={child.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                        <div className="flex items-center gap-4">
                          <div
                            className="w-12 h-12 rounded-full flex items-center justify-center text-2xl"
                            style={{
                              backgroundColor: child.color ? `${child.color}20` : '#f3f4f6',
                              color: child.color || '#6b7280'
                            }}
                          >
                            {child.avatar || '👶'}
                          </div>
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="font-semibold text-gray-900">{child.name}</h3>
                              {child.grade_level && (
                                <Badge variant="secondary" className="text-xs">
                                  {child.grade_level}
                                </Badge>
                              )}
                            </div>
                            <div className="text-sm text-gray-600">
                              Age {child.age || 'Unknown'}
                              {child.school_name && (
                                <>
                                  <span className="mx-2">•</span>
                                  <span className="font-medium">{child.school_name}</span>
                                </>
                              )}
                            </div>
                            {child.interests && child.interests.length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-2">
                                {child.interests.slice(0, 3).map((interest) => (
                                  <Badge key={interest} variant="outline" className="text-xs">
                                    {interest}
                                  </Badge>
                                ))}
                                {child.interests.length > 3 && (
                                  <Badge variant="outline" className="text-xs">
                                    +{child.interests.length - 3} more
                                  </Badge>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          onClick={() => handleEditChild(child)}
                          className="hover:bg-blue-50 hover:text-blue-700"
                          disabled={childrenApi.isLoading()}
                        >
                          <Edit className="w-4 h-4 mr-2" />
                          Edit
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="w-5 h-5" />
                  Notifications
                </CardTitle>
                <CardDescription>
                  Manage how you receive notifications, including deals and offers from local partners.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">Receive email newsletters</span>
                    <Switch
                      checked={user?.notification_preferences?.email_newsletter || false}
                      onCheckedChange={(val) => handleNotificationChange('email_newsletter', val)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">Weekly activity summary</span>
                    <Switch
                      checked={user?.notification_preferences?.weekly_summary || false}
                      onCheckedChange={(val) => handleNotificationChange('weekly_summary', val)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">Let me know about relevant offers</span>
                    <Switch
                      checked={user?.notification_preferences?.offers_alert || false}
                      onCheckedChange={(val) => handleNotificationChange('offers_alert', val)}
                    />
                  </div>
                  <div className="pt-4 space-y-3">
                    <Label htmlFor="radius-alert" className="text-sm font-medium text-gray-700">
                        New event radius alerts
                    </Label>
                    <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-600">Notify me about new events within my chosen radius.</span>
                        <Switch
                          checked={user?.notification_preferences?.event_radius_alert || false}
                          onCheckedChange={(val) => handleNotificationChange('event_radius_alert', val)}
                        />
                    </div>
                    {user?.notification_preferences?.event_radius_alert && (
                        <div className="space-y-2">
                            <div className="flex justify-between items-center text-sm">
                                <span>Radius:</span>
                                <span className="font-medium text-blue-600">
                                    {user?.notification_preferences?.event_alert_radius || 25} miles
                                </span>
                            </div>
                            <Slider
                              id="radius-alert"
                              defaultValue={[user?.notification_preferences?.event_alert_radius || 25]}
                              max={50}
                              min={1}
                              step={1}
                              onValueChange={(val) => handleNotificationChange('event_alert_radius', val[0])}
                            />
                        </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="preferences" className="mt-6">
            {/* Gamification Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Palette className="w-5 h-5" /> Gamification</CardTitle>
              </CardHeader>
              <CardContent>
                <GamificationSettings user={user} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="privacy" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Lock className="w-5 h-5" /> Community Privacy</CardTitle>
                <CardDescription>Manage your visibility and interactions within the community.</CardDescription>
              </CardHeader>
              <CardContent>
                {/* This section uses CommunityPrivacySettings component and `handlePrivacyChange` is available for future direct integrations if needed */}
                <CommunityPrivacySettings userId={user?.id} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="subscription" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Briefcase className="w-5 h-5" /> Your Subscription</CardTitle>
                <CardDescription>Manage your plan and billing details.</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="capitalize">Current Plan: <strong>{user?.subscription_tier}</strong></p>
                {user?.subscription_tier === 'free' && (
                  <Button className="mt-4" onClick={() => navigate(createPageUrl("Upgrade"))}>Upgrade to Pro</Button>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Child Profile Modal */}
        <Dialog open={showChildModal} onOpenChange={setShowChildModal}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto p-0">
            <DialogHeader className="p-6 pb-0">
              <DialogTitle>
                {editingChild ? `Edit ${editingChild.name}'s Profile` : 'Add New Child'}
              </DialogTitle>
            </DialogHeader>
            <div className="px-6 pb-6">
              <EnhancedChildProfile
                existingChild={editingChild}
                isEditing={!!editingChild} // Convert editingChild to boolean for isEditing prop
                onComplete={handleChildComplete}
              />
            </div>
          </DialogContent>
        </Dialog>
      </ProgressiveLoader>
    </div>
  );
}
