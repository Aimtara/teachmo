
import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { Pod, PodMember, User, Post, JoinRequest, Invitation } from '@/api/entities';
import { Loader2, Users, ShieldCheck, Settings, Lock, Globe, Plus, Send, Check, X, LogOut, Info, UserPlus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Breadcrumb } from "@/components/ui/breadcrumb";
import { createPageUrl } from '@/utils';

import CreatePostForm from '../components/feed/CreatePostForm';
import PostCard from '../components/feed/PostCard';

function InviteMembersModal({ pod, currentUser, existingMembers, onClose, onInviteSent }) {
    const [followers, setFollowers] = useState([]);
    const [selectedFollowers, setSelectedFollowers] = useState(new Set());
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchFollowers = async () => {
            const followingRecords = await User.getFollows(currentUser.id, 'following');
            const followingIds = followingRecords.map(f => f.following_id);
            if (followingIds.length > 0) {
                const allUsers = await User.list();
                const existingMemberIds = new Set(existingMembers.map(m => m.user_id));
                setFollowers(allUsers.filter(u => followingIds.includes(u.id) && !existingMemberIds.has(u.id)));
            }
            setIsLoading(false);
        };
        fetchFollowers();
    }, [currentUser, existingMembers]);

    const toggleFollower = (id) => {
        setSelectedFollowers(prev => {
            const newSet = new Set(prev);
            if (newSet.has(id)) newSet.delete(id);
            else newSet.add(id);
            return newSet;
        });
    };

    const handleSendInvites = async () => {
        try {
            const invites = Array.from(selectedFollowers).map(userId => ({
                inviter_id: currentUser.id,
                invitee_user_id: userId,
                resource_id: pod.id,
                resource_type: 'pod',
            }));
            await Invitation.bulkCreate(invites);

            // Skip notification creation due to database issues
            console.log("Skipping notification creation due to database connectivity issues");
            onInviteSent();
        } catch (error) {
            console.error("Error sending invites:", error);
            alert("Failed to send invites.");
        }
    };

    return (
        <Dialog open={true} onOpenChange={onClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Invite Members to {pod.name}</DialogTitle>
                </DialogHeader>
                <div className="py-4 max-h-[50vh] overflow-y-auto">
                    {isLoading ? <Loader2 className="mx-auto animate-spin" /> : (
                        followers.length > 0 ? followers.map(f => (
                            <div key={f.id} className="flex items-center justify-between p-2 rounded hover:bg-gray-100">
                                <Label htmlFor={`invite-${f.id}`} className="flex-1 cursor-pointer">{f.full_name}</Label>
                                <input type="checkbox" id={`invite-${f.id}`} checked={selectedFollowers.has(f.id)} onChange={() => toggleFollower(f.id)} />
                            </div>
                        )) : <p className="text-sm text-center text-gray-500">No one left to invite!</p>
                    )}
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose}>Cancel</Button>
                    <Button onClick={handleSendInvites} disabled={selectedFollowers.size === 0}>
                        <Send className="w-4 h-4 mr-2" /> Send Invites ({selectedFollowers.size})
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function JoinRequestModal({ pod, user, onClose, onJoinRequestSent }) {
    const [answer, setAnswer] = useState('');
    const [message, setMessage] = useState('');

    const handleSubmit = async () => {
        try {
            await JoinRequest.create({
                pod_id: pod.id,
                user_id: user.id,
                screening_answer: answer,
                message: message
            });
            onJoinRequestSent();
        } catch (error) {
            console.error("Error creating join request:", error);
            alert("Failed to send join request.");
        }
    };

    return (
         <Dialog open={true} onOpenChange={onClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Request to Join "{pod.name}"</DialogTitle>
                </DialogHeader>
                <div className="py-4 space-y-4">
                    {pod.screening_question && (
                        <div className="space-y-2">
                            <Label htmlFor="screening_answer">{pod.screening_question}</Label>
                            <Textarea id="screening_answer" value={answer} onChange={(e) => setAnswer(e.target.value)} />
                        </div>
                    )}
                    <div className="space-y-2">
                        <Label htmlFor="join_message">Message to Pod Owner (optional)</Label>
                        <Textarea id="join_message" value={message} onChange={(e) => setMessage(e.target.value)} />
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose}>Cancel</Button>
                    <Button onClick={handleSubmit}>Send Request</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

export default function PodDetailPage() {
    const location = useLocation();
    const [pod, setPod] = useState(null);
    const [members, setMembers] = useState([]);
    const [posts, setPosts] = useState([]);
    const [currentUser, setCurrentUser] = useState(null);
    const [isMember, setIsMember] = useState(false);
    const [isOwner, setIsOwner] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [joinRequests, setJoinRequests] = useState([]);
    
    const [showInviteModal, setShowInviteModal] = useState(false);
    const [showJoinModal, setShowJoinModal] = useState(false);
    const [hasRequested, setHasRequested] = useState(false);

    // FIX: More robust URL parsing
    const getPodId = () => {
        try {
            const params = new URLSearchParams(location.search);
            const podId = params.get('id');
            if (podId && podId.trim() && podId !== 'undefined' && podId !== 'null') {
                return podId.trim();
            }
        } catch (e) {
            console.error("Error parsing URL params:", e);
        }
        return null;
    };

    const loadData = async () => {
        try {
            setIsLoading(true);
            const podId = getPodId();
            
            // FIX: Silently handle missing ID, as the UI already shows a 'not found' message.
            if (!podId) {
                setPod(null);
                setIsLoading(false);
                return;
            }

            console.log('Attempting to load pod with ID:', podId);

            const [podData, user] = await Promise.all([
                Pod.get(podId),
                User.me()
            ]);
            
            if (!podData) {
                console.error('Pod not found for ID:', podId);
                setPod(null);
                setIsLoading(false);
                return;
            }

            console.log('Successfully loaded pod:', podData.name);
            setPod(podData);
            setCurrentUser(user);

            const [memberRecords, postRecords, requestRecords] = await Promise.all([
                PodMember.filter({ pod_id: podId }),
                Post.filter({ pod_id: podId }, '-created_date'),
                podData.owner_id === user.id ? JoinRequest.filter({ pod_id: podId, status: 'pending' }) : [],
            ]);
            
            setPosts(postRecords);
            setJoinRequests(requestRecords);
            
            const memberUserIds = memberRecords.map(m => m.user_id);
            const memberUsers = memberUserIds.length > 0 ? await Promise.all(
                memberUserIds.map(id => User.get(id).catch(() => null))
            ).then(users => users.filter(Boolean)) : [];
            
            setMembers(memberUsers);

            const currentUserIsMember = memberUserIds.includes(user.id);
            setIsMember(currentUserIsMember);
            setIsOwner(podData.owner_id === user.id);
            
            if (!currentUserIsMember) {
                const existingRequest = await JoinRequest.filter({ pod_id: podId, user_id: user.id });
                setHasRequested(existingRequest.length > 0 && existingRequest[0].status === 'pending');
            }
        } catch (error) {
            console.error("Error loading pod details:", error);
            setPod(null);
        }
        setIsLoading(false);
    };
    
    useEffect(() => {
        loadData();
    }, [location.search]);

    const handleJoin = async () => {
        if (pod.is_private || pod.requires_approval || pod.screening_question) {
            setShowJoinModal(true);
            return;
        }

        if (pod.max_members && pod.member_count >= pod.max_members) {
            alert("This pod is full.");
            return;
        }
        
        try {
            await PodMember.create({ pod_id: pod.id, user_id: currentUser.id });
            await Pod.update(pod.id, { member_count: pod.member_count + 1 });
            loadData();
        } catch(e) {
            console.error(e);
            alert("Error joining pod");
        }
    };
    
    const handleLeave = async () => {
        if (!window.confirm("Are you sure you want to leave this pod?")) return;
        
        try {
            const memberRecord = await PodMember.filter({ pod_id: pod.id, user_id: currentUser.id });
            if (memberRecord.length > 0) {
                await PodMember.delete(memberRecord[0].id);
                await Pod.update(pod.id, { member_count: pod.member_count - 1 });
                loadData();
            }
        } catch(e) {
            console.error(e);
            alert("Error leaving pod");
        }
    };
    
    const handleRequestAction = async (request, action) => {
        const newStatus = action === 'approve' ? 'approved' : 'declined';
        await JoinRequest.update(request.id, { status: newStatus });
        
        if (action === 'approve') {
             if (pod.max_members && pod.member_count >= pod.max_members) {
                alert("This pod is full. You cannot approve more members.");
                await JoinRequest.update(request.id, { status: 'pending' }); // revert
                return;
            }
            await PodMember.create({ pod_id: pod.id, user_id: request.user_id });
            await Pod.update(pod.id, { member_count: pod.member_count + 1 });
        }
        
        // Skip notification creation due to database issues
        console.log("Skipping notification creation due to database connectivity issues");
        
        loadData();
    };

    if (isLoading) return <div className="flex h-screen items-center justify-center"><Loader2 className="h-12 w-12 animate-spin" /></div>;
    
    if (!pod) {
        return (
            <div className="min-h-screen p-4 md:p-8 flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
                <div className="text-center">
                    <h2 className="text-2xl font-bold text-gray-800 mb-4">Pod not found</h2>
                    <p className="text-gray-600 mb-4">
                        The pod you're looking for might not exist or the link may be incorrect.
                    </p>
                    <Link to={createPageUrl("Community")}>
                        <Button>Back to Community</Button>
                    </Link>
                </div>
            </div>
        );
    }

    const isPodFull = pod.max_members && pod.member_count >= pod.max_members;

    const renderJoinButton = () => {
        if (isMember) return null;
        if (isPodFull) return <Button disabled>Pod is Full</Button>;
        if (hasRequested) return <Button disabled>Request Pending</Button>;
        return <Button onClick={handleJoin}>Join Pod</Button>;
    };

    const breadcrumbItems = [
        { label: "Community", href: createPageUrl("Community") },
        { label: "Pods", href: createPageUrl("Community") + "?tab=pods" },
        { label: pod.name }
    ];

    return (
        <>
            {showInviteModal && isMember && (
                <InviteMembersModal 
                    pod={pod} 
                    currentUser={currentUser} 
                    existingMembers={members} 
                    onClose={() => setShowInviteModal(false)}
                    onInviteSent={() => {
                        setShowInviteModal(false);
                        alert("Invites sent!");
                    }}
                />
            )}
            {showJoinModal && !isMember && (
                <JoinRequestModal
                    pod={pod}
                    user={currentUser}
                    onClose={() => setShowJoinModal(false)}
                    onJoinRequestSent={() => {
                        setShowJoinModal(false);
                        setHasRequested(true);
                        alert("Your request has been sent to the pod owner.");
                    }}
                />
            )}
        <div className="p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
            <div className="max-w-4xl mx-auto">
                <Breadcrumb items={breadcrumbItems} />
                
                <Card className="mb-6 border-0 shadow-lg bg-white/90 backdrop-blur-sm">
                    <CardHeader>
                        <div className="flex justify-between items-start">
                            <div>
                                <CardTitle className="text-2xl md:text-3xl font-bold flex items-center gap-3">
                                    {pod.is_private ? <Lock /> : <Globe />}
                                    {pod.name}
                                </CardTitle>
                                <CardDescription className="mt-2">{pod.description}</CardDescription>
                            </div>
                            <div className="flex-shrink-0 flex items-center gap-2">
                               {isMember && <Button variant="outline" onClick={() => setShowInviteModal(true)}><UserPlus className="w-4 h-4 mr-2" /> Invite</Button> }
                               {renderJoinButton()}
                               {isMember && !isOwner && <Button variant="destructive" size="sm" onClick={handleLeave}><LogOut className="w-4 h-4 mr-2" /> Leave</Button> }
                            </div>
                        </div>
                    </CardHeader>
                     <CardContent>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                           <div className="flex items-center gap-1"><Users /> {pod.member_count}{pod.max_members ? `/${pod.max_members}`:''} members</div>
                           {pod.requires_approval && <div className="flex items-center gap-1"><ShieldCheck /> Requires Approval</div>}
                        </div>
                    </CardContent>
                </Card>

                <Tabs defaultValue="feed">
                    <TabsList className="grid w-full grid-cols-3">
                        <TabsTrigger value="feed">Feed</TabsTrigger>
                        <TabsTrigger value="members">Members ({members.length})</TabsTrigger>
                        <TabsTrigger value="about">About</TabsTrigger>
                    </TabsList>
                    <TabsContent value="feed" className="mt-4">
                        {isMember ? (
                            <div className="space-y-4">
                                <CreatePostForm user={currentUser} podId={pod.id} onPostCreated={loadData} />
                                {posts.map(post => <PostCard key={post.id} post={post} currentUser={currentUser} />)}
                            </div>
                        ): (
                            <div className="text-center p-8 bg-white rounded-lg shadow-md">Join this pod to see and create posts.</div>
                        )}
                    </TabsContent>
                    <TabsContent value="members" className="mt-4">
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                            {members.map(member => (
                                <Card key={member.id} className="text-center p-4">
                                    <Avatar className="mx-auto mb-2">
                                        <AvatarImage src={member.avatar_url} />
                                        <AvatarFallback>{member.full_name ? member.full_name[0] : '?'}</AvatarFallback>
                                    </Avatar>
                                    <p className="font-semibold text-sm truncate">{member.full_name}</p>
                                    {pod.owner_id === member.id && <Badge variant="secondary" className="mt-1">Owner</Badge>}
                                </Card>
                            ))}
                        </div>
                    </TabsContent>
                    <TabsContent value="about" className="mt-4 space-y-4">
                         {isOwner && joinRequests.length > 0 && (
                            <Card>
                                <CardHeader>
                                    <CardTitle>Pending Join Requests ({joinRequests.length})</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-3">
                                    {joinRequests.map(req => {
                                        // Ensure user is found, provide a fallback if not (e.g., user deleted)
                                        const user = members.find(m => m.id === req.user_id) || {full_name: 'Unknown User', id: req.user_id};
                                        return (
                                        <div key={req.id} className="flex justify-between items-center p-2 border rounded-lg">
                                            <div>
                                                <p className="font-semibold">{user.full_name}</p>
                                                {req.screening_answer && <p className="text-sm text-gray-500 italic">"{req.screening_answer}"</p>}
                                                {req.message && <p className="text-sm text-gray-500">Message: "{req.message}"</p>}
                                            </div>
                                            <div className="flex gap-2">
                                                <Button size="sm" variant="outline" className="text-green-600 border-green-600 hover:bg-green-50" onClick={() => handleRequestAction(req, 'approve')}><Check className="w-4 h-4" /></Button>
                                                <Button size="sm" variant="outline" className="text-red-600 border-red-600 hover:bg-red-50" onClick={() => handleRequestAction(req, 'decline')}><X className="w-4 h-4" /></Button>
                                            </div>
                                        </div>
                                    )})}
                                </CardContent>
                            </Card>
                        )}
                        <Card>
                            <CardHeader><CardTitle>Pod Details</CardTitle></CardHeader>
                            <CardContent className="text-sm space-y-2">
                                <p><strong className="font-medium">Description: </strong>{pod.description}</p>
                                {pod.tags && pod.tags.length > 0 && <p><strong className="font-medium">Tags: </strong>{pod.tags.join(', ')}</p>}
                                {pod.screening_question && <p><strong className="font-medium">Screening Question: </strong>{pod.screening_question}</p>}
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
        </>
    );
}
