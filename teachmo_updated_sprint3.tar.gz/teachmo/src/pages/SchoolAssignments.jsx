import React, { useState, useEffect } from "react";
import { User, Child, Assignment, Course, StudentParentLink, UserMessage } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  BookOpen, 
  Calendar, 
  Clock, 
  CheckCircle, 
  AlertTriangle, 
  MessageSquare, 
  Eye, 
  Filter,
  Search,
  ExternalLink,
  User as UserIcon,
  GraduationCap
} from "lucide-react";
import { format, parseISO, isAfter, isBefore, addDays } from "date-fns";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useToast } from "@/components/ui/use-toast";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";

export default function SchoolAssignments() {
  const [user, setUser] = useState(null);
  const [children, setChildren] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [courses, setCourses] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedChild, setSelectedChild] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showMessageDialog, setShowMessageDialog] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState(null);
  const [messageContent, setMessageContent] = useState('');
  const [isSending, setIsSending] = useState(false);

  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const fetchSchoolData = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);

        if (currentUser.role !== 'parent') {
          navigate(createPageUrl("Dashboard"));
          return;
        }

        // Fetch children
        const childrenData = await Child.list('-created_date');
        setChildren(childrenData);

        if (childrenData.length === 0) {
          setIsLoading(false);
          return;
        }

        // Get student-parent links for this parent
        const studentLinks = await StudentParentLink.filter({ 
          parent_user_id: currentUser.id,
          verification_status: 'verified'
        });
        
        if (studentLinks.length === 0) {
          setIsLoading(false);
          return;
        }

        const studentIds = studentLinks.map(link => link.student_id);
        
        // Fetch assignments for all linked students
        const assignmentsData = await Assignment.filter({
          student_id: { $in: studentIds }
        }, '-due_date');
        setAssignments(assignmentsData);

        // Fetch course information
        const courseIds = [...new Set(assignmentsData.map(a => a.course_id))];
        const coursesPromises = courseIds.map(async (courseId) => {
          try {
            const course = await Course.get(courseId);
            return course;
          } catch (error) {
            console.error(`Failed to fetch course ${courseId}:`, error);
            return null;
          }
        });
        
        const coursesData = await Promise.all(coursesPromises);
        setCourses(coursesData.filter(Boolean));

        // Fetch teacher information
        const teacherIds = [...new Set(coursesData.filter(Boolean).map(c => c.teacher_id))];
        const teachersPromises = teacherIds.map(async (teacherId) => {
          try {
            const teacher = await User.get(teacherId);
            return teacher;
          } catch (error) {
            console.error(`Failed to fetch teacher ${teacherId}:`, error);
            return null;
          }
        });
        
        const teachersData = await Promise.all(teachersPromises);
        setTeachers(teachersData.filter(Boolean));

      } catch (error) {
        console.error("Error fetching school data:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load school assignments. Please try again."
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchSchoolData();
  }, [navigate, toast]);

  const handleMarkAsReviewed = async (assignmentId) => {
    try {
      // In a real app, you would create a parent review record
      // For now, we'll update a flag on the assignment or create a separate tracking entity
      toast({
        title: "Marked as Reviewed",
        description: "Assignment has been marked as reviewed by parent."
      });
    } catch (error) {
      console.error("Error marking assignment as reviewed:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to mark assignment as reviewed."
      });
    }
  };

  const handleContactTeacher = async (assignment) => {
    setSelectedAssignment(assignment);
    setMessageContent(`Hi, I have a question about the assignment "${assignment.title}" for my child.`);
    setShowMessageDialog(true);
  };

  const handleSendMessage = async () => {
    if (!messageContent.trim() || !selectedAssignment) return;

    setIsSending(true);
    try {
      const course = courses.find(c => c.id === selectedAssignment.course_id);
      if (!course || !course.teacher_id) {
        throw new Error("Teacher information not found");
      }

      const threadId = `parent_${user.id}_teacher_${course.teacher_id}_${Date.now()}`;
      
      await UserMessage.create({
        sender_id: user.id,
        recipient_id: course.teacher_id,
        content: messageContent.trim(),
        thread_id: threadId,
        message_type: 'text'
      });

      toast({
        title: "Message Sent",
        description: "Your message has been sent to the teacher."
      });

      setMessageContent('');
      setSelectedAssignment(null);
      setShowMessageDialog(false);

    } catch (error) {
      console.error("Error sending message:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to send message. Please try again."
      });
    } finally {
      setIsSending(false);
    }
  };

  const getStatusBadge = (assignment) => {
    const dueDate = assignment.due_date ? parseISO(assignment.due_date) : null;
    const now = new Date();
    const isOverdue = dueDate && isBefore(dueDate, now);
    const isDueSoon = dueDate && isAfter(dueDate, now) && isBefore(dueDate, addDays(now, 3));

    switch (assignment.status) {
      case 'Submitted':
        return <Badge className="bg-blue-100 text-blue-800">Submitted</Badge>;
      case 'Graded':
        return <Badge className="bg-green-100 text-green-800">Graded</Badge>;
      case 'InProgress':
        return <Badge className="bg-yellow-100 text-yellow-800">In Progress</Badge>;
      case 'NotStarted':
      default:
        if (isOverdue) {
          return <Badge className="bg-red-100 text-red-800">Overdue</Badge>;
        } else if (isDueSoon) {
          return <Badge className="bg-orange-100 text-orange-800">Due Soon</Badge>;
        } else {
          return <Badge className="bg-gray-100 text-gray-800">Not Started</Badge>;
        }
    }
  };

  const getGradeDisplay = (assignment) => {
    if (!assignment.grade) return '-';
    
    const numGrade = parseFloat(assignment.grade);
    if (!isNaN(numGrade)) {
      if (numGrade >= 90) return <span className="text-green-600 font-medium">{assignment.grade}</span>;
      if (numGrade >= 80) return <span className="text-blue-600 font-medium">{assignment.grade}</span>;
      if (numGrade >= 70) return <span className="text-yellow-600 font-medium">{assignment.grade}</span>;
      return <span className="text-red-600 font-medium">{assignment.grade}</span>;
    }
    
    return <span className="font-medium">{assignment.grade}</span>;
  };

  const filteredAssignments = assignments.filter(assignment => {
    const matchesChild = selectedChild === 'all' || assignment.student_id === selectedChild;
    const matchesStatus = statusFilter === 'all' || assignment.status === statusFilter || 
      (statusFilter === 'overdue' && assignment.due_date && isBefore(parseISO(assignment.due_date), new Date()));
    const matchesSearch = !searchTerm || 
      assignment.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      assignment.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesChild && matchesStatus && matchesSearch;
  });

  const groupedAssignments = filteredAssignments.reduce((groups, assignment) => {
    const course = courses.find(c => c.id === assignment.course_id);
    const courseName = course?.name || 'Unknown Course';
    
    if (!groups[courseName]) {
      groups[courseName] = [];
    }
    groups[courseName].push(assignment);
    return groups;
  }, {});

  const getAssignmentStats = () => {
    const total = filteredAssignments.length;
    const completed = filteredAssignments.filter(a => a.status === 'Submitted' || a.status === 'Graded').length;
    const overdue = filteredAssignments.filter(a => 
      a.due_date && isBefore(parseISO(a.due_date), new Date()) && 
      a.status !== 'Submitted' && a.status !== 'Graded'
    ).length;
    const dueSoon = filteredAssignments.filter(a => 
      a.due_date && isAfter(parseISO(a.due_date), new Date()) && 
      isBefore(parseISO(a.due_date), addDays(new Date(), 3))
    ).length;

    return { total, completed, overdue, dueSoon };
  };

  const stats = getAssignmentStats();

  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="max-w-6xl mx-auto">
          <div className="mb-6">
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-5 w-96" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            {[1, 2, 3, 4].map(i => (
              <Card key={i}><CardContent className="p-4"><Skeleton className="h-16 w-full" /></CardContent></Card>
            ))}
          </div>
          <Card><CardContent className="p-6"><Skeleton className="h-64 w-full" /></CardContent></Card>
        </div>
      </div>
    );
  }

  if (assignments.length === 0) {
    return (
      <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="max-w-6xl mx-auto">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">School Assignments</h1>
            <p className="text-gray-600">Track your children's school assignments and communicate with teachers</p>
          </div>

          <Card>
            <CardContent className="text-center py-12">
              <BookOpen className="w-16 h-16 mx-auto mb-6 text-gray-400" />
              <h3 className="text-xl font-semibold mb-2">No School Assignments Found</h3>
              <p className="text-gray-600 mb-6">
                {children.length === 0 
                  ? "Add your children's profiles to see their school assignments here."
                  : "We haven't found any school assignments yet. This could be because:"
                }
              </p>
              <div className="text-left max-w-md mx-auto space-y-2 text-gray-600 mb-6">
                {children.length > 0 && (
                  <>
                    <p>• Your school hasn't connected to Teachmo yet</p>
                    <p>• Your children haven't been linked to their school accounts</p>
                    <p>• No assignments have been created in the system</p>
                  </>
                )}
              </div>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                {children.length === 0 ? (
                  <Button onClick={() => navigate(createPageUrl("Settings"))}>
                    <UserIcon className="w-4 h-4 mr-2" />
                    Add Children
                  </Button>
                ) : (
                  <>
                    <Button onClick={() => navigate(createPageUrl("Integrations"))} variant="outline">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      View Integrations
                    </Button>
                    <Button onClick={() => navigate(createPageUrl("Messages"))}>
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Contact Teachers
                    </Button>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">School Assignments</h1>
            <p className="text-gray-600">Track your children's school assignments and communicate with teachers</p>
          </div>
          <Button
            onClick={() => navigate(createPageUrl("Messages"))}
            style={{backgroundColor: 'var(--teachmo-sage)'}}
            className="flex items-center gap-2"
          >
            <MessageSquare className="w-4 h-4" />
            Message Teachers
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.total}</p>
                  <p className="text-sm text-gray-600">Total Assignments</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-green-600">{stats.completed}</p>
                  <p className="text-sm text-gray-600">Completed</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-red-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-red-600">{stats.overdue}</p>
                  <p className="text-sm text-gray-600">Overdue</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-orange-100 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-orange-600">{stats.dueSoon}</p>
                  <p className="text-sm text-gray-600">Due Soon</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <Label htmlFor="search" className="text-sm font-medium">Search</Label>
                <div className="relative mt-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    id="search"
                    placeholder="Search assignments..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="w-full md:w-48">
                <Label htmlFor="child-filter" className="text-sm font-medium">Child</Label>
                <Select value={selectedChild} onValueChange={setSelectedChild}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select child" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Children</SelectItem>
                    {children.map((child) => (
                      <SelectItem key={child.id} value={child.id}>
                        {child.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="w-full md:w-48">
                <Label htmlFor="status-filter" className="text-sm font-medium">Status</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="All Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="NotStarted">Not Started</SelectItem>
                    <SelectItem value="InProgress">In Progress</SelectItem>
                    <SelectItem value="Submitted">Submitted</SelectItem>
                    <SelectItem value="Graded">Graded</SelectItem>
                    <SelectItem value="overdue">Overdue</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Assignments by Course */}
        <div className="space-y-6">
          {Object.keys(groupedAssignments).length === 0 ? (
            <Card>
              <CardContent className="text-center py-8">
                <Filter className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-600">No assignments match your current filters.</p>
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={() => {
                    setSelectedChild('all');
                    setStatusFilter('all');
                    setSearchTerm('');
                  }}
                >
                  Clear Filters
                </Button>
              </CardContent>
            </Card>
          ) : (
            Object.entries(groupedAssignments).map(([courseName, courseAssignments]) => {
              const course = courses.find(c => c.name === courseName);
              const teacher = course ? teachers.find(t => t.id === course.teacher_id) : null;

              return (
                <Card key={courseName}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <GraduationCap className="w-5 h-5" style={{color: 'var(--teachmo-sage)'}} />
                          {courseName}
                        </CardTitle>
                        {teacher && (
                          <p className="text-sm text-gray-600 mt-1">
                            Teacher: {teacher.full_name} • {courseAssignments.length} assignment{courseAssignments.length !== 1 ? 's' : ''}
                          </p>
                        )}
                      </div>
                      {teacher && (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => {
                            setSelectedAssignment({ course_id: course.id, title: `General inquiry about ${courseName}` });
                            setMessageContent(`Hi ${teacher.full_name}, I have a question about ${courseName}.`);
                            setShowMessageDialog(true);
                          }}
                        >
                          <MessageSquare className="w-4 h-4 mr-2" />
                          Contact Teacher
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {courseAssignments.map((assignment) => (
                        <div key={assignment.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <h4 className="font-semibold text-gray-900">{assignment.title}</h4>
                                {getStatusBadge(assignment)}
                              </div>
                              
                              {assignment.description && (
                                <p className="text-sm text-gray-700 mb-3">{assignment.description}</p>
                              )}
                              
                              <div className="flex items-center gap-4 text-sm text-gray-600">
                                {assignment.due_date && (
                                  <span className="flex items-center gap-1">
                                    <Calendar className="w-3 h-3" />
                                    Due: {format(parseISO(assignment.due_date), 'MMM d, yyyy')}
                                  </span>
                                )}
                                <span className="flex items-center gap-1">
                                  Grade: {getGradeDisplay(assignment)}
                                </span>
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-2 ml-4">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleMarkAsReviewed(assignment.id)}
                              >
                                <Eye className="w-4 h-4" />
                                Mark Reviewed
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleContactTeacher(assignment)}
                              >
                                <MessageSquare className="w-4 h-4" />
                                Ask Question
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>

        {/* Contact Teacher Dialog */}
        <Dialog open={showMessageDialog} onOpenChange={setShowMessageDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Contact Teacher</DialogTitle>
              <DialogDescription>
                Send a message about "{selectedAssignment?.title}" to the teacher.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="message">Your Message</Label>
                <Textarea
                  id="message"
                  placeholder="Type your message here..."
                  value={messageContent}
                  onChange={(e) => setMessageContent(e.target.value)}
                  rows={5}
                  className="mt-2"
                />
              </div>
              
              <Alert>
                <MessageSquare className="h-4 w-4" />
                <AlertDescription>
                  Your message will be sent directly to the teacher through Teachmo's secure messaging system.
                </AlertDescription>
              </Alert>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setShowMessageDialog(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleSendMessage}
                disabled={!messageContent.trim() || isSending}
                style={{backgroundColor: 'var(--teachmo-sage)'}}
              >
                {isSending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                    Sending...
                  </>
                ) : (
                  <>
                    <MessageSquare className="w-4 h-4 mr-2" />
                    Send Message
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}