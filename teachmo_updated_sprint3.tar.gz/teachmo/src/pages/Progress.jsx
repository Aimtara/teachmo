
import React, { useState, useEffect } from "react";
import { Child } from "@/api/entities";
import { Activity } from "@/api/entities";
import { ParentingTip } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Calendar, Award, Target, Star, Heart } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format, startOfWeek, endOfWeek, isWithinInterval } from "date-fns";

import ProgressOverview from "../components/progress/ProgressOverview";
import ActivityProgress from "../components/progress/ActivityProgress";
import TipsProgress from "../components/progress/TipsProgress";
import WeeklyInsights from "../components/progress/WeeklyInsights";
import PersonalizedInsights from "../components/dashboard/PersonalizedInsights";
import { usePremium } from "../components/shared/usePremium";
import PremiumGate from "../components/shared/PremiumGate";
import ActivityDetailModal from "../components/activities/ActivityDetailModal";
import SkillTrackProgress from "../components/progress/SkillTrackProgress";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { useEntityData } from '@/components/hooks/useEntityData';
import { ProgressiveLoader, PageLoadingSkeleton, EmptyState } from '@/components/shared/LoadingStates';

export default function Progress() {
  // Replace useState with standardized data hooks
  const childrenData = useEntityData(Child, {
    initialSort: '-created_date',
    enableCache: true
  });
  
  const activitiesData = useEntityData(Activity, {
    initialSort: '-created_date',
    enableCache: true
  });
  
  const tipsData = useEntityData(ParentingTip, {
    initialSort: '-created_date',
    enableCache: true
  });

  const [user, setUser] = useState(null);
  const [selectedChild, setSelectedChild] = useState(null);
  const [selectedActivity, setSelectedActivity] = useState(null);

  const { isPremium, checkFeatureAccess } = usePremium();

  useEffect(() => {
    // Load user data
    User.me().then(setUser).catch(() => null);
  }, []);

  useEffect(() => {
    // Set first child as selected when children load
    if (childrenData.data.length > 0 && !selectedChild) {
      setSelectedChild(childrenData.data[0]);
    }
  }, [childrenData.data, selectedChild]);

  const getChildProgress = (child) => {
    if (!child) return null;

    const childActivities = activitiesData.data.filter(a => a.child_id === child.id);
    const completedActivities = childActivities.filter(a => a.status === 'completed');
    const thisWeekCompleted = completedActivities.filter(a => {
      if (!a.completion_date) return false;
      const completionDate = new Date(a.completion_date);
      return isWithinInterval(completionDate, {
        start: startOfWeek(new Date()),
        end: endOfWeek(new Date())
      });
    });

    return {
      totalActivities: childActivities.length,
      completedActivities: completedActivities.length,
      weeklyCompleted: thisWeekCompleted.length,
      completionRate: childActivities.length > 0 ? (completedActivities.length / childActivities.length) * 100 : 0,
      averageRating: completedActivities.length > 0 
        ? completedActivities.reduce((sum, a) => sum + (a.rating || 0), 0) / completedActivities.length 
        : 0
    };
  };

  const handleStatClick = (statType) => {
    console.log(`Clicked on ${statType} stat`);
  };

  const handleActivityClick = (activity) => {
    setSelectedActivity(activity);
  };

  const isLoading = childrenData.isLoading || activitiesData.isLoading || tipsData.isLoading;
  const primaryError = childrenData.error || activitiesData.error || tipsData.error;
  
  return (
    <div className="min-h-screen p-2 sm:p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto">
        <div className="mb-4 sm:mb-6">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">Progress Tracking</h1>
          <p className="text-sm sm:text-base text-gray-600">
            Monitor your family's development journey and celebrate achievements.
          </p>
        </div>

        <ProgressiveLoader
          isLoading={isLoading}
          error={primaryError}
          onRetry={() => {
            childrenData.refresh();
            activitiesData.refresh();
            tipsData.refresh();
          }}
          fallback={() => <PageLoadingSkeleton cards={4} sidebar={true} />}
        >
          {childrenData.data.length === 0 ? (
            <EmptyState
              icon={TrendingUp}
              title="Your Progress Journey Starts Here"
              description="Add your first child profile to begin tracking their growth and celebrating milestones together."
              action={
                <Link to={createPageUrl('Settings')}>
                  <Button size="lg" style={{backgroundColor: 'var(--teachmo-sage)'}} className="text-white">
                    Add Child Profile
                  </Button>
                </Link>
              }
            />
          ) : (
            <div className="space-y-4 sm:space-y-6">
              <ProgressOverview 
                children={childrenData.data}
                selectedChild={selectedChild}
                onChildSelect={setSelectedChild}
                getChildProgress={getChildProgress}
                onStatClick={handleStatClick}
              />

              {selectedChild && (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 mb-4 sm:mb-6">
                    <SkillTrackProgress 
                      child={selectedChild}
                      activities={activitiesData.data.filter(a => a.child_id === selectedChild?.id)}
                    />
                    
                    {checkFeatureAccess('advanced_analytics') ? (
                      <PersonalizedInsights
                        children={childrenData.data.filter(c => c.id === selectedChild.id)}
                        activities={activitiesData.data}
                        user={user}
                      />
                    ) : (
                      <PremiumGate 
                        title="Unlock AI-Powered Parenting Insights"
                        description="Get personalized guidance and recommendations based on your child's progress."
                        feature="Our AI analyzes your child's activities and development to provide tailored parenting advice."
                      />
                    )}
                  </div>
                </motion.div>
              )}

              {selectedChild ? (
                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <ActivityProgress 
                    child={selectedChild}
                    activities={activitiesData.data.filter(a => a.child_id === selectedChild?.id)}
                    onActivityClick={handleActivityClick}
                  />
                  
                  <TipsProgress tips={tipsData.data} />
                </div>
              ) : (
                <Card className="p-8 text-center text-gray-600">
                  Please select a child to view their activity and tips progress.
                </Card>
              )}

              {checkFeatureAccess('advanced_analytics') ? (
                <WeeklyInsights 
                  child={selectedChild}
                  activities={activitiesData.data.filter(a => a.child_id === selectedChild?.id)}
                  tips={tipsData.data}
                />
              ) : (
                <PremiumGate 
                  title="Unlock Advanced Weekly Analytics"
                  description="Get detailed insights into weekly progress, trends, and developmental milestones."
                  feature="Track completion rates, category performance, and receive weekly development reports."
                />
              )}
            </div>
          )}
        </ProgressiveLoader>
      </div>

      <AnimatePresence>
        {selectedActivity && (
          <ActivityDetailModal
            activity={selectedActivity}
            child={selectedChild}
            onClose={() => setSelectedActivity(null)}
            onStatusChange={() => {}}
            onRating={() => {}}
            isBookmarked={false}
            onBookmark={() => {}}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
