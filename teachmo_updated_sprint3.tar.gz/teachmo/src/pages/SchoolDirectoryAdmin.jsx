
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Building,
  Search,
  Filter,
  Edit,
  Globe,
  MapPin,
  Users,
  Settings,
  CheckCircle,
  XCircle,
  Plus,
  DownloadCloud, // Added for ETL button
  Loader2 // Added for ETL loading spinner
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { useToast } from '@/components/ui/use-toast';
import { SchoolDirectory } from '@/api/entities';
// import { populateSchoolDirectory } from '@/api/functions'; // This is replaced by schoolDirectoryETL
import { schoolDirectoryETL } from '@/api/functions'; // New import
import RoleGuard from '@/components/shared/RoleGuard';
import { DashboardSkeleton } from '@/components/shared/ImprovedSkeletons';

const schoolTypeConfig = {
  public: { label: 'Public', color: 'bg-blue-100 text-blue-800' },
  charter: { label: 'Charter', color: 'bg-green-100 text-green-800' },
  private: { label: 'Private', color: 'bg-purple-100 text-purple-800' }
};

function SchoolCard({ school, onEdit }) {
  const typeConfig = schoolTypeConfig[school.school_type] || { label: school.school_type, color: 'bg-gray-100 text-gray-800' };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-lg border border-gray-200 hover:border-gray-300 transition-colors"
    >
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Building className="w-4 h-4 text-gray-500" />
                <CardTitle className="text-lg">{school.school_name}</CardTitle>
                <Badge className={typeConfig.color}>{typeConfig.label}</Badge>
                {school.integration_enabled && (
                  <Badge className="bg-green-100 text-green-800">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Integrated
                  </Badge>
                )}
              </div>

              <div className="space-y-1 text-sm text-gray-600">
                {school.school_domain && (
                  <div className="flex items-center gap-1">
                    <Globe className="w-3 h-3" />
                    {school.school_domain}
                  </div>
                )}
                {school.district_name && (
                  <div className="flex items-center gap-1">
                    <Users className="w-3 h-3" />
                    {school.district_name}
                  </div>
                )}
                {school.address && (
                  <div className="flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    {school.address} {school.state && `• ${school.state}`}
                  </div>
                )}
              </div>

              {school.grades_served && school.grades_served.length > 0 && (
                <div className="mt-2">
                  <span className="text-xs text-gray-500">Grades: </span>
                  {school.grades_served.slice(0, 5).map((grade, idx) => (
                    <Badge key={idx} variant="outline" className="text-xs mr-1">
                      {grade}
                    </Badge>
                  ))}
                  {school.grades_served.length > 5 && (
                    <span className="text-xs text-gray-500">+{school.grades_served.length - 5} more</span>
                  )}
                </div>
              )}
            </div>

            <div className="flex flex-col items-end gap-2">
              {school.last_verified && (
                <span className="text-xs text-gray-500">
                  Updated {format(new Date(school.last_verified), 'MMM d, yyyy')}
                </span>
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={() => onEdit(school)}
                className="text-xs"
              >
                <Edit className="w-3 h-3 mr-1" />
                Edit
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>
    </motion.div>
  );
}

function SchoolEditModal({ school, onClose, onSave }) {
  const isEditing = !!school;

  const [editedSchool, setEditedSchool] = useState(
    isEditing
      ? school
      : {
          school_name: '',
          school_type: 'public', // Default type
          school_domain: '',
          website_url: '',
          address: '',
          state: '', // Include state for new schools
          district_name: '',
          contact_email: '',
          integration_enabled: false,
          grades_served: [], // Initialize as empty array
          last_verified: new Date().toISOString(), // Or a default 'now' or empty string
        }
  );
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  const handleSave = async () => {
    setIsSaving(true);
    try {
      let savedSchool;
      if (isEditing) {
        savedSchool = await SchoolDirectory.update(school.school_id, editedSchool);
        toast({
          title: "School Updated",
          description: "School information has been saved successfully."
        });
      } else {
        // For new schools, `school_id` might be generated by the backend
        savedSchool = await SchoolDirectory.create(editedSchool); // Assuming SchoolDirectory has a create method
        toast({
          title: "School Added",
          description: "New school has been added successfully."
        });
      }
      onSave(savedSchool);
      onClose();
    } catch (error) {
      console.error('Error saving school:', error);
      toast({
        variant: "destructive",
        title: "Save Failed",
        description: `Could not save school changes. Please try again. ${error.message || ''}`
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
      >
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">{isEditing ? 'Edit School' : 'Add New School'}</h2>
            <Button variant="ghost" onClick={onClose}>×</Button>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="school_name">School Name</Label>
                <Input
                  id="school_name"
                  value={editedSchool.school_name}
                  onChange={(e) => setEditedSchool({...editedSchool, school_name: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="school_type">School Type</Label>
                <Select
                  value={editedSchool.school_type}
                  onValueChange={(value) => setEditedSchool({...editedSchool, school_type: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="public">Public</SelectItem>
                    <SelectItem value="charter">Charter</SelectItem>
                    <SelectItem value="private">Private</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="school_domain">School Domain</Label>
                <Input
                  id="school_domain"
                  value={editedSchool.school_domain || ''}
                  onChange={(e) => setEditedSchool({...editedSchool, school_domain: e.target.value})}
                  placeholder="example.edu"
                />
              </div>
              <div>
                <Label htmlFor="website_url">Website URL</Label>
                <Input
                  id="website_url"
                  value={editedSchool.website_url || ''}
                  onChange={(e) => setEditedSchool({...editedSchool, website_url: e.target.value})}
                  placeholder="https://..."
                />
              </div>
            </div>

            <div>
              <Label htmlFor="address">Address</Label>
              <Input
                id="address"
                value={editedSchool.address || ''}
                onChange={(e) => setEditedSchool({...editedSchool, address: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="state">State</Label>
              <Input
                id="state"
                value={editedSchool.state || ''}
                onChange={(e) => setEditedSchool({...editedSchool, state: e.target.value})}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="district_name">District Name</Label>
                <Input
                  id="district_name"
                  value={editedSchool.district_name || ''}
                  onChange={(e) => setEditedSchool({...editedSchool, district_name: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="contact_email">Contact Email</Label>
                <Input
                  id="contact_email"
                  type="email"
                  value={editedSchool.contact_email || ''}
                  onChange={(e) => setEditedSchool({...editedSchool, contact_email: e.target.value})}
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="integration_enabled"
                checked={editedSchool.integration_enabled}
                onCheckedChange={(checked) => setEditedSchool({...editedSchool, integration_enabled: checked})}
              />
              <Label htmlFor="integration_enabled">Enable Google Classroom Integration</Label>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={onClose}>Cancel</Button>
              <Button onClick={handleSave} disabled={isSaving}>
                {isSaving ? 'Saving...' : 'Save Changes'}
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default function SchoolDirectoryAdmin() {
  const [schools, setSchools] = useState([]);
  const [filteredSchools, setFilteredSchools] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState(''); // Renamed from searchTerm
  const [typeFilter, setTypeFilter] = useState('all');
  const [integrationFilter, setIntegrationFilter] = useState('all');
  const [selectedSchool, setSelectedSchool] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false); // New state for modal visibility
  const [isEtlRunning, setIsEtlRunning] = useState(false); // Renamed from isRunningETL
  const [stats, setStats] = useState({
    total: 0,
    public: 0,
    charter: 0,
    private: 0,
    integrated: 0
  });

  const { toast } = useToast();

  const loadSchools = useCallback(async () => {
    try {
      setIsLoading(true);
      const fetchedSchools = await SchoolDirectory.list('-last_verified', 1000);

      const newStats = {
        total: fetchedSchools.length,
        public: fetchedSchools.filter(s => s.school_type === 'public').length,
        charter: fetchedSchools.filter(s => s.school_type === 'charter').length,
        private: fetchedSchools.filter(s => s.school_type === 'private').length,
        integrated: fetchedSchools.filter(s => s.integration_enabled).length
      };

      setSchools(fetchedSchools);
      setStats(newStats);
    } catch (error) {
      console.error('Error loading schools:', error);
      toast({
        variant: "destructive",
        title: "Error Loading Schools",
        description: "Could not load school directory. Please try again."
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]); // Added toast to dependency array

  useEffect(() => {
    loadSchools();
  }, [loadSchools]); // Now loadSchools is a dependency

  useEffect(() => {
    filterSchools();
  }, [schools, searchQuery, typeFilter, integrationFilter]); // Changed searchTerm to searchQuery

  const filterSchools = () => {
    let filtered = schools.filter(school => {
      const matchesSearch = !searchQuery ||
        school.school_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        school.district_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        school.school_domain?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        school.state?.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesType = typeFilter === 'all' || school.school_type === typeFilter;

      const matchesIntegration = integrationFilter === 'all' ||
        (integrationFilter === 'enabled' && school.integration_enabled) ||
        (integrationFilter === 'disabled' && !school.integration_enabled);

      return matchesSearch && matchesType && matchesIntegration;
    });

    setFilteredSchools(filtered);
  };

  const handleRunEtl = async () => { // Renamed from handleRunETL
    setIsEtlRunning(true);
    toast({
      title: "Starting Data Import",
      description: "Processing school data from external source. This may take a moment."
    });
    try {
      const { data } = await schoolDirectoryETL(); // Changed to schoolDirectoryETL
      if (data.success) {
        toast({
          title: "Import Complete",
          description: `Created ${data.created} new schools and updated ${data.updated}.`
        });
        await loadSchools(); // Refresh the school list immediately
      } else {
        throw new Error(data.error);
      }
    } catch (error) {
      console.error('ETL Error:', error); // Changed log message
      toast({
        variant: 'destructive',
        title: 'Import Failed',
        description: error.message || 'An error occurred during the data import.'
      });
    } finally {
      setIsEtlRunning(false);
    }
  };

  const handleEditSchool = (school) => {
    setSelectedSchool(school);
    setShowEditModal(true);
  };

  const handleCloseModal = () => {
    setSelectedSchool(null); // Clear selected school on close
    setShowEditModal(false);
  };

  const handleSaveSchool = (updatedSchool) => {
    setSchools(prevSchools => {
      // Check if the school already exists (for updates)
      const existingSchoolIndex = prevSchools.findIndex(s => s.school_id === updatedSchool.school_id);
      if (existingSchoolIndex > -1) {
        // Update existing school
        return prevSchools.map((s, index) =>
          index === existingSchoolIndex ? updatedSchool : s
        );
      } else {
        // Add new school
        return [...prevSchools, updatedSchool];
      }
    });
    // Re-run filters and stats if schools array changes
    // A subsequent useEffect will handle this based on `schools` dependency
    handleCloseModal();
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <DashboardSkeleton />
      </div>
    );
  }

  return (
    <RoleGuard allowedRoles={['system_admin', 'admin']}>
      <div className="max-w-7xl mx-auto p-6 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">School Directory</h1>
            <p className="text-gray-600 mt-1">Manage the master list of schools in the Teachmo system.</p>
          </div>
          <div className="flex gap-2"> {/* Changed from gap-3 to gap-2 as per outline */}
            <Button onClick={handleRunEtl} disabled={isEtlRunning}>
              {isEtlRunning ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Importing...
                </>
              ) : (
                <>
                  <DownloadCloud className="w-4 h-4 mr-2" />
                  Run NCES Data Import
                </>
              )}
            </Button>
            <Button onClick={() => handleEditSchool(null)}> {/* Added new button */}
              <Plus className="w-4 h-4 mr-2" />
              Add School Manually
            </Button>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-5 gap-4">
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Schools</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <Building className="w-8 h-8 text-gray-400" />
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Public</p>
                <p className="text-2xl font-bold text-blue-600">{stats.public}</p>
              </div>
              <Building className="w-8 h-8 text-blue-400" />
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Charter</p>
                <p className="text-2xl font-bold text-green-600">{stats.charter}</p>
              </div>
              <Building className="w-8 h-8 text-green-400" />
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Private</p>
                <p className="text-2xl font-bold text-purple-600">{stats.private}</p>
              </div>
              <Building className="w-8 h-8 text-purple-400" />
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Integrated</p>
                <p className="text-2xl font-bold text-green-600">{stats.integrated}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-400" />
            </div>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-4">
          <div className="flex-1">
            <Input
              placeholder="Search schools, districts, domains, or states..."
              value={searchQuery} // Changed to searchQuery
              onChange={(e) => setSearchQuery(e.target.value)} // Changed to setSearchQuery
              className="max-w-md"
            />
          </div>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="School Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="public">Public</SelectItem>
              <SelectItem value="charter">Charter</SelectItem>
              <SelectItem value="private">Private</SelectItem>
            </SelectContent>
          </Select>
          <Select value={integrationFilter} onValueChange={setIntegrationFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Integration" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Schools</SelectItem>
              <SelectItem value="enabled">Integrated</SelectItem>
              <SelectItem value="disabled">Not Integrated</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Schools List */}
        {filteredSchools.length === 0 ? (
          <Card className="p-8 text-center">
            <Building className="w-12 h-12 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No schools found</h3>
            <p className="text-gray-600">
              {searchQuery ? 'Try adjusting your search terms.' : 'The directory appears to be empty.'}
            </p>
          </Card>
        ) : (
          <div className="grid gap-4">
            <AnimatePresence>
              {filteredSchools.map((school) => (
                <SchoolCard
                  key={school.school_id}
                  school={school}
                  onEdit={handleEditSchool} // Changed to call handleEditSchool
                />
              ))}
            </AnimatePresence>
          </div>
        )}

        {/* Edit Modal */}
        <AnimatePresence>
          {showEditModal && ( // Render modal only when showEditModal is true
            <SchoolEditModal
              school={selectedSchool}
              onClose={handleCloseModal} // Use handler
              onSave={handleSaveSchool} // Use handler
            />
          )}
        </AnimatePresence>
      </div>
    </RoleGuard>
  );
}
