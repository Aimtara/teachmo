import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, X, Clock, Sparkles, BookOpen, Users, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, LibraryResource, User, CalendarEvent } from "@/api/entities";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import VoiceInput from "./VoiceInput";

export default function GlobalSearch({ className = "" }) {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [recentSearches, setRecentSearches] = useState([]);
  const searchRef = useRef();
  const inputRef = useRef();

  useEffect(() => {
    // Load recent searches from localStorage
    const saved = localStorage.getItem('teachmo-recent-searches');
    if (saved) {
      setRecentSearches(JSON.parse(saved));
    }
  }, []);

  useEffect(() => {
    // Close search on escape key
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };

    // Global keyboard shortcut (Cmd/Ctrl + K)
    const handleGlobalSearch = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsOpen(true);
        setTimeout(() => inputRef.current?.focus(), 100);
      }
    };

    document.addEventListener('keydown', handleEscape);
    document.addEventListener('keydown', handleGlobalSearch);
    
    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.removeEventListener('keydown', handleGlobalSearch);
    };
  }, []);

  const performSearch = async (searchQuery) => {
    if (!searchQuery.trim()) {
      setResults([]);
      return;
    }

    setIsSearching(true);
    
    try {
      // Search across multiple entity types
      const [activities, resources, events] = await Promise.all([
        Activity.filter({
          $or: [
            { title: { $regex: searchQuery, $options: 'i' } },
            { description: { $regex: searchQuery, $options: 'i' } },
            { category: { $regex: searchQuery, $options: 'i' } }
          ]
        }, '-created_date', 5),
        LibraryResource.filter({
          $or: [
            { title: { $regex: searchQuery, $options: 'i' } },
            { description: { $regex: searchQuery, $options: 'i' } },
            { tags: { $in: [new RegExp(searchQuery, 'i')] } }
          ]
        }, '-created_date', 5),
        CalendarEvent.filter({
          $or: [
            { title: { $regex: searchQuery, $options: 'i' } },
            { description: { $regex: searchQuery, $options: 'i' } }
          ]
        }, '-start_time', 3)
      ]);

      const searchResults = [
        ...activities.map(item => ({ ...item, type: 'activity', icon: Sparkles })),
        ...resources.map(item => ({ ...item, type: 'resource', icon: BookOpen })),
        ...events.map(item => ({ ...item, type: 'event', icon: Calendar }))
      ];

      setResults(searchResults);
    } catch (error) {
      console.error('Search error:', error);
      setResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      performSearch(query);
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [query]);

  const handleSearch = (value) => {
    setQuery(value);
  };

  const handleVoiceInput = (transcript) => {
    setQuery(transcript);
    performSearch(transcript);
  };

  const saveRecentSearch = (searchTerm) => {
    const updated = [searchTerm, ...recentSearches.filter(s => s !== searchTerm)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem('teachmo-recent-searches', JSON.stringify(updated));
  };

  const clearRecentSearches = () => {
    setRecentSearches([]);
    localStorage.removeItem('teachmo-recent-searches');
  };

  const getResultUrl = (result) => {
    switch (result.type) {
      case 'activity':
        return createPageUrl(`UnifiedDiscover?activityId=${result.id}`);
      case 'resource':
        return createPageUrl(`Library?resourceId=${result.id}`);
      case 'event':
        return createPageUrl(`Calendar?eventId=${result.id}`);
      default:
        return createPageUrl('Dashboard');
    }
  };

  return (
    <>
      {/* Search Trigger Button */}
      <Button
        variant="outline"
        onClick={() => setIsOpen(true)}
        className={`gap-2 text-gray-500 hover:text-gray-700 ${className}`}
      >
        <Search className="w-4 h-4" />
        <span className="hidden sm:inline">Search...</span>
        <kbd className="hidden sm:inline-flex items-center gap-1 rounded border bg-white px-1.5 py-0.5 text-xs font-mono text-gray-500">
          <span>⌘</span>K
        </kbd>
      </Button>

      {/* Search Modal */}
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-50 flex items-start justify-center pt-[10vh]">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/50 backdrop-blur-sm"
              onClick={() => setIsOpen(false)}
            />
            
            {/* Search Modal */}
            <motion.div
              ref={searchRef}
              initial={{ opacity: 0, scale: 0.95, y: -20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -20 }}
              className="relative w-full max-w-2xl mx-4"
            >
              <Card className="shadow-2xl">
                <CardContent className="p-0">
                  {/* Search Input */}
                  <div className="flex items-center gap-3 p-4 border-b">
                    <Search className="w-5 h-5 text-gray-400" />
                    <Input
                      ref={inputRef}
                      value={query}
                      onChange={(e) => handleSearch(e.target.value)}
                      placeholder="Search activities, resources, events..."
                      className="border-0 bg-transparent text-lg focus:ring-0 focus:outline-none"
                      autoFocus
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setIsOpen(false)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>

                  {/* Voice Search */}
                  <div className="px-4 py-2 border-b">
                    <VoiceInput
                      onVoiceInput={handleVoiceInput}
                      placeholder="Try saying 'Find creative activities for my 5 year old'"
                      className="text-sm"
                    />
                  </div>

                  {/* Search Results */}
                  <div className="max-h-96 overflow-y-auto">
                    {query.length === 0 && recentSearches.length > 0 && (
                      <div className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="text-sm font-medium text-gray-700">Recent Searches</h4>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={clearRecentSearches}
                            className="text-xs text-gray-500"
                          >
                            Clear
                          </Button>
                        </div>
                        <div className="space-y-2">
                          {recentSearches.map((search, index) => (
                            <button
                              key={index}
                              onClick={() => handleSearch(search)}
                              className="flex items-center gap-2 w-full p-2 text-sm text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                            >
                              <Clock className="w-4 h-4" />
                              {search}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {query.length > 0 && (
                      <div className="p-4">
                        {isSearching ? (
                          <div className="flex items-center justify-center py-8">
                            <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
                          </div>
                        ) : results.length > 0 ? (
                          <div className="space-y-2">
                            {results.map((result) => {
                              const IconComponent = result.icon;
                              return (
                                <Link
                                  key={`${result.type}-${result.id}`}
                                  to={getResultUrl(result)}
                                  onClick={() => {
                                    saveRecentSearch(query);
                                    setIsOpen(false);
                                  }}
                                  className="flex items-center gap-3 p-3 hover:bg-gray-100 rounded-lg transition-colors"
                                >
                                  <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                                    <IconComponent className="w-4 h-4 text-gray-600" />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <h5 className="font-medium text-gray-900 truncate">
                                      {result.title}
                                    </h5>
                                    <p className="text-sm text-gray-600 truncate">
                                      {result.description}
                                    </p>
                                  </div>
                                  <Badge variant="outline" className="text-xs">
                                    {result.type}
                                  </Badge>
                                </Link>
                              );
                            })}
                          </div>
                        ) : (
                          <div className="text-center py-8">
                            <Search className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                            <p className="text-gray-500">No results found for "{query}"</p>
                            <p className="text-sm text-gray-400 mt-1">
                              Try different keywords or check spelling
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}