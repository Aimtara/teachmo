export const fetchWithRetry = async (apiCall, options = {}) => {
  const { 
    retries = 3, 
    delay = 1000, 
    backoff = 2,
    onRetry = () => {},
    onFail = () => {} 
  } = options;
  let attempt = 0;
  let currentDelay = delay;

  while (attempt < retries) {
    try {
      const result = await apiCall();
      
      // Handle base44 entity methods that return data directly
      if (result !== null && result !== undefined) {
        return result;
      }
      
      // If we get null/undefined, treat as an error
      throw new Error('API returned null or undefined result');
      
    } catch (error) {
      attempt++;
      
      // Check if this is a network/connection error that we should retry
      const shouldRetry = 
        error.message?.includes('Network') || 
        error.message?.includes('Failed to fetch') || 
        error.message?.includes('fetch') ||
        error.message?.includes('timeout') ||
        error.message?.includes('ECONNREFUSED') ||
        error.message?.includes('ETIMEDOUT') ||
        error.response?.status === 429 || // Rate limit
        error.response?.status >= 500; // Server errors
      
      // Don't retry authentication errors or client errors (except rate limiting)
      if (!shouldRetry && (
        error.message?.includes('Unauthorized') ||
        error.message?.includes('401') ||
        error.message?.includes('403') ||
        (error.response?.status >= 400 && error.response?.status < 500 && error.response?.status !== 429)
      )) {
        console.error("Non-retryable error:", error);
        onFail(error);
        throw error;
      }
      
      if (attempt >= retries) {
        console.error("API call failed after multiple retries:", error);
        onFail(error);
        throw error;
      }
      
      const isRateLimitError = error.response?.status === 429;
      
      onRetry({ attempt, retries, isRateLimitError, error: error.message });

      console.warn(
        `API call failed (attempt ${attempt}/${retries}). Retrying in ${currentDelay}ms...`,
        error.message || error
      );
      
      await new Promise(resolve => setTimeout(resolve, currentDelay));
      currentDelay *= backoff; // Exponential backoff
    }
  }
};

// Specialized retry function for base44 authentication
export const retryAuthCall = async (authCall, maxRetries = 2) => {
  let lastError;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const result = await authCall();
      return result;
    } catch (error) {
      lastError = error;
      
      // Don't retry auth errors - they won't resolve with retries
      if (error.message?.includes('Unauthorized') || error.message?.includes('401')) {
        throw error;
      }
      
      // Only retry network-related errors
      if (attempt < maxRetries && (
        error.message?.includes('Network') || 
        error.message?.includes('fetch') ||
        error.message?.includes('timeout')
      )) {
        console.warn(`Auth attempt ${attempt} failed, retrying...`, error.message);
        await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
        continue;
      }
      
      throw error;
    }
  }
  
  throw lastError;
};