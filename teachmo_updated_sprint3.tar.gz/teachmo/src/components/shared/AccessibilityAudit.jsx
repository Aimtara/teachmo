import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  AlertTriangle, 
  CheckCircle, 
  Eye, 
  Keyboard, 
  MousePointer, 
  Volume2,
  RefreshCw,
  ExternalLink,
  Info,
  AlertCircle
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';

// Accessibility checks configuration
const ACCESSIBILITY_CHECKS = {
  keyboard: {
    name: 'Keyboard Navigation',
    icon: Keyboard,
    checks: [
      'All interactive elements are keyboard accessible',
      'Focus indicators are visible and clear', 
      'Tab order is logical',
      'No keyboard traps exist',
      'Skip links are present'
    ]
  },
  screen_reader: {
    name: 'Screen Reader Support',
    icon: Volume2,
    checks: [
      'All images have alt text',
      'Form labels are properly associated',
      'Headings are structured hierarchically',
      'ARIA landmarks are present',
      'Dynamic content changes are announced'
    ]
  },
  visual: {
    name: 'Visual Accessibility',
    icon: Eye,
    checks: [
      'Color contrast meets WCAG AA standards',
      'Text is resizable up to 200%',
      'Content doesn\'t rely solely on color',
      'Focus indicators are visible',
      'Error messages are clearly visible'
    ]
  },
  motor: {
    name: 'Motor Accessibility',
    icon: MousePointer,
    checks: [
      'Click targets are at least 44x44 pixels',
      'Drag and drop has keyboard alternatives',
      'Time limits can be extended',
      'Motion can be disabled',
      'Hover content is accessible'
    ]
  }
};

const AccessibilityIssue = ({ issue, onResolve }) => {
  const severityColors = {
    critical: 'bg-red-100 text-red-800 border-red-200',
    serious: 'bg-orange-100 text-orange-800 border-orange-200',
    moderate: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    minor: 'bg-blue-100 text-blue-800 border-blue-200'
  };

  const severityIcons = {
    critical: AlertCircle,
    serious: AlertTriangle,
    moderate: Info,
    minor: Info
  };

  const SeverityIcon = severityIcons[issue.severity];

  return (
    <div className="border rounded-lg p-4 space-y-3">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2">
          <SeverityIcon className="w-5 h-5" />
          <div>
            <h4 className="font-semibold">{issue.title}</h4>
            <p className="text-sm text-gray-600">{issue.description}</p>
          </div>
        </div>
        <Badge className={severityColors[issue.severity]}>
          {issue.severity}
        </Badge>
      </div>
      
      {issue.element && (
        <div className="bg-gray-50 p-2 rounded text-sm font-mono">
          {issue.element}
        </div>
      )}
      
      <div className="space-y-2">
        <p className="text-sm font-medium">How to fix:</p>
        <p className="text-sm text-gray-700">{issue.solution}</p>
      </div>
      
      {issue.wcagReference && (
        <div className="flex items-center gap-2 text-sm text-blue-600">
          <ExternalLink className="w-4 h-4" />
          <span>WCAG {issue.wcagReference}</span>
        </div>
      )}
      
      <div className="flex gap-2">
        <Button size="sm" variant="outline" onClick={() => onResolve(issue.id)}>
          Mark as Resolved
        </Button>
        {issue.learnMoreUrl && (
          <Button size="sm" variant="ghost" asChild>
            <a href={issue.learnMoreUrl} target="_blank" rel="noopener noreferrer">
              Learn More
            </a>
          </Button>
        )}
      </div>
    </div>
  );
};

const AccessibilityScoreCard = ({ score, category, details }) => {
  const getScoreColor = (score) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreDescription = (score) => {
    if (score >= 90) return 'Excellent';
    if (score >= 70) return 'Good';
    if (score >= 50) return 'Needs Improvement';
    return 'Poor';
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">{category}</CardTitle>
          <div className="text-right">
            <div className={`text-2xl font-bold ${getScoreColor(score)}`}>
              {score}%
            </div>
            <div className="text-sm text-gray-500">
              {getScoreDescription(score)}
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Progress value={score} className="mb-3" />
        <div className="space-y-1">
          {details.map((item, index) => (
            <div key={index} className="flex items-center gap-2 text-sm">
              {item.passed ? (
                <CheckCircle className="w-4 h-4 text-green-500" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-red-500" />
              )}
              <span className={item.passed ? 'text-gray-700' : 'text-red-700'}>
                {item.check}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default function AccessibilityAudit() {
  const [auditResults, setAuditResults] = useState(null);
  const [isRunning, setIsRunning] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const { toast } = useToast();

  // Simulated accessibility audit results
  // In a real implementation, this would integrate with axe-core or similar
  const runAccessibilityAudit = async () => {
    setIsRunning(true);
    
    try {
      // Simulate audit delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock audit results based on common accessibility issues
      const mockResults = {
        overallScore: 78,
        categories: {
          keyboard: {
            score: 85,
            details: [
              { check: 'All interactive elements are keyboard accessible', passed: true },
              { check: 'Focus indicators are visible and clear', passed: true },
              { check: 'Tab order is logical', passed: false },
              { check: 'No keyboard traps exist', passed: true },
              { check: 'Skip links are present', passed: true }
            ]
          },
          screen_reader: {
            score: 72,
            details: [
              { check: 'All images have alt text', passed: false },
              { check: 'Form labels are properly associated', passed: true },
              { check: 'Headings are structured hierarchically', passed: true },
              { check: 'ARIA landmarks are present', passed: true },
              { check: 'Dynamic content changes are announced', passed: false }
            ]
          },
          visual: {
            score: 68,
            details: [
              { check: 'Color contrast meets WCAG AA standards', passed: false },
              { check: 'Text is resizable up to 200%', passed: true },
              { check: 'Content doesn\'t rely solely on color', passed: true },
              { check: 'Focus indicators are visible', passed: true },
              { check: 'Error messages are clearly visible', passed: false }
            ]
          },
          motor: {
            score: 88,
            details: [
              { check: 'Click targets are at least 44x44 pixels', passed: true },
              { check: 'Drag and drop has keyboard alternatives', passed: true },
              { check: 'Time limits can be extended', passed: true },
              { check: 'Motion can be disabled', passed: false },
              { check: 'Hover content is accessible', passed: true }
            ]
          }
        },
        issues: [
          {
            id: 1,
            title: 'Missing alt text on images',
            description: 'Several images are missing alternative text descriptions',
            severity: 'serious',
            element: '<img src="child-avatar.png" />',
            solution: 'Add descriptive alt attributes to all images. For decorative images, use alt="".',
            wcagReference: '1.1.1',
            learnMoreUrl: 'https://www.w3.org/WAI/WCAG21/Understanding/non-text-content.html'
          },
          {
            id: 2,
            title: 'Insufficient color contrast',
            description: 'Some text has insufficient contrast against its background',
            severity: 'serious',
            element: '<p style="color: #999; background: #fff;">',
            solution: 'Ensure text has a contrast ratio of at least 4.5:1 for normal text and 3:1 for large text.',
            wcagReference: '1.4.3',
            learnMoreUrl: 'https://www.w3.org/WAI/WCAG21/Understanding/contrast-minimum.html'
          },
          {
            id: 3,
            title: 'Illogical tab order',
            description: 'Tab navigation doesn\'t follow the visual layout in some forms',
            severity: 'moderate',
            solution: 'Ensure tabindex values create a logical navigation flow, or rely on natural DOM order.',
            wcagReference: '2.4.3'
          },
          {
            id: 4,
            title: 'Dynamic content not announced',
            description: 'Loading states and form errors aren\'t announced to screen readers',
            severity: 'serious',
            solution: 'Use aria-live regions to announce dynamic content changes.',
            wcagReference: '4.1.3',
            learnMoreUrl: 'https://www.w3.org/WAI/WCAG21/Understanding/status-messages.html'
          }
        ],
        lastRun: new Date().toISOString()
      };
      
      setAuditResults(mockResults);
      
      toast({
        title: "Accessibility Audit Complete",
        description: `Found ${mockResults.issues.length} issues across key user flows.`
      });
      
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Audit Failed",
        description: "Could not complete accessibility audit. Please try again."
      });
    } finally {
      setIsRunning(false);
    }
  };

  const resolveIssue = (issueId) => {
    setAuditResults(prev => ({
      ...prev,
      issues: prev.issues.filter(issue => issue.id !== issueId)
    }));
    
    toast({
      title: "Issue Resolved",
      description: "The accessibility issue has been marked as resolved."
    });
  };

  const getCategoryDetails = (categoryKey) => {
    const category = ACCESSIBILITY_CHECKS[categoryKey];
    const results = auditResults?.categories[categoryKey];
    
    return {
      ...category,
      ...results
    };
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="w-6 h-6" />
            Accessibility Audit
          </CardTitle>
          <p className="text-gray-600">
            Comprehensive accessibility testing for WCAG 2.1 AA compliance
          </p>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-6">
            <div>
              <p className="text-sm text-gray-600 mb-2">
                Last audit: {auditResults?.lastRun ? 
                  new Date(auditResults.lastRun).toLocaleDateString() : 
                  'Never'
                }
              </p>
              {auditResults && (
                <div className="flex items-center gap-2">
                  <span className="text-2xl font-bold">{auditResults.overallScore}%</span>
                  <span className="text-gray-600">Overall Score</span>
                </div>
              )}
            </div>
            <Button 
              onClick={runAccessibilityAudit} 
              disabled={isRunning}
              className="flex items-center gap-2"
            >
              {isRunning ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Running Audit...
                </>
              ) : (
                <>
                  <Eye className="w-4 h-4" />
                  Run Accessibility Audit
                </>
              )}
            </Button>
          </div>

          {auditResults && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                {Object.entries(ACCESSIBILITY_CHECKS).map(([key, category]) => {
                  const results = auditResults.categories[key];
                  const IconComponent = category.icon;
                  
                  return (
                    <Card 
                      key={key} 
                      className="cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => {
                        setSelectedCategory(key);
                        setShowDetails(true);
                      }}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <IconComponent className="w-5 h-5" />
                          <span className="font-medium text-sm">{category.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-2xl font-bold">{results.score}%</span>
                          <Progress value={results.score} className="flex-1 h-2" />
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              {auditResults.issues.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold mb-4">
                    Issues Found ({auditResults.issues.length})
                  </h3>
                  <div className="space-y-4">
                    {auditResults.issues.map(issue => (
                      <AccessibilityIssue 
                        key={issue.id}
                        issue={issue}
                        onResolve={resolveIssue}
                      />
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Category Details Modal */}
      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedCategory && (
                <>
                  {React.createElement(ACCESSIBILITY_CHECKS[selectedCategory].icon, { className: "w-6 h-6" })}
                  {ACCESSIBILITY_CHECKS[selectedCategory].name} Details
                </>
              )}
            </DialogTitle>
            <DialogDescription>
              Detailed breakdown of accessibility checks in this category
            </DialogDescription>
          </DialogHeader>
          
          {selectedCategory && auditResults && (
            <ScrollArea className="h-[400px] p-4">
              <AccessibilityScoreCard
                score={auditResults.categories[selectedCategory].score}
                category={ACCESSIBILITY_CHECKS[selectedCategory].name}
                details={auditResults.categories[selectedCategory].details}
              />
            </ScrollArea>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}