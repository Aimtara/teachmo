
import React from 'react';
import { useUser } from '@/components/hooks/useUser';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Lock } from 'lucide-react';

// Role hierarchy for permission checking
const ROLE_HIERARCHY = {
  'system_admin': 5,
  'admin': 5, // Add 'admin' role with system admin level
  'district_admin': 4,
  'school_admin': 3,
  'teacher': 2,
  'parent': 1
};

// Check if user has required role or higher
const hasMinimumRole = (userRole, requiredRole) => {
  const userLevel = ROLE_HIERARCHY[userRole] || 0;
  const requiredLevel = ROLE_HIERARCHY[requiredRole] || 0;
  return userLevel >= requiredLevel;
};

// Check if user has specific permissions
const hasPermission = (user, permission) => {
  if (!user) return false;
  
  // System admins and admins have all permissions
  if (user.role === 'system_admin' || user.role === 'admin') return true;
  
  // Check admin_permissions object
  if (user.admin_permissions && user.admin_permissions[permission]) {
    return true;
  }
  
  // Role-based permissions
  const rolePermissions = {
    'district_admin': [
      'manage_district_users',
      'manage_schools',
      'view_district_analytics',
      'send_district_announcements'
    ],
    'school_admin': [
      'manage_school_users',
      'view_school_analytics',
      'send_school_announcements',
      'manage_integrations'
    ],
    'teacher': [
      'manage_classes',
      'view_student_data',
      'send_messages',
      'create_assignments'
    ],
    'parent': [
      'view_child_data',
      'communicate_with_teachers',
      'access_activities'
    ]
  };
  
  return rolePermissions[user.role]?.includes(permission) || false;
};

// Main RoleGuard component
export const RoleGuard = ({ 
  children, 
  requiredRole = null, 
  requiredPermission = null,
  requiresAuth = true,
  fallback = null,
  showError = true
}) => {
  const { user, isLoading } = useUser();
  
  if (isLoading) {
    return <div className="flex items-center justify-center p-8">Loading...</div>;
  }
  
  // Check authentication
  if (requiresAuth && !user) {
    if (!showError) return fallback;
    return (
      <Alert className="m-4">
        <Lock className="h-4 w-4" />
        <AlertDescription>
          You must be signed in to access this content.
        </AlertDescription>
      </Alert>
    );
  }
  
  // Check role requirement
  if (requiredRole && !hasMinimumRole(user?.role, requiredRole)) {
    if (!showError) return fallback;
    return (
      <Alert className="m-4" variant="destructive">
        <Shield className="h-4 w-4" />
        <AlertDescription>
          You don't have permission to access this content. Required role: {requiredRole}
        </AlertDescription>
      </Alert>
    );
  }
  
  // Check specific permission
  if (requiredPermission && !hasPermission(user, requiredPermission)) {
    if (!showError) return fallback;
    return (
      <Alert className="m-4" variant="destructive">
        <Shield className="h-4 w-4" />
        <AlertDescription>
          You don't have the required permissions to access this content.
        </AlertDescription>
      </Alert>
    );
  }
  
  return children;
};

// Hook for checking permissions in components
export const usePermissions = () => {
  const { user } = useUser();
  
  return {
    hasRole: (role) => hasMinimumRole(user?.role, role),
    hasPermission: (permission) => hasPermission(user, permission),
    canAccess: (requiredRole, requiredPermission) => {
      if (requiredRole && !hasMinimumRole(user?.role, requiredRole)) return false;
      if (requiredPermission && !hasPermission(user, requiredPermission)) return false;
      return true;
    }
  };
};

export default RoleGuard;
