import React, { useState } from 'react';
import { PartnerResource } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { Plus, FileText, Edit, Trash2, Loader2, Eye, Download } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

export default function PartnerResourceForm({ partner, resources, onUpdate }) {
  const [showForm, setShowForm] = useState(false);
  const [editingResource, setEditingResource] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    content: '',
    type: '',
    category: '',
    min_age: '',
    max_age: '',
    thumbnail_url: '',
    video_url: '',
    download_url: '',
    tags: []
  });

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      content: '',
      type: '',
      category: '',
      min_age: '',
      max_age: '',
      thumbnail_url: '',
      video_url: '',
      download_url: '',
      tags: []
    });
    setEditingResource(null);
  };

  const handleEdit = (resource) => {
    setFormData({
      ...resource,
      min_age: resource.age_range?.min_age || '',
      max_age: resource.age_range?.max_age || '',
      tags: resource.tags || []
    });
    setEditingResource(resource);
    setShowForm(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const resourceData = {
        partner_id: partner.id,
        ...formData,
        age_range: formData.min_age && formData.max_age ? {
          min_age: parseInt(formData.min_age),
          max_age: parseInt(formData.max_age)
        } : null,
        status: 'pending_review'
      };

      if (editingResource) {
        await PartnerResource.update(editingResource.id, resourceData);
        toast({
          title: 'Resource Updated',
          description: 'Your resource has been updated and is pending review.'
        });
      } else {
        await PartnerResource.create(resourceData);
        toast({
          title: 'Resource Submitted',
          description: 'Your resource has been submitted for review.'
        });
      }

      setShowForm(false);
      resetForm();
      onUpdate();
    } catch (error) {
      console.error('Failed to save resource:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to save resource. Please try again.'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (resourceId) => {
    if (confirm('Are you sure you want to delete this resource?')) {
      try {
        await PartnerResource.delete(resourceId);
        toast({
          title: 'Resource Deleted',
          description: 'Resource has been removed.'
        });
        onUpdate();
      } catch (error) {
        toast({
          variant: 'destructive',
          title: 'Error',
          description: 'Failed to delete resource.'
        });
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Resources</h2>

        <Dialog open={showForm} onOpenChange={setShowForm}>
          <DialogTrigger asChild>
            <Button 
              disabled={partner.status !== 'approved'}
              onClick={() => {
                resetForm();
                setShowForm(true);
              }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Resource
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingResource ? 'Edit Resource' : 'Create New Resource'}
              </DialogTitle>
            </DialogHeader>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label htmlFor="title">Resource Title *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                    required
                  />
                </div>

                <div className="col-span-2">
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    rows={3}
                    required
                  />
                </div>

                <div>
                  <Label>Resource Type *</Label>
                  <Select onValueChange={(value) => setFormData(prev => ({ ...prev, type: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="article">Article</SelectItem>
                      <SelectItem value="guide">Guide</SelectItem>
                      <SelectItem value="video">Video</SelectItem>
                      <SelectItem value="workshop">Workshop</SelectItem>
                      <SelectItem value="toolkit">Toolkit</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Category *</Label>
                  <Select onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="parenting">Parenting Tips</SelectItem>
                      <SelectItem value="education">Education</SelectItem>
                      <SelectItem value="health">Health & Wellness</SelectItem>
                      <SelectItem value="development">Child Development</SelectItem>
                      <SelectItem value="activities">Activities</SelectItem>
                      <SelectItem value="safety">Safety</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="min_age">Min Age</Label>
                  <Input
                    id="min_age"
                    type="number"
                    min="0"
                    max="18"
                    value={formData.min_age}
                    onChange={(e) => setFormData(prev => ({ ...prev, min_age: e.target.value }))}
                  />
                </div>

                <div>
                  <Label htmlFor="max_age">Max Age</Label>
                  <Input
                    id="max_age"
                    type="number"
                    min="0"
                    max="18"
                    value={formData.max_age}
                    onChange={(e) => setFormData(prev => ({ ...prev, max_age: e.target.value }))}
                  />
                </div>

                <div className="col-span-2">
                  <Label htmlFor="content">Full Content *</Label>
                  <Textarea
                    id="content"
                    value={formData.content}
                    onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                    rows={8}
                    placeholder="Write your resource content here. You can include tips, instructions, or educational material..."
                    required
                  />
                </div>

                <div className="col-span-2">
                  <Label htmlFor="thumbnail_url">Thumbnail Image URL</Label>
                  <Input
                    id="thumbnail_url"
                    type="url"
                    value={formData.thumbnail_url}
                    onChange={(e) => setFormData(prev => ({ ...prev, thumbnail_url: e.target.value }))}
                    placeholder="https://..."
                  />
                </div>

                {formData.type === 'video' && (
                  <div className="col-span-2">
                    <Label htmlFor="video_url">Video URL</Label>
                    <Input
                      id="video_url"
                      type="url"
                      value={formData.video_url}
                      onChange={(e) => setFormData(prev => ({ ...prev, video_url: e.target.value }))}
                      placeholder="https://youtube.com/..."
                    />
                  </div>
                )}

                <div className="col-span-2">
                  <Label htmlFor="download_url">Download Link (Optional)</Label>
                  <Input
                    id="download_url"
                    type="url"
                    value={formData.download_url}
                    onChange={(e) => setFormData(prev => ({ ...prev, download_url: e.target.value }))}
                    placeholder="https://..."
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
                  {editingResource ? 'Update Resource' : 'Submit Resource'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {resources.map(resource => (
          <Card key={resource.id}>
            <CardContent className="pt-6">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-semibold text-lg">{resource.title}</h3>
                    <Badge className={
                      resource.status === 'approved' ? 'bg-green-100 text-green-800' :
                      resource.status === 'pending_review' ? 'bg-yellow-100 text-yellow-800' :
                      resource.status === 'rejected' ? 'bg-red-100 text-red-800' :
                      'bg-gray-100 text-gray-800'
                    }>
                      {resource.status.replace('_', ' ')}
                    </Badge>
                  </div>
                  
                  <p className="text-gray-600 mb-2">{resource.description}</p>
                  
                  <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-600">
                    <div>Type: {resource.type}</div>
                    <div>Category: {resource.category}</div>
                    {resource.views > 0 && (
                      <>
                        <div className="flex items-center gap-2">
                          <Eye className="w-4 h-4" />
                          {resource.views} views
                        </div>
                        {resource.downloads > 0 && (
                          <div className="flex items-center gap-2">
                            <Download className="w-4 h-4" />
                            {resource.downloads} downloads
                          </div>
                        )}
                      </>
                    )}
                  </div>

                  {resource.status === 'rejected' && resource.rejection_reason && (
                    <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded text-sm text-red-800">
                      <strong>Rejection Reason:</strong> {resource.rejection_reason}
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => handleEdit(resource)}>
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => handleDelete(resource.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {resources.length === 0 && (
          <Card>
            <CardContent className="pt-6 text-center">
              <FileText className="w-12 h-12 mx-auto mb-4 text-gray-400" />
              <p className="text-gray-600">No resources yet. Create your first resource to get started!</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}