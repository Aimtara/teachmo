# Teachmo Testing Framework

This directory contains the comprehensive testing framework for Teachmo, implemented as part of Phase 1 of our optimization plan.

## Overview

The testing framework includes:
- **Unit tests** for individual components and functions
- **Integration tests** for user workflows
- **Accessibility tests** for inclusive design
- **Performance tests** for optimization

## Structure

```
components/testing/
├── setup.js                    # Jest configuration and global mocks
├── TestUtils.jsx               # Testing utilities and helpers
├── README.md                   # This file
├── Dashboard.test.jsx          # Dashboard page tests
├── UserAuthentication.test.jsx # Authentication flow tests
├── ChildManagement.test.jsx    # Child profile management tests
├── ActivityManagement.test.jsx # Activity system tests
├── Messaging.test.jsx          # Parent-teacher messaging tests
└── TeacherDashboard.test.jsx   # Teacher-specific functionality tests
```

## Running Tests

Note: This testing framework is designed to work with Jest. To run these tests in a typical development environment, you would need:

```bash
# Install dependencies (would be in package.json)
npm install --save-dev jest @testing-library/react @testing-library/jest-dom

# Run all tests
npm test

# Run tests in watch mode (for development)
npm run test:watch

# Generate coverage report
npm run test:coverage

# Run tests for CI/CD
npm run test:ci
```

## Test Categories

### 1. Critical User Flows
- **User Authentication**: Login, logout, session management
- **Child Onboarding**: Adding, editing, and managing child profiles
- **Activity Management**: Browsing, filtering, completing activities
- **Parent-Teacher Messaging**: Sending, receiving, and managing conversations
- **Teacher Dashboard**: Google Classroom integration, class management

### 2. Component Tests
- **Dashboard Components**: Welcome cards, activity suggestions, stats
- **Form Components**: Validation, submission, error handling
- **Navigation**: Role-based routing, mobile menu functionality

### 3. Integration Tests
- **Data Flow**: Entity CRUD operations, API error handling
- **State Management**: Component state updates, global state synchronization
- **External Services**: Google Classroom sync, third-party integrations

## Testing Utilities

### Mock Data Generators
```javascript
import { mockUser, mockChild, mockActivity } from './TestUtils';

const testUser = mockUser({ role: 'teacher' });
const testChild = mockChild({ age: 8 });
```

### Custom Render Function
```javascript
import { renderWithProviders } from './TestUtils';

renderWithProviders(<MyComponent />, {
  mockUserData: mockUser({ role: 'parent' })
});
```

### Form Testing
```javascript
import { fillForm, submitForm } from './TestUtils';

await fillForm({
  'child name': 'Test Child',
  'age': '7'
});
await submitForm(/save/i);
```

### Accessibility Testing
```javascript
import { expectAccessibleForm, expectKeyboardNavigation } from './TestUtils';

expectAccessibleForm(screen.getByRole('form'));
await expectKeyboardNavigation(screen.getByRole('button'));
```

## Best Practices

### 1. Test Structure
- **Arrange**: Set up test data and mocks
- **Act**: Perform the action being tested
- **Assert**: Verify the expected outcome

### 2. User-Centric Testing
- Test from the user's perspective
- Use semantic queries (getByRole, getByLabelText)
- Focus on behavior, not implementation

### 3. Async Testing
- Always wait for async operations
- Use `waitFor` for state changes
- Test loading and error states

### 4. Mock Strategy
- Mock external dependencies (APIs, third-party libraries)
- Use realistic mock data
- Reset mocks between tests

## Coverage Goals

We aim for **≥70% coverage** across:
- **Branches**: Conditional logic paths
- **Functions**: All exported functions
- **Lines**: Code execution
- **Statements**: Individual statements

## Adding New Tests

When adding new features:

1. **Create test file**: `FeatureName.test.jsx`
2. **Import utilities**: Use existing test helpers
3. **Mock dependencies**: Set up appropriate mocks
4. **Test happy path**: Primary user workflow
5. **Test edge cases**: Error states, validation
6. **Test accessibility**: Keyboard navigation, screen readers

## Continuous Integration

Tests run automatically on:
- **Pull requests**: All tests must pass
- **Main branch**: Full test suite with coverage
- **Nightly builds**: Extended test suite

## Troubleshooting

### Common Issues

1. **Mock not working**: Check import paths in setup.js
2. **Async test failing**: Add proper waitFor statements
3. **Component not rendering**: Verify all providers are included
4. **Navigation test failing**: Check mock router setup

### Debug Commands

```bash
# Run specific test file
npm test Dashboard.test.jsx

# Run with verbose output
npm test -- --verbose

# Debug specific test
npm test -- --testNamePattern="renders dashboard"
```

## Implementation Notes

Since this is built on the base44 platform, the testing framework is designed to:

- Work with the existing entity/page/component structure
- Mock the base44 SDK and entity operations
- Test user flows specific to the Teachmo application
- Validate accessibility and error handling patterns

The tests are comprehensive but would need to be integrated with a proper Jest setup in a development environment to run.

## Next Steps

### Phase 2 Enhancements
- **Visual regression testing** with Percy or Chromatic
- **End-to-end testing** with Playwright
- **Performance testing** with Lighthouse CI
- **Accessibility auditing** with axe-core

### Metrics Tracking
- **Test execution time** monitoring
- **Flaky test detection** and resolution
- **Coverage trend analysis**
- **Test maintenance overhead** measurement

This testing framework provides a solid foundation for maintaining code quality, preventing regressions, and ensuring Teachmo delivers a reliable experience for all users.