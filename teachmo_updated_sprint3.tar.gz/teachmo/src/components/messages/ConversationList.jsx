import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { format, isToday, isYesterday } from 'date-fns';
import { Users } from 'lucide-react';

export default function ConversationList({ conversations, activeConversationId, onSelectConversation, currentUser }) {
  
  const formatLastActivity = (timestamp) => {
    if (!timestamp) return '';
    try {
      const date = new Date(timestamp);
      if (isToday(date)) return format(date, 'p'); // e.g., 4:30 PM
      if (isYesterday(date)) return 'Yesterday';
      return format(date, 'MMM d'); // e.g., Jan 2
    } catch (e) {
      return '';
    }
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="py-4">
        <CardTitle>Conversations</CardTitle>
      </CardHeader>
      <CardContent className="p-0 flex-1 overflow-y-auto">
        {conversations.length > 0 ? (
          conversations.map(convo => {
            const isActive = convo.id === activeConversationId;
            const unreadCount = convo.unread_count?.[currentUser?.id] || 0;
            
            return (
              <div
                key={convo.id}
                onClick={() => onSelectConversation(convo)}
                className={`flex items-center gap-3 p-3 cursor-pointer transition-colors border-l-4 ${
                  isActive
                    ? 'bg-blue-50 border-blue-500'
                    : 'border-transparent hover:bg-gray-50'
                }`}
              >
                <Avatar>
                  <AvatarImage src={convo.partner?.avatar_url} />
                  <AvatarFallback>{convo.partner?.full_name?.[0] || 'U'}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center">
                    <h4 className={`font-semibold truncate text-sm ${isActive ? 'text-blue-800' : 'text-gray-800'}`}>
                      {convo.partner?.full_name || 'User'}
                    </h4>
                    <span className="text-xs text-gray-500 flex-shrink-0 ml-2">
                      {formatLastActivity(convo.last_activity)}
                    </span>
                  </div>
                   <div className="flex justify-between items-center">
                      <p className="text-xs text-gray-600 truncate">
                        {convo.last_message_preview}
                      </p>
                      {unreadCount > 0 && (
                        <Badge variant="destructive" className="h-5 w-5 p-0 flex items-center justify-center text-xs">
                          {unreadCount}
                        </Badge>
                      )}
                  </div>
                </div>
              </div>
            )
          })
        ) : (
          <div className="p-8 text-center text-gray-500 flex flex-col items-center justify-center h-full">
            <Users className="w-12 h-12 mb-4 text-gray-300"/>
            <p className="font-medium">No conversations yet.</p>
            <p className="text-sm">Start a new message to get started.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}