import React, { useState, useEffect } from 'react';
import { PartnerOffer, Partner } from '@/api/entities';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Heart, Clock, ExternalLink, Tag } from 'lucide-react';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';
import OfferCard from './OfferCard';

export default function OffersCarousel({ userLocation, children }) {
  const [offers, setOffers] = useState([]);
  const [partners, setPartners] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadOffers();
  }, []);

  const loadOffers = async () => {
    try {
      // Load active offers
      const now = new Date().toISOString();
      const offersData = await PartnerOffer.filter({
        status: 'published',
        end_date: { $gte: now }
      }, '-created_date', 10);

      // Load partner data for logos
      const partnerIds = [...new Set(offersData.map(offer => offer.partner_id))];
      const partnersData = await Promise.all(
        partnerIds.map(id => Partner.filter({ id }).catch(() => null))
      );
      const validPartners = partnersData.filter(Boolean).flat();

      setOffers(offersData);
      setPartners(validPartners);
    } catch (error) {
      console.error('Failed to load offers:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Don't render if no offers
  if (!isLoading && offers.length === 0) {
    return null;
  }

  if (isLoading) {
    return (
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-4">
          <Tag className="w-5 h-5 text-purple-600" />
          <h2 className="text-xl font-bold">Deals & Discounts</h2>
        </div>
        <div className="flex gap-4 overflow-x-auto pb-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="flex-shrink-0 w-80 h-40 bg-gray-200 animate-pulse rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Tag className="w-5 h-5 text-purple-600" />
          <h2 className="text-xl font-bold">Deals & Discounts</h2>
        </div>
        <Badge variant="outline" className="text-purple-600 border-purple-200">
          {offers.length} active offers
        </Badge>
      </div>
      
      <div className="flex gap-4 overflow-x-auto pb-4 snap-x snap-mandatory">
        {offers.map((offer, index) => {
          const partner = partners.find(p => p.id === offer.partner_id);
          return (
            <motion.div
              key={offer.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex-shrink-0 snap-start"
            >
              <OfferCard 
                offer={offer} 
                partner={partner}
                onUpdate={loadOffers}
              />
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}