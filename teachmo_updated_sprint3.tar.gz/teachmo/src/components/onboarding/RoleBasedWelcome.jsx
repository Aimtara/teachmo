import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Check, ArrowRight, User as UserIcon, Briefcase, Home, ChevronRight, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { useToast } from '@/components/ui/use-toast';
import { Card } from '@/components/ui/card';

const welcomeConfigs = {
  parent: {
    title: 'Welcome to Your Family Hub!',
    description: 'You\'re all set to start this journey. Here are some of the things you can do to support your child\'s growth:',
    features: [
      'Discover personalized activities for your child\'s age.',
      'Get instant, expert advice from your AI Parenting Coach.',
      'Track developmental milestones and see progress over time.',
      'Connect with teachers to bridge the gap between home and school.',
    ],
    primaryAction: {
      text: 'Add Your Child',
      url: '/Welcome?step=child_profile',
      icon: ArrowRight,
    },
  },
  teacher: {
    title: 'Welcome to Your Teacher Dashboard!',
    description: 'You\'re ready to connect with parents and manage your classes. Here\'s what you can do:',
    features: [
      'Manage all your classes and students in one place.',
      'Send announcements and messages directly to parents.',
      'Access a library of resources and teaching materials.',
      'View analytics on student engagement and progress.',
    ],
    primaryAction: {
      text: 'Set Up Your Classes',
      url: createPageUrl('TeacherClasses'),
      icon: ArrowRight,
    },
  },
  school_admin: {
    title: 'School Administrator Dashboard',
    description: 'Manage your school, staff, and school-wide communications.',
    features: [
      'Oversee all teachers, students, and parent connections.',
      'Send school-wide announcements and notifications.',
      'View detailed analytics on school engagement.',
      'Configure school settings and integrations.'
    ],
    primaryAction: {
      text: 'Go to Admin Dashboard',
      url: createPageUrl('SchoolAdminDashboard'),
      icon: ArrowRight,
    }
  },
};

export default function RoleBasedWelcome({ user, onNextStep }) {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleRoleSelect = async (selectedRole) => {
    setIsLoading(true);
    try {
      const updateData = {
        role: selectedRole,
        onboarding_step: 1,
        status: 'active'
      };
      
      console.log('Updating user with data:', updateData);
      
      await User.updateMyUserData(updateData);
      
      toast({
        title: "Role Updated",
        description: `Welcome! You're now set up as a ${selectedRole.replace('_', ' ')}.`,
      });
      
      // Navigate based on role
      setTimeout(() => {
        if (selectedRole === 'parent') {
          // Parents continue with progressive onboarding
          onNextStep();
        } else if (selectedRole === 'teacher') {
          // Teachers go to teacher onboarding
          navigate(createPageUrl('TeacherOnboarding'));
        } else {
          // Admins go to admin onboarding
          navigate(createPageUrl('AdminOnboarding'));
        }
      }, 1000);
      
    } catch (error) {
      console.error("Failed to update user role:", error);
      
      let errorMessage = "Could not save your role. Please try again.";
      
      if (error.message?.includes('401') || error.message?.includes('Unauthorized')) {
        errorMessage = "Your session has expired. Please sign in again.";
      } else if (error.message?.includes('403') || error.message?.includes('Forbidden')) {
        errorMessage = "You don't have permission to update your role.";
      } else if (error.message?.includes('Network') || error.message?.includes('Failed to fetch')) {
        errorMessage = "Network error. Please check your connection and try again.";
      }
      
      toast({
        variant: "destructive",
        title: "Update Failed",
        description: errorMessage,
      });
      
      setIsLoading(false);
    }
  };

  // Check if user needs role selection
  const needsRoleSelection = !user?.role || user?.role === 'user' || !user?.onboarding_step || user?.onboarding_step < 1;

  if (needsRoleSelection) {
    return (
      <div className="text-center max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold mb-4">Welcome to Teachmo!</h1>
        <p className="text-lg text-gray-600 mb-8">
          To get started, please tell us who you are. This will help us personalize your experience.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <motion.div whileHover={{ y: -5 }}>
            <Card
              className={`p-8 text-left cursor-pointer hover:shadow-xl hover:border-blue-500 transition-all ${
                isLoading ? 'opacity-50 pointer-events-none' : ''
              }`}
              onClick={() => !isLoading && handleRoleSelect('parent')}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold">I'm a Parent</h2>
                <Home className="w-8 h-8 text-blue-500" />
              </div>
              <p className="text-gray-600 mb-6">Get personalized activities, expert tips, and track your child's developmental journey.</p>
              <div className="flex items-center text-blue-600 font-semibold">
                <span>Choose Parent</span>
                <ChevronRight className="w-5 h-5 ml-1" />
              </div>
            </Card>
          </motion.div>
          
          <motion.div whileHover={{ y: -5 }}>
            <Card
              className={`p-8 text-left cursor-pointer hover:shadow-xl hover:border-purple-500 transition-all ${
                isLoading ? 'opacity-50 pointer-events-none' : ''
              }`}
              onClick={() => !isLoading && handleRoleSelect('teacher')}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold">I'm an Educator</h2>
                <Briefcase className="w-8 h-8 text-purple-500" />
              </div>
              <p className="text-gray-600 mb-6">Manage your classes, communicate with parents, and access teaching resources.</p>
              <div className="flex items-center text-purple-600 font-semibold">
                <span>Choose Educator</span>
                <ChevronRight className="w-5 h-5 ml-1" />
              </div>
            </Card>
          </motion.div>
        </div>

        {isLoading && (
          <div className="mt-8 flex items-center justify-center gap-2">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span className="text-gray-600">Saving your selection...</span>
          </div>
        )}
      </div>
    );
  }

  const welcomeConfig = welcomeConfigs[user.role] || welcomeConfigs.parent;

  const handlePrimaryAction = () => {
    if (user.role === 'parent') {
      onNextStep();
    } else {
      navigate(welcomeConfig.primaryAction.url);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="text-center"
    >
      <h1 className="text-3xl font-bold mb-2">{welcomeConfig.title}</h1>
      <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">{welcomeConfig.description}</p>
      
      <div className="max-w-md mx-auto text-left space-y-3 mb-10">
        {welcomeConfig.features.map((feature, index) => (
          <div key={index} className="flex items-start gap-3">
            <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
              <Check className="w-4 h-4 text-green-600" />
            </div>
            <span>{feature}</span>
          </div>
        ))}
      </div>
      
      <Button size="lg" onClick={handlePrimaryAction}>
        {welcomeConfig.primaryAction.text}
        <welcomeConfig.primaryAction.icon className="w-5 h-5 ml-2" />
      </Button>
    </motion.div>
  );
}