# Teachmo Drop-in
See previous instructions; this bundle includes Supabase, FCM push, presence, demo mode, calendar, messages, directory, profile, onboarding, help, Tailwind config, and seed.sql.
