import React, { useState } from 'react';
import { User } from '@/api/entities';
import { Child } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/components/ui/use-toast';
import { Download, Trash2, Shield, FileText, Mail, Loader2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';

export default function PrivacyRights() {
  const [user, setUser] = useState(null);
  const [children, setChildren] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [exportLoading, setExportLoading] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const { toast } = useToast();

  React.useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const [userData, childrenData] = await Promise.all([
        User.me(),
        Child.list()
      ]);
      setUser(userData);
      setChildren(childrenData);
    } catch (error) {
      console.error('Failed to load user data:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to load your data. Please try again.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleExportData = async () => {
    setExportLoading(true);
    try {
      // In a real implementation, this would call a backend endpoint
      // that generates and returns all user data in a downloadable format
      const userData = {
        profile: {
          name: user.full_name,
          email: user.email,
          role: user.role,
          createdDate: user.created_date,
          lastLogin: user.last_login_date
        },
        children: children.map(child => ({
          name: child.name,
          age: child.age,
          birthDate: child.birth_date,
          interests: child.interests,
          learningStyle: child.learning_style
        })),
        exportDate: new Date().toISOString()
      };

      // Create and download JSON file
      const blob = new Blob([JSON.stringify(userData, null, 2)], { 
        type: 'application/json' 
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `teachmo-data-export-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: 'Data Export Complete',
        description: 'Your data has been downloaded as a JSON file.'
      });
    } catch (error) {
      console.error('Export failed:', error);
      toast({
        variant: 'destructive',
        title: 'Export Failed',
        description: 'Failed to export your data. Please try again.'
      });
    } finally {
      setExportLoading(false);
    }
  };

  const handleDeleteAccount = async () => {
    setDeleteLoading(true);
    try {
      // In production, this would call a backend endpoint that:
      // 1. Schedules account deletion
      // 2. Removes all personal data
      // 3. Logs the deletion request for audit purposes
      
      // For now, we'll simulate the process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: 'Account Deletion Requested',
        description: 'Your account and all associated data will be deleted within 30 days. You will receive a confirmation email.'
      });
      
      // In a real app, redirect to logout or confirmation page
      setDeleteConfirmOpen(false);
    } catch (error) {
      console.error('Deletion failed:', error);
      toast({
        variant: 'destructive',
        title: 'Deletion Failed',
        description: 'Failed to process your deletion request. Please try again.'
      });
    } finally {
      setDeleteLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <div className="text-center">
        <Shield className="w-12 h-12 mx-auto mb-4 text-blue-600" />
        <h1 className="text-3xl font-bold mb-2">Your Privacy Rights</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          You have important rights regarding your personal information. This page helps you understand 
          and exercise those rights.
        </p>
      </div>

      <Alert>
        <Shield className="h-4 w-4" />
        <AlertDescription>
          <strong>California Residents:</strong> Under the California Consumer Privacy Act (CCPA), you have 
          specific rights to know, delete, and control the sale of your personal information.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6">
        {/* Data Categories We Collect */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Information We Collect
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold mb-2">Personal Information:</h4>
                <ul className="text-sm space-y-1 text-gray-600">
                  <li>• Name and email address</li>
                  <li>• Account preferences</li>
                  <li>• Communication preferences</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Child Information (with consent):</h4>
                <ul className="text-sm space-y-1 text-gray-600">
                  <li>• Child's name and age</li>
                  <li>• Learning preferences</li>
                  <li>• Activity completion data</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Your Rights */}
        <Card>
          <CardHeader>
            <CardTitle>Exercise Your Rights</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <Button
                onClick={handleExportData}
                disabled={exportLoading}
                className="h-auto p-4 flex-col items-start"
                variant="outline"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Download className="w-5 h-5" />
                  <span className="font-semibold">Download My Data</span>
                </div>
                <span className="text-sm text-gray-600 text-left">
                  Get a copy of all personal information we have about you and your children
                </span>
                {exportLoading && <Loader2 className="w-4 h-4 animate-spin mt-2" />}
              </Button>

              <Button
                onClick={() => setDeleteConfirmOpen(true)}
                className="h-auto p-4 flex-col items-start"
                variant="outline"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Trash2 className="w-5 h-5" />
                  <span className="font-semibold">Delete My Account</span>
                </div>
                <span className="text-sm text-gray-600 text-left">
                  Permanently delete your account and all associated data
                </span>
              </Button>
            </div>

            <div className="pt-4 border-t">
              <h4 className="font-semibold mb-2">Need Help?</h4>
              <p className="text-sm text-gray-600 mb-3">
                If you have questions about your privacy rights or need assistance, contact us:
              </p>
              <Button variant="outline" size="sm">
                <Mail className="w-4 h-4 mr-2" />
                Contact Privacy Team
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Trash2 className="w-5 h-5 text-red-600" />
              Delete Account
            </DialogTitle>
            <DialogDescription>
              This action cannot be undone. This will permanently delete your account and all 
              associated data, including your children's profiles and activity history.
            </DialogDescription>
          </DialogHeader>
          
          <Alert className="border-red-200 bg-red-50">
            <AlertDescription className="text-red-800">
              <strong>Warning:</strong> All data will be permanently removed within 30 days. 
              You will receive a confirmation email with details about what was deleted.
            </AlertDescription>
          </Alert>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteConfirmOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleDeleteAccount}
              disabled={deleteLoading}
            >
              {deleteLoading && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              Delete My Account
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}