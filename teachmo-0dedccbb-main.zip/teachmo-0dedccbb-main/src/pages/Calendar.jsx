import React, { useState, useEffect, useMemo } from "react";
import { CalendarEvent, User, Activity, LocalEvent, Child } from "@/api/entities";
import { Plus, ChevronLeft, ChevronRight, Settings2, Users, AlertTriangle, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AnimatePresence } from "framer-motion";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import CalendarView from "../components/calendar/CalendarView";
import EventModal from "../components/calendar/EventModal";
import UnscheduledPanel from "../components/calendar/UnscheduledPanel";
import SchedulingAssistant from "../components/calendar/SchedulingAssistant";
import { startOfMonth, endOfMonth, startOfWeek, endOfWeek, startOfDay, endOfDay, format, addDays, subDays, addWeeks, subWeeks, addMonths, subMonths } from "date-fns";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent } from "@/components/ui/card";
import { useApi } from "@/components/hooks/useApi";
import { LoadingSpinner, ErrorState } from "@/components/shared/LoadingStates";

export default function CalendarPage() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState('month'); // 'month', 'week', 'day'
  const [scheduledEvents, setScheduledEvents] = useState([]);
  const [unscheduledItems, setUnscheduledItems] = useState([]);
  const [user, setUser] = useState(null);
  const [children, setChildren] = useState([]);
  const [selectedChildId, setSelectedChildId] = useState("all");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [eventToSchedule, setEventToSchedule] = useState(null);

  const api = useApi({ context: 'calendar' });

  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    try {
      const [currentUser, childrenData] = await Promise.all([
        api.execute(() => User.me(), { key: 'user', errorContext: 'loading user data' }),
        api.execute(() => Child.list(), { key: 'children', errorContext: 'loading children data' })
      ]);
      setUser(currentUser);
      setChildren(childrenData);
    } catch (err) {
      console.error("Critical Calendar data fetch error:", err);
      setUser(null);
    }
  };

  useEffect(() => {
    if (user && !api.hasError('user')) {
      fetchEvents();
    }
  }, [currentDate, user, view, selectedChildId]);

  const getDateRange = () => {
    switch(view) {
      case 'day':
        return { start: startOfDay(currentDate), end: endOfDay(currentDate) };
      case 'week':
        return { start: startOfWeek(currentDate), end: endOfWeek(currentDate) };
      case 'month':
      default:
        return { start: startOfMonth(currentDate), end: endOfMonth(currentDate) };
    }
  };

  const fetchEvents = async () => {
    if (!user) return;
    
    const { start, end } = getDateRange();
    
    const scheduledFilter = {
        user_id: user.id,
        start_time: { $gte: start.toISOString() },
        end_time: { $lte: end.toISOString() }
    };
    
    if (selectedChildId !== "all") {
        scheduledFilter.child_id = selectedChildId;
    }

    try {
      const [fetchedScheduled, suggestedActivities, localEvents] = await Promise.all([
        api.execute(() => CalendarEvent.filter(scheduledFilter, '-start_time'), {
          key: 'events',
          errorContext: 'loading calendar events'
        }),
        api.execute(() => Activity.filter({ status: 'suggested' }), {
          key: 'activities',
          errorContext: 'loading suggested activities'
        }),
        api.execute(() => LocalEvent.list(), {
          key: 'localEvents',
          errorContext: 'loading local events'
        })
      ]);

      setScheduledEvents(fetchedScheduled.map(e => ({...e, type: e.type || 'event'})));

      const filteredActivities = selectedChildId !== 'all' 
        ? suggestedActivities.filter(a => a.child_id === selectedChildId)
        : suggestedActivities;

      let potentialItems = [];
      potentialItems.push(...filteredActivities.map(a => ({
        id: a.id,
        title: a.title,
        description: a.description,
        resource_id: a.id,
        resource_type: 'activity',
        child_id: a.child_id,
        color: children.find(c => c.id === a.child_id)?.color || '#86efac'
      })));
      
      potentialItems.push(...localEvents.map(le => ({ 
        id: le.id,
        title: le.title,
        description: le.description,
        start_time: le.start_time,
        end_time: le.end_time,
        resource_id: le.id, 
        resource_type: 'local_event',
        color: '#fca5a5'
      })));
      
      setUnscheduledItems(potentialItems);

    } catch (error) {
      console.error("Error fetching calendar data:", error);
    }
  };
  
  const handleDateChange = (direction) => {
    const changeFn = direction === 'next' 
      ? { day: addDays, week: addWeeks, month: addMonths }
      : { day: subDays, week: subWeeks, month: subMonths };
    
    setCurrentDate(prev => changeFn[view](prev, 1));
  };
  
  const handleToday = () => { setCurrentDate(new Date()); };
  const handleDayClick = (day) => { setCurrentDate(day); setView('day'); };
  
  const openEventModal = (event) => {
    setEventToSchedule(null);
    setSelectedEvent(event);
    setIsModalOpen(true);
  };
  
  const handleDragEnd = (result) => {
    const { source, destination, draggableId } = result;
    
    if (!destination) return;
    
    if (destination.droppableId.startsWith('calendar-')) {
      const dateStr = destination.droppableId.replace('calendar-', '');
      const date = new Date(dateStr);
      
      const item = unscheduledItems.find(i => i.id === draggableId);
      if (!item) return;
      
      handleDropOnDate(item, date);
    }
  };

  const handleDropOnDate = (item, date) => {
    const droppedResourceType = item.resource_type || 'activity'; 
    
    let startTime = new Date(date);
    let endTime = new Date(date);

    if (item.start_time) {
      const itemStartTime = new Date(item.start_time);
      const itemEndTime = new Date(item.end_time || item.start_time);
      startTime.setHours(itemStartTime.getHours(), itemStartTime.getMinutes(), itemStartTime.getSeconds());
      endTime.setHours(itemEndTime.getHours(), itemEndTime.getMinutes(), itemEndTime.getSeconds());
      if (itemEndTime.getTime() < itemStartTime.getTime()) {
        endTime = addDays(endTime, 1);
      }
    } else {
      startTime.setHours(10, 0, 0, 0);
      endTime = new Date(startTime.getTime() + 60 * 60 * 1000);
    }

    const newEvent = {
        title: item.title,
        description: item.description,
        start_time: startTime.toISOString(),
        end_time: endTime.toISOString(),
        resource_id: item.resource_id || item.id,
        resource_type: droppedResourceType,
        child_id: item.child_id || (selectedChildId !== 'all' ? selectedChildId : null),
        color: children.find(c => c.id === item.child_id)?.color || item.color || '#6B9DC8'
    };
    setSelectedEvent(null);
    setEventToSchedule(newEvent);
    setIsModalOpen(true);
  };

  const handleScheduleFromAssistant = (activity, date) => {
    let startTime = new Date(date);
    startTime.setHours(10, 0, 0, 0);
    let endTime = new Date(startTime.getTime() + 60 * 60 * 1000);
    
    const newEvent = {
        title: activity.title,
        description: activity.description,
        start_time: startTime.toISOString(),
        end_time: endTime.toISOString(),
        resource_id: activity.id,
        resource_type: 'activity',
        child_id: activity.child_id || (selectedChildId !== 'all' ? selectedChildId : null),
        color: children.find(c => c.id === activity.child_id)?.color || '#6B9DC8'
    };
    setSelectedEvent(null);
    setEventToSchedule(newEvent);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedEvent(null);
    setEventToSchedule(null);
    fetchEvents();
  };
  
  const headerFormat = useMemo(() => {
    switch(view) {
      case 'day': return "eeee, MMMM d, yyyy";
      case 'week': 
        const weekStart = startOfWeek(currentDate);
        const weekEnd = endOfWeek(currentDate);
        if (weekStart.getMonth() === weekEnd.getMonth()) {
          return `MMMM d`;
        }
        if (weekStart.getFullYear() !== weekEnd.getFullYear()) {
          return `MMM d, yyyy - MMM d, yyyy`;
        }
        return `MMM d - MMM d`;
      case 'month':
      default:
        return "MMMM yyyy";
    }
  }, [view, currentDate]);

  const selectedChild = children.find(c => c.id === selectedChildId);

  const handleRetry = () => {
    fetchInitialData();
  }

  // Show loading state while initial data is loading
  if (api.isLoading('user') || api.isLoading('children')) {
    return (
      <div className="min-h-screen p-4 md:p-6 flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <LoadingSpinner size="lg" text="Loading your calendar..." />
      </div>
    );
  }

  // Show error state if critical data fails to load
  if (api.hasError('user')) {
    return (
      <div className="min-h-screen p-4 md:p-6 flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <ErrorState 
          error={api.getError('user')} 
          onRetry={handleRetry}
          title="Could Not Load Calendar"
        />
      </div>
    );
  }

  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <div className="flex h-screen overflow-hidden" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <UnscheduledPanel 
          items={unscheduledItems.filter(item => 
            selectedChildId === "all" || !item.child_id || item.child_id === selectedChildId
          )} 
          selectedChild={selectedChild}
          isLoading={api.isLoading('activities') || api.isLoading('localEvents')}
        />
        
        <div className="flex-1 flex flex-col p-4 md:p-6 overflow-y-auto">
          <header className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-2">
                <Button variant="outline" onClick={() => handleDateChange('prev')}><ChevronLeft className="w-5 h-5" /></Button>
                <h1 className="text-xl md:text-2xl font-bold text-gray-800 text-center w-48 md:w-64">
                  {format(currentDate, headerFormat)}
                </h1>
                <Button variant="outline" onClick={() => handleDateChange('next')}><ChevronRight className="w-5 h-5" /></Button>
              </div>
              <Button variant="outline" onClick={handleToday}>Today</Button>
              
              <div className="flex items-center gap-1 p-1 bg-gray-200/80 rounded-lg">
                <Button variant={view === 'day' ? 'default' : 'ghost'} size="sm" onClick={() => setView('day')} className={`transition-all ${view === 'day' ? 'bg-white text-gray-800 shadow' : 'text-gray-600'}`}>Day</Button>
                <Button variant={view === 'week' ? 'default' : 'ghost'} size="sm" onClick={() => setView('week')} className={`transition-all ${view === 'week' ? 'bg-white text-gray-800 shadow' : 'text-gray-600'}`}>Week</Button>
                <Button variant={view === 'month' ? 'default' : 'ghost'} size="sm" onClick={() => setView('month')} className={`transition-all ${view === 'month' ? 'bg-white text-gray-800 shadow' : 'text-gray-600'}`}>Month</Button>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <Select value={selectedChildId} onValueChange={setSelectedChildId}>
                <SelectTrigger className="w-48">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    <SelectValue placeholder="Select Child" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Children</SelectItem>
                  {children.map(child => (
                    <SelectItem key={child.id} value={child.id}>
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full" style={{backgroundColor: child.color}}></div>
                        {child.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button onClick={() => openEventModal(null)} style={{backgroundColor: 'var(--teachmo-sage)'}}>
                <Plus className="w-5 h-5 mr-2" />
                Add Event
              </Button>
            </div>
          </header>

          <div className="mb-6">
            <SchedulingAssistant 
              user={user} 
              children={children} 
              onSchedule={handleScheduleFromAssistant} 
            />
          </div>

          <CalendarView
            currentDate={currentDate}
            events={scheduledEvents}
            onEventClick={openEventModal}
            isLoading={api.isLoading('events')}
            view={view}
            onDayClick={handleDayClick}
            childrenData={children}
            selectedChildId={selectedChildId}
          />
        </div>

        <AnimatePresence>
          {(isModalOpen && user) && (
            <EventModal
              event={selectedEvent || eventToSchedule}
              user={user}
              onClose={closeModal}
              childrenData={children}
              defaultChildId={selectedChildId !== "all" ? selectedChildId : null}
            />
          )}
        </AnimatePresence>
      </div>
    </DragDropContext>
  );
}