
import React, { useState, useEffect } from "react";
import { User, Post, Comment, Like, Follow, Pod, PodMember, UserMessage, UserConversation } from "@/api/entities"; // Removed CommunityVisibility as it's no longer used in initial load
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Users, 
  MessageSquare, 
  Heart, 
  Search, 
  Plus, 
  UserPlus,
  Crown,
  Shield,
  Loader2,
  Send,
  MoreHorizontal,
  RefreshCw,
  AlertTriangle
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

import PostCard from "../components/feed/PostCard";
import CreatePostForm from "../components/feed/CreatePostForm";
import UserCard from "../components/community/UserCard";
import PodCard from "../components/pods/PodCard";
import { usePremium } from '../components/shared/usePremium'; // New import
import { CommunitySkeleton } from '../components/shared/ImprovedSkeletons'; // New import

export default function UnifiedCommunity() {
  const [activeTab, setActiveTab] = useState("feed");
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Feed state
  const [posts, setPosts] = useState([]);
  const [comments, setComments] = useState([]); // Keep state, but not loaded initially by loadCommunityData
  const [likes, setLikes] = useState([]); // Keep state, but not loaded initially by loadCommunityData
  
  // Community state
  const [users, setUsers] = useState([]); // Keep state, but not loaded initially by loadCommunityData
  const [follows, setFollows] = useState([]); // Keep state, but not loaded initially by loadCommunityData
  const [searchQuery, setSearchQuery] = useState("");
  
  // Pods state
  const [pods, setPods] = useState([]);
  const [myPods, setMyPods] = useState([]); // Keep state, but not loaded initially by loadCommunityData
  
  // Messages state
  const [conversations, setConversations] = useState([]); // Keep state, but not loaded initially by loadCommunityData
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");

  const { isPremium } = usePremium(); // New hook usage

  useEffect(() => {
    loadCommunityData();
  }, []);

  const loadCommunityData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      // Simplified loading based on outline: only posts, user, and pods
      const [postsData, currentUser, podsData] = await Promise.all([
        Post.list('-created_date', 50, { with: { user: true } }), // Added { with: { user: true } }
        User.me(),
        Pod.list('-member_count', 10) // Changed criteria
      ]);
      
      setPosts(postsData);
      setUser(currentUser);
      setPods(podsData);

      // Existing data types that are no longer loaded initially:
      // comments, likes, users, follows, myPods, conversations
      // These will remain empty arrays/null until specific actions trigger their loading.

    } catch (err) {
      console.error("Error loading community data:", err);
      if (
        err.message?.includes('Network') || err.message?.includes('Failed to fetch') || 
        err.message?.includes('ServerSelectionTimeoutError') || err.message?.includes('replica set')
      ) {
        setError({
          type: 'database',
          message: 'Having trouble connecting to our servers to load the community. Please check your internet connection or try again in a moment.',
        });
      } else {
        setError({ type: 'general', message: "We couldn't load community data. Please try refreshing the page." });
      }
    }
    setIsLoading(false);
  };

  // Removed loadPostsByScope, loadUsersByScope, loadPodsByScope functions as they are no longer called by loadCommunityData.

  const handleLikePost = async (postId) => {
    try {
      // Note: `likes` array might be empty if not loaded by initial `loadCommunityData`
      // This functionality assumes `likes` are either loaded on demand or are managed client-side after initial empty state.
      const existingLike = likes.find(l => l.post_id === postId && l.user_id === user.id);
      
      if (existingLike) {
        await Like.delete(existingLike.id);
        setLikes(likes.filter(l => l.id !== existingLike.id));
      } else {
        const newLike = await Like.create({ post_id: postId, user_id: user.id });
        setLikes([...likes, newLike]);
      }
    } catch (error) {
      console.error("Error handling like:", error);
    }
  };

  const handleFollowUser = async (userId) => {
    try {
      // Note: `follows` array might be empty if not loaded by initial `loadCommunityData`
      const existingFollow = follows.find(f => f.follower_id === user.id && f.following_id === userId);
      
      if (existingFollow) {
        await Follow.delete(existingFollow.id);
        setFollows(follows.filter(f => f.id !== existingFollow.id));
      } else {
        const newFollow = await Follow.create({ follower_id: user.id, following_id: userId });
        setFollows([...follows, newFollow]);
        
        // Skip notification creation due to database issues
        console.log("Skipping notification creation due to database connectivity issues");
      }
    } catch (error) {
      console.error("Error handling follow:", error);
    }
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedConversation) return;
    
    try {
      const message = await UserMessage.create({
        sender_id: user.id,
        recipient_id: selectedConversation.other_user.id,
        content: newMessage.trim(),
        thread_id: selectedConversation.thread_id
      });
      
      setMessages([...messages, message]);
      setNewMessage("");
      
      // Update conversation last activity
      await UserConversation.update(selectedConversation.id, {
        last_message_preview: newMessage.trim(),
        last_activity: new Date().toISOString()
      });
      
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  const handlePostCreated = (newPost) => {
    setPosts(prevPosts => [newPost, ...prevPosts]);
  };

  const getFilteredUsers = () => {
    return users.filter(u => 
      u.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.username?.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  const isFollowing = (userId) => {
    return follows.some(f => f.follower_id === user?.id && f.following_id === userId);
  };

  const getPostLikes = (postId) => {
    return likes.filter(l => l.post_id === postId);
  };

  const hasLikedPost = (postId) => {
    return likes.some(l => l.post_id === postId && l.user_id === user?.id);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="max-w-7xl mx-auto">
          <CommunitySkeleton />
        </div>
      </div>
    );
  }

  // Full-page error state for Community
  if (error && !isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-6 flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <Card className="max-w-2xl mx-auto border-0 shadow-lg bg-white/90 backdrop-blur-sm">
            <CardContent className="p-8 text-center">
              <AlertTriangle className="w-16 h-16 mx-auto mb-6 text-red-500" />
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                {error.type === 'database' ? 'Connection Issue' : 'Could Not Load Community'}
              </h2>
              <p className="text-gray-700 mb-6 max-w-md mx-auto">{error.message}</p>
              <Button onClick={loadCommunityData} size="lg"> {/* Changed function call */}
                <RefreshCw className="w-5 h-5 mr-2" />
                Try Again
              </Button>
            </CardContent>
          </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Connect & Share</h1>
            <p className="text-gray-600">Join the parenting community</p>
          </div>
        </div>

        {/* Unified Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="feed" className="gap-2">
              <MessageSquare className="w-4 h-4" />
              Feed
            </TabsTrigger>
            <TabsTrigger value="community" className="gap-2">
              <Users className="w-4 h-4" />
              Parents
            </TabsTrigger>
            <TabsTrigger value="pods" className="gap-2">
              <Shield className="w-4 h-4" />
              Support Groups
            </TabsTrigger>
            <TabsTrigger value="messages" className="gap-2">
              <Send className="w-4 h-4" />
              Messages
            </TabsTrigger>
          </TabsList>

          {/* Feed Tab */}
          <TabsContent value="feed" className="space-y-6">
            <CreatePostForm user={user} onPostCreated={handlePostCreated} /> {/* Changed onPostCreated prop */}
            
            <div className="space-y-4">
              <AnimatePresence>
                {posts.map((post) => (
                  <PostCard
                    key={post.id}
                    post={post}
                    comments={comments.filter(c => c.post_id === post.id)} // `comments` will be empty unless loaded separately
                    likes={getPostLikes(post.id)} // `likes` will be empty unless loaded separately
                    hasLiked={hasLikedPost(post.id)}
                    onLike={() => handleLikePost(post.id)}
                    currentUser={user}
                    onUpdate={loadCommunityData} // Changed function call
                  />
                ))}
              </AnimatePresence>
            </div>
          </TabsContent>

          {/* Community Tab */}
          <TabsContent value="community" className="space-y-6">
            <div className="relative">
              <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search parents..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <AnimatePresence>
                {getFilteredUsers().map((parentUser) => ( // `users` will be empty unless loaded separately
                  <UserCard
                    key={parentUser.id}
                    user={parentUser}
                    isFollowing={isFollowing(parentUser.id)} // `follows` will be empty unless loaded separately
                    onFollowToggle={() => handleFollowUser(parentUser.id)}
                    onMessage={() => {
                      // Switch to messages tab and start conversation
                      setActiveTab("messages");
                      // Logic to start new conversation would go here
                    }}
                  />
                ))}
              </AnimatePresence>
            </div>
          </TabsContent>

          {/* Pods Tab */}
          <TabsContent value="pods" className="space-y-6">
            {myPods.length > 0 && ( // `myPods` will be empty unless loaded separately
              <div>
                <h3 className="text-xl font-semibold mb-4">My Support Groups</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                  {myPods.map((pod) => (
                    <PodCard key={pod.id} pod={pod} />
                  ))}
                </div>
              </div>
            )}
            
            <div>
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold">Discover Groups</h3>
                <Link to={createPageUrl("Pods")}>
                  <Button style={{backgroundColor: 'var(--teachmo-sage)'}} className="gap-2">
                    <Plus className="w-4 h-4" />
                    Create Group
                  </Button>
                </Link>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {pods.filter(p => !myPods.some(mp => mp.id === p.id)).slice(0, 6).map((pod) => (
                  <PodCard key={pod.id} pod={pod} />
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Messages Tab */}
          <TabsContent value="messages" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-96">
              {/* Conversations List */}
              <div className="lg:col-span-1 bg-white rounded-xl shadow-md">
                <div className="p-4 border-b">
                  <h3 className="font-semibold">Messages</h3>
                </div>
                <div className="space-y-2 p-2 max-h-80 overflow-y-auto">
                  {conversations.map((conv) => ( // `conversations` will be empty unless loaded separately
                    <div
                      key={conv.id}
                      onClick={() => setSelectedConversation(conv)}
                      className={`p-3 rounded-lg cursor-pointer transition-colors ${
                        selectedConversation?.id === conv.id ? 'bg-blue-50' : 'hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Avatar className="w-10 h-10">
                          <AvatarImage src={conv.other_user?.avatar_url} />
                          <AvatarFallback>
                            {conv.other_user?.full_name?.[0] || 'U'}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">
                            {conv.other_user?.full_name || 'User'}
                          </p>
                          <p className="text-xs text-gray-500 truncate">
                            {conv.last_message_preview || 'No messages yet'}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Chat Window */}
              <div className="lg:col-span-2 bg-white rounded-xl shadow-md flex flex-col">
                {selectedConversation ? (
                  <>
                    <div className="p-4 border-b flex items-center gap-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={selectedConversation.other_user?.avatar_url} />
                        <AvatarFallback>
                          {selectedConversation.other_user?.full_name?.[0] || 'U'}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold">
                          {selectedConversation.other_user?.full_name || 'User'}
                        </h3>
                        <p className="text-sm text-gray-500">
                          {selectedConversation.other_user?.username || ''}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex-1 p-4 space-y-3 overflow-y-auto">
                      {messages.map((message) => ( // `messages` will be empty unless loaded separately upon conversation selection
                        <div
                          key={message.id}
                          className={`flex ${
                            message.sender_id === user?.id ? 'justify-end' : 'justify-start'
                          }`}
                        >
                          <div
                            className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                              message.sender_id === user?.id
                                ? 'bg-blue-500 text-white'
                                : 'bg-gray-100 text-gray-900'
                            }`}
                          >
                            <p className="text-sm">{message.content}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="p-4 border-t">
                      <div className="flex gap-2">
                        <Input
                          placeholder="Type a message..."
                          value={newMessage}
                          onChange={(e) => setNewMessage(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                          className="flex-1"
                        />
                        <Button onClick={handleSendMessage} style={{backgroundColor: 'var(--teachmo-sage)'}}>
                          <Send className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="flex-1 flex items-center justify-center text-gray-500">
                    <div className="text-center">
                      <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>Select a conversation to start chatting</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
