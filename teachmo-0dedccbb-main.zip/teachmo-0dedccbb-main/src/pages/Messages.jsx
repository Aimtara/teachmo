import React, { useState, useEffect, useCallback } from 'react';
import { User, UserConversation, Child } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  MessageSquare, 
  Users, 
  Bot,
  Plus,
  Loader2
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import ConversationList from '../components/messages/ConversationList';
import ChatWindow from '../components/messages/ChatWindow';
import { DashboardSkeleton } from '@/components/shared/ImprovedSkeletons';

// Updated Component for Starting a Conversation
const StartConversationView = ({ onStartConversation, children, user }) => {
  const [selectedChildId, setSelectedChildId] = useState('');
  const [selectedTeacherId, setSelectedTeacherId] = useState('');
  const [availableTeachers, setAvailableTeachers] = useState([]);
  const [isLoadingTeachers, setIsLoadingTeachers] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const fetchTeachers = async () => {
      if (!selectedChildId) {
        setAvailableTeachers([]);
        return;
      }
      setIsLoadingTeachers(true);
      try {
        const child = children.find(c => c.id === selectedChildId);
        if (child && child.school_id) {
          // Fetch all users with role 'teacher' at the same school
          const teachers = await User.filter({
            role: 'teacher',
            school_id: child.school_id,
          });
          setAvailableTeachers(teachers);
        } else {
            setAvailableTeachers([]);
            toast({
                variant: 'destructive',
                title: 'No School Assigned',
                description: 'This child is not associated with a school. Please update their profile.',
            });
        }
      } catch (error) {
        console.error("Error fetching teachers:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Could not load teachers for this school.",
        });
      } finally {
        setIsLoadingTeachers(false);
      }
    };
    fetchTeachers();
  }, [selectedChildId, children, toast]);

  const handleStart = () => {
    if (selectedTeacherId && selectedChildId) {
      const teacher = availableTeachers.find(t => t.id === selectedTeacherId);
      const child = children.find(c => c.id === selectedChildId);
      onStartConversation(teacher, child);
    }
  };

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>New Conversation</CardTitle>
        <CardDescription>Start a new conversation with one of your child's teachers.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <label className="font-medium">1. Which child is this about?</label>
          <Select onValueChange={setSelectedChildId} value={selectedChildId}>
            <SelectTrigger><SelectValue placeholder="Select a child..." /></SelectTrigger>
            <SelectContent>
              {children.map(child => (
                <SelectItem key={child.id} value={child.id}>{child.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {selectedChildId && (
          <div className="space-y-2">
            <label className="font-medium">2. Select a teacher</label>
            <Select onValueChange={setSelectedTeacherId} value={selectedTeacherId} disabled={isLoadingTeachers || availableTeachers.length === 0}>
              <SelectTrigger>
                {isLoadingTeachers ? (
                    <div className="flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin"/>
                        <span>Loading Teachers...</span>
                    </div>
                ) : (
                    <SelectValue placeholder={availableTeachers.length > 0 ? "Select a teacher..." : "No teachers found for this school"} />
                )}
              </SelectTrigger>
              <SelectContent>
                {availableTeachers.map(teacher => (
                  <SelectItem key={teacher.id} value={teacher.id}>{teacher.full_name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        <Button onClick={handleStart} disabled={!selectedTeacherId || !selectedChildId}>
          <MessageSquare className="w-4 h-4 mr-2" />
          Start Conversation
        </Button>
      </CardContent>
    </Card>
  );
};


export default function Messages() {
  const [user, setUser] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [activeConversation, setActiveConversation] = useState(null);
  const [children, setChildren] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isStartingNew, setIsStartingNew] = useState(false);
  
  const { toast } = useToast();

  const loadData = useCallback(async () => {
    try {
      const userData = await User.me();
      setUser(userData);

      const [conversationData, childrenData] = await Promise.all([
          UserConversation.filter({ participant_ids: { $in: [userData.id] } }, '-last_activity', 50),
          userData.role === 'parent' ? Child.list() : Promise.resolve([])
      ]);
      
      setChildren(childrenData);
      const enrichedConversations = await enrichConversations(conversationData, userData.id);
      setConversations(enrichedConversations);

      if (enrichedConversations.length > 0 && !activeConversation) {
        setActiveConversation(enrichedConversations[0]);
      }
    } catch (error) {
      console.error('Error loading messages data:', error);
      toast({
        variant: "destructive",
        title: "Error loading messages",
        description: "Could not load your conversations."
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast, activeConversation]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const enrichConversations = async (convos, currentUserId) => {
    const participantIds = new Set(convos.flatMap(c => c.participant_ids));
    const users = await User.filter({ id: { $in: Array.from(participantIds) } });
    const userMap = new Map(users.map(u => [u.id, u]));

    return convos.map(convo => {
      const partnerId = convo.participant_ids.find(id => id !== currentUserId);
      const partner = userMap.get(partnerId);
      return { ...convo, partner, currentUser: userMap.get(currentUserId) };
    });
  };

  const handleSelectConversation = (conversation) => {
    setIsStartingNew(false);
    setActiveConversation(conversation);
  };

  const handleStartNewConversation = async (teacher, child) => {
    if (!teacher || !child || !user) return;

    // Use a consistent thread_id format: parentId_teacherId_childId
    const threadId = `${user.id}_${teacher.id}_${child.id}`;

    // Check if a conversation already exists
    const existing = conversations.find(c => c.thread_id === threadId);
    if (existing) {
      setActiveConversation(existing);
      setIsStartingNew(false);
      toast({ title: "Conversation already exists", description: "Loading existing conversation." });
      return;
    }

    try {
      const newConversation = await UserConversation.create({
        thread_id: threadId,
        participant_ids: [user.id, teacher.id],
        last_message_preview: `Conversation about ${child.name} started.`,
        last_activity: new Date().toISOString(),
        unread_count: { [user.id]: 0, [teacher.id]: 0 }
      });
      
      const enriched = (await enrichConversations([newConversation], user.id))[0];
      setConversations(prev => [enriched, ...prev]);
      setActiveConversation(enriched);
      setIsStartingNew(false);
      toast({ title: "New Conversation Started" });
    } catch (error) {
      console.error('Error starting conversation:', error);
      toast({ variant: "destructive", title: "Error", description: "Could not start a new conversation." });
    }
  };
  
  const handleNewMessage = (newMessage) => {
    setConversations(prevConvos => {
      const updatedConvos = prevConvos.map(convo => 
        convo.id === newMessage.conversation_id 
        ? { ...convo, last_message_preview: newMessage.content, last_activity: newMessage.created_date }
        : convo
      );
      // Sort by last activity
      return updatedConvos.sort((a, b) => new Date(b.last_activity) - new Date(a.last_activity));
    });
  };

  if (isLoading) {
    return <DashboardSkeleton />;
  }
  
  const renderContent = () => {
    if (isStartingNew) {
      return <StartConversationView children={children} onStartConversation={handleStartNewConversation} user={user} />;
    }
    if (activeConversation) {
      return (
        <ChatWindow
          key={activeConversation.id}
          conversation={activeConversation}
          currentUser={user}
          partner={activeConversation.partner}
          onNewMessage={handleNewMessage}
        />
      );
    }
    return (
      <div className="h-full flex flex-col items-center justify-center bg-gray-50 rounded-lg">
        <MessageSquare className="w-16 h-16 text-gray-300 mb-4" />
        <h3 className="text-lg font-semibold text-gray-700 mb-2">Select a conversation</h3>
        <p className="text-gray-500 text-center max-w-sm">
          Choose a conversation from the list, or start a new one to connect with your child's teachers.
        </p>
      </div>
    );
  };

  return (
    <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <MessageSquare className="w-8 h-8" style={{color: 'var(--teachmo-sage)'}} />
              Messages
            </h1>
            <p className="text-gray-600 mt-1">
              Connect with your child's teachers
            </p>
          </div>
          <div className="flex items-center gap-2">
             <Button variant="outline" onClick={() => setIsStartingNew(true)}>
               <Plus className="w-4 h-4 mr-2" />
               New Message
            </Button>
            <Link to={createPageUrl("AIAssistant")}>
              <Button variant="outline" className="flex items-center gap-2">
                <Bot className="w-4 h-4" />
                AI Coach
              </Button>
            </Link>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[calc(100vh-220px)]">
          <div className="lg:col-span-4 xl:col-span-3">
            <ConversationList
              conversations={conversations}
              activeConversationId={activeConversation?.id}
              onSelectConversation={handleSelectConversation}
              currentUser={user}
            />
          </div>
          <div className="lg:col-span-8 xl:col-span-9">
            {renderContent()}
          </div>
        </div>
      </div>
    </div>
  );
}