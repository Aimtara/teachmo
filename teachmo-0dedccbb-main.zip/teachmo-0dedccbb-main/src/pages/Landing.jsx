
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { Check, ShieldCheck, BookOpen, Users, Heart, Bot, BarChart, Loader2 } from 'lucide-react';
import TermsModal from '@/components/shared/TermsModal';
import { Checkbox } from "@/components/ui/checkbox";

const Feature = ({ icon: Icon, title, children }) => (
  <div className="flex items-start gap-4">
    <div className="flex-shrink-0 w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
      <Icon className="w-6 h-6 text-blue-600" />
    </div>
    <div>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="text-gray-600">{children}</p>
    </div>
  </div>
);

const Testimonial = ({ quote, author, role }) => (
  <blockquote className="p-6 bg-gray-50 rounded-lg">
    <p className="text-gray-700 italic">"{quote}"</p>
    <footer className="mt-4 text-sm font-semibold text-gray-900">{author}
      <span className="text-gray-500 font-normal">, {role}</span>
    </footer>
  </blockquote>
);

export default function LandingPage() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [isSignInLoading, setIsSignInLoading] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);

  const handleGetStarted = async () => {
    setIsLoading(true);
    try {
      // Redirect to Google login, then back to the Welcome page for onboarding.
      await User.loginWithRedirect(
        window.location.origin + createPageUrl("Welcome")
      );
    } catch (error) {
      console.error("Login failed", error);
      setIsLoading(false);
    }
  };

  const handleSignIn = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsSignInLoading(true);
    try {
      // Redirect to Google login for existing users
      await User.loginWithRedirect(
        window.location.origin + createPageUrl("Dashboard")
      );
    } catch (error) {
      console.error("Sign in failed", error);
      setIsSignInLoading(false);
    }
  };

  return (
    <div className="bg-white">
      {/* Header */}
      <header className="relative px-4 py-6 sm:px-6 lg:px-8">
        <nav className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Heart className="w-8 h-8 text-blue-600" />
            <span className="text-2xl font-bold text-gray-900">Teachmo</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
              className="text-sm font-medium text-gray-600 hover:text-blue-600 transition-colors"
            >
              Features
            </button>
            <button
              onClick={() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' })}
              className="text-sm font-medium text-gray-600 hover:text-blue-600 transition-colors"
            >
              Pricing
            </button>
            <Button
              variant="ghost"
              onClick={handleSignIn}
              disabled={isSignInLoading}
              className="hover:bg-blue-50 hover:text-blue-700"
            >
              {isSignInLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Signing In...
                </>
              ) : (
                'Sign In'
              )}
            </Button>
          </div>
        </nav>
      </header>

      <main>
        {/* Hero Section */}
        <div className="relative isolate pt-14">
          <div className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80" aria-hidden="true">
            <div className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-[#80d4ff] to-[#6b9dc8] opacity-30 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]" style={{ clipPath: 'polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)' }}></div>
          </div>
          <div className="py-24 sm:py-32">
            <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
                <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">
                  Parenting, Powered by <span className="text-blue-600">AI</span>.
                  <br />
                  Guidance, Backed by <span className="text-blue-600">Science</span>.
                </h1>
                <p className="mt-6 text-lg leading-8 text-gray-600 max-w-2xl mx-auto">
                  Teachmo is your AI-powered parenting coach, offering personalized activities, expert advice, and progress tracking to help your child thrive.
                </p>
                <div className="mt-10 flex items-center justify-center gap-x-6">
                  <Button
                    size="lg"
                    className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                    onClick={handleGetStarted}
                    disabled={!termsAccepted || isLoading}
                  >
                    {isLoading ? 'Redirecting...' : 'Start Free Today'}
                  </Button>
                </div>
                <div className="flex items-center space-x-2 mt-8 justify-center">
                  <Checkbox
                    id="terms"
                    checked={termsAccepted}
                    onCheckedChange={setTermsAccepted}
                    aria-labelledby="terms-label"
                  />
                  <div id="terms-label" className="text-sm text-gray-600">
                    I agree to the{' '}
                    <button
                      onClick={() => setShowTermsModal(true)}
                      className="underline font-medium text-blue-600 hover:text-blue-800"
                    >
                      Terms & Privacy Policy
                    </button>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <section id="features" className="py-24 sm:py-32 bg-gray-50">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="mx-auto max-w-2xl lg:text-center">
              <h2 className="text-base font-semibold leading-7 text-blue-600">Everything You Need</h2>
              <p className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">A Smarter Way to Parent</p>
              <p className="mt-6 text-lg leading-8 text-gray-600">
                From personalized activities to real-time advice, Teachmo provides the tools to support every stage of your child's development.
              </p>
            </div>
            <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-4xl">
              <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-10 lg:max-w-none lg:grid-cols-2 lg:gap-y-16">
                <Feature icon={Bot} title="AI Parenting Coach">
                  Get instant, evidence-based answers to your parenting questions, 24/7.
                </Feature>
                <Feature icon={BookOpen} title="Personalized Activities">
                  Receive daily activity suggestions tailored to your child's age and developmental needs.
                </Feature>
                <Feature icon={BarChart} title="Track Milestones">
                  Easily monitor and celebrate your child's growth and skill development over time.
                </Feature>
                <Feature icon={Users} title="Connect with Teachers">
                  Bridge the gap between home and school with seamless parent-teacher communication tools.
                </Feature>
              </dl>
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="py-24 sm:py-32">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl text-center mb-16">Loved by Parents & Educators</h2>
            <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
              <Testimonial quote="Teachmo has been a game-changer. The activity suggestions are brilliant and my kids love them!" author="Sarah J." role="Parent of 2" />
              <Testimonial quote="As a teacher, the ability to communicate with parents through Teachmo has been invaluable. It creates a real home-school connection." author="David L." role="2nd Grade Teacher" />
              <Testimonial quote="I was overwhelmed with information online. Teachmo's AI coach gives me clear, actionable advice I can trust." author="Maria G." role="New Parent" />
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section id="pricing" className="py-24 sm:py-32 bg-gray-50">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="mx-auto max-w-2xl sm:text-center">
              <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Simple, Transparent Pricing</h2>
              <p className="mt-6 text-lg leading-8 text-gray-600">
                Choose the plan that's right for your family. Get started for free.
              </p>
            </div>
            <div className="mx-auto mt-16 max-w-2xl rounded-3xl ring-1 ring-gray-200 sm:mt-20 lg:mx-0 lg:flex lg:max-w-none">
              <div className="p-8 sm:p-10 lg:flex-auto">
                <h3 className="text-2xl font-bold tracking-tight text-gray-900">Teachmo Premium</h3>
                <p className="mt-6 text-base leading-7 text-gray-600">
                  Unlock advanced features, unlimited AI access, and in-depth analytics to supercharge your parenting journey.
                </p>
                <div className="mt-10 flex items-center gap-x-4">
                  <h4 className="flex-none text-sm font-semibold leading-6 text-blue-600">What’s included</h4>
                  <div className="h-px flex-auto bg-gray-100"></div>
                </div>
                <ul role="list" className="mt-8 grid grid-cols-1 gap-4 text-sm leading-6 text-gray-600 sm:grid-cols-2 sm:gap-6">
                  <li className="flex gap-x-3"><Check className="h-6 w-5 flex-none text-blue-600" />Unlimited AI Coach Conversations</li>
                  <li className="flex gap-x-3"><Check className="h-6 w-5 flex-none text-blue-600" />Advanced Progress Analytics</li>
                  <li className="flex gap-x-3"><Check className="h-6 w-5 flex-none text-blue-600" />Premium Content Library</li>
                  <li className="flex gap-x-3"><Check className="h-6 w-5 flex-none text-blue-600" />Family Collaboration Tools</li>
                </ul>
              </div>
              <div className="-mt-2 p-2 lg:mt-0 lg:w-full lg:max-w-md lg:flex-shrink-0">
                <div className="rounded-2xl bg-gray-50 py-10 text-center ring-1 ring-inset ring-gray-900/5 lg:flex lg:flex-col lg:justify-center lg:py-16">
                  <div className="mx-auto max-w-xs px-8">
                    <p className="text-base font-semibold text-gray-600">Unlock everything</p>
                    <p className="mt-6 flex items-baseline justify-center gap-x-2">
                      <span className="text-5xl font-bold tracking-tight text-gray-900">$12</span>
                      <span className="text-sm font-semibold leading-6 tracking-wide text-gray-600">/month</span>
                    </p>
                    <Button
                      size="lg"
                      className="mt-10 block w-full bg-blue-600 px-3 py-2 text-center text-sm font-semibold text-white shadow-sm hover:bg-blue-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 disabled:opacity-50"
                      onClick={handleGetStarted}
                      disabled={!termsAccepted || isLoading}
                    >
                      Get Premium
                    </Button>
                    <p className="mt-6 text-xs leading-5 text-gray-600">
                      Invoices and receipts available for easy company reimbursement.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <TermsModal open={showTermsModal} onOpenChange={setShowTermsModal} />
    </div>
  );
}
