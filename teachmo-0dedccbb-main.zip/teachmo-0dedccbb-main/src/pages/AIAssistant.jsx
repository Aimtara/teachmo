
import React, { useState, useEffect } from "react";
import { InvokeLLM } from '@/api/integrations';
import { User, Child } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Bot, Loader2, Plus, MessageSquare, AlertCircle, RefreshCw } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import ConversationList from "../components/ai/ConversationList";
import ChatWindow from "../components/ai/ChatWindow";
import { AIAssistantSkeleton } from '../components/shared/ImprovedSkeletons';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function AIAssistant() {
  const [user, setUser] = useState(null);
  const [children, setChildren] = useState([]);
  const [conversations, setConversations] = useState([]);
  const [activeConversation, setActiveConversation] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isResponding, setIsResponding] = useState(false);
  const [currentMessage, setCurrentMessage] = useState('');
  const [error, setError] = useState(null);
  const [retryCount, setRetryCount] = useState(0);

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const [userData, childrenData] = await Promise.all([
          User.me(),
          Child.list(),
        ]);
        setUser(userData);
        setChildren(childrenData);

        // Sort conversations by updatedAt in descending order
        const sortedConversations = (userData.conversations || []).sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
        setConversations(sortedConversations);

        if (sortedConversations.length > 0) {
          setActiveConversation(sortedConversations[0]);
        } else {
          // Start a new conversation if none exist
          const newConversation = {
            id: Date.now().toString(),
            title: "New Chat",
            messages: [
              {
                id: '1',
                content: `Hi ${userData?.full_name?.split(' ')[0] || 'there'}! 👋 I'm your AI parenting coach. How can I help you today?`,
                isUser: false,
                timestamp: new Date().toISOString()
              }
            ],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };
          setActiveConversation(newConversation);
          setConversations([newConversation]);
        }
      } catch (err) {
        console.error("Failed to load AI Assistant data:", err);
        if (err.message?.includes('429') || err.response?.status === 429) {
          setError("We're experiencing high demand right now. Please wait a moment and try again.");
        } else {
          setError("Could not load your AI Coach. Please check your connection and try again.");
        }
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, [retryCount]);

  const handleRetry = () => {
    setRetryCount(c => c + 1);
  };

  const updateConversations = async (newConversations) => {
      // Ensure conversations are always sorted by update time before saving and setting state
      const sorted = newConversations.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
      setConversations(sorted);
      await User.updateMyUserData({ conversations: sorted });
  };

  const startNewConversation = (currentUserData) => {
    const newConversation = {
      id: Date.now().toString(),
      title: "New Conversation",
      messages: [
        {
          id: '1',
          content: `Hi ${currentUserData?.full_name?.split(' ')[0] || 'there'}! 👋 I'm your AI parenting coach. How can I help you today?`,
          isUser: false,
          timestamp: new Date().toISOString()
        }
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // Prepend new conversation and update
    const updatedConversations = [newConversation, ...conversations];
    setConversations(updatedConversations); // Update state immediately
    setActiveConversation(newConversation); // Set the new conversation as active
    // The updateConversations function will persist this change to the backend.
    // We don't call updateConversations here directly as it's triggered by message updates
    // or deleting conversations. For a new conversation, it will be saved when first message is sent.
  };

  const handleSelectConversation = (id) => {
    const conversationToSelect = conversations.find(c => c.id === id);
    if (conversationToSelect) {
      setActiveConversation(conversationToSelect);
    }
  };

  const handleRenameConversation = async (id, newTitle) => {
    const updated = conversations.map(c => c.id === id ? { ...c, title: newTitle } : c);
    await updateConversations(updated);
  };

  const handleDeleteConversation = async (id) => {
    const updated = conversations.filter(c => c.id !== id);
    await updateConversations(updated);

    if (activeConversation && activeConversation.id === id) {
        if (updated.length > 0) {
            // After sorting, the first element is the most recent.
            setActiveConversation(updated[0]);
        } else {
            // If no conversations left, start a new one
            startNewConversation(user); // Use the 'user' state variable
        }
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
          <AIAssistantSkeleton />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen p-4 md:p-6 flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <Alert variant="destructive" className="max-w-md bg-white">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error Loading Coach</AlertTitle>
          <AlertDescription>
            {error}
          </AlertDescription>
          <Button onClick={handleRetry} variant="outline" className="mt-4">
            <RefreshCw className="w-4 h-4 mr-2" />
            Try Again
          </Button>
        </Alert>
      </div>
    );
  }

  return (
    <div className="flex h-[calc(100vh-120px)]" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-6xl mx-auto w-full p-2 sm:p-4 md:p-6 flex flex-col">
        <header className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-3">
            <Bot className="w-8 h-8" style={{color: 'var(--teachmo-sage)'}} />
            AI Coach
          </h1>
          <p className="text-gray-600">
            Get instant, personalized advice for your parenting questions.
          </p>
        </header>

        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-6">
            {/* Conversation List (Pane 1) - Always visible in desktop view */}
            <div className="md:col-span-4 lg:col-span-3 h-full">
               <ConversationList
                  conversations={conversations}
                  activeConversationId={activeConversation?.id} // Pass id for highlighting
                  onSelectConversation={handleSelectConversation}
                  onNewConversation={() => startNewConversation(user)} // Use the 'user' state variable
                  onRename={handleRenameConversation}
                  onDelete={handleDeleteConversation}
                />
            </div>

            {/* Chat Window (Pane 2) - Always visible in desktop view */}
            <div className="md:col-span-8 lg:col-span-9 h-full">
                {activeConversation ? (
                    <ChatWindow
                        key={activeConversation.id} // Use activeConversation.id as key
                        conversation={activeConversation}
                        childContext={children}
                        updateConversations={updateConversations}
                        allConversations={conversations}
                    />
                ) : (
                    <div className="h-full flex flex-col items-center justify-center bg-white/80 rounded-lg shadow-sm">
                        <MessageSquare className="w-16 h-16 text-gray-300 mb-4" />
                        <h3 className="text-lg font-semibold text-gray-700">Select a conversation</h3>
                        <p className="text-gray-500">Or start a new one to begin chatting with your AI coach.</p>
                        <Button onClick={() => startNewConversation(user)} className="mt-4">
                           <Plus className="w-4 h-4 mr-2" />
                           New Conversation
                        </Button>
                    </div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
}
