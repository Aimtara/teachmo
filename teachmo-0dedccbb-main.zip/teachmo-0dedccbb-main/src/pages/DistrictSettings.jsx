
import React, { useState, useEffect } from 'react';
import { User, District } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Settings, Save, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { withAdminGuard } from '@/components/shared/AdminRoleGuard';

function DistrictSettings() {
  const [district, setDistrict] = useState(null);
  const [formData, setFormData] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  const { toast } = useToast();

  useEffect(() => {
    const fetchDistrictSettings = async () => {
      try {
        const currentUser = await User.me();
        if (!currentUser.district_id) {
          throw new Error('User is not associated with a district');
        }

        const districtData = await District.get(currentUser.district_id);
        setDistrict(districtData);
        setFormData({
          ...districtData,
          settings: districtData.settings || {
            sso_enabled: false,
            sso_provider: 'google',
            data_residency: 'US',
            require_teacher_verification: true,
            enable_district_analytics: true
          }
        });
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error loading district settings",
          description: error.message
        });
        console.error('District settings fetch error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchDistrictSettings();
  }, [toast]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSettingChange = (settingName, value) => {
    setFormData(prev => ({
      ...prev,
      settings: { ...prev.settings, [settingName]: value }
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await District.update(district.id, formData);
      toast({
        title: "Settings saved",
        description: "District settings have been updated successfully."
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Save failed",
        description: "An error occurred while saving settings."
      });
      console.error('Settings save error:', error);
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="p-4 md:p-8 space-y-6">
        <Skeleton className="h-10 w-1/3" />
        <Card><CardContent className="p-6 space-y-4">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}</CardContent></Card>
      </div>
    );
  }

  if (!district) {
    return (
      <div className="p-4 md:p-8">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-gray-600">District information not found.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-6 flex items-center gap-3">
          <Settings className="w-8 h-8" style={{color: 'var(--teachmo-sage)'}} />
          District Settings
        </h1>

        <div className="space-y-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">District Name</Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name || ''}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <Label htmlFor="state">State/Province</Label>
                  <Input
                    id="state"
                    name="state"
                    value={formData.state || ''}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="contact_email">Contact Email</Label>
                  <Input
                    id="contact_email"
                    name="contact_email"
                    type="email"
                    value={formData.contact_email || ''}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <Label htmlFor="contact_phone">Contact Phone</Label>
                  <Input
                    id="contact_phone"
                    name="contact_phone"
                    value={formData.contact_phone || ''}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="website">Website</Label>
                <Input
                  id="website"
                  name="website"
                  type="url"
                  value={formData.website || ''}
                  onChange={handleInputChange}
                />
              </div>

              <div>
                <Label htmlFor="subscription_tier">Subscription Tier</Label>
                <Select value={formData.subscription_tier || ''} onValueChange={(value) => handleSelectChange('subscription_tier', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select subscription tier" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pilot">Pilot</SelectItem>
                    <SelectItem value="basic">Basic</SelectItem>
                    <SelectItem value="premium">Premium</SelectItem>
                    <SelectItem value="enterprise">Enterprise</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Advanced Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Advanced Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">Single Sign-On (SSO)</h4>
                  <p className="text-sm text-gray-600">Enable SSO authentication for district users</p>
                </div>
                <Switch
                  checked={formData.settings?.sso_enabled || false}
                  onCheckedChange={(checked) => handleSettingChange('sso_enabled', checked)}
                />
              </div>

              {formData.settings?.sso_enabled && (
                <div>
                  <Label htmlFor="sso_provider">SSO Provider</Label>
                  <Select value={formData.settings?.sso_provider || 'google'} onValueChange={(value) => handleSettingChange('sso_provider', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select SSO provider" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="google">Google</SelectItem>
                      <SelectItem value="microsoft">Microsoft</SelectItem>
                      <SelectItem value="clever">Clever</SelectItem>
                      <SelectItem value="classlink">ClassLink</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div>
                <Label htmlFor="data_residency">Data Residency</Label>
                <Select value={formData.settings?.data_residency || 'US'} onValueChange={(value) => handleSettingChange('data_residency', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select data residency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="US">United States</SelectItem>
                    <SelectItem value="EU">European Union</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">Teacher Verification Required</h4>
                  <p className="text-sm text-gray-600">Require verification before teachers can access student data</p>
                </div>
                <Switch
                  checked={formData.settings?.require_teacher_verification || false}
                  onCheckedChange={(checked) => handleSettingChange('require_teacher_verification', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">District Analytics</h4>
                  <p className="text-sm text-gray-600">Enable district-wide analytics and reporting</p>
                </div>
                <Switch
                  checked={formData.settings?.enable_district_analytics || false}
                  onCheckedChange={(checked) => handleSettingChange('enable_district_analytics', checked)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Save Button */}
          <div className="flex justify-end">
            <Button onClick={handleSave} disabled={isSaving}>
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Save Settings
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default withAdminGuard(DistrictSettings, { 
  requiredRoles: ['district_admin', 'system_admin', 'admin'] 
});
