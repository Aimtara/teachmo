import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Database, Info, CheckCircle, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import SupabaseExample from '../components/examples/SupabaseExample';

export default function SupabaseSetup() {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Supabase Integration</h1>
          <p className="text-lg text-gray-600">
            Add powerful database and authentication capabilities to your Base44 app
          </p>
        </div>

        {/* Setup Instructions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              Setup Instructions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="font-semibold text-gray-900">1. Create Supabase Project</h3>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" />
                    Go to <a href="https://supabase.com" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline inline-flex items-center gap-1">supabase.com <ExternalLink className="w-3 h-3" /></a>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" />
                    Create a new project
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" />
                    Go to Settings → API
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" />
                    Copy your Project URL and anon key
                  </li>
                </ul>
              </div>

              <div className="space-y-4">
                <h3 className="font-semibold text-gray-900">2. Set Environment Variables</h3>
                <p className="text-sm text-gray-600">
                  In your Base44 dashboard, go to <strong>Settings → Environment Variables</strong> and add:
                </p>
                <div className="bg-gray-100 p-3 rounded text-sm font-mono space-y-1">
                  <div>VITE_SUPABASE_URL=https://your-project.supabase.co</div>
                  <div>VITE_SUPABASE_ANON_KEY=eyJhbGciOi...</div>
                </div>
              </div>
            </div>

            <Alert>
              <Info className="h-4 w-4" />
              <AlertTitle>Environment Variables</AlertTitle>
              <AlertDescription>
                Base44 automatically secures your environment variables. Never commit credentials directly to your code.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {/* Features */}
        <Card>
          <CardHeader>
            <CardTitle>What You Can Do</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <h4 className="font-semibold text-gray-900">🔐 Authentication</h4>
                <p className="text-sm text-gray-600">
                  User sign-up, sign-in, password reset, and social logins
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-gray-900">🗄️ Database</h4>
                <p className="text-sm text-gray-600">
                  PostgreSQL database with real-time subscriptions
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-gray-900">📁 Storage</h4>
                <p className="text-sm text-gray-600">
                  File uploads, image processing, and CDN delivery
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Usage Example */}
        <Card>
          <CardHeader>
            <CardTitle>Code Example</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
              <pre>{`import { useSupabaseOperations } from '@/components/hooks/useSupabase';

function MyComponent() {
  const { auth, db, storage } = useSupabaseOperations();
  
  // Authentication
  const handleSignIn = async () => {
    await auth.signIn(email, password);
  };
  
  // Database
  const fetchData = async () => {
    const { data } = await db.select('my_table');
  };
  
  // Storage
  const uploadFile = async (file) => {
    await storage.upload('bucket', 'path', file);
  };
}`}</pre>
            </div>
          </CardContent>
        </Card>

        {/* Live Example */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Live Example</h2>
          <SupabaseExample />
        </div>

        {/* Integration Notes */}
        <Card>
          <CardHeader>
            <CardTitle>Integration with Base44</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <Info className="h-4 w-4" />
              <AlertTitle>Best Practices</AlertTitle>
              <AlertDescription>
                <ul className="mt-2 space-y-1 text-sm">
                  <li>• Use Base44 entities for core app data and user management</li>
                  <li>• Use Supabase for additional storage, complex queries, or real-time features</li>
                  <li>• Both systems can coexist - choose the right tool for each feature</li>
                  <li>• Enable Row Level Security (RLS) in Supabase for data protection</li>
                </ul>
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}