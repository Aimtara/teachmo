
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  BookOpen, 
  Users, 
  MessageSquare, 
  Calendar,
  TrendingUp,
  Plus,
  Bell,
  CheckCircle,
  Clock,
  AlertTriangle,
  ExternalLink,
  Settings,
  Sparkles,
  BarChart3,
  FileText,
  Heart,
  RefreshCw // Added RefreshCw icon
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { format, isToday, isAfter } from 'date-fns'; // Added isAfter
import { 
  User, 
  Course, 
  Assignment, 
  UserMessage, 
  UserConversation,
  Announcement,
  InAppNotification
} from '@/api/entities';
import { useToast } from '@/components/ui/use-toast';
import RoleGuard from '@/components/shared/RoleGuard';
import { DashboardSkeleton } from '@/components/shared/ImprovedSkeletons';

function TeacherDashboard() {
  const [user, setUser] = useState(null);
  const [dashboardData, setDashboardData] = useState({
    courses: [],
    assignments: [], // Added assignments to state
    recentMessages: [],
    upcomingAssignments: [],
    recentAnnouncements: [],
    notifications: [],
    stats: {
      totalStudents: 0,
      unreadMessages: 0,
      pendingAssignments: 0,
      activeClasses: 0
    }
  });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setIsLoading(true);
      setError(null);

      // Load current user
      const currentUser = await User.me();
      setUser(currentUser);

      if (!currentUser.onboarding_completed) {
        // Redirect to onboarding if not completed
        window.location.href = createPageUrl('TeacherOnboarding');
        return;
      }

      // Load teacher's courses
      let courses = [];
      try {
        courses = await Course.filter({ teacher_id: currentUser.id });
      } catch (courseError) {
        console.warn('Could not load courses:', courseError);
      }

      // Load assignments from Google Classroom integration
      let assignments = [];
      try {
        const courseIds = courses.map(c => c.id);
        if (courseIds.length > 0) {
          assignments = await Assignment.filter({
            course_id: { $in: courseIds }
          }, '-due_date', 20); // Load 20 recent assignments
        }
      } catch (assignmentError) {
        console.warn('Could not load assignments:', assignmentError);
      }

      // Load recent messages
      let recentMessages = [];
      try {
        const conversations = await UserConversation.filter({
          participant_ids: { $in: [currentUser.id] }
        }, '-last_activity', 5);
        recentMessages = conversations;
      } catch (messageError) {
        console.warn('Could not load messages:', messageError);
      }

      // Load upcoming assignments (assignments due soon)
      // Now derived from the broader 'assignments' array
      const upcomingAssignments = assignments.filter(assignment => {
        const dueDate = new Date(assignment.due_date);
        const now = new Date();
        const diffTime = dueDate - now;
        const diffDays = diffTime / (1000 * 60 * 60 * 24);
        return diffDays >= 0 && diffDays <= 7; // Due within the next 7 days
      });

      // Load recent announcements
      let recentAnnouncements = [];
      try {
        recentAnnouncements = await Announcement.filter({
          sender_id: currentUser.id
        }, '-created_date', 5);
      } catch (announcementError) {
        console.warn('Could not load announcements:', announcementError);
      }

      // Load notifications
      let notifications = [];
      try {
        notifications = await InAppNotification.filter({
          user_id: currentUser.id,
          read: false
        }, '-created_date', 5);
      } catch (notificationError) {
        console.warn('Could not load notifications:', notificationError);
      }

      // Calculate stats
      const stats = {
        totalStudents: courses.reduce((sum, course) => sum + (course.enrollment_count || 0), 0),
        unreadMessages: recentMessages.filter(msg => 
          msg.unread_count && msg.unread_count[currentUser.id] > 0
        ).length,
        pendingAssignments: assignments.filter(assignment => // Use 'assignments' here
          assignment.status === 'NotStarted' || assignment.status === 'InProgress'
        ).length,
        activeClasses: courses.filter(course => course.is_active !== false).length
      };

      setDashboardData({
        courses,
        assignments, // Included assignments in dashboardData
        recentMessages,
        upcomingAssignments,
        recentAnnouncements,
        notifications,
        stats
      });

    } catch (err) {
      console.error('Error loading teacher dashboard:', err);
      setError({
        message: 'Could not load your dashboard. Please try refreshing the page.',
        canRetry: true
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleRetry = () => {
    loadDashboardData();
  };

  const markNotificationAsRead = async (notificationId) => {
    try {
      await InAppNotification.update(notificationId, { read: true });
      setDashboardData(prev => ({
        ...prev,
        notifications: prev.notifications.filter(n => n.id !== notificationId)
      }));
    } catch (error) {
      console.error('Could not mark notification as read:', error);
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    const name = user?.full_name?.split(' ')[0] || 'Teacher';
    
    if (hour < 12) return `Good morning, ${name}!`;
    if (hour < 17) return `Good afternoon, ${name}!`;
    return `Good evening, ${name}!`;
  };

  const getMotivationalMessage = () => {
    const messages = [
      "Your dedication shapes young minds every day.",
      "Teaching is the profession that creates all other professions.",
      "You're making a difference in students' lives.",
      "Every lesson you teach plants seeds for the future.",
      "Your classroom is where dreams begin to take shape."
    ];
    return messages[new Date().getDate() % messages.length];
  };

  if (isLoading) {
    return (
      <div className="p-4 md:p-6">
        <DashboardSkeleton />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 md:p-6">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription className="flex items-center justify-between">
            <span>{error.message}</span>
            {error.canRetry && (
              <Button variant="outline" size="sm" onClick={handleRetry}>
                Try Again
              </Button>
            )}
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // Configuration for assignment status badges
  const statusConfig = {
    'NotStarted': { label: 'Not Started', color: 'bg-red-100 text-red-800' },
    'InProgress': { label: 'In Progress', color: 'bg-yellow-100 text-yellow-800' },
    'Submitted': { label: 'Submitted', color: 'bg-blue-100 text-blue-800' },
    'Graded': { label: 'Graded', color: 'bg-green-100 text-green-800' },
    'Returned': { label: 'Returned', color: 'bg-purple-100 text-purple-800' }
  };

  return (
    <div className="p-4 md:p-6 space-y-6 min-h-screen" style={{backgroundColor: 'var(--teachmo-cream, #f9f7f4)'}}>
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">{getGreeting()}</h1>
          <p className="text-gray-600 mt-1">{getMotivationalMessage()}</p>
          {user?.teaching_profile && (
            <div className="flex flex-wrap gap-2 mt-2">
              {user.teaching_profile.subjects_taught?.slice(0, 3).map((subject, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {subject}
                </Badge>
              ))}
              {user.teaching_profile.grades_taught?.length > 0 && (
                <Badge variant="outline" className="text-xs">
                  {user.teaching_profile.grades_taught.join(', ')}
                </Badge>
              )}
            </div>
          )}
        </div>
        
        <div className="flex gap-2">
          <Button asChild variant="outline">
            <Link to={createPageUrl('Settings')}>
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </Link>
          </Button>
          {!user?.google_classroom_connected ? (
            <Button asChild>
              <Link to={createPageUrl('Integrations')}>
                <Plus className="w-4 h-4 mr-2" />
                Connect Google Classroom
              </Link>
            </Button>
          ) : (
            <Button asChild variant="outline">
              <Link to={createPageUrl('TeacherAssignments')}>
                <FileText className="w-4 h-4 mr-2" />
                View Assignments
              </Link>
            </Button>
          )}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-700">Active Classes</p>
                  <p className="text-2xl font-bold text-blue-900">{dashboardData.stats.activeClasses}</p>
                </div>
                <BookOpen className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-700">Total Students</p>
                  <p className="text-2xl font-bold text-green-900">{dashboardData.stats.totalStudents}</p>
                </div>
                <Users className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-700">Unread Messages</p>
                  <p className="text-2xl font-bold text-purple-900">{dashboardData.stats.unreadMessages}</p>
                </div>
                <MessageSquare className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-orange-700">Due Soon</p>
                  <p className="text-2xl font-bold text-orange-900">{dashboardData.stats.pendingAssignments}</p>
                </div>
                <Clock className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Google Classroom Integration Status */}
      {user?.google_classroom_connected && (
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-blue-900">Google Classroom Connected</h3>
                  <p className="text-sm text-blue-700">
                    {user.last_integration_sync 
                      ? `Last synced: ${format(new Date(user.last_integration_sync), 'MMM d, h:mm a')}`
                      : 'Ready to sync your data'
                    }
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button asChild size="sm" variant="outline" className="border-blue-300 text-blue-700 hover:bg-blue-50">
                  <Link to={createPageUrl('Integrations')}>
                    <RefreshCw className="w-4 h-4 mr-1" />
                    Sync
                  </Link>
                </Button>
                <Button asChild size="sm" className="bg-blue-600 hover:bg-blue-700">
                  <Link to={createPageUrl('TeacherAssignments')}>
                    <FileText className="w-4 h-4 mr-1" />
                    Assignments
                  </Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-yellow-600" />
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button asChild className="h-auto p-4 flex flex-col items-center gap-2 bg-blue-600 hover:bg-blue-700">
              <Link to={createPageUrl('TeacherMessages')}>
                <MessageSquare className="w-6 h-6" />
                <div className="text-center">
                  <div className="font-semibold">Message Parents</div>
                  <div className="text-xs opacity-90">Send updates & communicate</div>
                </div>
              </Link>
            </Button>
            
            <Button asChild variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
              <Link to={createPageUrl('Announcements')}>
                <FileText className="w-6 h-6 text-green-600" />
                <div className="text-center">
                  <div className="font-semibold">Create Announcement</div>
                  <div className="text-xs text-gray-600">Share with your classes</div>
                </div>
              </Link>
            </Button>
            
            <Button asChild variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
              <Link to={createPageUrl('TeacherClasses')}>
                <Users className="w-6 h-6 text-purple-600" />
                <div className="text-center">
                  <div className="font-semibold">Manage Classes</div>
                  <div className="text-xs text-gray-600">View students & assignments</div>
                </div>
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Main Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Classes & Messages */}
        <div className="lg:col-span-2 space-y-6">
          {/* My Classes */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-blue-600" />
                My Classes
              </CardTitle>
              <Button asChild variant="outline" size="sm">
                <Link to={createPageUrl('TeacherClasses')}>
                  View All
                </Link>
              </Button>
            </CardHeader>
            <CardContent>
              {dashboardData.courses.length === 0 ? (
                <div className="text-center py-8">
                  <BookOpen className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No Classes Yet</h3>
                  <p className="text-gray-600 mb-4">
                    Connect your Google Classroom or add classes manually to get started.
                  </p>
                  <Button asChild>
                    <Link to={createPageUrl('Integrations')}>
                      Connect Google Classroom
                    </Link>
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  {dashboardData.courses.slice(0, 3).map((course) => (
                    <div key={course.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                      <div>
                        <h4 className="font-semibold text-gray-900">{course.name}</h4>
                        <p className="text-sm text-gray-600">
                          {course.course_code} • {course.enrollment_count || 0} students
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Badge variant="outline">
                          {course.source_system || 'Manual'}
                        </Badge>
                        <Button asChild size="sm" variant="ghost">
                          <Link to={createPageUrl(`CourseDetail?id=${course.id}`)}>
                            <ExternalLink className="w-4 h-4" />
                          </Link>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Assignments - New Section */}
          {user?.google_classroom_connected && dashboardData.assignments?.length > 0 && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-green-600" />
                  Recent Assignments
                </CardTitle>
                <Button asChild variant="outline" size="sm">
                  <Link to={createPageUrl('TeacherAssignments')}>
                    View All
                  </Link>
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {dashboardData.assignments.slice(0, 3).map((assignment) => {
                    const course = dashboardData.courses.find(c => c.id === assignment.course_id);
                    const dueDate = assignment.due_date ? new Date(assignment.due_date) : null;
                    const isAssignmentOverdue = dueDate && isAfter(new Date(), dueDate) && assignment.status !== 'Graded';
                    
                    return (
                      <div key={assignment.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-gray-900 truncate">{assignment.title}</h4>
                          <div className="flex items-center gap-2 mt-1">
                            {course && (
                              <Badge variant="outline" className="text-xs">
                                {course.name}
                              </Badge>
                            )}
                            <Badge className={statusConfig[assignment.status]?.color || 'bg-gray-100 text-gray-800'}>
                              {statusConfig[assignment.status]?.label || assignment.status}
                            </Badge>
                            {isAssignmentOverdue && (
                              <Badge className="bg-red-100 text-red-800 text-xs">
                                Overdue
                              </Badge>
                            )}
                          </div>
                          {dueDate && (
                            <p className="text-xs text-gray-500 mt-1">
                              Due: {format(dueDate, 'MMM d, yyyy')}
                            </p>
                          )}
                        </div>
                        {assignment.grade && (
                          <div className="text-sm font-medium text-green-600 ml-2">
                            {assignment.grade}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recent Messages */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-purple-600" />
                Recent Messages
              </CardTitle>
              <Button asChild variant="outline" size="sm">
                <Link to={createPageUrl('TeacherMessages')}>
                  View All
                </Link>
              </Button>
            </CardHeader>
            <CardContent>
              {dashboardData.recentMessages.length === 0 ? (
                <div className="text-center py-6">
                  <MessageSquare className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-gray-600">No recent messages</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {dashboardData.recentMessages.slice(0, 3).map((conversation) => (
                    <div key={conversation.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-gray-900 truncate">
                          Parent Conversation
                        </p>
                        <p className="text-sm text-gray-600 truncate">
                          {conversation.last_message_preview || 'No preview available'}
                        </p>
                        <p className="text-xs text-gray-500">
                          {conversation.last_activity && format(new Date(conversation.last_activity), 'MMM d, h:mm a')}
                        </p>
                      </div>
                      {conversation.unread_count && conversation.unread_count[user?.id] > 0 && (
                        <Badge variant="destructive" className="ml-2">
                          {conversation.unread_count[user.id]}
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Sidebar */}
        <div className="space-y-6">
          {/* Notifications */}
          {dashboardData.notifications.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="w-5 h-5 text-yellow-600" />
                  Notifications
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {dashboardData.notifications.map((notification) => (
                    <div key={notification.id} className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <p className="text-sm text-gray-900">{notification.content}</p>
                      <div className="flex justify-between items-center mt-2">
                        <p className="text-xs text-gray-500">
                          {format(new Date(notification.created_date), 'MMM d, h:mm a')}
                        </p>
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => markNotificationAsRead(notification.id)}
                        >
                          Mark as read
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Upcoming Assignments */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-green-600" />
                Due This Week
              </CardTitle>
            </CardHeader>
            <CardContent>
              {dashboardData.upcomingAssignments.length === 0 ? (
                <div className="text-center py-4">
                  <CheckCircle className="w-8 h-8 mx-auto mb-2 text-green-500" />
                  <p className="text-sm text-gray-600">No assignments due this week</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {dashboardData.upcomingAssignments.slice(0, 4).map((assignment) => (
                    <div key={assignment.id} className="p-2 border rounded-lg">
                      <p className="font-medium text-sm text-gray-900 truncate">{assignment.title}</p>
                      <p className="text-xs text-gray-600">
                        Due {format(new Date(assignment.due_date), 'MMM d')}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Announcements */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-600" />
                Your Announcements
              </CardTitle>
              <Button asChild size="sm">
                <Link to={createPageUrl('Announcements')}>
                  <Plus className="w-4 h-4" />
                </Link>
              </Button>
            </CardHeader>
            <CardContent>
              {dashboardData.recentAnnouncements.length === 0 ? (
                <div className="text-center py-4">
                  <FileText className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-sm text-gray-600">No announcements yet</p>
                  <Button asChild size="sm" variant="outline" className="mt-2">
                    <Link to={createPageUrl('Announcements')}>
                      Create First Announcement
                    </Link>
                  </Button>
                </div>
              ) : (
                <div className="space-y-2">
                  {dashboardData.recentAnnouncements.slice(0, 3).map((announcement) => (
                    <div key={announcement.id} className="p-2 border rounded-lg">
                      <p className="font-medium text-sm text-gray-900 truncate">{announcement.title}</p>
                      <p className="text-xs text-gray-600">
                        {format(new Date(announcement.created_date), 'MMM d')}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default function ProtectedTeacherDashboard() {
  return (
    <RoleGuard allowedRoles={['teacher', 'school_admin', 'district_admin', 'system_admin', 'admin']}>
      <TeacherDashboard />
    </RoleGuard>
  );
}
