
import React, { useState, useEffect, useMemo } from 'react';
import { User, School } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Search, AlertCircle, Users, BookOpen, Shield, Edit } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from "@/components/ui/use-toast";
import { useAdminPermissions } from '@/components/shared/AdminRoleGuard'; // 'withAdminGuard' removed
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { RoleGuard } from '@/components/shared/RoleGuard'; // New import
import { useAuth } from '@/hooks/useAuth'; // Assuming useAuth hook provides the current user context

const DistrictUsersPage = () => {
  // Get current user and authentication loading state from a shared auth context/hook
  const { user: currentUser, isLoading: authLoading } = useAuth();

  const [users, setUsers] = useState([]);
  const [schools, setSchools] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');

  const { toast } = useToast();
  const { getAccessibleUsers } = useAdminPermissions(currentUser); // useAdminPermissions now receives user from useAuth
  const navigate = useNavigate();

  useEffect(() => {
    const fetchDistrictData = async () => {
      try {
        setIsLoading(true);
        setError(null); // Clear any previous errors

        // Ensure current user is available and not still loading auth
        if (!currentUser) {
          setError('User not authenticated or user data unavailable.');
          setIsLoading(false);
          return;
        }

        if (!currentUser.district_id) {
          setError('You are not associated with a specific district.');
          setIsLoading(false);
          return;
        }

        // Fetch all users in the district
        const allUsers = await User.filter({ district_id: currentUser.district_id }, '-created_date');
        const accessibleUsers = getAccessibleUsers(allUsers);
        setUsers(accessibleUsers);

        // Fetch all schools in the district
        const districtSchools = await School.filter({ district_id: currentUser.district_id });
        setSchools(districtSchools);

      } catch (e) {
        setError('Failed to load district data. Please try again.');
        console.error(e);
      } finally {
        setIsLoading(false);
      }
    };

    // Only fetch if currentUser is available and authentication is not still loading
    if (currentUser && !authLoading) {
      fetchDistrictData();
    }
  }, [currentUser, authLoading, getAccessibleUsers]); // Added authLoading to dependencies

  const handleEditUser = (userId) => {
    navigate(createPageUrl(`AdminUserEdit?id=${userId}`));
  };

  const filteredUsers = useMemo(() => {
    // If still loading data and users array is empty, return an empty array to prevent filtering issues
    if (!users.length && isLoading) return [];

    return users.filter(user => {
      const matchesSearch = user.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email?.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesRole = roleFilter === 'all' || user.role === roleFilter;
      return matchesSearch && matchesRole;
    });
  }, [users, searchTerm, roleFilter, isLoading]); // Added isLoading to dependencies for completeness

  const getUserSchool = (user) => {
    if (user.school_id) {
      const school = schools.find(s => s.id === user.school_id);
      return school ? school.name : 'Unknown School';
    }
    return 'District Level';
  };

  const getRoleBadgeColor = (role) => {
    switch (role) {
      case 'district_admin': return 'bg-purple-100 text-purple-800';
      case 'school_admin': return 'bg-blue-100 text-blue-800';
      case 'teacher': return 'bg-green-100 text-green-800';
      case 'parent': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case 'active': return 'success';
      case 'invited': return 'secondary';
      case 'deactivated': return 'destructive';
      default: return 'outline';
    }
  };

  // Handle authentication loading state
  if (authLoading) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center" style={{ backgroundColor: 'var(--teachmo-cream)' }}>
        <Skeleton className="w-full h-[calc(100vh-64px)]" /> {/* Adjust skeleton size as needed */}
      </div>
    );
  }

  // Handle authentication errors (e.g., no user found after loading)
  if (error && !currentUser) {
    return (
      <div className="min-h-screen p-4 md:p-8" style={{ backgroundColor: 'var(--teachmo-cream)' }}>
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Authentication Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      </div>
    );
  }

  // Handle general data loading errors (e.g., district data fetch error, but user is authenticated)
  if (error && currentUser) {
    return (
      <div className="min-h-screen p-4 md:p-8" style={{ backgroundColor: 'var(--teachmo-cream)' }}>
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8" style={{ backgroundColor: 'var(--teachmo-cream)' }}>
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-lg bg-purple-100 flex items-center justify-center">
            <Users className="w-6 h-6 text-purple-600" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">District Users</h1>
            <p className="text-gray-600">District-wide User Overview</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Users</p>
                  <p className="text-2xl font-bold text-gray-900">{users.length}</p>
                </div>
                <Users className="w-8 h-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Schools</p>
                  <p className="text-2xl font-bold text-gray-900">{schools.length}</p>
                </div>
                <BookOpen className="w-8 h-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Teachers</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {users.filter(u => u.role === 'teacher').length}
                  </p>
                </div>
                <Shield className="w-8 h-8 text-green-400" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Parents</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {users.filter(u => u.role === 'parent').length}
                  </p>
                </div>
                <Users className="w-8 h-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <Input
            placeholder="Search users..."
            className="pl-9"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* Users Table */}
      <Card className="shadow-lg">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>School</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Login</TableHead>
                  <TableHead>Permissions</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-4 w-40" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                      <TableCell><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                    </TableRow>
                  ))
                ) : filteredUsers.length > 0 ? (
                  filteredUsers.map(user => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div className="font-medium">{user.full_name || 'N/A'}</div>
                        <div className="text-sm text-gray-500">{user.email}</div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getRoleBadgeColor(user.role)}>
                          {user.role?.replace('_', ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">{getUserSchool(user)}</div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadgeVariant(user.status)} className="capitalize">
                          {user.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {user.last_login_date ? format(new Date(user.last_login_date), 'MMM d, yyyy') : 'Never'}
                      </TableCell>
                      <TableCell>
                        <div className="text-xs">
                          {user.admin_permissions?.can_manage_users && (
                            <Badge variant="outline" className="mr-1 mb-1">User Mgmt</Badge>
                          )}
                          {user.admin_permissions?.can_send_announcements && (
                            <Badge variant="outline" className="mr-1 mb-1">Announcements</Badge>
                          )}
                          {user.admin_permissions?.can_manage_events && (
                            <Badge variant="outline" className="mr-1 mb-1">Events</Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditUser(user.id)}
                        >
                          <Edit className="w-4 h-4 mr-1" />
                          Edit
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center h-24">
                      No users found matching your criteria.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// Export a new component wrapped with RoleGuard
export default function ProtectedDistrictUsers() {
  return (
    <RoleGuard allowedRoles={['district_admin', 'system_admin', 'admin']}>
      <DistrictUsersPage />
    </RoleGuard>
  );
}
