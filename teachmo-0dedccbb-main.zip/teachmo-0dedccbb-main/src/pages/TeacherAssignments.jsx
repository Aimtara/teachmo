import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  BookOpen, 
  Users, 
  Calendar, 
  Search, 
  Filter,
  CheckCircle,
  Clock,
  AlertTriangle,
  FileText,
  BarChart3,
  RefreshCw,
  ExternalLink
} from 'lucide-react';
import { motion } from 'framer-motion';
import { format, isAfter, isBefore, addDays } from 'date-fns';
import { Assignment, Course, User } from '@/api/entities';
import { useToast } from '@/components/ui/use-toast';
import RoleGuard from '@/components/shared/RoleGuard';
import { DashboardSkeleton } from '@/components/shared/ImprovedSkeletons';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const statusConfig = {
  NotStarted: { label: 'Not Started', color: 'bg-gray-100 text-gray-800', icon: Clock },
  InProgress: { label: 'In Progress', color: 'bg-blue-100 text-blue-800', icon: Clock },
  Submitted: { label: 'Submitted', color: 'bg-green-100 text-green-800', icon: CheckCircle },
  Graded: { label: 'Graded', color: 'bg-purple-100 text-purple-800', icon: CheckCircle }
};

function AssignmentCard({ assignment, course }) {
  const config = statusConfig[assignment.status] || statusConfig.NotStarted;
  const IconComponent = config.icon;
  const dueDate = assignment.due_date ? new Date(assignment.due_date) : null;
  const isOverdue = dueDate && isAfter(new Date(), dueDate) && assignment.status !== 'Graded';
  const isDueSoon = dueDate && isBefore(dueDate, addDays(new Date(), 3)) && assignment.status !== 'Graded';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-lg border border-gray-200 hover:border-gray-300 transition-colors"
    >
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <CardTitle className="text-lg mb-2">{assignment.title}</CardTitle>
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="outline" className="text-xs">
                  <BookOpen className="w-3 h-3 mr-1" />
                  {course?.name || 'Unknown Course'}
                </Badge>
                <Badge className={config.color}>
                  <IconComponent className="w-3 h-3 mr-1" />
                  {config.label}
                </Badge>
                {isOverdue && (
                  <Badge className="bg-red-100 text-red-800">
                    <AlertTriangle className="w-3 h-3 mr-1" />
                    Overdue
                  </Badge>
                )}
                {isDueSoon && !isOverdue && (
                  <Badge className="bg-yellow-100 text-yellow-800">
                    <Clock className="w-3 h-3 mr-1" />
                    Due Soon
                  </Badge>
                )}
              </div>
              {assignment.description && (
                <p className="text-sm text-gray-600 line-clamp-2 mb-2">
                  {assignment.description}
                </p>
              )}
              <div className="flex items-center gap-4 text-xs text-gray-500">
                {dueDate && (
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    Due {format(dueDate, 'MMM d, yyyy')}
                  </span>
                )}
                {assignment.grade && (
                  <span className="flex items-center gap-1 text-green-600 font-medium">
                    <BarChart3 className="w-3 h-3" />
                    Grade: {assignment.grade}
                  </span>
                )}
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>
    </motion.div>
  );
}

function AssignmentStats({ assignments }) {
  const stats = {
    total: assignments.length,
    notStarted: assignments.filter(a => a.status === 'NotStarted').length,
    inProgress: assignments.filter(a => a.status === 'InProgress').length,
    submitted: assignments.filter(a => a.status === 'Submitted').length,
    graded: assignments.filter(a => a.status === 'Graded').length,
    overdue: assignments.filter(a => {
      const dueDate = a.due_date ? new Date(a.due_date) : null;
      return dueDate && isAfter(new Date(), dueDate) && a.status !== 'Graded';
    }).length
  };

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
      <Card>
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
          <div className="text-sm text-gray-600">Total</div>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-gray-500">{stats.notStarted}</div>
          <div className="text-sm text-gray-600">Not Started</div>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-blue-600">{stats.inProgress}</div>
          <div className="text-sm text-gray-600">In Progress</div>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-green-600">{stats.submitted}</div>
          <div className="text-sm text-gray-600">Submitted</div>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-purple-600">{stats.graded}</div>
          <div className="text-sm text-gray-600">Graded</div>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-red-600">{stats.overdue}</div>
          <div className="text-sm text-gray-600">Overdue</div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function TeacherAssignmentsPage() {
  const [assignments, setAssignments] = useState([]);
  const [courses, setCourses] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCourse, setSelectedCourse] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedTab, setSelectedTab] = useState('all');
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      if (!currentUser.google_classroom_connected) {
        setIsLoading(false);
        return;
      }

      // Load teacher's courses
      const teacherCourses = await Course.filter({ 
        teacher_id: currentUser.id,
        source_system: 'google_classroom'
      });
      setCourses(teacherCourses);

      // Load assignments for all courses
      const courseIds = teacherCourses.map(c => c.id);
      if (courseIds.length > 0) {
        const courseAssignments = await Assignment.filter({
          course_id: { $in: courseIds }
        }, '-due_date');
        setAssignments(courseAssignments);
      }

    } catch (error) {
      console.error('Error loading assignments:', error);
      toast({
        variant: "destructive",
        title: "Loading Error",
        description: "Could not load assignments. Please try again."
      });
    } finally {
      setIsLoading(false);
    }
  };

  const filteredAssignments = assignments.filter(assignment => {
    const matchesSearch = assignment.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         assignment.description?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCourse = selectedCourse === 'all' || assignment.course_id === selectedCourse;
    const matchesStatus = selectedStatus === 'all' || assignment.status === selectedStatus;
    
    let matchesTab = true;
    if (selectedTab === 'pending') {
      matchesTab = ['NotStarted', 'InProgress'].includes(assignment.status);
    } else if (selectedTab === 'completed') {
      matchesTab = ['Submitted', 'Graded'].includes(assignment.status);
    } else if (selectedTab === 'overdue') {
      const dueDate = assignment.due_date ? new Date(assignment.due_date) : null;
      matchesTab = dueDate && isAfter(new Date(), dueDate) && assignment.status !== 'Graded';
    }

    return matchesSearch && matchesCourse && matchesStatus && matchesTab;
  });

  const coursesMap = new Map(courses.map(c => [c.id, c]));

  if (isLoading) {
    return (
      <RoleGuard allowedRoles={['teacher', 'school_admin', 'district_admin', 'system_admin', 'admin']}>
        <div className="p-4 md:p-6">
          <DashboardSkeleton />
        </div>
      </RoleGuard>
    );
  }

  return (
    <RoleGuard allowedRoles={['teacher', 'school_admin', 'district_admin', 'system_admin', 'admin']}>
      <div className="max-w-7xl mx-auto p-6 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Assignments</h1>
            <p className="text-gray-600 mt-1">Manage assignments synced from Google Classroom</p>
          </div>
          <div className="flex gap-2">
            <Button asChild variant="outline">
              <Link to={createPageUrl('Integrations')}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Sync Now
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link to={createPageUrl('TeacherClasses')}>
                <BookOpen className="w-4 h-4 mr-2" />
                My Classes
              </Link>
            </Button>
          </div>
        </div>

        {!user?.google_classroom_connected ? (
          <Card>
            <CardContent className="p-8 text-center">
              <BookOpen className="w-16 h-16 mx-auto mb-4 text-gray-400" />
              <h3 className="text-xl font-semibold mb-2">Google Classroom Not Connected</h3>
              <p className="text-gray-600 mb-4">
                Connect your Google Classroom account to view and manage assignments.
              </p>
              <Button asChild>
                <Link to={createPageUrl('Integrations')}>
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Connect Google Classroom
                </Link>
              </Button>
            </CardContent>
          </Card>
        ) : assignments.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <FileText className="w-16 h-16 mx-auto mb-4 text-gray-400" />
              <h3 className="text-xl font-semibold mb-2">No Assignments Found</h3>
              <p className="text-gray-600 mb-4">
                No assignments have been synced yet. Try syncing your Google Classroom data.
              </p>
              <Button asChild variant="outline">
                <Link to={createPageUrl('Integrations')}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Sync Google Classroom
                </Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <>
            <AssignmentStats assignments={assignments} />

            <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="all">All ({assignments.length})</TabsTrigger>
                <TabsTrigger value="pending">
                  Pending ({assignments.filter(a => ['NotStarted', 'InProgress'].includes(a.status)).length})
                </TabsTrigger>
                <TabsTrigger value="completed">
                  Completed ({assignments.filter(a => ['Submitted', 'Graded'].includes(a.status)).length})
                </TabsTrigger>
                <TabsTrigger value="overdue">
                  Overdue ({assignments.filter(a => {
                    const dueDate = a.due_date ? new Date(a.due_date) : null;
                    return dueDate && isAfter(new Date(), dueDate) && a.status !== 'Graded';
                  }).length})
                </TabsTrigger>
              </TabsList>

              <div className="flex flex-col md:flex-row gap-4 mt-6 mb-6">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search assignments..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={selectedCourse} onValueChange={setSelectedCourse}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue placeholder="Filter by course" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Courses</SelectItem>
                    {courses.map((course) => (
                      <SelectItem key={course.id} value={course.id}>
                        {course.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="NotStarted">Not Started</SelectItem>
                    <SelectItem value="InProgress">In Progress</SelectItem>
                    <SelectItem value="Submitted">Submitted</SelectItem>
                    <SelectItem value="Graded">Graded</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <TabsContent value={selectedTab} className="space-y-4">
                {filteredAssignments.length === 0 ? (
                  <div className="text-center py-12">
                    <FileText className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">No assignments found</h3>
                    <p className="text-gray-600">
                      Try adjusting your filters or search terms.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredAssignments.map((assignment) => (
                      <AssignmentCard
                        key={assignment.id}
                        assignment={assignment}
                        course={coursesMap.get(assignment.course_id)}
                      />
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </>
        )}
      </div>
    </RoleGuard>
  );
}