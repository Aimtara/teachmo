import React, { useState, useEffect, useCallback } from 'react';
import { User, Child, SchoolParticipationRequest } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { 
  CheckCircle, 
  AlertCircle, 
  Clock, 
  Users, 
  BookOpen, 
  Calendar,
  Loader2,
  School,
  ExternalLink,
  Plus,
  RefreshCw,
  Unlink,
  Activity,
  BarChart3,
  CheckCheck
} from 'lucide-react';
import RequestSchoolModal from '../components/integration/RequestSchoolModal';
import { getSchoolIntegrationStatus } from '@/api/functions';
import { getGoogleAuthUrl } from '@/api/functions';
import { googleClassroomSync } from '@/api/functions';
import { handleGoogleDisconnect } from '@/api/functions';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { format } from 'date-fns';
import RoleGuard from '@/components/shared/RoleGuard';

export default function Integrations() {
  const [user, setUser] = useState(null);
  const [children, setChildren] = useState([]);
  const [schoolRequests, setSchoolRequests] = useState([]);
  const [selectedChild, setSelectedChild] = useState('');
  const [isCheckingSchool, setIsCheckingSchool] = useState(false);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [schoolModalData, setSchoolModalData] = useState({ name: '', domain: '' });
  const [isLoading, setIsLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isDisconnecting, setIsDisconnecting] = useState(false);
  const [syncHistory, setSyncHistory] = useState([]);
  const { toast } = useToast();

  const handleGoogleClassroomConnect = async () => {
    if (user?.role === 'parent') {
      // Parent flow - connect child's classroom
      if (!selectedChild) {
        toast({
          variant: "destructive",
          title: "Select a Child",
          description: "Please select which child's classroom you want to connect."
        });
        return;
      }

      const child = children.find(c => c.id === selectedChild);
      if (!child) return;

      setIsCheckingSchool(true);

      try {
        const { data } = await getSchoolIntegrationStatus({
          school_domain: child.school_domain,
          school_name: child.school_name
        });

        if (data.success && data.school && data.school.integration_enabled) {
          const { data: authData } = await getGoogleAuthUrl({
            child_id: selectedChild,
            school_domain: child.school_domain
          });

          if (authData.success) {
            window.location.href = authData.auth_url;
          } else {
            throw new Error(authData.error || 'Failed to get authorization URL');
          }
        } else {
          setSchoolModalData({
            name: child.school_name || '',
            domain: child.school_domain || ''
          });
          setShowRequestModal(true);
        }
      } catch (error) {
        console.error('Error connecting to Google Classroom:', error);
        toast({
          variant: "destructive",
          title: "Connection Failed",
          description: error.message || "Could not connect to Google Classroom."
        });
      } finally {
        setIsCheckingSchool(false);
      }
    } else {
      // Teacher flow - connect directly
      try {
        const { data: authData } = await getGoogleAuthUrl({
          teacher_user_id: user.id
        });

        if (authData.success) {
          window.location.href = authData.auth_url;
        } else {
          throw new Error(authData.error || 'Failed to get authorization URL');
        }
      } catch (error) {
        console.error('Error connecting to Google Classroom:', error);
        toast({
          variant: "destructive",
          title: "Connection Failed",
          description: error.message || "Could not connect to Google Classroom."
        });
      }
    }
  };

  const handleSync = useCallback(async () => {
    if (!user) return;
    setIsSyncing(true);
    
    const startTime = new Date().toISOString();
    toast({ 
      title: "Sync Started", 
      description: "Fetching your latest Google Classroom data..." 
    });
    
    try {
      const { data } = await googleClassroomSync({ teacher_user_id: user.id });
      if (data.success) {
        toast({ 
          title: "Sync Successful!", 
          description: data.message,
          duration: 5000
        });
        
        // Add to sync history
        setSyncHistory(prev => [{
          timestamp: startTime,
          status: 'success',
          message: data.message,
          details: data.details || {}
        }, ...prev.slice(0, 9)]); // Keep last 10 syncs
        
        const updatedUser = await User.me();
        setUser(updatedUser);
      } else {
        throw new Error(data.error);
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Sync Failed",
        description: error.message || "Could not sync your data. Please try again."
      });
      
      // Add failed sync to history
      setSyncHistory(prev => [{
        timestamp: startTime,
        status: 'error',
        message: error.message || 'Unknown error occurred',
        details: {}
      }, ...prev.slice(0, 9)]);
    } finally {
      setIsSyncing(false);
    }
  }, [user, toast]);

  const handleDisconnect = useCallback(async () => {
    setIsDisconnecting(true);
    try {
      const { data } = await handleGoogleDisconnect();
      if (data.success) {
        toast({ 
          title: "Disconnected", 
          description: "Successfully disconnected from Google Classroom." 
        });
        const updatedUser = await User.me();
        setUser(updatedUser);
        setSyncHistory([]); // Clear sync history
      } else {
        throw new Error(data.error);
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Disconnect Failed",
        description: error.message || "Could not disconnect. Please try again."
      });
    } finally {
      setIsDisconnecting(false);
    }
  }, [toast]);

  useEffect(() => {
    const loadData = async () => {
      try {
        const userData = await User.me();
        setUser(userData);

        if (userData.role === 'parent') {
          const childrenData = await Child.list('-created_date');
          setChildren(childrenData);
          
          const requests = await SchoolParticipationRequest.filter(
            { parent_id: userData.id },
            '-requested_at'
          );
          setSchoolRequests(requests);
        }

      } catch (error) {
        console.error('Error loading integration data:', error);
        toast({
          variant: "destructive",
          title: "Loading Error",
          description: "Could not load integration settings."
        });
      } finally {
        setIsLoading(false);
      }
    };

    loadData();

    // Check for success/error query params from OAuth redirect
    const queryParams = new URLSearchParams(window.location.search);
    if (queryParams.get('success') === 'google-classroom') {
      toast({
        title: "Google Classroom Connected!",
        description: "Your account is now linked. We'll start syncing your data.",
      });
      if (user?.role === 'teacher') {
        handleSync();
      }
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (queryParams.has('error')) {
      toast({
        variant: "destructive",
        title: "Connection Failed",
        description: queryParams.get('error') || "An unknown error occurred during Google authentication."
      });
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, [toast, handleSync, user?.role]);

  const getRequestStatusColor = (status) => {
    switch (status) {
      case 'new': return 'bg-blue-100 text-blue-800';
      case 'in_review': return 'bg-yellow-100 text-yellow-800';
      case 'added': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getRequestStatusIcon = (status) => {
    switch (status) {
      case 'new': return <Clock className="w-4 h-4" />;
      case 'in_review': return <AlertCircle className="w-4 h-4" />;
      case 'added': return <CheckCircle className="w-4 h-4" />;
      case 'rejected': return <AlertCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <RoleGuard allowedRoles={['parent', 'teacher', 'school_admin', 'district_admin', 'system_admin', 'admin']}>
      <div className="max-w-4xl mx-auto p-6 space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Integrations</h1>
          <p className="text-gray-600">
            {user?.role === 'parent' 
              ? "Connect Teachmo with your child's school systems to get a complete picture of their learning journey."
              : "Connect your teaching tools to streamline communication and track student progress."
            }
          </p>
        </div>

        {/* Google Classroom Integration */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <CardTitle>Google Classroom</CardTitle>
                <CardDescription>
                  {user?.role === 'parent' 
                    ? "Sync assignments, grades, and class updates directly from your child's classroom"
                    : "Sync your courses, assignments, and student data automatically"
                  }
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {user?.google_classroom_connected ? (
              <div className="space-y-4">
                <Alert variant="default" className="bg-green-50 border-green-200">
                  <CheckCircle className="h-4 w-4 text-green-600"/>
                  <AlertDescription className="text-green-800">
                    <div className="flex items-center justify-between">
                      <span>Google Classroom is connected!</span>
                      <Badge variant="outline" className="ml-2">
                        <Activity className="w-3 h-3 mr-1" />
                        Active
                      </Badge>
                    </div>
                  </AlertDescription>
                </Alert>
                
                {user.last_integration_sync && (
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-700">Last Sync</span>
                      <span className="text-sm text-gray-600">
                        {format(new Date(user.last_integration_sync), 'MMM d, yyyy h:mm a')}
                      </span>
                    </div>
                    {syncHistory.length > 0 && (
                      <div className="mt-3">
                        <details className="group">
                          <summary className="cursor-pointer text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1">
                            <BarChart3 className="w-3 h-3" />
                            View Sync History
                          </summary>
                          <div className="mt-2 space-y-2 max-h-32 overflow-y-auto">
                            {syncHistory.slice(0, 5).map((sync, index) => (
                              <div key={index} className="text-xs p-2 bg-white rounded border">
                                <div className="flex items-center justify-between">
                                  <span className={sync.status === 'success' ? 'text-green-600' : 'text-red-600'}>
                                    {sync.status === 'success' ? <CheckCheck className="w-3 h-3 inline mr-1" /> : <AlertCircle className="w-3 h-3 inline mr-1" />}
                                    {sync.status === 'success' ? 'Success' : 'Failed'}
                                  </span>
                                  <span className="text-gray-500">
                                    {format(new Date(sync.timestamp), 'MMM d, h:mm a')}
                                  </span>
                                </div>
                                <p className="text-gray-600 mt-1">{sync.message}</p>
                              </div>
                            ))}
                          </div>
                        </details>
                      </div>
                    )}
                  </div>
                )}
                
                <div className="flex flex-col sm:flex-row gap-2">
                  <Button onClick={handleSync} disabled={isSyncing} className="flex-1 sm:flex-none">
                    {isSyncing ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin"/>
                        Syncing...
                      </>
                    ) : (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2"/>
                        Sync Now
                      </>
                    )}
                  </Button>
                  <Button 
                    onClick={handleDisconnect} 
                    disabled={isDisconnecting} 
                    variant="destructive" 
                    className="flex-1 sm:flex-none"
                  >
                    {isDisconnecting ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin"/>
                        Disconnecting...
                      </>
                    ) : (
                      <>
                        <Unlink className="w-4 h-4 mr-2"/>
                        Disconnect
                      </>
                    )}
                  </Button>
                </div>
              </div>
            ) : (
              <>
                {user?.role === 'parent' && children.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Users className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>Add a child profile first to connect their classroom</p>
                    <Button variant="outline" className="mt-4" onClick={() => window.location.href = '/Dashboard'}>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Child Profile
                    </Button>
                  </div>
                ) : (
                  <>
                    {user?.role === 'parent' && (
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-gray-700">
                          Select Child to Connect
                        </label>
                        <Select value={selectedChild} onValueChange={setSelectedChild}>
                          <SelectTrigger>
                            <SelectValue placeholder="Choose which child's classroom to connect..." />
                          </SelectTrigger>
                          <SelectContent>
                            {children.map((child) => (
                              <SelectItem key={child.id} value={child.id}>
                                <div className="flex items-center gap-2">
                                  <span>{child.avatar}</span>
                                  <span>{child.name}</span>
                                  {child.school_name && (
                                    <span className="text-sm text-gray-500">
                                      • {child.school_name}
                                    </span>
                                  )}
                                  {child.onboarded && (
                                    <Badge variant="outline" className="text-xs">
                                      Linked Account
                                    </Badge>
                                  )}
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    <Button 
                      onClick={handleGoogleClassroomConnect}
                      disabled={user?.role === 'parent' ? (!selectedChild || isCheckingSchool) : isCheckingSchool}
                      className="w-full bg-blue-600 hover:bg-blue-700"
                    >
                      {isCheckingSchool ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          {user?.role === 'parent' ? 'Checking School...' : 'Connecting...'}
                        </>
                      ) : (
                        <>
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Connect Google Classroom
                        </>
                      )}
                    </Button>

                    <div className="text-xs text-gray-500 space-y-1">
                      {user?.role === 'parent' ? (
                        <>
                          <p>• All features work with both manual profiles and linked student accounts</p>
                          <p>• If your school isn't supported yet, we'll help you request integration</p>
                        </>
                      ) : (
                        <>
                          <p>• Sync your courses, assignments, and student submissions automatically</p>
                          <p>• Connect with parents through integrated messaging</p>
                        </>
                      )}
                    </div>
                  </>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* School Integration Requests - Only for Parents */}
        {user?.role === 'parent' && schoolRequests.length > 0 && (
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                  <School className="w-6 h-6 text-amber-600" />
                </div>
                <div>
                  <CardTitle>School Integration Requests</CardTitle>
                  <CardDescription>
                    Track the status of your school integration requests
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {schoolRequests.map((request) => (
                  <div 
                    key={request.id}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      {getRequestStatusIcon(request.status)}
                      <div>
                        <p className="font-medium">{request.school_name}</p>
                        <p className="text-sm text-gray-500">
                          Requested {new Date(request.requested_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <Badge className={getRequestStatusColor(request.status)}>
                      {request.status.replace('_', ' ')}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Request School Modal */}
        <RequestSchoolModal
          isOpen={showRequestModal}
          onClose={() => setShowRequestModal(false)}
          schoolName={schoolModalData.name}
          schoolDomain={schoolModalData.domain}
        />
      </div>
    </RoleGuard>
  );
}