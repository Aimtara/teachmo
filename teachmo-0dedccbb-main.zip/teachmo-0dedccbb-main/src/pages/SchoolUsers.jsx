
import React, { useState, useEffect, useMemo } from 'react';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Search, AlertCircle, Users, Edit } from 'lucide-react';
import { format } from 'date-fns';
import { useAdminPermissions } from '@/components/shared/AdminRoleGuard'; // Removed withAdminGuard import
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { RoleGuard } from '@/components/shared/RoleGuard'; // Added RoleGuard import

const SchoolUsersPage = ({ user: currentUser }) => {
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const navigate = useNavigate();
  const { getAccessibleUsers } = useAdminPermissions(currentUser);

  useEffect(() => {
    const fetchSchoolData = async () => {
      try {
        setIsLoading(true);
        if (!currentUser || !currentUser.school_id) { // Added null check for currentUser
          setError('You are not associated with a specific school or user data is missing.');
          return;
        }

        const allUsers = await User.filter({ school_id: currentUser.school_id }, '-created_date');
        const accessibleUsers = getAccessibleUsers(allUsers);
        setUsers(accessibleUsers);
      } catch (e) {
        setError('Failed to load school data. Please try again.');
        console.error(e);
      } finally {
        setIsLoading(false);
      }
    };

    if (currentUser) {
      fetchSchoolData();
    }
  }, [currentUser, getAccessibleUsers]);

  const filteredUsers = useMemo(() => {
    return users.filter(user =>
      (user.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
       user.email?.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [users, searchTerm]);
  
  const getRoleBadgeColor = (role) => {
    switch (role) {
      case 'school_admin': return 'bg-blue-100 text-blue-800';
      case 'teacher': return 'bg-green-100 text-green-800';
      case 'parent': return 'bg-gray-100 text-gray-800';
      case 'district_admin': return 'bg-purple-100 text-purple-800'; // Added for completeness given new roles
      case 'system_admin': return 'bg-red-100 text-red-800'; // Added for completeness
      case 'admin': return 'bg-indigo-100 text-indigo-800'; // Added for completeness
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleEditUser = (userId) => {
    navigate(createPageUrl(`AdminUserEdit?id=${userId}`));
  };

  if (error) {
    return (
      <div className="p-8">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-6 h-6" />
            School User Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <Input
                placeholder="Search users..."
                className="pl-9"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Last Login</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-4 w-40" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                      <TableCell><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                    </TableRow>
                  ))
                ) : filteredUsers.length > 0 ? (
                  filteredUsers.map(user => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div className="font-medium">{user.full_name || 'N/A'}</div>
                        <div className="text-sm text-gray-500">{user.email}</div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getRoleBadgeColor(user.role)}>
                          {user.role?.replace('_', ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {user.last_login_date ? format(new Date(user.last_login_date), 'MMM d, yyyy') : 'Never'}
                      </TableCell>
                      <TableCell className="text-right">
                              <Button
                                variant="outline"
                                size="sm" 
                                onClick={() => handleEditUser(user.id)}
                              >
                                <Edit className="w-4 h-4 mr-1" />
                                Edit
                              </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center h-24">
                      No users found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default function ProtectedSchoolUsers() {
  return (
    <RoleGuard allowedRoles={['school_admin', 'district_admin', 'system_admin', 'admin']}>
      <SchoolUsersPage />
    </RoleGuard>
  );
}
