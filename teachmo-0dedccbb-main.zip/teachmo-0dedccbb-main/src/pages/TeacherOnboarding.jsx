import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  BookOpen, 
  Users, 
  School, 
  CheckCircle, 
  ArrowRight, 
  MessageSquare,
  Calendar,
  BarChart3,
  Settings,
  Sparkles,
  User,
  Building
} from 'lucide-react';
import { User as UserEntity, SchoolDirectory } from '@/api/entities';
import SchoolAutoComplete from '@/components/onboarding/SchoolAutoComplete';
import { assignDefaultPermissions } from '@/api/functions';

const steps = [
  { 
    title: 'Welcome', 
    icon: User, 
    description: 'Get started with Teachmo'
  },
  { 
    title: 'School Info', 
    icon: School, 
    description: 'Connect to your school'
  },
  { 
    title: 'Teaching Details', 
    icon: BookOpen, 
    description: 'Tell us about your classes'
  },
  { 
    title: 'Communication', 
    icon: MessageSquare, 
    description: 'Set up parent communication'
  },
  { 
    title: 'Complete', 
    icon: CheckCircle, 
    description: 'Ready to go!'
  }
];

const gradeLevels = [
  'Pre-K', 'Kindergarten', '1st Grade', '2nd Grade', '3rd Grade', '4th Grade',
  '5th Grade', '6th Grade', '7th Grade', '8th Grade', '9th Grade', '10th Grade',
  '11th Grade', '12th Grade', 'Multiple Grades'
];

const subjects = [
  'Math', 'English/Language Arts', 'Science', 'Social Studies', 'Art', 'Music',
  'Physical Education', 'Foreign Language', 'Special Education', 'Library/Media',
  'Technology', 'Multiple Subjects'
];

export default function TeacherOnboarding() {
  const [currentStep, setCurrentStep] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [user, setUser] = useState(null);
  const [selectedSchool, setSelectedSchool] = useState(null);
  
  const [teacherData, setTeacherData] = useState({
    school_id: '',
    employee_id: '',
    grades_taught: [],
    subjects_taught: [],
    years_experience: '',
    classroom_number: '',
    communication_preferences: {
      email_enabled: true,
      in_app_messages: true,
      message_hours_start: '8:00',
      message_hours_end: '16:00',
      auto_reply_enabled: false,
      auto_reply_message: ''
    },
    class_management_style: '',
    parent_communication_frequency: 'weekly'
  });

  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    loadCurrentUser();
  }, []);

  const loadCurrentUser = async () => {
    try {
      const currentUser = await UserEntity.me();
      setUser(currentUser);
      
      // Pre-fill any existing data
      if (currentUser.school_id) {
        setTeacherData(prev => ({
          ...prev,
          school_id: currentUser.school_id,
          employee_id: currentUser.employee_id || ''
        }));
      }
    } catch (error) {
      console.error('Error loading user:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not load your profile. Please try refreshing the page."
      });
    }
  };

  const handleInputChange = (field, value) => {
    setTeacherData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleMultiSelect = (field, option) => {
    setTeacherData(prev => ({
      ...prev,
      [field]: prev[field].includes(option) 
        ? prev[field].filter(item => item !== option)
        : [...prev[field], option]
    }));
  };

  const handleCommunicationPrefChange = (field, value) => {
    setTeacherData(prev => ({
      ...prev,
      communication_preferences: {
        ...prev.communication_preferences,
        [field]: value
      }
    }));
  };

  const handleSchoolSelect = (school) => {
    setSelectedSchool(school);
    setTeacherData(prev => ({
      ...prev,
      school_id: school?.school_id || ''
    }));
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1: // School Info
        return teacherData.school_id && teacherData.employee_id;
      case 2: // Teaching Details
        return teacherData.grades_taught.length > 0 && 
               teacherData.subjects_taught.length > 0 && 
               teacherData.years_experience;
      case 3: // Communication
        return true; // All fields are optional or have defaults
      default:
        return true;
    }
  };

  const handleComplete = async () => {
    setIsSubmitting(true);
    try {
      // Update user profile with teacher data
      const updatedUserData = {
        school_id: teacherData.school_id,
        employee_id: teacherData.employee_id,
        onboarding_completed: true,
        onboarding_step: steps.length,
        // Store teacher-specific data in a structured way
        teaching_profile: {
          grades_taught: teacherData.grades_taught,
          subjects_taught: teacherData.subjects_taught,
          years_experience: parseInt(teacherData.years_experience),
          classroom_number: teacherData.classroom_number,
          class_management_style: teacherData.class_management_style,
          parent_communication_frequency: teacherData.parent_communication_frequency
        },
        notification_preferences: {
          ...user?.notification_preferences,
          teacher_settings: teacherData.communication_preferences
        }
      };

      await UserEntity.updateMyUserData(updatedUserData);

      // Assign default permissions for teacher role
      try {
        await assignDefaultPermissions({
          user_id: user.id,
          role: 'teacher'
        });
      } catch (permError) {
        console.warn('Could not assign default permissions:', permError);
        // Continue with onboarding completion
      }

      toast({
        title: "Welcome to Teachmo! 🎉",
        description: "Your teacher profile has been set up successfully."
      });

      // Move to final step
      setCurrentStep(steps.length - 1);

    } catch (error) {
      console.error('Error completing onboarding:', error);
      toast({
        variant: "destructive",
        title: "Setup Failed",
        description: "Could not complete your profile setup. Please try again."
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const navigateToDashboard = () => {
    navigate(createPageUrl('TeacherDashboard'));
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0: // Welcome
        return (
          <div className="text-center space-y-6">
            <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
              <BookOpen className="w-10 h-10 text-blue-600" />
            </div>
            
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                Welcome to Teachmo for Educators!
              </h2>
              <p className="text-gray-600 max-w-md mx-auto">
                Let's set up your teacher profile so you can connect with parents, 
                manage your classes, and enhance family engagement.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto">
              <div className="bg-green-50 p-3 rounded-lg">
                <MessageSquare className="w-6 h-6 text-green-600 mx-auto mb-2" />
                <p className="text-xs text-green-800 font-medium">Parent Communication</p>
              </div>
              <div className="bg-purple-50 p-3 rounded-lg">
                <Users className="w-6 h-6 text-purple-600 mx-auto mb-2" />
                <p className="text-xs text-purple-800 font-medium">Class Management</p>
              </div>
              <div className="bg-orange-50 p-3 rounded-lg">
                <BarChart3 className="w-6 h-6 text-orange-600 mx-auto mb-2" />
                <p className="text-xs text-orange-800 font-medium">Student Insights</p>
              </div>
              <div className="bg-blue-50 p-3 rounded-lg">
                <Calendar className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                <p className="text-xs text-blue-800 font-medium">Assignment Tracking</p>
              </div>
            </div>
          </div>
        );

      case 1: // School Info
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <School className="w-12 h-12 text-blue-600 mx-auto mb-3" />
              <h2 className="text-xl font-bold text-gray-900">Connect to Your School</h2>
              <p className="text-gray-600">
                This helps us link you with students and enable school-specific features.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="school">School *</Label>
                <SchoolAutoComplete
                  onSchoolSelect={handleSchoolSelect}
                  placeholder="Search for your school..."
                  className="w-full"
                />
                {selectedSchool && (
                  <div className="mt-2">
                    <Badge variant="outline" className="bg-green-50 text-green-700">
                      <Building className="w-3 h-3 mr-1" />
                      {selectedSchool.school_name}
                    </Badge>
                  </div>
                )}
              </div>

              <div>
                <Label htmlFor="employee_id">Employee/Staff ID *</Label>
                <Input
                  id="employee_id"
                  value={teacherData.employee_id}
                  onChange={(e) => handleInputChange('employee_id', e.target.value)}
                  placeholder="Your school employee ID"
                />
                <p className="text-xs text-gray-500 mt-1">
                  This helps verify your employment with the school
                </p>
              </div>
            </div>
          </div>
        );

      case 2: // Teaching Details
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <BookOpen className="w-12 h-12 text-purple-600 mx-auto mb-3" />
              <h2 className="text-xl font-bold text-gray-900">About Your Teaching</h2>
              <p className="text-gray-600">
                Tell us about the grades and subjects you teach.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <Label>Grades You Teach *</Label>
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {gradeLevels.map((grade) => (
                    <button
                      key={grade}
                      type="button"
                      onClick={() => handleMultiSelect('grades_taught', grade)}
                      className={`p-2 text-xs border rounded-lg transition-colors ${
                        teacherData.grades_taught.includes(grade)
                          ? 'bg-blue-100 border-blue-300 text-blue-800'
                          : 'border-gray-200 hover:bg-gray-50'
                      }`}
                    >
                      {grade}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <Label>Subjects You Teach *</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {subjects.map((subject) => (
                    <button
                      key={subject}
                      type="button"
                      onClick={() => handleMultiSelect('subjects_taught', subject)}
                      className={`p-2 text-xs border rounded-lg transition-colors text-left ${
                        teacherData.subjects_taught.includes(subject)
                          ? 'bg-purple-100 border-purple-300 text-purple-800'
                          : 'border-gray-200 hover:bg-gray-50'
                      }`}
                    >
                      {subject}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="years_experience">Years Teaching *</Label>
                  <Select 
                    value={teacherData.years_experience} 
                    onValueChange={(value) => handleInputChange('years_experience', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0">First year teacher</SelectItem>
                      <SelectItem value="1">1-2 years</SelectItem>
                      <SelectItem value="3">3-5 years</SelectItem>
                      <SelectItem value="6">6-10 years</SelectItem>
                      <SelectItem value="11">11-15 years</SelectItem>
                      <SelectItem value="16">16-20 years</SelectItem>
                      <SelectItem value="21">20+ years</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="classroom_number">Classroom/Room</Label>
                  <Input
                    id="classroom_number"
                    value={teacherData.classroom_number}
                    onChange={(e) => handleInputChange('classroom_number', e.target.value)}
                    placeholder="e.g., Room 205"
                  />
                </div>
              </div>
            </div>
          </div>
        );

      case 3: // Communication Preferences
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <MessageSquare className="w-12 h-12 text-green-600 mx-auto mb-3" />
              <h2 className="text-xl font-bold text-gray-900">Communication Settings</h2>
              <p className="text-gray-600">
                Set your preferences for how parents can reach you.
              </p>
            </div>

            <div className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="email_enabled"
                    checked={teacherData.communication_preferences.email_enabled}
                    onCheckedChange={(checked) => 
                      handleCommunicationPrefChange('email_enabled', checked)
                    }
                  />
                  <Label htmlFor="email_enabled">Allow email notifications</Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="in_app_messages"
                    checked={teacherData.communication_preferences.in_app_messages}
                    onCheckedChange={(checked) => 
                      handleCommunicationPrefChange('in_app_messages', checked)
                    }
                  />
                  <Label htmlFor="in_app_messages">Accept in-app messages from parents</Label>
                </div>
              </div>

              <div>
                <Label>Preferred Communication Hours</Label>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  <div>
                    <Label htmlFor="message_hours_start" className="text-xs">From</Label>
                    <Input
                      id="message_hours_start"
                      type="time"
                      value={teacherData.communication_preferences.message_hours_start}
                      onChange={(e) => handleCommunicationPrefChange('message_hours_start', e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="message_hours_end" className="text-xs">To</Label>
                    <Input
                      id="message_hours_end"
                      type="time"
                      value={teacherData.communication_preferences.message_hours_end}
                      onChange={(e) => handleCommunicationPrefChange('message_hours_end', e.target.value)}
                    />
                  </div>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Parents will see when you're available for messages
                </p>
              </div>

              <div>
                <Label htmlFor="parent_communication_frequency">
                  How often do you typically communicate with parents?
                </Label>
                <Select 
                  value={teacherData.parent_communication_frequency} 
                  onValueChange={(value) => handleInputChange('parent_communication_frequency', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select frequency..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily updates</SelectItem>
                    <SelectItem value="weekly">Weekly summaries</SelectItem>
                    <SelectItem value="biweekly">Every two weeks</SelectItem>
                    <SelectItem value="monthly">Monthly reports</SelectItem>
                    <SelectItem value="as_needed">As needed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        );

      case 4: // Complete
        return (
          <div className="text-center space-y-6">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                You're All Set! 🎉
              </h2>
              <p className="text-gray-600 max-w-md mx-auto">
                Your Teachmo profile is ready. You can now connect with parents, 
                manage your classes, and track student progress.
              </p>
            </div>

            <div className="bg-blue-50 rounded-lg p-4 max-w-md mx-auto">
              <h3 className="font-semibold text-blue-900 mb-2">What's Next?</h3>
              <ul className="text-sm text-blue-800 space-y-1 text-left">
                <li>✓ Connect with Google Classroom (optional)</li>
                <li>✓ Start messaging with parents</li>
                <li>✓ Set up your class announcements</li>
                <li>✓ Track student engagement</li>
              </ul>
            </div>

            <Button onClick={navigateToDashboard} size="lg">
              Go to Dashboard
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        );

      default:
        return null;
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-2xl mx-auto">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            {steps.map((step, index) => {
              const StepIcon = step.icon;
              const isActive = index === currentStep;
              const isCompleted = index < currentStep;
              
              return (
                <div
                  key={index}
                  className={`flex items-center justify-center w-10 h-10 rounded-full border-2 transition-colors ${
                    isActive
                      ? 'border-blue-600 bg-blue-600 text-white'
                      : isCompleted
                      ? 'border-green-600 bg-green-600 text-white'
                      : 'border-gray-300 bg-white text-gray-400'
                  }`}
                >
                  <StepIcon className="w-5 h-5" />
                </div>
              );
            })}
          </div>
          
          <div className="bg-gray-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(currentStep / (steps.length - 1)) * 100}%` }}
            />
          </div>
          
          <div className="text-center mt-2">
            <h1 className="text-lg font-semibold text-gray-900">
              {steps[currentStep].title}
            </h1>
            <p className="text-sm text-gray-600">
              Step {currentStep + 1} of {steps.length}
            </p>
          </div>
        </div>

        {/* Step Content */}
        <Card className="border-0 shadow-xl">
          <CardContent className="p-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ x: 20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -20, opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                {renderStepContent()}
              </motion.div>
            </AnimatePresence>

            {/* Navigation Buttons */}
            {currentStep < steps.length - 1 && (
              <div className="flex justify-between mt-8 pt-6 border-t">
                {currentStep > 0 && (
                  <Button variant="outline" onClick={prevStep}>
                    Back
                  </Button>
                )}
                
                <Button
                  onClick={currentStep === steps.length - 2 ? handleComplete : nextStep}
                  disabled={!canProceed() || isSubmitting}
                  className={currentStep === 0 ? 'ml-auto' : ''}
                >
                  {isSubmitting ? (
                    'Setting up...'
                  ) : currentStep === steps.length - 2 ? (
                    'Complete Setup'
                  ) : (
                    'Continue'
                  )}
                  {!isSubmitting && <ArrowRight className="w-4 h-4 ml-2" />}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}