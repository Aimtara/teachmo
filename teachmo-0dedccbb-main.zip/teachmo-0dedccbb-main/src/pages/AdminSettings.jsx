
import React, { useState, useEffect } from 'react';
import { District, School } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertCircle, Save } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from '@/components/ui/badge'; // Added import
import { format } from 'date-fns'; // Added import

export default function AdminSettings() {
  const [district, setDistrict] = useState(null);
  const [schools, setSchools] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [activeSchool, setActiveSchool] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Assuming the admin is tied to one district.
        // In a real multi-district app, you'd get the admin's district ID.
        const districtsData = await District.list();
        if (districtsData.length > 0) {
          const mainDistrict = districtsData[0];
          setDistrict(mainDistrict);
          
          const schoolsData = await School.filter({ district_id: mainDistrict.id });
          setSchools(schoolsData);
          if (schoolsData.length > 0) {
            setActiveSchool(schoolsData[0]);
          }
        }
      } catch (e) {
        setError('Failed to load settings data.');
        console.error(e);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleDistrictSave = async () => {
    setIsSaving(true);
    try {
      await District.update(district.id, district);
      alert('District settings saved successfully!');
    } catch (e) {
      setError('Failed to save district settings.');
      console.error(e);
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleSchoolSave = async () => {
    setIsSaving(true);
    try {
      await School.update(activeSchool.id, activeSchool);
      alert('School settings saved successfully!');
    } catch (e) {
      setError('Failed to save school settings.');
      console.error(e);
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return <SettingsSkeleton />;
  }
  
  if (error) {
    return (
      <div className="p-8">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      </div>
    );
  }
  
  if (!district) {
     return (
       <div className="p-8">
         <Alert>
           <AlertCircle className="h-4 w-4" />
           <AlertTitle>No District Found</AlertTitle>
           <AlertDescription>
             No district has been configured for this account. Please contact support.
           </AlertDescription>
         </Alert>
       </div>
     );
  }

  return (
    <div className="min-h-screen p-4 md:p-8 space-y-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <header>
        <h1 className="text-3xl font-bold text-gray-900">System Settings</h1>
        <p className="text-gray-600">Manage district, school, and feature settings.</p>
      </header>

      <Tabs defaultValue="district" className="w-full">
        <TabsList>
          <TabsTrigger value="district">District Settings</TabsTrigger>
          <TabsTrigger value="schools">School Settings</TabsTrigger>
          <TabsTrigger value="subscription">Subscription</TabsTrigger>
          <TabsTrigger value="features">Feature Flags</TabsTrigger>
        </TabsList>

        <TabsContent value="district" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>District Profile</CardTitle>
              <CardDescription>Update your district's primary information.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="districtName" className="font-medium">District Name</label>
                  <Input id="districtName" value={district.name} onChange={(e) => setDistrict({...district, name: e.target.value})} />
                </div>
                <div>
                  <label htmlFor="districtState" className="font-medium">State</label>
                  <Input id="districtState" value={district.state} onChange={(e) => setDistrict({...district, state: e.target.value})} />
                </div>
                <div>
                  <label htmlFor="districtWebsite" className="font-medium">Website</label>
                  <Input id="districtWebsite" value={district.website} onChange={(e) => setDistrict({...district, website: e.target.value})} />
                </div>
                <div>
                  <label htmlFor="districtEmail" className="font-medium">Contact Email</label>
                  <Input id="districtEmail" type="email" value={district.contact_email} onChange={(e) => setDistrict({...district, contact_email: e.target.value})} />
                </div>
              </div>
              <Button onClick={handleDistrictSave} disabled={isSaving}>
                <Save className="mr-2 h-4 w-4" />
                {isSaving ? 'Saving...' : 'Save District Settings'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="schools" className="mt-4">
            <div className="flex gap-6">
                <div className="w-1/4">
                    <h3 className="font-semibold mb-2">Schools</h3>
                    <div className="space-y-2">
                        {schools.map(school => (
                            <div key={school.id} onClick={() => setActiveSchool(school)}
                                className={`p-3 rounded-lg cursor-pointer ${activeSchool?.id === school.id ? 'bg-blue-100 font-bold' : 'hover:bg-gray-100'}`}>
                                {school.name}
                            </div>
                        ))}
                    </div>
                </div>
                <div className="w-3/4">
                   {activeSchool && (
                        <Card>
                            <CardHeader>
                                <CardTitle>{activeSchool.name}</CardTitle>
                                <CardDescription>Manage settings for this school.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div>
                                    <label htmlFor="schoolName" className="font-medium">School Name</label>
                                    <Input id="schoolName" value={activeSchool.name} onChange={(e) => setActiveSchool({...activeSchool, name: e.target.value})} />
                                </div>
                                <div>
                                    <label htmlFor="schoolAddress" className="font-medium">Address</label>
                                    <Textarea id="schoolAddress" value={activeSchool.address} onChange={(e) => setActiveSchool({...activeSchool, address: e.target.value})} />
                                </div>
                                <Button onClick={handleSchoolSave} disabled={isSaving}>
                                    <Save className="mr-2 h-4 w-4" />
                                    {isSaving ? 'Saving...' : 'Save School Settings'}
                                </Button>
                            </CardContent>
                        </Card>
                   )}
                </div>
            </div>
        </TabsContent>

        <TabsContent value="subscription" className="mt-4">
            <Card>
                <CardHeader>
                    <CardTitle>Subscription Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                    <p><strong>Tier:</strong> <Badge>{district.subscription_tier}</Badge></p>
                    <p><strong>Status:</strong> <Badge variant={district.is_active ? 'default' : 'destructive'}>{district.is_active ? 'Active' : 'Inactive'}</Badge></p>
                    <p><strong>Subscription Period:</strong> {format(new Date(district.subscription_start_date), 'PP')} - {format(new Date(district.subscription_end_date), 'PP')}</p>
                    <Button variant="outline">Contact Support to Change Plan</Button>
                </CardContent>
            </Card>
        </TabsContent>
        
        <TabsContent value="features" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Feature Flags</CardTitle>
              <CardDescription>Enable or disable features for your entire district.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-3 rounded-lg border">
                <div>
                  <h4 className="font-medium">Parent-Teacher Messaging</h4>
                  <p className="text-sm text-gray-600">Allow parents and teachers to communicate directly.</p>
                </div>
                <Switch 
                  checked={district.settings?.enable_parent_teacher_messaging ?? true}
                  onCheckedChange={(checked) => setDistrict({...district, settings: {...district.settings, enable_parent_teacher_messaging: checked }})}
                />
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg border">
                <div>
                  <h4 className="font-medium">SSO / Google Workspace Login</h4>
                   <p className="text-sm text-gray-600">Allow users to sign in with their district Google accounts.</p>
                </div>
                <Switch 
                  checked={district.settings?.sso_enabled ?? false}
                  onCheckedChange={(checked) => setDistrict({...district, settings: {...district.settings, sso_enabled: checked }})}
                 />
              </div>
               <Button onClick={handleDistrictSave} disabled={isSaving}>
                <Save className="mr-2 h-4 w-4" />
                {isSaving ? 'Saving...' : 'Save Feature Settings'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}


const SettingsSkeleton = () => (
    <div className="p-8 space-y-6">
        <Skeleton className="h-9 w-64 mb-2" />
        <Skeleton className="h-5 w-80 mb-6" />
        <div className="flex gap-4 border-b pb-2">
            <Skeleton className="h-8 w-24" />
            <Skeleton className="h-8 w-24" />
            <Skeleton className="h-8 w-24" />
        </div>
        <Card>
            <CardHeader>
                <Skeleton className="h-7 w-48 mb-2" />
                <Skeleton className="h-5 w-72" />
            </CardHeader>
            <CardContent className="space-y-4">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-32" />
            </CardContent>
        </Card>
    </div>
);
