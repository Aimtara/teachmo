
import React, { useState, useEffect, useCallback } from "react";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User, Child, Activity, ParentingTip, Achievement, UserAchievement, JournalEntry, Assignment, StudentParentLink } from "@/api/entities";
import { Loader2, Plus, Target, TrendingUp, Calendar, Users, BookOpen, Sparkles, ArrowRight, CheckCircle, Clock, Bot, AlertCircle, RefreshCw, MessageSquare, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format, isToday, startOfWeek, endOfWeek, parseISO, isYesterday } from "date-fns";
import { motion } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";

import EmotionalCheckIn from "../components/dashboard/EmotionalCheckIn";
import { usePremium } from "../components/shared/usePremium";
import QuickChildSetup from "../components/dashboard/QuickChildSetup";
import { DashboardSkeleton } from "../components/shared/ImprovedSkeletons";
import { SkipLink } from "../components/shared/SkipLink";
import { useAccessibility } from "../components/shared/AccessibilityProvider";
import QuickTips from "../components/tour/QuickTips";
import ProgressCelebration from "../components/tour/ProgressCelebration";
import { fetchWithRetry, retryAuthCall, checkNetworkStatus, withGracefulDegradation } from "@/components/shared/apiUtils";
import { useToast } from "@/components/ui/use-toast";
import TodaysFocus from "../components/dashboard/TodaysFocus";
import QuickActionBar from "../components/dashboard/QuickActionBar";
import OffersCarousel from "../components/offers/OffersCarousel";
import PersonalizedInsights from "../components/dashboard/PersonalizedInsights";
import PersonalizedDashboard from "../components/dashboard/PersonalizedDashboard";

import { useApi, useEntityCrud } from '@/components/hooks/useApi';
import { useEntityData } from '@/components/hooks/useEntityData';
import { ProgressiveLoader, EmptyState, NetworkStatus } from '@/components/shared/LoadingStates';
import { ApiProvider } from '@/components/shared/ApiProvider';

export default function Dashboard() {
  // Enhanced API hooks with better error handling and rate limit management
  const [user, setUser] = useState(null);
  const [children, setChildren] = useState([]);
  const [activities, setActivities] = useState([]);
  const [tips, setTips] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [retryCount, setRetryCount] = useState(0);
  const [loadingStep, setLoadingStep] = useState('user');

  const [showCelebration, setShowCelebration] = useState(false);
  const [celebrationData, setCelebrationData] = useState(null);
  const [networkStatus, setNetworkStatus] = useState(checkNetworkStatus());
  const [weeklyStats, setWeeklyStats] = useState({
    activitiesCompleted: 0,
    activitiesPlanned: 0,
    streak: 0,
    tipProgress: 0,
    totalTips: 0
  });

  const { isPremium } = usePremium();
  const { announceToScreenReader } = useAccessibility();
  const { toast } = useToast();

  // Network status monitoring
  useEffect(() => {
    const handleOnline = () => {
      const newStatus = checkNetworkStatus();
      setNetworkStatus(newStatus);
      if (newStatus.online && error) { // Only attempt reload if there was a previous error
        announceToScreenReader("Connection restored. Reloading data.");
        loadDashboardData();
      }
    };

    const handleOffline = () => {
      const newStatus = checkNetworkStatus();
      setNetworkStatus(newStatus);
      announceToScreenReader("Connection lost. Some features may not work properly.");
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [announceToScreenReader, error]);

  // Enhanced dashboard data loading with sequential loading to avoid rate limits
  const loadDashboardData = useCallback(async () => {
    setIsLoading(true);
    setError(null); // Clear previous errors
    
    try {
      // Step 1: Load user data first
      setLoadingStep('user');
      const userData = await withGracefulDegradation(
        () => retryAuthCall(() => User.me()),
        null
      );
      
      if (!userData) {
        throw new Error('Unable to load user profile');
      }
      
      setUser(userData);

      // --- Login Streak Calculation Logic ---
      if (userData) {
        const today = new Date();
        const lastLogin = userData.last_login_date ? parseISO(userData.last_login_date) : null;
        let newStreak = userData.login_streak || 0;
        let needsUpdate = false;

        if (!lastLogin) {
          newStreak = 1;
          needsUpdate = true;
        } else if (!isToday(lastLogin)) {
          if (isYesterday(lastLogin)) {
            newStreak++;
          } else {
            newStreak = 1;
          }
          needsUpdate = true;
        }

        if (needsUpdate) {
          try {
            await User.updateMyUserData({
              login_streak: newStreak,
              last_login_date: today.toISOString()
            });
            // Update the local userData object to reflect changes immediately
            userData.login_streak = newStreak;
            userData.last_login_date = today.toISOString();
            setUser(userData);
          } catch (updateError) {
            console.error("Failed to update user streak:", updateError);
          }
        }
      }

      // Add delays between API calls to avoid rate limiting
      const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

      // Step 2: Load children data with delay
      setLoadingStep('children');
      await delay(500);
      const childrenResult = await withGracefulDegradation(() => Child.list(), []);
      setChildren(childrenResult);

      // Step 3: Load activities data with delay
      setLoadingStep('activities');
      await delay(500);
      const activitiesResult = await withGracefulDegradation(
        () => Activity.filter({ status: { $ne: 'completed' } }, '-created_date', 10), 
        []
      );
      setActivities(activitiesResult);

      // Step 4: Load tips data with delay
      setLoadingStep('tips');
      await delay(500);
      const tipsResult = await withGracefulDegradation(() => ParentingTip.list('-created_date', 5), []);
      setTips(tipsResult);

      // Calculate weekly stats AFTER data is loaded
      const weekStart = startOfWeek(new Date());
      const weekEnd = endOfWeek(new Date());
      
      const weeklyActivities = activitiesResult.filter(a => 
        a.completion_date && 
        new Date(a.completion_date) >= weekStart && 
        new Date(a.completion_date) <= weekEnd
      );

      setWeeklyStats({
        activitiesCompleted: weeklyActivities.filter(a => a.status === 'completed').length,
        activitiesPlanned: activitiesResult.filter(a => a.status === 'planned').length,
        streak: userData?.login_streak || 0,
        tipProgress: tipsResult.filter(t => t.is_read).length,
        totalTips: tipsResult.length
      });

      // Reset retry count on successful load
      setRetryCount(0);
      announceToScreenReader("Dashboard loaded successfully.");

    } catch (err) {
      console.error('Dashboard data load failed:', err);
      setRetryCount(prev => prev + 1);
      
      // Handle different types of errors
      if (err.message?.includes('429') || err.response?.status === 429) {
        setError({
          type: 'rate_limit',
          message: `We're experiencing high demand right now. Please wait a moment and try again.`,
          canRetry: true
        });
        toast({
          variant: "destructive",
          title: "Rate Limit Exceeded",
          description: "Please wait a moment and try again."
        });
      } else if (!networkStatus.online) {
        setError({
          type: 'network',
          message: 'You appear to be offline. Please check your internet connection.',
          canRetry: true
        });
        toast({
          variant: "destructive",
          title: "You're Offline",
          description: "Please check your internet connection and try again.",
        });
      } else if (retryCount < 2) {
        setError({
          type: 'loading',
          message: 'Having trouble loading your dashboard. Retrying...',
          canRetry: true
        });
        toast({
          variant: "destructive",
          title: "Loading Error",
          description: "Having trouble loading your data. Retrying...",
        });
        // Auto-retry after a delay
        setTimeout(() => loadDashboardData(), 3000);
      } else {
        setError({
          type: 'general',
          message: 'Unable to load your dashboard. Please refresh the page or try again later.',
          canRetry: true
        });
        toast({
          variant: "destructive",
          title: "Connection Problem",
          description: "Unable to load your dashboard. Please refresh the page or try again later.",
        });
      }
    } finally {
      setIsLoading(false);
      setLoadingStep(''); // Clear loading step
    }
  }, [networkStatus.online, retryCount, announceToScreenReader, toast]);

  // Initial load
  useEffect(() => {
    loadDashboardData();
  }, [loadDashboardData]);

  // Check for achievements when data loads or relevant data changes
  useEffect(() => {
    if (!user || isLoading) return;

    const userAchievements = user.tutorial_progress?.achievements || [];

    // Check for first activity completion
    if (activities.some(a => a.status === 'completed') && 
        !userAchievements.includes('first_activity')) {
      triggerAchievement('first_activity');
    }

    // Check for activity streak
    if (weeklyStats.activitiesCompleted >= 3 && 
        !userAchievements.includes('activity_streak_3')) {
      triggerAchievement('activity_streak_3');
    }
  }, [user, activities, weeklyStats.activitiesCompleted, isLoading]);

  const triggerAchievement = async (achievementType) => {
    try {
      const currentAchievements = user.tutorial_progress?.achievements || [];
      if (currentAchievements.includes(achievementType)) return;

      const updatedTutorialProgress = {
        ...(user.tutorial_progress || {}),
        achievements: [...currentAchievements, achievementType]
      };

      await User.updateMyUserData({
        tutorial_progress: updatedTutorialProgress
      });
      
      setUser(prev => ({
        ...prev,
        tutorial_progress: updatedTutorialProgress
      }));

      setCelebrationData({ type: achievementType });
      setShowCelebration(true);
      
      toast({
        title: "🎉 Achievement Unlocked!",
        description: `You've earned the "${achievementType.replace(/_/g, ' ')}" badge.`,
      });

      announceToScreenReader(`Achievement unlocked: ${achievementType.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}`);
    } catch (error) {
      console.error('Error saving achievement:', error);
      toast({
        variant: "destructive",
        title: "Oh no!",
        description: "There was a problem saving your achievement.",
      });
      announceToScreenReader("Failed to unlock achievement.");
    }
  };

  const handleMoodUpdate = async (newMood) => {
    try {
      await User.updateMyUserData({
        current_mood: newMood,
        last_mood_checkin: new Date().toISOString()
      });
      
      setUser(prev => ({
        ...prev,
        current_mood: newMood,
        last_mood_checkin: new Date().toISOString()
      }));

      announceToScreenReader(`Mood updated to ${newMood}`);
    } catch (error) {
      announceToScreenReader("Failed to update mood");
      toast({
        variant: "destructive",
        title: "Mood Update Failed",
        description: "Could not update your mood. Please try again.",
      });
    }
  };

  const handleChildAdded = async () => {
    // Reload children data only
    try {
      const childrenResult = await withGracefulDegradation(() => Child.list(), []);
      setChildren(childrenResult);
      toast({
        title: "Child Added!",
        description: "Your child's profile has been successfully added.",
      });
    } catch (error) {
      console.error('Failed to reload children:', error);
      toast({
        variant: "destructive",
        title: "Error reloading children",
        description: "Could not refresh child list. Please try reloading the page.",
      });
    }
  };

  // Calculate derived state
  const hasChildren = children.length > 0;
  const hasPlannedActivities = activities.some(a => a.status === 'planned');
  
  // Loading states with better user feedback
  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="max-w-7xl mx-auto">
          <DashboardSkeleton />
          {loadingStep && (
            <div className="fixed bottom-4 right-4 bg-white rounded-lg shadow-lg p-3 flex items-center gap-2 z-50 border shadow-md">
              <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
              <span className="text-sm text-gray-700">
                Loading {loadingStep === 'user' ? 'profile' : 
                        loadingStep === 'children' ? 'children' : 
                        loadingStep === 'activities' ? 'activities' :
                        loadingStep === 'tips' ? 'tips' : 'data'}...
              </span>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Error states
  if (error) {
    return (
      <div className="min-h-screen p-4 md:p-6 flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <Alert className={`max-w-md ${error.type === 'rate_limit' ? 'border-yellow-300 bg-yellow-50' : 'border-red-300 bg-red-50'}`}>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="space-y-3">
            <p>{error.message}</p>
            {error.canRetry && (
              <Button onClick={loadDashboardData} variant="outline" className="w-full">
                <RefreshCw className="w-4 h-4 mr-2" />
                {error.type === 'rate_limit' ? 'Try Again' : 'Retry Loading'}
              </Button>
            )}
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <ApiProvider>
      <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <SkipLink />
        
        {/* Enhanced Network Status */}
        {!networkStatus.online && (
          <Alert className="mb-4 border-yellow-300 bg-yellow-50">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              You're currently offline. Some features may not work properly.
            </AlertDescription>
          </Alert>
        )}
        
        {/* Quick Tips for contextual help */}
        <QuickTips currentPage="Dashboard" />
        
        {/* Achievement Celebration */}
        <ProgressCelebration
          achievement={celebrationData}
          show={showCelebration}
          onClose={() => setShowCelebration(false)}
        />

        <main id="main-content" className="max-w-7xl mx-auto space-y-6">
          {/* SIMPLIFIED HEADER */}
          <header className="mb-6">
            <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">
              {new Date().getHours() < 12 ? 'Good morning' : new Date().getHours() < 17 ? 'Good afternoon' : 'Good evening'}, {user?.full_name?.split(' ')[0] || 'Parent'}! 
            </h1>
            {weeklyStats.streak > 0 && (
              <div className="flex items-center gap-2 text-orange-600 font-medium" aria-label={`${weeklyStats.streak} day login streak`}>
                <span role="img" aria-label="Fire emoji">🔥</span> 
                <span>{weeklyStats.streak} day streak</span>
              </div>
            )}
          </header>

          {/* CHILD SETUP - Only show if no children */}
          {!hasChildren && (
            <div data-tour="add-child">
              <QuickChildSetup onChildAdded={handleChildAdded} />
            </div>
          )}

          {/* Main Dashboard Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Main Content Column */}
            <div className="lg:col-span-8 space-y-8">
              {/* TODAY'S FOCUS */}
              {hasChildren && (
                <div data-tour="todays-focus">
                  <TodaysFocus
                    user={user}
                    activities={activities}
                    schoolAssignments={[]}
                    messages={[]}
                    onUpdate={loadDashboardData}
                  />
                </div>
              )}

              {/* QUICK ACTION BAR */}
              <QuickActionBar 
                user={user}
                children={children}
                hasChildren={hasChildren}
                hasPlannedActivities={hasPlannedActivities}
                hasPremium={isPremium}
              />

              {/* EMOTIONAL CHECK-IN */}
              <div data-tour="emotional-check-in">
                <EmotionalCheckIn user={user} onMoodUpdate={handleMoodUpdate} />
              </div>

              {/* AD/OFFER CAROUSEL */}
              <OffersCarousel />

              {/* PERSONALIZED INSIGHTS */}
              {hasChildren && (
                <PersonalizedInsights 
                  user={user}
                  children={children} 
                  activities={activities} 
                  assignments={[]}
                  schoolAssignments={[]}
                  tips={tips}
                  onUpdate={loadDashboardData}
                />
              )}
            </div>

            {/* Right Sidebar Column */}
            <div className="lg:col-span-4 space-y-8">
              {/* PARENTING TIP CARD */}
              {tips.length > 0 && (
                <Card className="shadow-lg" data-tour="parenting-tip">
                  <CardHeader>
                    <CardTitle className="text-xl flex items-center justify-between">
                      <span>Parenting Tip of the Day</span>
                      <BookOpen className="w-5 h-5 text-purple-600" />
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 mb-4">{tips[0].title}</p>
                    <Link to={createPageUrl("Tips")}>
                      <Button variant="outline" className="w-full">
                        View All Tips <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                    {!isPremium && (
                      <div className="mt-4 text-center text-sm text-gray-500">
                        Unlock more personalized tips with <Link to={createPageUrl("Premium")} className="text-purple-600 font-semibold hover:underline">Premium</Link>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* WEEKLY STATS CARD */}
              <Card className="shadow-lg" data-tour="weekly-stats">
                <CardHeader>
                  <CardTitle className="text-xl flex items-center justify-between">
                    <span>Your Weekly Progress</span>
                    <TrendingUp className="w-5 h-5 text-green-600" />
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Activities Completed:</span>
                    <Badge variant="secondary" className="bg-green-100 text-green-700 text-base py-1 px-3">
                      {weeklyStats.activitiesCompleted}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Planned Activities:</span>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700 text-base py-1 px-3">
                      {weeklyStats.activitiesPlanned}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Login Streak:</span>
                    <Badge variant="secondary" className="bg-orange-100 text-orange-700 text-base py-1 px-3">
                      {weeklyStats.streak} Days 🔥
                    </Badge>
                  </div>
                  {weeklyStats.totalTips > 0 && (
                    <div>
                      <div className="flex items-center justify-between text-gray-700 mb-2">
                        <span>Tips Read:</span>
                        <span>{weeklyStats.tipProgress}/{weeklyStats.totalTips}</span>
                      </div>
                      <Progress value={(weeklyStats.tipProgress / weeklyStats.totalTips) * 100} className="h-2" />
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* CHILD CARDS */}
              {hasChildren && (
                <Card className="shadow-lg" data-tour="child-overview">
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-xl">Your Children</CardTitle>
                    <Link to={createPageUrl("Children")}>
                      <Button variant="ghost" size="sm">
                        Manage All
                      </Button>
                    </Link>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {children.slice(0, 3).map(child => (
                        <div key={child.id} className="flex items-center justify-between py-2 border-b last:border-b-0">
                          <div className="flex items-center gap-3">
                            <span className="text-2xl" role="img" aria-label="Child avatar">{child.avatar || '👶'}</span>
                            <div>
                              <p className="font-semibold text-gray-800">{child.name}</p>
                              <p className="text-sm text-gray-500">{child.age} years old</p>
                            </div>
                          </div>
                          <Link to={createPageUrl("ChildProfile", { childId: child.id })}>
                            <Button variant="outline" size="sm">View</Button>
                          </Link>
                        </div>
                      ))}
                      {children.length > 3 && (
                        <div className="text-center pt-2">
                          <Link to={createPageUrl("Children")} className="text-blue-600 hover:underline text-sm">
                            View {children.length - 3} more children
                          </Link>
                        </div>
                      )}
                      <Link to={createPageUrl("ChildSetup")}>
                        <Button variant="ghost" className="w-full mt-2 border border-dashed">
                          <Plus className="mr-2 h-4 w-4" /> Add New Child
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          {/* PERSONALIZED DASHBOARD */}
          {hasChildren && (
            <PersonalizedDashboard
              user={user}
              children={children}
              activities={activities}
              schoolAssignments={[]}
              weeklyStats={weeklyStats}
              onMoodUpdate={handleMoodUpdate}
              tips={tips}
              isPremium={isPremium}
            />
          )}

          {/* Empty state for no children */}
          {!hasChildren && !isLoading && (
            <EmptyState
              title="Welcome to Teachmo!"
              description="Get started by adding your first child profile to receive personalized activities and parenting guidance."
              action={
                <Link to={createPageUrl("ChildSetup")}>
                  <Button size="lg" className="mt-4">
                    <Plus className="w-5 h-5 mr-2" />
                    Add Your First Child
                  </Button>
                </Link>
              }
            />
          )}
        </main>
      </div>
    </ApiProvider>
  );
}
