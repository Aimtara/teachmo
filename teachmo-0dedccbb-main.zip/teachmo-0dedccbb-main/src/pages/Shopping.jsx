import React, { useState, useEffect } from "react";
import { Product } from "@/api/entities";
import { ShoppingBag, Star } from "lucide-react";
import { motion } from "framer-motion";

const ProductCard = ({ product }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    whileHover={{ y: -5 }}
    className="border rounded-lg overflow-hidden shadow-sm hover:shadow-lg transition-all"
  >
    <div className="relative">
      <img src={product.image_url || 'https://placehold.co/600x400?text=Product'} alt={product.title} className="w-full h-48 object-cover" />
      {product.is_sponsored && (
        <div className="absolute top-2 right-2 bg-yellow-400 text-yellow-900 px-2 py-1 text-xs font-bold rounded-full flex items-center gap-1">
          <Star className="w-3 h-3" />
          Sponsored
        </div>
      )}
    </div>
    <div className="p-4">
      <h3 className="font-bold text-lg">{product.title}</h3>
      <p className="text-gray-600 text-sm mb-2">{product.category}</p>
      <p className="text-gray-700 text-sm mb-4 line-clamp-3">{product.description}</p>
      <a href={product.affiliate_url} target="_blank" rel="noopener noreferrer" className="w-full inline-block text-center bg-blue-600 text-white font-semibold py-2 rounded-lg hover:bg-blue-700 transition-colors">
        View Product
      </a>
    </div>
  </motion.div>
);

const AdBanner = () => (
    <div className="p-6 rounded-lg bg-gray-100 text-center my-8">
        <p className="font-semibold text-gray-600">Advertisement</p>
    </div>
)

export default function ShoppingPage() {
  const [products, setProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      setIsLoading(true);
      try {
        const productData = await Product.list('-created_date');
        setProducts(productData);
      } catch (error) {
        console.error("Error loading products:", error);
      }
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  return (
    <div className="min-h-screen p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-3">
            <ShoppingBag style={{color: 'var(--teachmo-sage)'}} />
            Shop Partner Products
          </h1>
          <p className="text-gray-600">
            Discover tools, books, and resources recommended by Teachmo.
          </p>
        </div>

        {isLoading ? (
          <p>Loading products...</p>
        ) : (
            <>
            <AdBanner />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {products.map((product) => (
                    <ProductCard key={product.id} product={product} />
                ))}
            </div>
            </>
        )}
         {products.length === 0 && !isLoading && (
              <div className="text-center py-12">
                <ShoppingBag className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No products to show right now.</h3>
                <p className="text-gray-600">Check back later for curated tools and resources!</p>
              </div>
            )}
      </div>
    </div>
  );
}