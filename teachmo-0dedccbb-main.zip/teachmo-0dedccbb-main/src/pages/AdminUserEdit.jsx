
import React, { useState, useEffect, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { User } from '@/api/entities';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, ArrowLeft, Save, AlertCircle } from 'lucide-react';
import RoleGuard from '@/components/shared/RoleGuard';
import { createPageUrl } from '@/utils';
import { useEntityCrud } from '@/components/hooks/useApi';

export default function AdminUserEditPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();

  const userApi = useEntityCrud(User);

  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    full_name: '',
    role: '',
    user_type: '', // Changed from role to user_type for the specific user type
    status: ''
  });

  const params = new URLSearchParams(location.search);
  const userId = params.get('userId');

  const loadUser = useCallback(async () => {
    if (!userId) {
      toast({ variant: 'destructive', title: 'No User ID found in URL' });
      navigate(createPageUrl('AdminUsers'));
      return;
    }
    
    try {
      // WORKAROUND: Use filter instead of get to avoid the backend coroutine error
      const users = await userApi.filter({ id: userId }, null, 1);
      
      if (users && users.length > 0) {
        const fetchedUser = users[0];
        setUser(fetchedUser);
        setFormData({
          full_name: fetchedUser.full_name || '',
          role: fetchedUser.role || 'user', // Changed default from 'parent' to 'user'
          user_type: fetchedUser.user_type || 'parent', // Use user_type for specific type
          status: fetchedUser.status || 'active'
        });
      } else {
        toast({ variant: 'destructive', title: 'Error', description: 'User not found.' });
        navigate(createPageUrl('AdminUsers'));
      }
    } catch (error) {
      // The useApi hook will show a toast for the error
      console.error('Error loading user:', error);
      navigate(createPageUrl('AdminUsers'));
    }
  }, [userId, navigate, toast]);

  useEffect(() => {
    loadUser();
  }, [loadUser]);
  
  const handleInputChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.id]: e.target.value }));
  };
  
  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
        await userApi.update(userId, formData, 'User updated successfully!');
        navigate(createPageUrl('AdminUsers'));
    } catch (error) {
        // Error toast is handled by the hook
        console.error('Failed to update user:', error);
    }
  };

  if (userApi.isLoading('filter') || !user) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }
  
  if (userApi.hasError('filter')) {
     return (
        <div className="p-4 md:p-8">
            <Card className="max-w-2xl mx-auto border-red-500">
                <CardHeader>
                    <CardTitle className="text-red-600 flex items-center gap-2"><AlertCircle /> Loading Error</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-gray-700">Could not load the user data. This might be due to a server issue or the user may not exist.</p>
                    <Button onClick={() => navigate(createPageUrl('AdminUsers'))} variant="outline" className="mt-4">
                        <ArrowLeft className="mr-2 h-4 w-4"/>
                        Back to User List
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
  }

  return (
    <RoleGuard allowedRoles={['system_admin', 'admin', 'district_admin', 'school_admin']}>
      <div className="max-w-2xl mx-auto p-4 md:p-6">
        <Button onClick={() => navigate(createPageUrl('AdminUsers'))} variant="ghost" className="mb-4 text-gray-700 hover:bg-gray-100">
          <ArrowLeft className="mr-2 h-4 w-4"/>
          Back to User Management
        </Button>
        <Card>
          <CardHeader>
            <CardTitle>Edit User Profile</CardTitle>
            <CardDescription>Update the details for <span className="font-medium text-gray-900">{user.email}</span>.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="full_name">Full Name</Label>
                <Input
                  id="full_name"
                  value={formData.full_name}
                  onChange={handleInputChange}
                  disabled={userApi.isLoading('update')}
                />
              </div>
               <div>
                <Label>Email (Read-only)</Label>
                <Input value={user.email} readOnly disabled className="bg-gray-100" />
              </div>
              <div>
                <Label htmlFor="role">System Role</Label>
                <Select
                  value={formData.role}
                  onValueChange={(value) => handleSelectChange('role', value)}
                  disabled={userApi.isLoading('update')}
                >
                  <SelectTrigger id="role">
                    <SelectValue placeholder="Select a system role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="user">User</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="user_type">User Type</Label>
                <Select
                  value={formData.user_type}
                  onValueChange={(value) => handleSelectChange('user_type', value)}
                  disabled={userApi.isLoading('update')}
                >
                  <SelectTrigger id="user_type">
                    <SelectValue placeholder="Select user type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="parent">Parent</SelectItem>
                    <SelectItem value="teacher">Teacher</SelectItem>
                    <SelectItem value="school_admin">School Admin</SelectItem>
                    <SelectItem value="district_admin">District Admin</SelectItem>
                    <SelectItem value="system_admin">System Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="status">Status</Label>
                 <Select
                  value={formData.status}
                  onValueChange={(value) => handleSelectChange('status', value)}
                  disabled={userApi.isLoading('update')}
                >
                  <SelectTrigger id="status">
                    <SelectValue placeholder="Select a status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="invited">Invited</SelectItem>
                    <SelectItem value="deactivated">Deactivated</SelectItem>
                    <SelectItem value="system_locked">System Locked</SelectItem>
                    <SelectItem value="system_disabled">System Disabled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className='flex justify-end'>
                 <Button type="submit" disabled={userApi.isLoading('update')} className="bg-blue-600 hover:bg-blue-700">
                    {userApi.isLoading('update') && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    <Save className="mr-2 h-4 w-4"/>
                    Save Changes
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </RoleGuard>
  );
}
