import React, { useState, useEffect } from 'react';
import { getAdminAnalytics } from '@/api/functions';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, BarChart2, Activity, MessageSquare, AlertCircle } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';
import RoleGuard from '@/components/shared/RoleGuard';
import { DashboardSkeleton } from '@/components/shared/ImprovedSkeletons';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-2 border rounded-lg shadow-sm">
        <p className="font-bold">{label}</p>
        <p className="text-sm" style={{ color: payload[0].color }}>{`${payload[0].name}: ${payload[0].value.toFixed(2)}%`}</p>
      </div>
    );
  }
  return null;
};

const HeatmapTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
        const hour = payload[0].payload.hour;
        const day = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][payload[0].payload.day];
        return (
            <div className="bg-white p-2 border rounded-lg shadow-sm">
                <p className="font-bold">{`${day} at ${hour}:00`}</p>
                <p className="text-sm">{`Engagement: ${payload[0].value}`}</p>
            </div>
        );
    }
    return null;
};

function EngagementHeatmap({ data }) {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const hours = Array.from({ length: 24 }, (_, i) => `${i}:00`);

    const processedData = [];
    data.forEach((dayData, dayIndex) => {
        dayData.forEach((value, hourIndex) => {
            processedData.push({ day: dayIndex, hour: hourIndex, value });
        });
    });

    const maxVal = Math.max(...processedData.map(d => d.value));

    return (
        <div style={{ width: '100%', overflowX: 'auto' }}>
            <div className="grid grid-cols-25 gap-1">
                <div />
                {hours.map(h => <div key={h} className="text-xs text-center">{h}</div>)}
                {days.map((day, dayIndex) => (
                    <React.Fragment key={day}>
                        <div className="text-xs text-right pr-1">{day}</div>
                        {hours.map((_, hourIndex) => {
                            const value = data[dayIndex]?.[hourIndex] || 0;
                            const opacity = maxVal > 0 ? value / maxVal : 0;
                            return (
                                <div
                                    key={`${day}-${hourIndex}`}
                                    className="w-4 h-4 rounded-sm"
                                    style={{ backgroundColor: `rgba(37, 99, 235, ${opacity})` }}
                                    title={`Engagement: ${value}`}
                                />
                            );
                        })}
                    </React.Fragment>
                ))}
            </div>
        </div>
    );
}

function AdminAnalyticsPage() {
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        setLoading(true);
        const { data } = await getAdminAnalytics();
        setMetrics(data);
      } catch (err) {
        console.error("Failed to fetch analytics:", err);
        setError("Could not load analytics data. Please try again later.");
      } finally {
        setLoading(false);
      }
    };
    fetchMetrics();
  }, []);

  if (loading) return <DashboardSkeleton />;
  if (error) return (
    <div className="p-4 md:p-6 flex items-center justify-center">
      <AlertCircle className="w-8 h-8 text-red-500 mr-4" />
      <p className="text-red-700">{error}</p>
    </div>
  );
  if (!metrics) return <div className="p-4 md:p-6">No analytics data available.</div>;

  const featureAdoptionData = [
    { name: 'Activity Completion', value: metrics.featureAdoption.activityCompletion },
    { name: 'AI Coach Usage', value: metrics.featureAdoption.aiCoachUsage },
    { name: 'Calendar Sync', value: metrics.featureAdoption.calendarSync },
  ];

  return (
    <div className="p-4 md:p-6 space-y-6">
      <header>
        <h1 className="text-3xl font-bold text-gray-900">Admin Analytics</h1>
        <p className="text-gray-600">Platform-wide engagement and adoption metrics.</p>
      </header>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Daily Active Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.dau}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Active Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.mau}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Feature Adoption</CardTitle>
            <BarChart2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {`${(featureAdoptionData.reduce((acc, item) => acc + item.value, 0) / featureAdoptionData.length).toFixed(1)}%`}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Feedback Count</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.feedbackCount}</div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Feature Adoption Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={featureAdoptionData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis unit="%" />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="value" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Engagement Heatmap (Last 30 Days)</CardTitle>
          </CardHeader>
          <CardContent>
             <EngagementHeatmap data={metrics.engagementHeatmap} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default function ProtectedAdminAnalytics() {
    return (
        <RoleGuard allowedRoles={['system_admin', 'district_admin', 'school_admin', 'admin']}>
            <AdminAnalyticsPage />
        </RoleGuard>
    );
}