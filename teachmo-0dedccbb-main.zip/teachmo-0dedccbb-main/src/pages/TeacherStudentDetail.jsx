import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { User, Student, Assignment, Course, StudentParentLink, UserMessage } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, User as UserIcon, MessageSquare, BookOpen, TrendingUp, Calendar, Clock, CheckCircle, AlertTriangle, Send, Phone, Mail } from "lucide-react";
import { format, parseISO } from "date-fns";
import { createPageUrl } from "@/utils";
import { useToast } from "@/components/ui/use-toast";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";

export default function TeacherStudentDetail() {
  const { studentId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [student, setStudent] = useState(null);
  const [parentLinks, setParentLinks] = useState([]);
  const [studentAssignments, setStudentAssignments] = useState([]);
  const [studentCourses, setStudentCourses] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showMessageDialog, setShowMessageDialog] = useState(false);
  const [showGradeDialog, setShowGradeDialog] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState(null);
  const [messageContent, setMessageContent] = useState("");
  const [newGrade, setNewGrade] = useState("");
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    const fetchStudentDetails = async () => {
      try {
        // Fetch student
        const studentData = await Student.get(studentId);
        setStudent(studentData);

        // Fetch parent links
        const parentLinksData = await StudentParentLink.filter({ 
          student_id: studentId,
          verification_status: 'verified' 
        });
        
        // Fetch parent user details
        const parentDetailsPromises = parentLinksData.map(async (link) => {
          try {
            const parentUser = await User.get(link.parent_user_id);
            return { ...link, parentUser };
          } catch (error) {
            console.error(`Failed to fetch parent ${link.parent_user_id}:`, error);
            return null;
          }
        });
        
        const parentDetails = await Promise.all(parentDetailsPromises);
        setParentLinks(parentDetails.filter(Boolean));

        // Fetch student assignments
        const assignments = await Assignment.filter({ student_id: studentId }, '-due_date');
        setStudentAssignments(assignments);

        // Fetch courses this student is enrolled in
        const courseIds = [...new Set(assignments.map(a => a.course_id))];
        const coursesPromises = courseIds.map(async (courseId) => {
          try {
            return await Course.get(courseId);
          } catch (error) {
            console.error(`Failed to fetch course ${courseId}:`, error);
            return null;
          }
        });
        
        const courses = await Promise.all(coursesPromises);
        setStudentCourses(courses.filter(Boolean));

      } catch (error) {
        console.error("Error fetching student details:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load student details."
        });
        navigate(createPageUrl("TeacherClasses"));
      } finally {
        setIsLoading(false);
      }
    };

    if (studentId) {
      fetchStudentDetails();
    }
  }, [studentId, navigate, toast]);

  const handleSendMessage = async (parentUserId) => {
    if (!messageContent.trim()) return;

    setIsSending(true);
    try {
      const currentUser = await User.me();
      
      // Create conversation thread ID
      const threadId = `teacher_${currentUser.id}_parent_${parentUserId}_${Date.now()}`;
      
      await UserMessage.create({
        sender_id: currentUser.id,
        recipient_id: parentUserId,
        content: messageContent.trim(),
        thread_id: threadId,
        message_type: 'text'
      });

      toast({
        title: "Message Sent",
        description: "Your message has been sent to the parent."
      });

      setMessageContent("");
      setShowMessageDialog(false);
    } catch (error) {
      console.error("Error sending message:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to send message. Please try again."
      });
    } finally {
      setIsSending(false);
    }
  };

  const handleUpdateGrade = async () => {
    if (!selectedAssignment || !newGrade.trim()) return;

    setIsSending(true);
    try {
      await Assignment.update(selectedAssignment.id, {
        grade: newGrade.trim(),
        status: 'Graded'
      });

      // Update local state
      setStudentAssignments(prev => 
        prev.map(a => 
          a.id === selectedAssignment.id 
            ? { ...a, grade: newGrade.trim(), status: 'Graded' }
            : a
        )
      );

      toast({
        title: "Grade Updated",
        description: `Grade "${newGrade}" has been recorded for ${selectedAssignment.title}.`
      });

      setNewGrade("");
      setShowGradeDialog(false);
      setSelectedAssignment(null);
    } catch (error) {
      console.error("Error updating grade:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update grade. Please try again."
      });
    } finally {
      setIsSending(false);
    }
  };

  const getAssignmentStatusBadge = (assignment) => {
    switch (assignment.status) {
      case 'Submitted':
        return <Badge className="bg-blue-100 text-blue-800">Submitted</Badge>;
      case 'Graded':
        return <Badge className="bg-green-100 text-green-800">Graded</Badge>;
      case 'InProgress':
        return <Badge className="bg-yellow-100 text-yellow-800">In Progress</Badge>;
      case 'NotStarted':
      default:
        const isOverdue = assignment.due_date && parseISO(assignment.due_date) < new Date();
        return isOverdue 
          ? <Badge className="bg-red-100 text-red-800">Overdue</Badge>
          : <Badge className="bg-gray-100 text-gray-800">Not Started</Badge>;
    }
  };

  const getGradeColor = (grade) => {
    if (!grade) return 'text-gray-500';
    const numGrade = parseFloat(grade);
    if (numGrade >= 90) return 'text-green-600';
    if (numGrade >= 80) return 'text-blue-600';
    if (numGrade >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="max-w-6xl mx-auto">
          <div className="mb-6">
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-5 w-96" />
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card><CardContent className="p-6"><Skeleton className="h-32 w-full" /></CardContent></Card>
            <Card className="lg:col-span-2"><CardContent className="p-6"><Skeleton className="h-64 w-full" /></CardContent></Card>
          </div>
        </div>
      </div>
    );
  }

  if (!student) {
    return (
      <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <Alert variant="destructive" className="max-w-2xl mx-auto mt-8">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Student not found. Please check the URL and try again.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  const completedAssignments = studentAssignments.filter(a => a.status === 'Graded').length;
  const totalAssignments = studentAssignments.length;
  const averageGrade = studentAssignments
    .filter(a => a.grade && !isNaN(parseFloat(a.grade)))
    .reduce((sum, a, _, arr) => sum + parseFloat(a.grade) / arr.length, 0);

  return (
    <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <Button 
            variant="outline" 
            onClick={() => navigate(createPageUrl("TeacherClasses"))}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Classes
          </Button>
          
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                {student.first_name} {student.last_name}
              </h1>
              <p className="text-gray-600">
                Student ID: {student.external_id} | {studentCourses.length} Course{studentCourses.length !== 1 ? 's' : ''}
              </p>
            </div>
            
            {parentLinks.length > 0 && (
              <Button
                onClick={() => setShowMessageDialog(true)}
                style={{backgroundColor: 'var(--teachmo-sage)'}}
                className="flex items-center gap-2"
              >
                <MessageSquare className="w-4 h-4" />
                Message Parents
              </Button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Student Overview */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                  Academic Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Completed Assignments</span>
                    <span className="font-semibold">{completedAssignments}/{totalAssignments}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Average Grade</span>
                    <span className={`font-semibold ${getGradeColor(averageGrade.toFixed(1))}`}>
                      {averageGrade > 0 ? `${averageGrade.toFixed(1)}%` : 'No grades yet'}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Courses Enrolled</span>
                    <span className="font-semibold">{studentCourses.length}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Parent Contacts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserIcon className="w-5 h-5 text-green-600" />
                  Parent Contacts
                </CardTitle>
              </CardHeader>
              <CardContent>
                {parentLinks.length === 0 ? (
                  <p className="text-gray-600">No verified parent contacts</p>
                ) : (
                  <div className="space-y-3">
                    {parentLinks.map((link) => (
                      <div key={link.id} className="border rounded-lg p-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{link.parentUser.full_name}</p>
                            <p className="text-sm text-gray-600 capitalize">{link.relationship}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => window.open(`mailto:${link.parentUser.email}`)}
                            >
                              <Mail className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setShowMessageDialog(true)}
                            >
                              <MessageSquare className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Assignments & Courses */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-purple-600" />
                  Student Details
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="assignments" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="assignments">Assignments ({studentAssignments.length})</TabsTrigger>
                    <TabsTrigger value="courses">Courses ({studentCourses.length})</TabsTrigger>
                  </TabsList>

                  <TabsContent value="assignments" className="space-y-4">
                    {studentAssignments.length === 0 ? (
                      <div className="text-center py-8">
                        <BookOpen className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                        <p className="text-gray-600">No assignments found for this student.</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {studentAssignments.map((assignment) => (
                          <div key={assignment.id} className="border rounded-lg p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h4 className="font-semibold text-gray-900 mb-1">
                                  {assignment.title}
                                </h4>
                                {assignment.description && (
                                  <p className="text-sm text-gray-600 mb-2">
                                    {assignment.description}
                                  </p>
                                )}
                                <div className="flex items-center gap-4 text-sm">
                                  {assignment.due_date && (
                                    <span className="flex items-center gap-1 text-gray-600">
                                      <Calendar className="w-3 h-3" />
                                      Due: {format(parseISO(assignment.due_date), 'MMM d, yyyy')}
                                    </span>
                                  )}
                                  {assignment.grade && (
                                    <span className={`flex items-center gap-1 font-medium ${getGradeColor(assignment.grade)}`}>
                                      Grade: {assignment.grade}
                                    </span>
                                  )}
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                {getAssignmentStatusBadge(assignment)}
                                {assignment.status === 'Submitted' && (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      setSelectedAssignment(assignment);
                                      setNewGrade(assignment.grade || '');
                                      setShowGradeDialog(true);
                                    }}
                                  >
                                    Grade
                                  </Button>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="courses" className="space-y-4">
                    {studentCourses.length === 0 ? (
                      <div className="text-center py-8">
                        <BookOpen className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                        <p className="text-gray-600">No courses found for this student.</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {studentCourses.map((course) => (
                          <Card key={course.id} className="border">
                            <CardContent className="p-4">
                              <h4 className="font-semibold text-gray-900 mb-1">
                                {course.name}
                              </h4>
                              <p className="text-sm text-gray-600 mb-2">
                                {course.course_code}
                              </p>
                              <div className="text-xs text-gray-500">
                                {studentAssignments.filter(a => a.course_id === course.id).length} assignments
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Message Dialog */}
        <Dialog open={showMessageDialog} onOpenChange={setShowMessageDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Send Message to Parents</DialogTitle>
              <DialogDescription>
                Send a message about {student.first_name} to their parent(s).
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  placeholder={`Hi, I wanted to update you about ${student.first_name}...`}
                  value={messageContent}
                  onChange={(e) => setMessageContent(e.target.value)}
                  rows={4}
                  className="mt-2"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowMessageDialog(false)}>
                Cancel
              </Button>
              {parentLinks.map((link) => (
                <Button
                  key={link.id}
                  onClick={() => handleSendMessage(link.parent_user_id)}
                  disabled={!messageContent.trim() || isSending}
                  style={{backgroundColor: 'var(--teachmo-sage)'}}
                >
                  {isSending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Send to {link.parentUser.full_name}
                    </>
                  )}
                </Button>
              ))}
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Grade Dialog */}
        <Dialog open={showGradeDialog} onOpenChange={setShowGradeDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Grade Assignment</DialogTitle>
              <DialogDescription>
                Enter a grade for "{selectedAssignment?.title}"
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="grade">Grade</Label>
                <Input
                  id="grade"
                  placeholder="e.g., 95, A-, B+"
                  value={newGrade}
                  onChange={(e) => setNewGrade(e.target.value)}
                  className="mt-2"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowGradeDialog(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleUpdateGrade}
                disabled={!newGrade.trim() || isSending}
                style={{backgroundColor: 'var(--teachmo-sage)'}}
              >
                {isSending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                    Saving...
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Save Grade
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}