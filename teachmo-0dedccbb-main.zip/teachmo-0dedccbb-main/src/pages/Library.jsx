
import React, { useState, useEffect } from "react";
import { LibraryResource, UserBookmark, UserActivity } from "@/api/entities";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Search, Bookmark, BookOpen, Filter, Loader2, AlertTriangle, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import ResourceCard from "../components/library/ResourceCard";
import LibraryFilters from "../components/library/LibraryFilters";
import BookmarkedResources from "../components/library/BookmarkedResources";
import { usePremium } from "../components/shared/usePremium";
import { LibrarySkeleton } from '../components/shared/ImprovedSkeletons';

export default function Library() {
  const [resources, setResources] = useState([]);
  const [bookmarks, setBookmarks] = useState([]);
  const [filters, setFilters] = useState({ category: 'all', type: 'all', searchTerm: '' });
  const [isLoading, setIsLoading] = useState(true);
  const { isPremium } = usePremium();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [resourcesData, bookmarksData] = await Promise.all([
        LibraryResource.list(),
        UserBookmark.filter({ resource_type: 'library_resource' })
      ]);
      setResources(resourcesData);
      setBookmarks(bookmarksData);
    } catch (error) {
      console.error("Failed to load library data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const isBookmarked = (resourceId) => bookmarks.some(b => b.resource_id === resourceId);

  const handleBookmarkToggle = async (resourceId, itemType, isCurrentlyBookmarked) => {
    // User ID is expected to be inferred from the session by the backend for UserBookmark.create
    try {
      if (isCurrentlyBookmarked) {
        const bookmark = bookmarks.find(b => b.resource_id === resourceId);
        if (bookmark) {
          await UserBookmark.delete(bookmark.id);
          setBookmarks(prev => prev.filter(b => b.id !== bookmark.id));
        }
      } else {
        const newBookmark = await UserBookmark.create({
          resource_id: resourceId,
          resource_type: itemType,
        });
        setBookmarks(prev => [...prev, newBookmark]);
      }
    } catch (error) {
      console.error("Error toggling bookmark:", error);
    }
  };

  const bookmarkedResources = resources.filter(r => isBookmarked(r.id));

  const filteredResources = resources.filter(resource => {
    const searchTermLower = filters.searchTerm.toLowerCase();
    const matchesSearch = filters.searchTerm ?
      resource.title.toLowerCase().includes(searchTermLower) ||
      resource.description.toLowerCase().includes(searchTermLower) ||
      (resource.tags && resource.tags.some(tag => tag.toLowerCase().includes(searchTermLower)))
      : true;

    const matchesType = filters.type === 'all' || resource.type === filters.type;
    const matchesCategory = filters.category === 'all' || resource.category === filters.category;

    return matchesSearch && matchesType && matchesCategory && (!resource.is_premium || isPremium);
  });

  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="max-w-7xl mx-auto">
          <LibrarySkeleton />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Resource Library</h1>
          <p className="text-lg text-gray-600">Expert articles, guides, and videos to support your parenting journey.</p>
        </header>

        {bookmarks.length > 0 && (
          <BookmarkedResources
            bookmarkedResources={bookmarkedResources}
            onBookmark={handleBookmarkToggle}
            onView={(resourceId) => UserActivity.create({ resource_id: resourceId, resource_type: 'library_resource', action: 'viewed' })}
          />
        )}

        <section className={bookmarks.length > 0 ? "mt-12" : ""}> {/* Add margin top if bookmarks exist */}
          <Card className="bg-transparent border-0">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <BookOpen className="w-6 h-6 text-blue-600" />
                Explore All Resources
              </CardTitle>
              <div className="pt-4 flex flex-col md:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    placeholder="Search by title, topic, or keyword..."
                    value={filters.searchTerm}
                    onChange={(e) => setFilters(prev => ({ ...prev, searchTerm: e.target.value }))}
                    className="pl-10 h-12"
                  />
                   {filters.searchTerm && (
                        <Button variant="ghost" size="icon" className="absolute right-2 top-1/2 -translate-y-1/2" onClick={() => setFilters(prev => ({ ...prev, searchTerm: '' }))}>
                            <X className="w-5 h-5 text-gray-500" />
                        </Button>
                    )}
                </div>
                <LibraryFilters filters={filters} onFiltersChange={setFilters} />
              </div>
            </CardHeader>
            <CardContent>
              {filteredResources.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <AnimatePresence>
                    {filteredResources.map(resource => (
                      <ResourceCard
                        key={resource.id}
                        resource={resource}
                        isBookmarked={isBookmarked(resource.id)}
                        onBookmark={(isBookmarked) => handleBookmarkToggle(resource.id, 'library_resource', isBookmarked)}
                        onView={() => UserActivity.create({ resource_id: resource.id, resource_type: 'library_resource', action: 'viewed' })}
                      />
                    ))}
                  </AnimatePresence>
                </div>
              ) : (
                <div className="text-center py-12 bg-white/50 rounded-lg">
                  <AlertTriangle className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-xl font-semibold text-gray-800">No Resources Found</h3>
                  <p className="text-gray-600 mt-2">Try adjusting your search or filters to find what you're looking for.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  );
}
