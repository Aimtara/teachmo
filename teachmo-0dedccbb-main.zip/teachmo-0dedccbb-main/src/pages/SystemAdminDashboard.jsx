
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Users,
  School,
  Activity,
  RefreshCw,
  Download,
  Globe,
  Briefcase,
  ExternalLink,
  Eye, // Added for accessibility section
  BookOpen // Added for Developer Resources
} from 'lucide-react';
import { getAdminAnalytics } from '@/api/functions';
import { schoolDirectoryETL } from '@/api/functions';
import { populateSchoolDirectory } from '@/api/functions';
import RoleGuard from '@/components/shared/RoleGuard';
import { useToast } from '@/components/ui/use-toast';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import SecurityStatusWidget from '@/components/admin/SecurityStatusWidget';
import AccessibilityAudit from '@/components/shared/AccessibilityAudit';
import AccessibilityLinter from '@/components/shared/AccessibilityLinter';

// DashboardSkeleton component based on initial loading state
const DashboardSkeleton = () => (
  <div className="space-y-6">
    <div className="h-8 w-64 bg-gray-200 rounded animate-pulse" />
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {[...Array(4)].map((_, i) => (
        <Card key={i}>
          <CardContent className="p-6">
            <div className="h-24 bg-gray-200 rounded animate-pulse" />
          </CardContent>
        </Card>
      ))}
    </div>
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        <Card><CardContent className="p-6 h-64 bg-gray-200 rounded animate-pulse" /></Card>
        <Card><CardContent className="p-6 h-64 bg-gray-200 rounded animate-pulse" /></Card>
      </div>
      <div className="space-y-6">
        <Card><CardContent className="p-6 h-48 bg-gray-200 rounded animate-pulse" /></Card>
      </div>
    </div>
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card><CardContent className="p-6 h-48 bg-gray-200 rounded animate-pulse" /></Card>
      <Card><CardContent className="p-6 h-48 bg-gray-200 rounded animate-pulse" /></Card>
    </div>
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
      <Card><CardContent className="p-6 h-64 bg-gray-200 rounded animate-pulse" /></Card>
      <Card><CardContent className="p-6 h-64 bg-gray-200 rounded animate-pulse" /></Card>
    </div>
  </div>
);

// Renamed SystemDashboard to AdminDashboardContent to be wrapped by RoleGuard
function AdminDashboardContent() {
  const [analytics, setAnalytics] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [etlStatus, setEtlStatus] = useState({
    isRunning: false,
    lastRun: null,
    schoolCount: 0,
    message: ''
  });
  const { toast } = useToast();

  useEffect(() => {
    loadAnalytics();
    loadETLStatus();
  }, []);

  const loadAnalytics = async () => {
    try {
      const { data } = await getAdminAnalytics();
      if (data.success) {
        setAnalytics(data.analytics);
      }
    } catch (error) {
      console.error('Error loading analytics:', error);
      toast({
        variant: "destructive",
        title: "Analytics Error",
        description: "Could not load system analytics."
      });
    } finally {
      setIsLoading(false);
    }
  };

  const loadETLStatus = async () => {
    // In a real implementation, this would check the ETL status from a dedicated endpoint.
    // For now, we'll simulate it. Let's assume initial school count is 0 until ETL is run or an API provides it.
    // We can use analytics.total_schools if it's already loaded, or default to 0.
    // As analytics loads async, initial schoolCount might be 0 until analytics is loaded.
    const initialSchoolCount = analytics?.total_schools || 0;
    setEtlStatus({
        isRunning: false,
        lastRun: null, // User needs to run it for the first time
        schoolCount: initialSchoolCount,
        message: initialSchoolCount > 0 ? `${initialSchoolCount} schools in directory.` : 'Directory is empty. Run ETL to populate.'
    });
  };

  const runSchoolDirectoryETL = async (forceRefresh = false) => {
    setEtlStatus(prev => ({ ...prev, isRunning: true, message: 'Running sample ETL...' }));

    try {
      const { data } = await schoolDirectoryETL({
        force_refresh: forceRefresh,
        source: 'sample'
      });

      if (data.success) {
        toast({
          title: "Sample ETL Complete! 🎉",
          description: `${data.stats.created} schools created, ${data.stats.updated} updated.`
        });

        setEtlStatus({
          isRunning: false,
          lastRun: new Date().toISOString(),
          schoolCount: data.stats.total_in_directory,
          message: `${data.stats.total_in_directory} schools now in directory. Last run: ${new Date().toLocaleTimeString()}.`
        });
      } else {
        throw new Error(data.error || 'ETL failed');
      }
    } catch (error) {
      console.error('ETL Error:', error);
      toast({
        variant: "destructive",
        title: "ETL Failed",
        description: error.message || "Could not populate school directory."
      });
      setEtlStatus(prev => ({ ...prev, isRunning: false, message: `Error: ${error.message}` }));
    }
  };

  const runProductionETL = async () => {
    setEtlStatus(prev => ({ ...prev, isRunning: true, message: 'Importing NCES datasets...' }));

    try {
      const { data } = await populateSchoolDirectory({
        source: 'nces_production',
        include_private: true,
        enrich_domains: true
      });

      if (data.success) {
        toast({
          title: "Production ETL Complete! 🎉",
          description: `${data.stats.total_processed} schools processed from NCES datasets.`
        });

        setEtlStatus({
          isRunning: false,
          lastRun: new Date().toISOString(),
          schoolCount: data.stats.total_in_directory,
          message: `${data.stats.total_in_directory} schools now in directory. Last run: ${new Date().toLocaleTimeString()}.`
        });
      } else {
        throw new Error(data.error || 'Production ETL failed');
      }
    } catch (error) {
      console.error('Production ETL Error:', error);
      toast({
        variant: "destructive",
        title: "Production ETL Failed",
        description: error.message || "Could not import NCES datasets."
      });
      setEtlStatus(prev => ({ ...prev, isRunning: false, message: `Error: ${error.message}` }));
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto space-y-6">
        <header>
          <h1 className="text-3xl font-bold text-gray-900">System Administration</h1>
          <p className="text-gray-600 mt-1">Platform-wide monitoring and management tools.</p>
        </header>

        {isLoading ? (
          <DashboardSkeleton />
        ) : (
          <div className="space-y-8">
            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <StatCard icon={Users} title="Total Users" value={analytics?.total_users || 0} trend={analytics?.user_trend || '0%'} />
              <StatCard icon={Briefcase} title="Active Subscriptions" value={analytics?.active_subscriptions || 0} trend={analytics?.subscription_trend || '0%'} />
              <StatCard icon={School} title="Onboarded Schools" value={analytics?.onboarded_schools || 0} trend={analytics?.school_trend || '0%'} />
              <StatCard icon={Activity} title="Daily Active Users" value={analytics?.daily_active_users || 0} trend={analytics?.dau_trend || '0%'} />
            </div>

            {/* Main Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Column */}
              <div className="lg:col-span-2 space-y-6">
                {/* User & School Management */}
                <Card>
                  <CardHeader>
                    <CardTitle>Management</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <ManagementLink to={createPageUrl("SystemUsers")} icon={Users} title="User Management" description="Manage all users, roles, and permissions." />
                    <ManagementLink to={createPageUrl("SystemDistricts")} icon={Globe} title="District Management" description="Oversee and manage school districts." />
                    <ManagementLink to={createPageUrl("SchoolRequests")} icon={School} title="School Requests" description="Review and process new school requests." />
                  </CardContent>
                </Card>

                {/* School Directory ETL */}
                <Card>
                  <CardHeader>
                    <CardTitle>School Directory ETL</CardTitle>
                    <CardDescription>Populate and maintain the nationwide school directory.</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-gray-50 rounded-lg text-center">
                      <p className="text-sm text-gray-700">
                        {etlStatus.message || 'Ready to run ETL.'}
                      </p>
                      {etlStatus.isRunning && <Progress value={50} className="mt-2 h-2 animate-pulse" />}
                    </div>
                    <div className="flex flex-col sm:flex-row gap-4">
                      <Button
                        onClick={() => runSchoolDirectoryETL(false)}
                        disabled={etlStatus.isRunning}
                        className="flex-1"
                        variant="outline"
                      >
                        <RefreshCw className={`w-4 h-4 mr-2 ${etlStatus.isRunning ? 'animate-spin' : ''}`} />
                        Run Sample ETL
                      </Button>
                      <Button
                        onClick={runProductionETL}
                        disabled={etlStatus.isRunning}
                        className="flex-1"
                      >
                        <Download className={`w-4 h-4 mr-2 ${etlStatus.isRunning ? 'animate-spin' : ''}`} />
                        Run Production ETL
                      </Button>
                    </div>
                    <Button
                      onClick={() => runSchoolDirectoryETL(true)}
                      disabled={etlStatus.isRunning}
                      variant="destructive"
                      className="w-full"
                    >
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Force Refresh Sample ETL (with caution)
                    </Button>
                    <p className="text-xs text-gray-500 text-center">
                      Use Production ETL to import real NCES data. This may take several minutes.
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Right Column (kept for layout, but SecurityStatusWidget is moved from here) */}
              <div className="space-y-6">
                {/* This column is intentionally left empty in the current design */}
              </div>
            </div>

            {/* Security & Developer Tools Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <SecurityStatusWidget />
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="w-6 h-6" />
                    Developer Resources
                  </CardTitle>
                  <CardDescription>
                    Onboarding documentation and contribution guidelines.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                     <p className="text-sm text-gray-700">
                      Access the complete developer guide for project setup, architecture, key conventions, and contribution processes.
                    </p>
                    <Button variant="outline" className="w-full" asChild>
                      <Link to={createPageUrl("DeveloperGuide")}>
                        Open Developer Guide
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Accessibility Overview Card (moved from former Security & Accessibility Section) */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6"> {/* Placed in its own grid for consistent layout with other sections */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Eye className="w-6 h-6" />
                    Accessibility Overview
                  </CardTitle>
                  <CardDescription>
                    Monitor platform accessibility compliance
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">WCAG 2.1 AA Compliance</span>
                      <Badge variant="outline" className="bg-yellow-50 text-yellow-700">
                        In Progress
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Accessibility Audit Score</span>
                      <span className="text-lg font-bold text-yellow-600">78%</span>
                    </div>
                    <Button variant="outline" className="w-full" asChild>
                      <Link to={createPageUrl("AccessibilityAudit")}>
                        View Full Accessibility Report
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
              {/* This column is intentionally left empty to push the Accessibility Overview card to the left if needed,
                  or can be repurposed for another single item. */}
              <div></div>
            </div>


            {/* Accessibility Tools Section */}
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900">Accessibility Tools</h2>
              
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                <AccessibilityLinter />
                <AccessibilityAudit />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

const StatCard = ({ icon: Icon, title, value, trend }) => (
  <Card>
    <CardContent className="p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <div className="flex items-center gap-2">
            <p className="text-2xl font-bold">{value.toLocaleString()}</p>
            {trend && (
              <Badge className={parseFloat(trend) > 0 ? 'bg-green-100 text-green-800' : (parseFloat(trend) < 0 ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800')}>
                {trend}
              </Badge>
            )}
          </div>
        </div>
        <Icon className="h-8 w-8 text-blue-600" />
      </div>
    </CardContent>
  </Card>
);

const ManagementLink = ({ to, icon: Icon, title, description }) => (
  <Link to={to} className="block p-4 border rounded-lg hover:bg-gray-50 transition-colors">
    <div className="flex items-start gap-4">
      <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
        <Icon className="w-5 h-5 text-blue-600" />
      </div>
      <div>
        <h3 className="font-semibold text-gray-900">{title}</h3>
        <p className="text-sm text-gray-600">{description}</p>
      </div>
      <ExternalLink className="w-5 h-5 text-gray-400 ml-auto" />
    </div>
  </Link>
);

// The main exported component, wrapping the dashboard content with RoleGuard
export default function SystemAdminDashboard() {
  return (
    <RoleGuard allowedRoles={['system_admin', 'admin']}>
      <AdminDashboardContent />
    </RoleGuard>
  );
}
