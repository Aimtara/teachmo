import React, { useState, useEffect, useMemo } from 'react';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Search, Edit } from 'lucide-react';
import { format } from 'date-fns';
import { createPageUrl } from '@/utils';
import { useNavigate } from 'react-router-dom';
import RoleGuard from '@/components/shared/RoleGuard';
import { useApi } from '@/components/hooks/useApi';
import { LoadingSpinner, ListLoadingSkeleton, ErrorState } from '@/components/shared/LoadingStates';

function SystemUsersPage() {
  const [users, setUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showBulkActions, setShowBulkActions] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState([]);

  const navigate = useNavigate();
  const api = useApi({ context: 'user management' });

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    try {
      const allUsers = await api.execute(
        () => User.list('-created_date'),
        { 
          key: 'users',
          errorContext: 'loading users'
        }
      );
      setUsers(allUsers);
    } catch (error) {
      console.error('Failed to load users:', error);
    }
  };

  const filteredUsers = useMemo(() => {
    return users.filter(user => {
      const matchesSearch = (user.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           user.email?.toLowerCase().includes(searchTerm.toLowerCase()));
      const matchesRole = roleFilter === 'all' || user.role === roleFilter;
      const matchesStatus = statusFilter === 'all' || user.status === statusFilter;

      return matchesSearch && matchesRole && matchesStatus;
    });
  }, [users, searchTerm, roleFilter, statusFilter]);

  const getRoleBadgeColor = (role) => {
    switch (role) {
      case 'system_admin': return 'bg-red-100 text-red-800';
      case 'district_admin': return 'bg-purple-100 text-purple-800';
      case 'school_admin': return 'bg-blue-100 text-blue-800';
      case 'teacher': return 'bg-green-100 text-green-800';
      case 'parent': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleEditUser = (userId) => {
    navigate(createPageUrl(`AdminUserEdit?id=${userId}`));
  };

  const handleRetry = () => {
    loadUsers();
  };

  if (api.isLoading('users')) {
    return (
      <div className="p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <Card>
          <CardHeader>
            <CardTitle>System User Management</CardTitle>
          </CardHeader>
          <CardContent>
            <ListLoadingSkeleton items={10} showActions={true} />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (api.hasError('users')) {
    return (
      <div className="p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <Card>
          <CardHeader>
            <CardTitle>System User Management</CardTitle>
          </CardHeader>
          <CardContent>
            <ErrorState 
              error={api.getError('users')}
              onRetry={handleRetry}
              title="Failed to Load Users"
            />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <Card>
        <CardHeader>
          <CardTitle>System User Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <Input
              placeholder="Search all users..."
              className="pl-9"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Login</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.length > 0 ? (
                  filteredUsers.map(user => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div className="font-medium">{user.full_name || 'N/A'}</div>
                        <div className="text-sm text-gray-500">{user.email}</div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getRoleBadgeColor(user.role)}>
                          {user.role?.replace('_', ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={user.status === 'active' ? 'default' : 'secondary'}>
                          {user.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {user.last_login_date ? format(new Date(user.last_login_date), 'MMM d, yyyy') : 'Never'}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditUser(user.id)}
                        >
                          <Edit className="w-4 h-4 mr-1" />
                          Edit
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center h-24">
                      No users found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function ProtectedSystemUsers() {
  return (
    <RoleGuard allowedRoles={['system_admin', 'admin']}>
      <SystemUsersPage />
    </RoleGuard>
  );
}