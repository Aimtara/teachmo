import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import AccessibilityAudit from '../components/shared/AccessibilityAudit';
import AccessibilityLinter from '../components/shared/AccessibilityLinter';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

export default function AccessibilityAuditPage() {
  return (
    <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Link to={createPageUrl("SystemAdminDashboard")}>
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Accessibility Audit</h1>
            <p className="text-gray-600 mt-1">
              Comprehensive accessibility testing and compliance monitoring
            </p>
          </div>
        </div>

        {/* Overview */}
        <Card>
          <CardHeader>
            <CardTitle>About Accessibility Compliance</CardTitle>
            <CardDescription>
              Teachmo is committed to providing an inclusive experience for all users, including those with disabilities.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="prose prose-sm max-w-none text-gray-700">
              <p>
                We follow the Web Content Accessibility Guidelines (WCAG) 2.1 AA standards to ensure our platform 
                is accessible to users with various abilities and assistive technologies.
              </p>
              <p>
                This audit page provides tools to test and monitor our accessibility compliance across key user flows, 
                including authentication, onboarding, activity management, messaging, and administrative functions.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Audit Tools */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          <AccessibilityLinter />
          <AccessibilityAudit />
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Accessibility Resources</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button variant="outline" asChild>
                <a href="https://www.w3.org/WAI/WCAG21/quickref/" target="_blank" rel="noopener noreferrer">
                  WCAG 2.1 Quick Reference
                </a>
              </Button>
              <Button variant="outline" asChild>
                <a href="https://www.deque.com/axe/" target="_blank" rel="noopener noreferrer">
                  Axe DevTools Extension
                </a>
              </Button>
              <Button variant="outline" asChild>
                <a href="https://webaim.org/resources/contrastchecker/" target="_blank" rel="noopener noreferrer">
                  Color Contrast Checker
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}