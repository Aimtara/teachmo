
import React, { useState, useEffect } from 'react';
import { User, Student, Assignment, Announcement } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, Users, BookOpen, MessageSquare, Calendar, BarChart3 } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { withAdminGuard } from '@/components/shared/AdminRoleGuard';

function SchoolAnalytics() {
  const [analytics, setAnalytics] = useState({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const currentUser = await User.me();
        
        // Fetch school-specific data
        const [users, students, assignments, announcements] = await Promise.all([
          User.filter({ school_id: currentUser.school_id }),
          Student.filter({ source_system: 'school_system' }),
          Assignment.list('-created_date', 100),
          Announcement.filter({ school_id: currentUser.school_id })
        ]);

        setAnalytics({
          totalUsers: users.length,
          totalStudents: students.length,
          totalAssignments: assignments.length,
          totalAnnouncements: announcements.length,
          activeTeachers: users.filter(u => u.role === 'teacher' && u.status === 'active').length,
          activeParents: users.filter(u => u.role === 'parent' && u.status === 'active').length,
          recentAssignments: assignments.slice(0, 5),
          recentAnnouncements: announcements.slice(0, 5)
        });
      } catch (error) {
        console.error('Analytics fetch error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchAnalytics();
  }, []);

  if (isLoading) {
    return (
      <div className="p-4 md:p-8 space-y-6">
        <Skeleton className="h-10 w-1/3" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i}><CardContent className="p-6"><Skeleton className="h-16 w-full" /></CardContent></Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-6 flex items-center gap-3">
          <BarChart3 className="w-8 h-8" style={{color: 'var(--teachmo-sage)'}} />
          School Analytics
        </h1>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Users</p>
                  <p className="text-3xl font-bold text-gray-900">{analytics.totalUsers}</p>
                </div>
                <Users className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Teachers</p>
                  <p className="text-3xl font-bold text-gray-900">{analytics.activeTeachers}</p>
                </div>
                <BookOpen className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Parents</p>
                  <p className="text-3xl font-bold text-gray-900">{analytics.activeParents}</p>
                </div>
                <Users className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Announcements</p>
                  <p className="text-3xl font-bold text-gray-900">{analytics.totalAnnouncements}</p>
                </div>
                <MessageSquare className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Analytics */}
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="engagement">Engagement</TabsTrigger>
            <TabsTrigger value="communication">Communication</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <Card>
              <CardHeader>
                <CardTitle>School Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Total Students</span>
                    <Badge variant="outline">{analytics.totalStudents}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Total Assignments</span>
                    <Badge variant="outline">{analytics.totalAssignments}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Parent-Teacher Messages</span>
                    <Badge variant="outline">Coming Soon</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="engagement">
            <Card>
              <CardHeader>
                <CardTitle>User Engagement</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Advanced engagement metrics will be available soon.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="communication">
            <Card>
              <CardHeader>
                <CardTitle>Recent Announcements</CardTitle>
              </CardHeader>
              <CardContent>
                {analytics.recentAnnouncements?.length > 0 ? (
                  <div className="space-y-2">
                    {analytics.recentAnnouncements.map((announcement) => (
                      <div key={announcement.id} className="p-3 border rounded-lg">
                        <h4 className="font-medium">{announcement.title}</h4>
                        <p className="text-sm text-gray-600 line-clamp-2">{announcement.content}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-600">No recent announcements.</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default withAdminGuard(SchoolAnalytics, { 
  requiredRoles: ['school_admin', 'district_admin', 'system_admin', 'admin'] 
});
