import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'; import Layout from '@/components/Layout';
import Login from '@/pages/Login'; import Dashboard from '@/pages/Dashboard'; import Messages from '@/pages/Messages'; import Thread from '@/pages/Thread'; import CalendarPage from '@/pages/Calendar';
import Directory from '@/pages/Directory'; import Profile from '@/pages/Profile'; import Help from '@/pages/Help'; import Onboarding from '@/pages/Onboarding';
import { useSession } from '@/hooks/useSession'; import { ensureDemoLogin } from '@/lib/demo';
function RequireAuth({children}:{children:JSX.Element}){const {user,loading}=useSession(); if(loading) return <div className='p-6'>Loading…</div>; if(!user) return <Navigate to='/login' replace/>; return children;}
export default function App(){ ensureDemoLogin(); return (<BrowserRouter><Routes><Route path='/login' element={<Login/>}/><Route path='/' element={<Navigate to='/dashboard' replace/>}/>
<Route path='/dashboard' element={<RequireAuth><Layout><Dashboard/></Layout></RequireAuth>}/>
<Route path='/messages' element={<RequireAuth><Layout><Messages/></Layout></RequireAuth>}/>
<Route path='/messages/:threadId' element={<RequireAuth><Layout><Thread/></Layout></RequireAuth>}/>
<Route path='/calendar' element={<RequireAuth><Layout><CalendarPage/></Layout></RequireAuth>}/>
<Route path='/directory' element={<RequireAuth><Layout><Directory/></Layout></RequireAuth>}/>
<Route path='/profile' element={<RequireAuth><Layout><Profile/></Layout></RequireAuth>}/>
<Route path='/onboarding' element={<RequireAuth><Layout><Onboarding/></Layout></RequireAuth>}/>
<Route path='/help' element={<RequireAuth><Layout><Help/></Layout></RequireAuth>}/>
<Route path='*' element={<Navigate to='/dashboard' replace/>}/></Routes></BrowserRouter>);}