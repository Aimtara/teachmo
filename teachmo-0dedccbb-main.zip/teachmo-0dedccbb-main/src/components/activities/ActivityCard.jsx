
import React, { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Clock,
  CheckCircle,
  Play,
  RotateCcw,
  Star,
  Target,
  Package,
  Heart,
  User,
  Bookmark,
  BookmarkCheck,
  Eye,
  Share2,
  Users as UsersIcon,
  CalendarPlus
} from "lucide-react";
import { motion } from "framer-motion";
import InviteModal from "./InviteModal";
import { User as UserEntity } from "@/api/entities";
import EventModal from "../calendar/EventModal";

const categoryColors = {
  creative: "bg-purple-100 text-purple-800",
  educational: "bg-blue-100 text-blue-800",
  physical: "bg-green-100 text-green-800",
  social: "bg-pink-100 text-pink-800",
  emotional: "bg-indigo-100 text-indigo-800",
  problem_solving: "bg-orange-100 text-orange-800",
  science: "bg-cyan-100 text-cyan-800",
  art: "bg-red-100 text-red-800",
  music: "bg-yellow-100 text-yellow-800",
  outdoor: "bg-emerald-100 text-emerald-800"
};

const statusColors = {
  suggested: "bg-blue-50 text-blue-700 border-blue-200",
  planned: "bg-yellow-50 text-yellow-700 border-yellow-200",
  completed: "bg-green-50 text-green-700 border-green-200",
  skipped: "bg-gray-50 text-gray-700 border-gray-200"
};

export default function ActivityCard({ activity, child, onStatusChange, onRating, onBookmark, onView, isPersonalized, isBookmarked }) {
  const [showCopiedMessage, setShowCopiedMessage] = useState(false);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  React.useEffect(() => {
    UserEntity.me().then(setCurrentUser);
  }, []);

  const handleStatusChange = (newStatus) => {
    onStatusChange(activity.id, newStatus);
  };

  const handleRatingClick = (rating) => {
    onRating(activity.id, rating);
  };

  const handleBookmarkClick = (e) => {
    e.stopPropagation();
    onBookmark(isBookmarked);
  };

  const handleCardClick = () => {
    if (onView) {
      onView(activity);
    }
  };

  const handleShareClick = (e) => {
    e.stopPropagation();
    const shareText = `Check out this fun activity from Teachmo:\n\nTitle: ${activity.title}\n\nDescription: ${activity.description}`;
    navigator.clipboard.writeText(shareText).then(() => {
      setShowCopiedMessage(true);
      setTimeout(() => setShowCopiedMessage(false), 2000);
    }).catch(err => {
      console.error('Failed to copy text: ', err);
    });
  };

  const handleInviteClick = (e) => {
    e.stopPropagation();
    setShowInviteModal(true);
  };

  const handleScheduleClick = (e) => {
    e.stopPropagation();
    setShowScheduleModal(true);
  };

  const getCalendarEventFromActivity = () => {
    const now = new Date();
    let durationMinutes = 30; // Default duration
    if (activity.duration) {
      const durationMatch = activity.duration.match(/\d+/g);
      if (durationMatch) {
          const times = durationMatch.map(Number);
          if (times.length > 1) {
              durationMinutes = (times[0] + times[1]) / 2;
          } else {
              durationMinutes = times[0];
          }
      }
    }
    const endTime = new Date(now.getTime() + durationMinutes * 60000);

    return {
      title: activity.title,
      description: activity.description,
      start_time: now.toISOString(),
      end_time: endTime.toISOString(),
      resource_id: activity.id,
      resource_type: 'activity',
      child_id: child?.id,
      color: child?.color || '#6B9DC8'
    };
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        whileHover={{ y: -4 }}
        transition={{ duration: 0.2 }}
      >
        <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm hover:shadow-xl transition-all duration-300 h-full flex flex-col">
          <div onClick={handleCardClick} className="cursor-pointer group flex-grow">
            <CardHeader className="pb-4">
              {/* Enhanced badge display with better mobile layout */}
              <div className="flex items-start justify-between mb-2 gap-2">
                <div className="flex flex-wrap gap-1.5 min-w-0 flex-1">
                  <Badge className={categoryColors[activity.category] || "bg-gray-100 text-gray-900"}>
                    {activity.category?.replace(/_/g, ' ')}
                  </Badge>
                  <Badge variant="outline" className={statusColors[activity.status]}>
                    {activity.status}
                  </Badge>
                  
                  {/* Quick-read labels with improved contrast */}
                  {activity.duration && (
                    <Badge variant="outline" className="bg-blue-50 text-blue-800 border-blue-200 text-xs">
                      {activity.duration}
                    </Badge>
                  )}
                  
                  {activity.materials_needed && activity.materials_needed.length === 0 && (
                    <Badge variant="outline" className="bg-green-50 text-green-800 border-green-200 text-xs">
                      No materials
                    </Badge>
                  )}
                  
                  {activity.is_sponsored && (
                    <Badge className="bg-yellow-100 text-yellow-900 border border-yellow-200 text-xs">
                      <Star className="w-3 h-3 mr-1" aria-hidden="true" />
                      Sponsored
                    </Badge>
                  )}
                  
                  {isPersonalized && child && (
                    <Badge className="bg-gradient-to-r from-pink-500 to-purple-500 text-white text-xs">
                      <Heart className="w-3 h-3 mr-1" aria-hidden="true" />
                      <span className="hidden sm:inline">For {child.name}</span>
                      <span className="sm:hidden">{child.name}</span>
                    </Badge>
                  )}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleBookmarkClick}
                  className="text-gray-500 hover:text-gray-700 p-2 flex-shrink-0 z-10 touch-target"
                  aria-label={isBookmarked ? `Remove ${activity.title} from bookmarks` : `Add ${activity.title} to bookmarks`}
                >
                  {isBookmarked ? (
                    <BookmarkCheck className="w-4 h-4 text-blue-600" aria-hidden="true" />
                  ) : (
                    <Bookmark className="w-4 h-4" aria-hidden="true" />
                  )}
                </Button>
              </div>

              <div>
                <h3 className="font-bold text-base sm:text-lg text-gray-900 leading-tight group-hover:text-blue-600 transition-colors line-clamp-2">
                  {activity.title}
                </h3>

                {child && (
                  <div className="flex items-center gap-2 mt-2">
                    <div
                      className="w-5 h-5 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                      style={{ backgroundColor: child.color || 'var(--teachmo-coral)' }}
                      aria-hidden="true"
                    >
                      {child.avatar || child.name[0].toUpperCase()}
                    </div>
                    <p className="text-sm text-gray-700 truncate">
                      For {child.name} ({child.age} years old)
                    </p>
                  </div>
                )}
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              <p className="text-gray-700 text-sm leading-relaxed line-clamp-3">
                {activity.description}
              </p>

              {/* Enhanced material display */}
              {activity.materials_needed && activity.materials_needed.length > 0 && (
                <div>
                  <p className="text-sm font-medium text-gray-800 mb-2 flex items-center gap-1">
                    <Package className="w-3 h-3 flex-shrink-0" aria-hidden="true" />
                    Materials ({activity.materials_needed.length})
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {activity.materials_needed.slice(0, 3).map((material, index) => (
                      <Badge key={index} variant="outline" className="text-xs bg-gray-50 truncate max-w-20">
                        {material}
                      </Badge>
                    ))}
                    {activity.materials_needed.length > 3 && (
                      <Badge variant="outline" className="text-xs bg-gray-50">
                        +{activity.materials_needed.length - 3}
                      </Badge>
                    )}
                  </div>
                </div>
              )}

              {activity.why_it_matters && (
                <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                  <p className="text-sm font-medium text-blue-900 mb-1 flex items-center gap-1">
                    <Target className="w-3 h-3 flex-shrink-0" aria-hidden="true" />
                    Why This Matters
                  </p>
                  <p className="text-xs text-blue-800 line-clamp-2">{activity.why_it_matters}</p>
                </div>
              )}

              {activity.teachmo_tip && (
                <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-3 rounded-lg border border-purple-100">
                  <p className="text-sm font-medium text-purple-900 mb-1 flex items-center gap-1">
                    <Heart className="w-3 h-3 text-purple-600 flex-shrink-0" />
                    Teachmo Tip
                  </p>
                  <p className="text-xs text-purple-800 line-clamp-2">{activity.teachmo_tip}</p>
                </div>
              )}

              {activity.learning_objectives && activity.learning_objectives.length > 0 && (
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-2 flex items-center gap-1">
                    <Target className="w-3 h-3 flex-shrink-0" />
                    Learning Goals
                  </p>
                  <div className="space-y-1">
                    {activity.learning_objectives.slice(0, 2).map((objective, index) => (
                      <p key={index} className="text-xs text-gray-600 bg-green-50 px-2 py-1 rounded line-clamp-1">
                        {objective}
                      </p>
                    ))}
                    {activity.learning_objectives.length > 2 && (
                      <p className="text-xs text-gray-500">
                        +{activity.learning_objectives.length - 2} more goals
                      </p>
                    )}
                  </div>
                </div>
              )}

              {(!activity.why_it_matters || !activity.teachmo_tip) && (
                <div className="bg-yellow-50 p-2 rounded-lg border border-yellow-200">
                  <p className="text-xs text-yellow-800 flex items-center gap-1">
                    <Eye className="w-3 h-3 flex-shrink-0" aria-hidden="true" />
                    <span className="line-clamp-2">Click card for full details and tips</span>
                  </p>
                </div>
              )}
            </CardContent>
          </div>

          <div className="p-4 pt-0">
            {/* Enhanced rating section */}
            {activity.status === 'completed' && (
              <div className="mb-4">
                <p className="text-sm font-medium text-gray-800 mb-2">Rate this activity:</p>
                <div className="flex items-center gap-1" role="group" aria-label="Rate this activity">
                  {[1, 2, 3, 4, 5].map((rating) => (
                    <button
                      key={rating}
                      className={`w-8 h-8 flex items-center justify-center rounded touch-target transition-colors ${
                        rating <= (activity.rating || 0)
                          ? 'text-yellow-400'
                          : 'text-gray-300 hover:text-yellow-300'
                      }`}
                      onClick={(e) => { e.stopPropagation(); handleRatingClick(rating); }}
                      aria-label={`Rate ${rating} out of 5 stars`}
                    >
                      <Star
                        className={`w-5 h-5 ${
                          rating <= (activity.rating || 0) ? 'fill-current' : ''
                        }`}
                        aria-hidden="true"
                      />
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="flex flex-col gap-2 pt-2">
              {/* Enhanced action buttons with better touch targets */}
              {activity.status === 'suggested' && (
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={(e) => { e.stopPropagation(); handleStatusChange('planned'); }}
                    className="flex-1 text-sm min-h-[44px]"
                    style={{ backgroundColor: 'var(--teachmo-blue)', color: 'white' }}
                    aria-label={`Plan ${activity.title} activity`}
                  >
                    <Play className="w-4 h-4 mr-1" aria-hidden="true" />
                    <span className="hidden sm:inline">Plan this Activity</span>
                    <span className="sm:hidden">Plan</span>
                  </Button>
                </div>
              )}

              {activity.status === 'planned' && (
                <div className="flex flex-col gap-2">
                  <Button
                    size="sm"
                    onClick={(e) => { e.stopPropagation(); handleStatusChange('completed'); }}
                    className="w-full bg-green-600 hover:bg-green-700 text-sm min-h-[44px]"
                    aria-label={`Mark ${activity.title} as complete`}
                  >
                    <CheckCircle className="w-4 h-4 mr-1" aria-hidden="true" />
                    Complete
                  </Button>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleScheduleClick}
                      className="text-xs sm:text-sm min-h-[44px]"
                      aria-label={`Schedule ${activity.title}`}
                    >
                      <CalendarPlus className="w-4 h-4 mr-1" aria-hidden="true" />
                      Schedule
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={(e) => { e.stopPropagation(); handleStatusChange('suggested'); }}
                      className="text-xs sm:text-sm min-h-[44px]"
                      aria-label={`Reset ${activity.title} to suggested`}
                    >
                      <RotateCcw className="w-4 h-4 mr-1" aria-hidden="true" />
                      Reset
                    </Button>
                  </div>
                </div>
              )}

              {activity.status === 'completed' && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleStatusChange('planned')}
                  className="w-full text-sm min-h-[44px]"
                  aria-label={`Do ${activity.title} again`}
                >
                  <RotateCcw className="w-4 h-4 mr-1" aria-hidden="true" />
                  Do Again
                </Button>
              )}

              {activity.status === 'skipped' && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleStatusChange('suggested')}
                  className="w-full text-sm min-h-[44px]"
                  aria-label={`Reconsider ${activity.title}`}
                >
                  <RotateCcw className="w-4 h-4 mr-1" aria-hidden="true" />
                  Reconsider
                </Button>
              )}
            </div>

            {/* Enhanced bottom action bar */}
            <div className="border-t border-gray-100 pt-3 mt-4 flex items-center justify-around">
               <Button
                size="sm"
                variant="ghost"
                onClick={handleCardClick}
                className="text-gray-600 hover:bg-gray-100 flex-1 text-xs sm:text-sm min-h-[44px]"
                aria-label={`View details for ${activity.title}`}
              >
                <Eye className="w-4 h-4 mr-1 sm:mr-2" aria-hidden="true" />
                Details
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={handleShareClick}
                className="text-gray-600 hover:bg-gray-100 flex-1 text-xs sm:text-sm min-h-[44px]"
                aria-label={`Share ${activity.title}`}
              >
                <Share2 className="w-4 h-4 mr-1 sm:mr-2" aria-hidden="true" />
                Share
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={handleInviteClick}
                className="text-gray-600 hover:bg-gray-100 flex-1 text-xs sm:text-sm min-h-[44px]"
                aria-label={`Invite others to ${activity.title}`}
              >
                <UsersIcon className="w-4 h-4 mr-1 sm:mr-2" aria-hidden="true" />
                Invite
              </Button>
              {showCopiedMessage && (
                <span className="text-xs text-green-600 absolute bg-white px-2 py-1 rounded shadow" role="status" aria-live="polite">
                  Copied!
                </span>
              )}
            </div>
          </div>
        </Card>
      </motion.div>
      {showInviteModal && currentUser && (
        <InviteModal
          resource={activity}
          resourceType="activity"
          currentUser={currentUser}
          onClose={() => setShowInviteModal(false)}
        />
      )}
      {showScheduleModal && currentUser && (
        <EventModal
          event={getCalendarEventFromActivity()}
          user={currentUser}
          onClose={() => setShowScheduleModal(false)}
        />
      )}
    </>
  );
}
