import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useSupabaseOperations } from '@/components/hooks/useSupabase';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Database, Users, Upload } from 'lucide-react';

export default function SupabaseExample() {
  const { isConfigured, user, auth, db, storage } = useSupabaseOperations();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [error, setError] = useState(null);
  
  // Authentication form state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  // Database form state
  const [newItem, setNewItem] = useState('');

  // Example: Fetch data from a Supabase table
  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Example table name - replace with your actual table
      const { data: items, error } = await db.select('example_table');
      
      if (error) throw error;
      setData(items || []);
    } catch (err) {
      setError(err.message);
      console.error('Error fetching data:', err);
    } finally {
      setLoading(false);
    }
  };

  // Example: Insert data into Supabase table
  const insertData = async () => {
    if (!newItem.trim()) return;
    
    try {
      setLoading(true);
      setError(null);
      
      const { error } = await db.insert('example_table', {
        name: newItem,
        created_at: new Date().toISOString(),
      });
      
      if (error) throw error;
      
      setNewItem('');
      await fetchData(); // Refresh the data
    } catch (err) {
      setError(err.message);
      console.error('Error inserting data:', err);
    } finally {
      setLoading(false);
    }
  };

  // Example: Sign in with Supabase Auth
  const handleSignIn = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const { error } = await auth.signIn(email, password);
      if (error) throw error;
      
      setEmail('');
      setPassword('');
    } catch (err) {
      setError(err.message);
      console.error('Error signing in:', err);
    } finally {
      setLoading(false);
    }
  };

  // Example: Sign out
  const handleSignOut = async () => {
    try {
      setLoading(true);
      const { error } = await auth.signOut();
      if (error) throw error;
    } catch (err) {
      setError(err.message);
      console.error('Error signing out:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isConfigured && user) {
      fetchData();
    }
  }, [isConfigured, user]);

  if (!isConfigured) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5" />
            Supabase Configuration
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Alert>
            <AlertDescription>
              Supabase is not configured. Please set the following environment variables in your Base44 dashboard:
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li><code>VITE_SUPABASE_URL</code> - Your Supabase project URL</li>
                <li><code>VITE_SUPABASE_ANON_KEY</code> - Your Supabase anonymous key</li>
              </ul>
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5" />
            Supabase Integration Example
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600">
            This example demonstrates basic Supabase operations including authentication and database interactions.
          </p>
        </CardContent>
      </Card>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Authentication Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Authentication
          </CardTitle>
        </CardHeader>
        <CardContent>
          {user ? (
            <div className="space-y-4">
              <p>Signed in as: <strong>{user.email}</strong></p>
              <Button onClick={handleSignOut} disabled={loading}>
                {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Sign Out
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  type="email"
                  placeholder="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                <Input
                  type="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <Button onClick={handleSignIn} disabled={loading || !email || !password}>
                {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Sign In
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Database Operations Section */}
      {user && (
        <Card>
          <CardHeader>
            <CardTitle>Database Operations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Add new item..."
                  value={newItem}
                  onChange={(e) => setNewItem(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && insertData()}
                />
                <Button onClick={insertData} disabled={loading || !newItem.trim()}>
                  {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                  Add
                </Button>
              </div>
              
              <div>
                <h4 className="font-semibold mb-2">Data from Supabase:</h4>
                {loading ? (
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Loading...
                  </div>
                ) : data.length > 0 ? (
                  <ul className="space-y-1">
                    {data.map((item, index) => (
                      <li key={index} className="p-2 bg-gray-100 rounded">
                        {item.name}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-gray-500">No data found</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}