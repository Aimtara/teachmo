import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { X, School, MapPin, Phone, Mail, Globe } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function CreateSchoolModal({ onSave, onCancel }) {
  const [formData, setFormData] = useState({
    name: '',
    school_type: '',
    status: 'pilot',
    address: '',
    phone: '',
    email: '',
    website: '',
    grade_levels: [],
    student_count: '',
    teacher_count: '',
    pilot_start_date: '',
    pilot_end_date: ''
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const schoolTypes = [
    { value: 'elementary', label: 'Elementary School' },
    { value: 'middle', label: 'Middle School' },
    { value: 'high', label: 'High School' },
    { value: 'k12', label: 'K-12 School' },
    { value: 'other', label: 'Other' }
  ];

  const statusOptions = [
    { value: 'pilot', label: 'Pilot School', description: 'Testing the platform' },
    { value: 'independent', label: 'Independent School', description: 'Not part of a district' }
  ];

  const gradeLevels = ['K', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: null }));
    }
  };

  const toggleGradeLevel = (grade) => {
    setFormData(prev => ({
      ...prev,
      grade_levels: prev.grade_levels.includes(grade)
        ? prev.grade_levels.filter(g => g !== grade)
        : [...prev.grade_levels, grade]
    }));
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'School name is required';
    }

    if (!formData.school_type) {
      newErrors.school_type = 'School type is required';
    }

    if (formData.email && !/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }

    if (formData.website && !/^https?:\/\/.+/.test(formData.website)) {
      newErrors.website = 'Website must start with http:// or https://';
    }

    if (formData.status === 'pilot') {
      if (!formData.pilot_start_date) {
        newErrors.pilot_start_date = 'Pilot start date is required for pilot schools';
      }
      if (!formData.pilot_end_date) {
        newErrors.pilot_end_date = 'Pilot end date is required for pilot schools';
      }
      if (formData.pilot_start_date && formData.pilot_end_date && 
          new Date(formData.pilot_start_date) >= new Date(formData.pilot_end_date)) {
        newErrors.pilot_end_date = 'Pilot end date must be after start date';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validate()) return;

    setIsSubmitting(true);
    try {
      const schoolData = {
        ...formData,
        student_count: formData.student_count ? parseInt(formData.student_count) : 0,
        teacher_count: formData.teacher_count ? parseInt(formData.teacher_count) : 0
      };

      await onSave(schoolData);
    } catch (error) {
      console.error('Error creating school:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onCancel}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          onClick={(e) => e.stopPropagation()}
          className="max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        >
          <Card className="shadow-2xl">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                  <School className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <CardTitle>Create New School</CardTitle>
                  <p className="text-sm text-gray-600">Add a new school to the platform</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={onCancel}>
                <X className="w-4 h-4" />
              </Button>
            </CardHeader>

            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Basic Information */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900">Basic Information</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">School Name *</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        className={errors.name ? 'border-red-500' : ''}
                        placeholder="Lincoln Elementary School"
                      />
                      {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
                    </div>

                    <div>
                      <Label htmlFor="school_type">School Type *</Label>
                      <Select value={formData.school_type} onValueChange={(value) => handleInputChange('school_type', value)}>
                        <SelectTrigger className={errors.school_type ? 'border-red-500' : ''}>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          {schoolTypes.map(type => (
                            <SelectItem key={type.value} value={type.value}>
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.school_type && <p className="text-red-500 text-sm mt-1">{errors.school_type}</p>}
                    </div>
                  </div>

                  {/* Status Selection */}
                  <div>
                    <Label>School Status *</Label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
                      {statusOptions.map(option => (
                        <div
                          key={option.value}
                          onClick={() => handleInputChange('status', option.value)}
                          className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                            formData.status === option.value
                              ? 'border-blue-500 bg-blue-50'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                        >
                          <h4 className="font-semibold text-gray-900">{option.label}</h4>
                          <p className="text-sm text-gray-600 mt-1">{option.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Pilot Dates (conditional) */}
                  {formData.status === 'pilot' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-orange-50 rounded-lg border border-orange-200">
                      <div>
                        <Label htmlFor="pilot_start_date">Pilot Start Date *</Label>
                        <Input
                          id="pilot_start_date"
                          type="date"
                          value={formData.pilot_start_date}
                          onChange={(e) => handleInputChange('pilot_start_date', e.target.value)}
                          className={errors.pilot_start_date ? 'border-red-500' : ''}
                        />
                        {errors.pilot_start_date && <p className="text-red-500 text-sm mt-1">{errors.pilot_start_date}</p>}
                      </div>

                      <div>
                        <Label htmlFor="pilot_end_date">Pilot End Date *</Label>
                        <Input
                          id="pilot_end_date"
                          type="date"
                          value={formData.pilot_end_date}
                          onChange={(e) => handleInputChange('pilot_end_date', e.target.value)}
                          className={errors.pilot_end_date ? 'border-red-500' : ''}
                        />
                        {errors.pilot_end_date && <p className="text-red-500 text-sm mt-1">{errors.pilot_end_date}</p>}
                      </div>
                    </div>
                  )}
                </div>

                {/* Contact Information */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900">Contact Information</h3>
                  
                  <div>
                    <Label htmlFor="address">Address</Label>
                    <Textarea
                      id="address"
                      value={formData.address}
                      onChange={(e) => handleInputChange('address', e.target.value)}
                      placeholder="123 Education St, Learning City, LC 12345"
                      rows={2}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="phone">Phone Number</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                        <Input
                          id="phone"
                          value={formData.phone}
                          onChange={(e) => handleInputChange('phone', e.target.value)}
                          placeholder="(555) 123-4567"
                          className="pl-10"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => handleInputChange('email', e.target.value)}
                          placeholder="contact@school.edu"
                          className={`pl-10 ${errors.email ? 'border-red-500' : ''}`}
                        />
                      </div>
                      {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="website">Website</Label>
                    <div className="relative">
                      <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        id="website"
                        value={formData.website}
                        onChange={(e) => handleInputChange('website', e.target.value)}
                        placeholder="https://www.school.edu"
                        className={`pl-10 ${errors.website ? 'border-red-500' : ''}`}
                      />
                    </div>
                    {errors.website && <p className="text-red-500 text-sm mt-1">{errors.website}</p>}
                  </div>
                </div>

                {/* School Details */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900">School Details</h3>
                  
                  <div>
                    <Label>Grade Levels Served</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {gradeLevels.map(grade => (
                        <Badge
                          key={grade}
                          variant={formData.grade_levels.includes(grade) ? 'default' : 'outline'}
                          className="cursor-pointer hover:bg-gray-100"
                          onClick={() => toggleGradeLevel(grade)}
                        >
                          {grade}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="student_count">Student Count (Optional)</Label>
                      <Input
                        id="student_count"
                        type="number"
                        value={formData.student_count}
                        onChange={(e) => handleInputChange('student_count', e.target.value)}
                        placeholder="500"
                        min="0"
                      />
                    </div>

                    <div>
                      <Label htmlFor="teacher_count">Teacher Count (Optional)</Label>
                      <Input
                        id="teacher_count"
                        type="number"
                        value={formData.teacher_count}
                        onChange={(e) => handleInputChange('teacher_count', e.target.value)}
                        placeholder="25"
                        min="0"
                      />
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex justify-end gap-3 pt-4 border-t">
                  <Button type="button" variant="outline" onClick={onCancel} disabled={isSubmitting}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? 'Creating...' : 'Create School'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}