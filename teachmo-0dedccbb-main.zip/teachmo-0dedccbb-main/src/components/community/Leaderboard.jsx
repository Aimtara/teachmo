
import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Trophy, Star } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function Leaderboard() {
  const [topParents, setTopParents] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchTopParents = async () => {
      setIsLoading(true);
      try {
        // Fetch users and sort by points. For a real "weekly" leaderboard,
        // we'd need more complex logic, but this is a great start.
        const users = await User.list('-points', 5);
        setTopParents(users);
      } catch (error) {
        console.error("Error fetching leaderboard data:", error);
      }
      setIsLoading(false);
    };
    fetchTopParents();
  }, []);

  const getRankColor = (rank) => {
    if (rank === 0) return "text-yellow-500";
    if (rank === 1) return "text-gray-400";
    if (rank === 2) return "text-orange-400";
    return "text-gray-500";
  };

  return (
    <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trophy style={{color: 'var(--teachmo-sage)'}}/>
          Top Parents This Week
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center gap-4">
                <Skeleton className="w-8 h-8 rounded-full" />
                <Skeleton className="h-6 w-3/4" />
              </div>
            ))}
          </div>
        ) : (
          <ul className="space-y-4">
            {topParents.map((parent, index) => (
              <li key={parent.id} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Trophy className={`w-6 h-6 ${getRankColor(index)}`} />
                  {parent.avatar_url ? (
                    <img src={parent.avatar_url} alt={parent.full_name} className="w-8 h-8 rounded-full object-cover" />
                  ) : (
                    <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-blue)'}}>
                      <span className="text-white font-semibold text-sm">{parent.full_name[0]}</span>
                    </div>
                  )}
                  <p className="font-medium text-gray-800">{parent.full_name}</p>
                </div>
                <div className="flex items-center gap-1 font-bold text-yellow-600">
                  <Star className="w-4 h-4" />
                  {parent.points}
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
