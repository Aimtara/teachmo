
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, CalendarIcon, Save, Users, Loader2 } from 'lucide-react';
import { format, set } from 'date-fns';
import { CalendarEvent } from '@/api/entities';
import { Child } from '@/api/entities';

export default function EventModal({ event, user, onClose, childrenData, defaultChildId }) {
    // Consolidated state for event details
    const [currentEvent, setCurrentEvent] = useState(() => {
        if (event) {
            const initialStartDate = event.start_time && !isNaN(new Date(event.start_time)) ? new Date(event.start_time) : new Date();
            const initialEndDateCandidate = event.end_time && !isNaN(new Date(event.end_time)) ? new Date(event.end_time) : initialStartDate;
            const initialEndDate = initialEndDateCandidate > initialStartDate ? initialEndDateCandidate : initialStartDate;

            return {
                title: event.title || '',
                description: event.description || '',
                location: event.location || '',
                start_time: initialStartDate,
                end_time: initialEndDate,
                all_day: event.all_day || false,
                color: event.color || '#6B9DC8',
                child_id: event.child_id || defaultChildId || null,
                reminder_opt_in: event.reminder_opt_in ?? true, // Default to true if not present
                resource_id: event.resource_id,
                resource_type: event.resource_type || 'custom',
                user_id: user.id // Ensure user_id is always present
            };
        } else {
            const now = new Date();
            const oneHourLater = new Date(now.getTime() + 60 * 60 * 1000);
            return {
                title: '',
                description: '',
                location: '',
                start_time: now,
                end_time: oneHourLater,
                all_day: false,
                color: childrenData.find(c => c.id === defaultChildId)?.color || '#6B9DC8',
                child_id: defaultChildId || null,
                reminder_opt_in: true,
                user_id: user.id,
                resource_type: 'custom',
                resource_id: null,
            };
        }
    });

    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    // Effect to update currentEvent when initial event prop changes or on new event setup
    useEffect(() => {
        if (event) {
            const initialStartDate = event.start_time && !isNaN(new Date(event.start_time)) ? new Date(event.start_time) : new Date();
            const initialEndDateCandidate = event.end_time && !isNaN(new Date(event.end_time)) ? new Date(event.end_time) : initialStartDate;
            const initialEndDate = initialEndDateCandidate > initialStartDate ? initialEndDateCandidate : initialStartDate;

            setCurrentEvent({
                title: event.title || '',
                description: event.description || '',
                location: event.location || '',
                start_time: initialStartDate,
                end_time: initialEndDate,
                all_day: event.all_day || false,
                color: event.color || '#6B9DC8',
                child_id: event.child_id || defaultChildId || null,
                reminder_opt_in: event.reminder_opt_in ?? true,
                resource_id: event.resource_id,
                resource_type: event.resource_type || 'custom',
                user_id: user.id
            });
        } else {
            const now = new Date();
            const oneHourLater = new Date(now.getTime() + 60 * 60 * 1000);
            setCurrentEvent({
                title: '',
                description: '',
                location: '',
                start_time: now,
                end_time: oneHourLater,
                all_day: false,
                color: childrenData.find(c => c.id === defaultChildId)?.color || '#6B9DC8',
                child_id: defaultChildId || null,
                reminder_opt_in: true,
                user_id: user.id,
                resource_type: 'custom',
                resource_id: null,
            });
        }
    }, [event, defaultChildId, user.id, childrenData]);

    const handleSave = async () => {
        setIsLoading(true);
        setError('');

        // Basic validation: end time must not be before start time
        if (currentEvent.end_time < currentEvent.start_time) {
            setError('End time cannot be before start time.');
            setIsLoading(false);
            return;
        }

        // Prepare data for API call (convert Date objects to ISO strings)
        const eventData = {
            ...currentEvent,
            start_time: currentEvent.start_time.toISOString(),
            end_time: currentEvent.end_time.toISOString(),
            // Ensure child_id is number or null
            child_id: currentEvent.child_id ? Number(currentEvent.child_id) : null,
            // Explicitly ensure user_id is always set for new events and updates
            user_id: user.id
        };

        try {
            if (event?.id) { // Check if 'event' prop has an 'id' indicating an existing event
                await CalendarEvent.update(event.id, eventData);
            } else {
                await CalendarEvent.create(eventData);
            }
            onClose(); // Close modal after successful save
        } catch (err) {
            console.error('Error saving event:', err);
            setError('Failed to save event. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <AnimatePresence>
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
                onClick={onClose}
            >
                <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="relative bg-white rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto"
                    onClick={(e) => e.stopPropagation()}
                >
                    <div className="p-6">
                        <div className="flex justify-between items-center mb-6">
                            <h3 className="text-xl font-bold text-gray-900">{event?.id ? 'Edit Event' : 'Create Event'}</h3>
                            <Button variant="ghost" size="icon" onClick={onClose}><X className="w-5 h-5" /></Button>
                        </div>
                        
                        <div className="space-y-4">
                            <Input
                                placeholder="Event Title"
                                value={currentEvent.title}
                                onChange={(e) => setCurrentEvent(prev => ({ ...prev, title: e.target.value }))}
                            />
                            <Textarea
                                placeholder="Description"
                                value={currentEvent.description}
                                onChange={(e) => setCurrentEvent(prev => ({ ...prev, description: e.target.value }))}
                                rows={3}
                            />
                            
                            <div>
                                <Label htmlFor="location">Location</Label>
                                <div className="relative">
                                    <Input
                                        id="location"
                                        placeholder="Event Address"
                                        value={currentEvent.location}
                                        onChange={(e) => setCurrentEvent(prev => ({ ...prev, location: e.target.value }))}
                                    />
                                </div>
                            </div>

                             <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <Label>For Child</Label>
                                     <Select
                                        value={currentEvent.child_id === null ? "family-event" : String(currentEvent.child_id)}
                                        onValueChange={(value) => setCurrentEvent(prev => ({ ...prev, child_id: value === 'family-event' ? null : Number(value) }))}
                                    >
                                        <SelectTrigger>
                                            <div className="flex items-center gap-2">
                                                <Users className="w-4 h-4" />
                                                <SelectValue placeholder="Select a child..." />
                                            </div>
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value={'family-event'}>Family Event</SelectItem>
                                            {childrenData && childrenData.map(child => (
                                                <SelectItem key={child.id} value={String(child.id)}>
                                                    <div className="flex items-center gap-2">
                                                        <div className="w-3 h-3 rounded-full" style={{backgroundColor: child.color}}></div>
                                                        {child.name}
                                                    </div>
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="flex items-center gap-2 pt-6">
                                    <Switch
                                        id="all-day"
                                        checked={currentEvent.all_day}
                                        onCheckedChange={(checked) => setCurrentEvent(prev => ({ ...prev, all_day: checked }))}
                                    />
                                    <Label htmlFor="all-day">All-day event</Label>
                                </div>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <Label>Start Date</Label>
                                    <Popover>
                                        <PopoverTrigger asChild>
                                            <Button variant="outline" className="w-full justify-start font-normal">
                                                <CalendarIcon className="mr-2 h-4 w-4" />
                                                {format(currentEvent.start_time, 'PPP')}
                                            </Button>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-auto p-0">
                                            <Calendar
                                                mode="single"
                                                selected={currentEvent.start_time}
                                                onSelect={(date) => setCurrentEvent(prev => ({ ...prev, start_time: date || prev.start_time }))}
                                            />
                                        </PopoverContent>
                                    </Popover>
                                </div>
                                <div>
                                    <Label>Start Time</Label>
                                    <Input
                                        type="time"
                                        value={format(currentEvent.start_time, 'HH:mm')}
                                        onChange={e => {
                                            const [hours, minutes] = e.target.value.split(':');
                                            setCurrentEvent(prev => ({
                                                ...prev,
                                                start_time: set(prev.start_time, { hours: parseInt(hours), minutes: parseInt(minutes) })
                                            }));
                                        }}
                                        disabled={currentEvent.all_day}
                                    />
                                </div>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <Label>End Date</Label>
                                    <Popover>
                                        <PopoverTrigger asChild>
                                            <Button variant="outline" className="w-full justify-start font-normal">
                                                <CalendarIcon className="mr-2 h-4 w-4" />
                                                {format(currentEvent.end_time, 'PPP')}
                                            </Button>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-auto p-0">
                                            <Calendar
                                                mode="single"
                                                selected={currentEvent.end_time}
                                                onSelect={(date) => setCurrentEvent(prev => ({ ...prev, end_time: date || prev.end_time }))}
                                            />
                                        </PopoverContent>
                                    </Popover>
                                </div>
                                <div>
                                    <Label>End Time</Label>
                                    <Input
                                        type="time"
                                        value={format(currentEvent.end_time, 'HH:mm')}
                                        onChange={e => {
                                            const [hours, minutes] = e.target.value.split(':');
                                            setCurrentEvent(prev => ({
                                                ...prev,
                                                end_time: set(prev.end_time, { hours: parseInt(hours), minutes: parseInt(minutes) })
                                            }));
                                        }}
                                        disabled={currentEvent.all_day}
                                    />
                                </div>
                            </div>
                            
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                    <Label>Color</Label>
                                    <Input
                                        type="color"
                                        value={currentEvent.color}
                                        onChange={e => setCurrentEvent(prev => ({ ...prev, color: e.target.value }))}
                                        className="w-10 h-10 p-1"
                                    />
                                </div>
                            </div>

                            <div className="flex items-center justify-between rounded-lg border p-3 shadow-sm">
                                  <div className="space-y-0.5">
                                    <Label htmlFor="reminder-switch" className="font-medium">Event Reminder</Label>
                                    <p className="text-[0.8rem] text-muted-foreground">
                                      Receive a notification before this event starts.
                                    </p>
                                  </div>
                                  <Switch
                                    id="reminder-switch"
                                    checked={currentEvent.reminder_opt_in}
                                    onCheckedChange={(checked) => setCurrentEvent(prev => ({ ...prev, reminder_opt_in: checked }))}
                                  />
                            </div>

                            {error && <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>}

                            <div className="flex justify-end gap-3 pt-4">
                                <Button variant="outline" onClick={onClose}>Cancel</Button>
                                <Button onClick={handleSave} disabled={isLoading}>
                                  {isLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                                  {event?.id ? 'Save Changes' : 'Create Event'}
                                </Button>
                            </div>
                        </div>
                    </div>
                </motion.div>
            </motion.div>
        </AnimatePresence>
    );
}
