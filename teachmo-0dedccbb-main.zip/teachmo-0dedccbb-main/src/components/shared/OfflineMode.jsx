import React, { useState, useEffect } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { WifiOff, Wifi, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const OfflineBanner = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showOfflineAlert, setShowOfflineAlert] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setShowOfflineAlert(false);
    };

    const handleOffline = () => {
      setIsOnline(false);
      setShowOfflineAlert(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Check initial state
    if (!navigator.onLine) {
      setShowOfflineAlert(true);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleRetry = () => {
    window.location.reload();
  };

  return (
    <AnimatePresence>
      {showOfflineAlert && (
        <motion.div
          initial={{ opacity: 0, y: -100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -100 }}
          className="fixed top-0 left-0 right-0 z-50 p-4"
        >
          <Alert className="bg-orange-50 border-orange-200 text-orange-800 shadow-lg max-w-md mx-auto">
            <WifiOff className="h-4 w-4" />
            <AlertDescription className="flex items-center justify-between">
              <span>You're currently offline</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleRetry}
                className="text-orange-800 hover:bg-orange-100"
              >
                <RefreshCw className="w-4 h-4 mr-1" />
                Retry
              </Button>
            </AlertDescription>
          </Alert>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export const OfflineStorage = {
  // Simple offline storage utilities
  set: (key, data) => {
    try {
      localStorage.setItem(`teachmo_offline_${key}`, JSON.stringify({
        data,
        timestamp: Date.now()
      }));
    } catch (error) {
      console.warn('Failed to store offline data:', error);
    }
  },

  get: (key, maxAge = 24 * 60 * 60 * 1000) => { // 24 hours default
    try {
      const stored = localStorage.getItem(`teachmo_offline_${key}`);
      if (!stored) return null;

      const { data, timestamp } = JSON.parse(stored);
      
      // Check if data is still fresh
      if (Date.now() - timestamp > maxAge) {
        localStorage.removeItem(`teachmo_offline_${key}`);
        return null;
      }

      return data;
    } catch (error) {
      console.warn('Failed to retrieve offline data:', error);
      return null;
    }
  },

  remove: (key) => {
    localStorage.removeItem(`teachmo_offline_${key}`);
  },

  clear: () => {
    Object.keys(localStorage)
      .filter(key => key.startsWith('teachmo_offline_'))
      .forEach(key => localStorage.removeItem(key));
  }
};

export const useOfflineSync = () => {
  const [pendingActions, setPendingActions] = useState([]);

  useEffect(() => {
    // Load pending actions from storage
    const stored = OfflineStorage.get('pending_actions', Infinity);
    if (stored && Array.isArray(stored)) {
      setPendingActions(stored);
    }
  }, []);

  const addPendingAction = (action) => {
    const updated = [...pendingActions, { ...action, id: Date.now(), timestamp: Date.now() }];
    setPendingActions(updated);
    OfflineStorage.set('pending_actions', updated);
  };

  const syncPendingActions = async () => {
    if (!navigator.onLine || pendingActions.length === 0) return;

    const successful = [];
    const failed = [];

    for (const action of pendingActions) {
      try {
        // Attempt to execute the pending action
        await action.execute();
        successful.push(action.id);
      } catch (error) {
        console.error('Failed to sync action:', action, error);
        failed.push(action.id);
      }
    }

    // Remove successful actions
    const remaining = pendingActions.filter(action => !successful.includes(action.id));
    setPendingActions(remaining);
    OfflineStorage.set('pending_actions', remaining);

    return { successful: successful.length, failed: failed.length };
  };

  return {
    pendingActions,
    addPendingAction,
    syncPendingActions,
    hasPendingActions: pendingActions.length > 0
  };
};