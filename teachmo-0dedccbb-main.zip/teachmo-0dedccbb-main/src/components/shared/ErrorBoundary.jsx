import React from 'react';
import { Button } from '@/components/ui/button';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({ errorInfo });
    // You can also log the error to an error reporting service
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen w-full flex flex-col items-center justify-center p-4" style={{backgroundColor: 'var(--teachmo-cream)'}}>
            <Card className="max-w-lg w-full shadow-lg border-red-200">
                <CardHeader>
                    <CardTitle className="flex items-center gap-3 text-red-600">
                        <AlertTriangle className="w-8 h-8"/>
                        <span className="text-2xl">Oops! Something went wrong.</span>
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-gray-700 mb-6">
                        We're sorry, but the application has encountered an unexpected error. Please try refreshing the page. If the problem persists, please contact our support team.
                    </p>
                    <div className="flex justify-center">
                        <Button onClick={() => window.location.reload()}>
                            <RefreshCw className="w-4 h-4 mr-2"/>
                            Refresh Page
                        </Button>
                    </div>
                    {process.env.NODE_ENV === 'development' && (
                        <details className="mt-6 text-left bg-gray-50 p-3 rounded-lg">
                            <summary className="cursor-pointer font-medium text-gray-700">Error Details</summary>
                            <pre className="mt-2 text-xs text-red-700 whitespace-pre-wrap break-words">
                                {this.state.error && this.state.error.toString()}
                                <br />
                                {this.state.errorInfo && this.state.errorInfo.componentStack}
                            </pre>
                        </details>
                    )}
                </CardContent>
            </Card>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;