import React from "react";
import { ChevronRight, Home } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function BreadcrumbNavigation({ items = [], className = "" }) {
  const allItems = [
    { label: "Home", href: createPageUrl("Dashboard"), icon: Home },
    ...items
  ];

  return (
    <nav className={`flex items-center space-x-1 text-sm text-gray-600 ${className}`} aria-label="Breadcrumb">
      <ol className="flex items-center space-x-1">
        {allItems.map((item, index) => {
          const isLast = index === allItems.length - 1;
          const IconComponent = item.icon;
          
          return (
            <li key={index} className="flex items-center">
              {index > 0 && (
                <ChevronRight className="w-4 h-4 mx-1 text-gray-400" />
              )}
              {isLast ? (
                <span className="flex items-center gap-1 text-gray-900 font-medium">
                  {IconComponent && <IconComponent className="w-4 h-4" />}
                  {item.label}
                </span>
              ) : (
                <Link
                  to={item.href}
                  className="flex items-center gap-1 hover:text-gray-900 transition-colors"
                >
                  {IconComponent && <IconComponent className="w-4 h-4" />}
                  {item.label}
                </Link>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}