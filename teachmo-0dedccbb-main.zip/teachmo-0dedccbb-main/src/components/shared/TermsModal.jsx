import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';

export default function TermsModal({ open, onOpenChange }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Terms of Service & Privacy Policy</DialogTitle>
          <DialogDescription>
            Last Updated: {new Date().toLocaleDateString()}
          </DialogDescription>
        </DialogHeader>
        <ScrollArea className="h-[60vh] p-4 border rounded-md">
          <h3 className="font-bold mb-2">1. Acceptance of Terms</h3>
          <p className="text-sm text-gray-700 mb-4">
            By accessing and using Teachmo ("the Service"), you accept and agree to be bound by the terms and provision of this agreement. In addition, when using these particular services, you shall be subject to any posted guidelines or rules applicable to such services. Any participation in this service will constitute acceptance of this agreement. If you do not agree to abide by the above, please do not use this service.
          </p>
          <h3 className="font-bold mb-2">2. Privacy Policy</h3>
          <p className="text-sm text-gray-700 mb-4">
            Our Privacy Policy, which is incorporated into these Terms of Service, describes how we collect, protect, and use your data. We are committed to protecting your privacy and security. Information collected is used to improve our service, personalize your experience, and communicate with you. We do not sell your personal data to third parties.
          </p>
          <h3 className="font-bold mb-2">3. User Accounts</h3>
          <p className="text-sm text-gray-700 mb-4">
            To use certain features of the Service, you must register for an account using Google OAuth. You are responsible for all activities that occur under your account. You agree to notify us immediately of any unauthorized use of your account.
          </p>
          <h3 className="font-bold mb-2">4. User-Generated Content</h3>
          <p className="text-sm text-gray-700 mb-4">
            You are solely responsible for any data, text, files, information, images, graphics, photos, profiles, audio and video clips, sounds, musical works, works of authorship, applications, links, and other content or materials (collectively, "Content") that you submit, post, or display on or via the Service.
          </p>
           <h3 className="font-bold mb-2">5. Data from Minors</h3>
          <p className="text-sm text-gray-700 mb-4">
            Teachmo is intended for use by parents and educators. You may provide information about your children for the purpose of personalizing the service. We comply with the Children's Online Privacy Protection Act (COPPA). We do not knowingly collect personal information from children under the age of 13 without obtaining parental consent.
          </p>
          <h3 className="font-bold mb-2">6. Intellectual Property</h3>
          <p className="text-sm text-gray-700 mb-4">
            The Service and its original content, features, and functionality are and will remain the exclusive property of Teachmo and its licensors.
          </p>
        </ScrollArea>
        <DialogFooter>
          <DialogClose asChild>
            <Button type="button">Close</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}