
import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Heart, MessageSquare, Repeat, MoreHorizontal, Send } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { formatDistanceToNow } from 'date-fns';
import { User, Kudo, Comment } from '@/api/entities';
import LazyImage from '../shared/LazyImage'; // Import the new component

export default function PostCard({ post, currentUser, onReply, onKudo }) {
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [isCommenting, setIsCommenting] = useState(false);

  // Safe access to kudos and comments with fallbacks
  const postKudos = post.kudos || [];
  const postComments = post.comments || [];

  const handleKudo = async () => {
    if (!currentUser) return;

    const existingKudo = postKudos.find(k => k.giver_user_id === currentUser.id);
    if (existingKudo) {
      // Already liked, could implement un-kudo here if desired
      return;
    }

    await Kudo.create({
      post_id: post.id,
      giver_user_id: currentUser.id,
      receiver_user_id: post.user_id,
    });
    
    // Create notification for the post author (REMOVED)
    console.log("Skipping notification creation due to database connectivity issues");

    if (onKudo) onKudo();
  };

  const handleComment = async () => {
    if (!currentUser || !newComment.trim()) return;
    setIsCommenting(true);
    
    await Comment.create({
      post_id: post.id,
      user_id: currentUser.id,
      content: newComment,
    });
    
    // Create notification for the post author (REMOVED)
    console.log("Skipping notification creation due to database connectivity issues");

    setNewComment('');
    setIsCommenting(false);
    if (onReply) onReply();
  };

  const isKudoed = postKudos.some(k => k.giver_user_id === currentUser?.id);

  return (
    <Card className="w-full shadow-lg bg-white/90 backdrop-blur-sm">
      <CardHeader className="flex flex-row items-center gap-4 p-4">
        <Avatar>
          <AvatarImage src={post.author_avatar_url} />
          <AvatarFallback>{post.author_name ? post.author_name[0] : 'U'}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <p className="font-semibold">{post.author_name}</p>
          <p className="text-xs text-gray-500">
            {formatDistanceToNow(new Date(post.created_date), { addSuffix: true })}
          </p>
        </div>
        <Button variant="ghost" size="icon">
          <MoreHorizontal className="w-5 h-5" />
        </Button>
      </CardHeader>
      <CardContent className="p-4">
        <p className="text-gray-800 whitespace-pre-wrap my-3">{post.content}</p>
        
        {post.image_url && (
          <div className="mt-3 rounded-lg overflow-hidden border">
             <LazyImage
                src={post.image_url}
                alt="Post attachment"
                className="w-full h-auto max-h-96"
                skeletonClassName="w-full h-64"
             />
          </div>
        )}
        {/* Placeholder for poll, milestone data, etc. if they were present in original */}
      </CardContent>
      <CardFooter className="px-4 py-2 bg-gray-50/50">
        <div className="flex gap-1">
          <Button variant="ghost" className="flex items-center gap-2" onClick={handleKudo}>
            <Heart className={`w-5 h-5 ${isKudoed ? 'text-red-500 fill-current' : ''}`} />
            <span className="text-sm">{postKudos.length}</span>
          </Button>
          <Button variant="ghost" className="flex items-center gap-2" onClick={() => setShowComments(!showComments)}>
            <MessageSquare className="w-5 h-5" />
            <span className="text-sm">{postComments.length}</span>
          </Button>
          <Button variant="ghost" className="flex items-center gap-2">
            <Repeat className="w-5 h-5" />
          </Button>
        </div>
      </CardFooter>
      {showComments && (
        <div className="p-4 border-t">
          <div className="space-y-4">
            {postComments.map(comment => (
              <div key={comment.id} className="flex items-start gap-3">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={comment.user?.avatar_url} />
                  <AvatarFallback>{comment.user?.full_name ? comment.user.full_name[0] : 'U'}</AvatarFallback>
                </Avatar>
                <div className="flex-1 bg-gray-100 rounded-lg p-2">
                  <p className="font-semibold text-sm">{comment.user?.full_name}</p>
                  <p className="text-sm text-gray-700">{comment.content}</p>
                </div>
              </div>
            ))}
            <div className="flex items-center gap-2">
              <Textarea 
                placeholder="Write a comment..." 
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                className="flex-1"
                rows={1}
              />
              <Button onClick={handleComment} disabled={isCommenting} size="icon">
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </Card>
  );
}
