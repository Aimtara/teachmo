
import React, { useState, useRef } from "react";
import { Post } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Send, Smile, Image, Film, BarChart3, HelpCircle, Star, Camera, Calendar, Plus, X } from "lucide-react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { InvokeLLM, UploadFile } from "@/api/integrations";

// Popular emoji categories for quick access
const EMOJI_CATEGORIES = {
  frequent: ["😊", "😂", "❤️", "👍", "🎉", "🤗", "💪", "🌟"],
  parenting: ["👶", "👧", "👦", "👨‍👩‍👧‍👦", "🍼", "🧸", "📚", "🎨", "⚽", "🎵"],
  emotions: ["😊", "😍", "😂", "🥰", "😭", "😤", "😴", "🤯", "😌", "🙃"],
  celebration: ["🎉", "🎊", "🏆", "⭐", "🌟", "💫", "✨", "🎈", "🎁", "🥳"]
};

const MILESTONE_TYPES = [
  { value: "first_word", label: "First Word", emoji: "🗣️" },
  { value: "first_steps", label: "First Steps", emoji: "👶" },
  { value: "potty_trained", label: "Potty Trained", emoji: "🚽" },
  { value: "first_day_school", label: "First Day of School", emoji: "🎒" },
  { value: "learned_to_read", label: "Learned to Read", emoji: "📚" },
  { value: "other", label: "Other Milestone", emoji: "🌟" }
];

const ADVICE_CATEGORIES = [
  { value: "discipline", label: "Discipline & Behavior" },
  { value: "sleep", label: "Sleep Issues" },
  { value: "feeding", label: "Feeding & Nutrition" },
  { value: "development", label: "Development Concerns" },
  { value: "behavior", label: "Behavioral Challenges" },
  { value: "school", label: "School & Learning" },
  { value: "social", label: "Social Skills" },
  { value: "other", label: "Other" }
];

export default function CreatePostForm({ user, onPostCreated, replyTo = null, podId = null }) {
  // FIX: Add a guard clause to prevent rendering if the user prop is missing.
  if (!user) {
    return null;
  }

  const [postContent, setPostContent] = useState(""); // Renamed from 'content'
  const [postType, setPostType] = useState("general");
  const [isSubmitting, setIsSubmitting] = useState(false); // Replaced 'isPosting'
  const [error, setError] = useState(null); // Added
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [attachedImageUrl, setAttachedImageUrl] = useState(""); // For preview (blob URL) or final URL
  const [selectedFile, setSelectedFile] = useState(null); // Added to hold the File object

  // Poll state
  const [pollQuestion, setPollQuestion] = useState("");
  const [pollOptions, setPollOptions] = useState(["", ""]);
  const [allowMultiple, setAllowMultiple] = useState(false);

  // Milestone state
  const [milestoneType, setMilestoneType] = useState("");
  const [childAge, setChildAge] = useState("");
  // milestoneDescription state removed, postContent is used for description

  // Advice request state
  const [adviceCategory, setAdviceCategory] = useState("");
  const [adviceChildAge, setAdviceChildAge] = useState("");
  const [urgency, setUrgency] = useState("medium");

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Basic validation before submission
    let isValid = true;
    let validationErrorMessage = "";

    if (postType === 'poll') {
      if (!pollQuestion.trim() || pollOptions.filter(opt => opt.trim()).length < 2) {
        isValid = false;
        validationErrorMessage = "Poll must have a question and at least two options.";
      }
    } else if (postType === 'milestone') {
      if (!milestoneType || !childAge.trim() || !postContent.trim()) {
        isValid = false;
        validationErrorMessage = "Milestone post requires type, child's age, and description.";
      }
    } else if (postType === 'advice_request') {
      if (!adviceCategory || !adviceChildAge.trim() || !postContent.trim()) {
        isValid = false;
        validationErrorMessage = "Advice request requires category, child's age, and detailed description.";
      }
    } else { // general or photo_challenge, or reply
      if (!postContent.trim() && !attachedImageUrl && !selectedFile) {
        isValid = false;
        validationErrorMessage = "Post content or an image is required.";
      }
    }

    if (!isValid) {
      setError(validationErrorMessage);
      return;
    }

    setIsSubmitting(true);
    setError(null);

    let finalImageUrl = attachedImageUrl; // This will hold the CDN URL after upload, or the current preview URL if no new file
    if (selectedFile) { // If a new file was selected, upload it
      try {
        const { file_url } = await UploadFile({ file: selectedFile });
        finalImageUrl = file_url; // Update to the CDN URL
      } catch (uploadError) {
        setError("Failed to upload image. Please try again.");
        setIsSubmitting(false);
        return;
      }
    }

    try {
      const postData = {
        content: postContent,
        user_id: user.id,
        author_name: user.full_name, // Added
        author_avatar_url: user.avatar_url, // Added
        pod_id: podId, // Added
        type: postType,
        image_url: finalImageUrl || undefined, // Use finalImageUrl
        parent_post_id: replyTo?.id || undefined
      };

      // Add type-specific data
      if (postType === 'poll') {
        postData.poll_data = {
          question: pollQuestion,
          options: pollOptions.filter(opt => opt.trim()),
          allow_multiple: allowMultiple,
          expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() // 7 days
        };
      } else if (postType === 'milestone') {
        postData.milestone_data = {
          child_age: childAge,
          milestone_type: milestoneType,
          description: postContent // Using postContent as the description
        };
      } else if (postType === 'advice_request') {
        postData.advice_request_data = {
          category: adviceCategory,
          child_age: adviceChildAge,
          urgency: urgency
        };
      }

      await Post.create(postData);

      // Reset form
      setPostContent("");
      setAttachedImageUrl("");
      setSelectedFile(null); // Clear selected file
      setPostType("general");
      setPollQuestion("");
      setPollOptions(["", ""]);
      setAllowMultiple(false);
      setMilestoneType("");
      setChildAge("");
      setAdviceCategory("");
      setAdviceChildAge("");
      setUrgency("medium");

      if (onPostCreated) {
        onPostCreated();
      }
    } catch (createError) {
      console.error("Error creating post:", createError);
      setError("Failed to create post. Please try again.");
    }
    setIsSubmitting(false);
  };

  const handleEmojiClick = (emoji) => {
    setPostContent(prev => prev + emoji);
    setShowEmojiPicker(false);
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (!file) {
      setAttachedImageUrl("");
      setSelectedFile(null);
      return;
    }
    // Set a preview URL (blob URL) and store the file for actual upload on submit
    setAttachedImageUrl(URL.createObjectURL(file));
    setSelectedFile(file);
  };

  const addPollOption = () => {
    if (pollOptions.length < 5) {
      setPollOptions([...pollOptions, ""]);
    }
  };

  const removePollOption = (index) => {
    if (pollOptions.length > 2) {
      setPollOptions(pollOptions.filter((_, i) => i !== index));
    }
  };

  const updatePollOption = (index, value) => {
    const newOptions = [...pollOptions];
    newOptions[index] = value;
    setPollOptions(newOptions);
  };

  return (
    <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg">
          {replyTo ? `Reply to ${replyTo.user?.full_name || 'post'}` : 'Share with the community'}
        </CardTitle>
        {error && <p className="text-red-500 text-sm mt-2">{error}</p>} {/* Display error message */}
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {!replyTo && (
            <Tabs value={postType} onValueChange={setPostType}>
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="general" className="text-xs">
                  <Send className="w-4 h-4 mr-1" />
                  Post
                </TabsTrigger>
                <TabsTrigger value="poll" className="text-xs">
                  <BarChart3 className="w-4 h-4 mr-1" />
                  Poll
                </TabsTrigger>
                <TabsTrigger value="milestone" className="text-xs">
                  <Star className="w-4 h-4 mr-1" />
                  Milestone
                </TabsTrigger>
                <TabsTrigger value="advice_request" className="text-xs">
                  <HelpCircle className="w-4 h-4 mr-1" />
                  Advice
                </TabsTrigger>
                <TabsTrigger value="photo_challenge" className="text-xs">
                  <Camera className="w-4 h-4 mr-1" />
                  Photo
                </TabsTrigger>
              </TabsList>

              <TabsContent value="general" className="space-y-4">
                <Textarea
                  placeholder={`What's on your mind, ${user.full_name.split(' ')[0]}?`}
                  value={postContent}
                  onChange={(e) => setPostContent(e.target.value)}
                  className="text-base min-h-[100px]"
                  disabled={isSubmitting}
                />
              </TabsContent>

              <TabsContent value="poll" className="space-y-4">
                <Input
                  placeholder="Ask a question..."
                  value={pollQuestion}
                  onChange={(e) => setPollQuestion(e.target.value)}
                  className="text-base"
                />
                <div className="space-y-2">
                  <label className="text-sm font-medium">Poll Options:</label>
                  {pollOptions.map((option, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        placeholder={`Option ${index + 1}`}
                        value={option}
                        onChange={(e) => updatePollOption(index, e.target.value)}
                        className="flex-1"
                      />
                      {pollOptions.length > 2 && (
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={() => removePollOption(index)}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                  {pollOptions.length < 5 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={addPollOption}
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add Option
                    </Button>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="milestone" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Child's Age</label>
                    <Input
                      placeholder="e.g., 2 years, 18 months"
                      value={childAge}
                      onChange={(e) => setChildAge(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Milestone Type</label>
                    <Select value={milestoneType} onValueChange={setMilestoneType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select milestone" />
                      </SelectTrigger>
                      <SelectContent>
                        {MILESTONE_TYPES.map(type => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.emoji} {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Textarea
                  placeholder="Tell us about this special moment..."
                  value={postContent}
                  onChange={(e) => setPostContent(e.target.value)}
                  className="min-h-[80px]"
                />
              </TabsContent>

              <TabsContent value="advice_request" className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="text-sm font-medium">Category</label>
                    <Select value={adviceCategory} onValueChange={setAdviceCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="Topic" />
                      </SelectTrigger>
                      <SelectContent>
                        {ADVICE_CATEGORIES.map(cat => (
                          <SelectItem key={cat.value} value={cat.value}>
                            {cat.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Child's Age</label>
                    <Input
                      placeholder="Age"
                      value={adviceChildAge}
                      onChange={(e) => setAdviceChildAge(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Urgency</label>
                    <Select value={urgency} onValueChange={setUrgency}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Textarea
                  placeholder="Describe your situation and what advice you're looking for..."
                  value={postContent}
                  onChange={(e) => setPostContent(e.target.value)}
                  className="min-h-[100px]"
                />
              </TabsContent>

              <TabsContent value="photo_challenge" className="space-y-4">
                <Textarea
                  placeholder="Share a photo of your little one and tell us about it! Use prompts like: #MorningRoutine #PlayTime #LearningMoment"
                  value={postContent}
                  onChange={(e) => setPostContent(e.target.value)}
                  className="min-h-[100px]"
                />
              </TabsContent>
            </Tabs>
          )}

          {replyTo && (
            <Textarea
              placeholder="Share your thoughts..."
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
              className="text-base min-h-[80px]"
              disabled={isSubmitting}
            />
          )}

          {/* Attachment Preview */}
          {attachedImageUrl && (
            <div className="relative inline-block">
              <img
                src={attachedImageUrl}
                alt="Attachment preview"
                className="max-w-xs max-h-48 rounded-lg border"
              />
              <Button
                type="button"
                variant="destructive"
                size="sm"
                onClick={() => {
                  setAttachedImageUrl("");
                  setSelectedFile(null); // Also clear the selected file
                }}
                className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0"
              >
                ×
              </Button>
            </div>
          )}

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {/* Emoji Picker */}
              <Popover open={showEmojiPicker} onOpenChange={setShowEmojiPicker}>
                <PopoverTrigger asChild>
                  <Button type="button" variant="outline" size="sm">
                    <Smile className="w-4 h-4" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80">
                  <div className="space-y-3">
                    {Object.entries(EMOJI_CATEGORIES).map(([category, emojis]) => (
                      <div key={category}>
                        <h4 className="text-sm font-medium text-gray-700 mb-2 capitalize">
                          {category}
                        </h4>
                        <div className="grid grid-cols-8 gap-1">
                          {emojis.map((emoji, index) => (
                            <button
                              key={index}
                              type="button"
                              onClick={() => handleEmojiClick(emoji)}
                              className="text-xl hover:bg-gray-100 p-1 rounded transition-colors"
                            >
                              {emoji}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>

              {/* Image Upload */}
              <label className="cursor-pointer">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
                <Button type="button" variant="outline" size="sm">
                  <Image className="w-4 h-4" />
                </Button>
              </label>
            </div>

            <Button
              type="submit"
              disabled={isSubmitting || (
                (postType === 'general' || postType === 'photo_challenge') && !postContent.trim() && !attachedImageUrl && !selectedFile
              ) || (
                postType === 'poll' && (!pollQuestion.trim() || pollOptions.filter(opt => opt.trim()).length < 2)
              ) || (
                postType === 'milestone' && (!milestoneType || !childAge.trim() || !postContent.trim())
              ) || (
                postType === 'advice_request' && (!adviceCategory || !adviceChildAge.trim() || !postContent.trim())
              ) || (
                // For replies, check if content or image is present
                replyTo && !postContent.trim() && !attachedImageUrl && !selectedFile
              )}
              style={{backgroundColor: 'var(--teachmo-sage)'}}
            >
              {isSubmitting ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Send className="w-4 h-4 mr-2" />
              )}
              {replyTo ? 'Reply' : 'Post'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
