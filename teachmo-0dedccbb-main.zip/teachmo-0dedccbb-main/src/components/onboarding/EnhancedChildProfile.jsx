import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Calendar, User, School, Heart, Sparkles, ArrowRight } from 'lucide-react';
import { Child } from '@/api/entities';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';
import SchoolAutoComplete from './SchoolAutoComplete';

export default function EnhancedChildProfile({ onComplete, existingChild = null, isEditing = false }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedSchool, setSelectedSchool] = useState(existingChild?.school_id ? {
    school_id: existingChild.school_id,
    school_name: existingChild.school_name
  } : null);
  
  const [childData, setChildData] = useState({
    name: existingChild?.name || '',
    birth_date: existingChild?.birth_date || '',
    grade_level: existingChild?.grade_level || '',
    school_name: existingChild?.school_name || '',
    school_id: existingChild?.school_id || null,
    school_domain: existingChild?.school_domain || null,
    learning_style: existingChild?.learning_style || 'not_sure',
    interests: existingChild?.interests || [],
    challenges: existingChild?.challenges || [],
    avatar: existingChild?.avatar || '👶',
    color: existingChild?.color || '#7C9885'
  });

  const { toast } = useToast();

  // Predefined options
  const gradeLevels = [
    'Pre-K', 'Kindergarten', '1st Grade', '2nd Grade', '3rd Grade', '4th Grade', 
    '5th Grade', '6th Grade', '7th Grade', '8th Grade', '9th Grade', '10th Grade', 
    '11th Grade', '12th Grade'
  ];

  const learningStyles = [
    { value: 'visual', label: 'Visual (learns through seeing)', emoji: '👀' },
    { value: 'auditory', label: 'Auditory (learns through hearing)', emoji: '👂' },
    { value: 'kinesthetic', label: 'Kinesthetic (learns through doing)', emoji: '🤲' },
    { value: 'not_sure', label: "I'm not sure yet", emoji: '🤔' }
  ];

  const interestOptions = [
    'Arts & Crafts', 'Science', 'Math', 'Reading', 'Music', 'Sports', 
    'Nature', 'Cooking', 'Building', 'Technology', 'Animals', 'Dancing'
  ];

  const challengeOptions = [
    'Focus & Attention', 'Social Skills', 'Reading', 'Math', 'Writing',
    'Following Directions', 'Emotional Regulation', 'Physical Coordination'
  ];

  const avatarOptions = ['👶', '👧', '👦', '🧒', '👩', '👨', '🌟', '🎈', '🚀', '🦄'];
  const colorOptions = ['#7C9885', '#6B9DC8', '#E8A598', '#F4A460', '#DDA0DD', '#98FB98'];

  const steps = [
    { title: 'Basic Info', icon: User },
    { title: 'School', icon: School },
    { title: 'Learning Style', icon: Sparkles },
    { title: 'Personalize', icon: Heart }
  ];

  const calculateAge = (birthDate) => {
    if (!birthDate) return '';
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  };

  const handleInputChange = (field, value) => {
    setChildData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleMultiSelect = (field, option) => {
    setChildData(prev => ({
      ...prev,
      [field]: prev[field].includes(option) 
        ? prev[field].filter(item => item !== option)
        : [...prev[field], option]
    }));
  };

  const handleSchoolSelect = (school) => {
    setSelectedSchool(school);
    setChildData(prev => ({
      ...prev,
      school_id: school?.school_id || null,
      school_name: school?.school_name || '',
      school_domain: school?.school_domain || null
    }));
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      // Calculate age from birth date
      const age = calculateAge(childData.birth_date);
      
      const finalChildData = {
        ...childData,
        age: age
      };

      let result;
      if (isEditing && existingChild) {
        result = await Child.update(existingChild.id, finalChildData);
      } else {
        result = await Child.create(finalChildData);
      }

      toast({
        title: isEditing ? "Profile Updated! 🎉" : "Child Profile Created! 🎉",
        description: `${childData.name}'s profile has been ${isEditing ? 'updated' : 'created'} successfully.`
      });

      if (onComplete) {
        onComplete(result);
      }
    } catch (error) {
      console.error('Error saving child profile:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: `Could not ${isEditing ? 'update' : 'create'} the profile. Please try again.`
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const canProceedFromStep = () => {
    switch (currentStep) {
      case 0:
        return childData.name.trim() && childData.birth_date;
      case 1:
        return childData.grade_level; // School is optional
      case 2:
        return childData.learning_style;
      case 3:
        return true;
      default:
        return false;
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      {/* Progress Bar */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={index} className="flex flex-col items-center">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 ${
                  index <= currentStep 
                    ? 'bg-green-500 text-white' 
                    : 'bg-gray-200 text-gray-500'
                }`}>
                  {index < currentStep ? (
                    <div className="w-3 h-3 bg-white rounded-full" />
                  ) : (
                    <Icon className="w-5 h-5" />
                  )}
                </div>
                <span className={`text-xs mt-2 font-medium ${
                  index <= currentStep ? 'text-green-600' : 'text-gray-500'
                }`}>
                  {step.title}
                </span>
              </div>
            );
          })}
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-green-500 h-2 rounded-full transition-all duration-500"
            style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
          />
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -50 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="shadow-lg">
            <CardHeader className="text-center pb-4">
              <CardTitle className="text-2xl font-bold text-gray-900">
                {steps[currentStep].title}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">

              {/* Step 0: Basic Info */}
              {currentStep === 0 && (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Child's Name</Label>
                    <Input
                      id="name"
                      value={childData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      placeholder="Enter your child's first name"
                      className="text-lg"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="birth_date">Birth Date</Label>
                    <Input
                      id="birth_date"
                      type="date"
                      value={childData.birth_date}
                      onChange={(e) => handleInputChange('birth_date', e.target.value)}
                      className="text-lg"
                    />
                    {childData.birth_date && (
                      <p className="text-sm text-gray-600 mt-1">
                        Age: {calculateAge(childData.birth_date)} years old
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* Step 1: School */}
              {currentStep === 1 && (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="grade">Grade Level</Label>
                    <Select value={childData.grade_level} onValueChange={(value) => handleInputChange('grade_level', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select grade level" />
                      </SelectTrigger>
                      <SelectContent>
                        {gradeLevels.map(grade => (
                          <SelectItem key={grade} value={grade}>{grade}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>School (Optional)</Label>
                    <p className="text-sm text-gray-600 mb-2">
                      Help us connect with your child's school for assignments and updates
                    </p>
                    <SchoolAutoComplete
                      onSelect={handleSchoolSelect}
                      selectedSchool={selectedSchool}
                      placeholder="Type your child's school name..."
                    />
                    {selectedSchool && (
                      <div className="mt-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                        <div className="flex items-center gap-2">
                          <School className="w-4 h-4 text-green-600" />
                          <span className="font-medium text-green-800">{selectedSchool.school_name}</span>
                        </div>
                        {selectedSchool.school_domain && (
                          <p className="text-xs text-green-600 mt-1">{selectedSchool.school_domain}</p>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Step 2: Learning Style */}
              {currentStep === 2 && (
                <div className="space-y-4">
                  <div>
                    <Label>How does {childData.name || 'your child'} learn best?</Label>
                    <p className="text-sm text-gray-600 mb-4">
                      This helps us suggest the most effective activities
                    </p>
                    <div className="grid grid-cols-1 gap-3">
                      {learningStyles.map(style => (
                        <div
                          key={style.value}
                          onClick={() => handleInputChange('learning_style', style.value)}
                          className={`p-4 border-2 rounded-lg cursor-pointer transition-all duration-200 ${
                            childData.learning_style === style.value
                              ? 'border-green-500 bg-green-50'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <span className="text-2xl">{style.emoji}</span>
                            <div>
                              <div className="font-medium">{style.label.split(' (')[0]}</div>
                              <div className="text-sm text-gray-600">
                                ({style.label.split(' (')[1]}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label>What are {childData.name || 'your child'}'s interests?</Label>
                    <p className="text-sm text-gray-600 mb-3">Select all that apply</p>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {interestOptions.map(interest => (
                        <Badge
                          key={interest}
                          variant={childData.interests.includes(interest) ? "default" : "outline"}
                          className={`cursor-pointer text-center py-2 transition-all duration-200 ${
                            childData.interests.includes(interest) 
                              ? 'bg-blue-500 text-white hover:bg-blue-600' 
                              : 'hover:bg-gray-100'
                          }`}
                          onClick={() => handleMultiSelect('interests', interest)}
                        >
                          {interest}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label>Any areas where {childData.name || 'your child'} needs extra support?</Label>
                    <p className="text-sm text-gray-600 mb-3">Optional - helps us suggest targeted activities</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {challengeOptions.map(challenge => (
                        <Badge
                          key={challenge}
                          variant={childData.challenges.includes(challenge) ? "default" : "outline"}
                          className={`cursor-pointer text-center py-2 transition-all duration-200 ${
                            childData.challenges.includes(challenge) 
                              ? 'bg-orange-500 text-white hover:bg-orange-600' 
                              : 'hover:bg-gray-100'
                          }`}
                          onClick={() => handleMultiSelect('challenges', challenge)}
                        >
                          {challenge}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Step 3: Personalize */}
              {currentStep === 3 && (
                <div className="space-y-6">
                  <div className="text-center">
                    <h3 className="text-lg font-semibold mb-2">
                      Let's personalize {childData.name}'s profile!
                    </h3>
                    <p className="text-gray-600">Choose an avatar and theme color</p>
                  </div>

                  <div>
                    <Label>Profile Avatar</Label>
                    <div className="grid grid-cols-5 gap-3 mt-2">
                      {avatarOptions.map(emoji => (
                        <div
                          key={emoji}
                          onClick={() => handleInputChange('avatar', emoji)}
                          className={`w-12 h-12 rounded-full flex items-center justify-center text-2xl cursor-pointer transition-all duration-200 ${
                            childData.avatar === emoji
                              ? 'ring-4 ring-blue-500 bg-blue-50'
                              : 'hover:bg-gray-100'
                          }`}
                        >
                          {emoji}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label>Theme Color</Label>
                    <div className="grid grid-cols-6 gap-3 mt-2">
                      {colorOptions.map(color => (
                        <div
                          key={color}
                          onClick={() => handleInputChange('color', color)}
                          className={`w-10 h-10 rounded-full cursor-pointer transition-all duration-200 ${
                            childData.color === color
                              ? 'ring-4 ring-gray-300 scale-110'
                              : 'hover:scale-105'
                          }`}
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Profile Preview */}
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="font-medium mb-2">Profile Preview:</h4>
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-12 h-12 rounded-full flex items-center justify-center text-2xl"
                        style={{ backgroundColor: childData.color + '20', color: childData.color }}
                      >
                        {childData.avatar}
                      </div>
                      <div>
                        <div className="font-semibold">{childData.name}</div>
                        <div className="text-sm text-gray-600">
                          {childData.grade_level} • Age {calculateAge(childData.birth_date)}
                        </div>
                        {childData.school_name && (
                          <div className="text-xs text-gray-500">{childData.school_name}</div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Navigation Buttons */}
              <div className="flex justify-between pt-6">
                <Button
                  variant="outline"
                  onClick={prevStep}
                  disabled={currentStep === 0}
                  className={currentStep === 0 ? 'invisible' : ''}
                >
                  Back
                </Button>

                {currentStep < steps.length - 1 ? (
                  <Button
                    onClick={nextStep}
                    disabled={!canProceedFromStep()}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Next <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                ) : (
                  <Button
                    onClick={handleSubmit}
                    disabled={isSubmitting || !canProceedFromStep()}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    {isSubmitting ? (
                      <>Saving...</>
                    ) : (
                      <>{isEditing ? 'Update Profile' : 'Create Profile'}</>
                    )}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}