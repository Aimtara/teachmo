import React from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Filter } from "lucide-react";

const TYPES = ["article", "video", "guide", "research"];
const CATEGORIES = [
  "communication", "discipline", "development", "education", "health", 
  "creativity", "social_skills", "emotional_intelligence", "independence", 
  "confidence", "safety", "nutrition"
];
const DIFFICULTIES = ["beginner", "intermediate", "advanced"];

export default function LibraryFilters({ filters, onFiltersChange }) {
  const handleFilterChange = (key, value) => {
    onFiltersChange(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="flex flex-wrap gap-4 items-center p-4 rounded-xl bg-white/80 backdrop-blur-sm shadow-md">
      <div className="flex items-center gap-2">
        <Filter className="w-4 h-4 text-gray-500" />
        <span className="text-sm font-medium text-gray-700">Filters:</span>
      </div>
      
      <Select value={filters.type} onValueChange={(value) => handleFilterChange('type', value)}>
        <SelectTrigger className="w-32">
          <SelectValue placeholder="Type" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Types</SelectItem>
          {TYPES.map((type) => (
            <SelectItem key={type} value={type}>
              {type.charAt(0).toUpperCase() + type.slice(1)}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select value={filters.category} onValueChange={(value) => handleFilterChange('category', value)}>
        <SelectTrigger className="w-40">
          <SelectValue placeholder="Category" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Categories</SelectItem>
          {CATEGORIES.map((category) => (
            <SelectItem key={category} value={category}>
              {category.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select value={filters.difficulty} onValueChange={(value) => handleFilterChange('difficulty', value)}>
        <SelectTrigger className="w-36">
          <SelectValue placeholder="Difficulty" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Levels</SelectItem>
          {DIFFICULTIES.map((difficulty) => (
            <SelectItem key={difficulty} value={difficulty}>
              {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {(filters.type !== 'all' || filters.category !== 'all' || filters.difficulty !== 'all') && (
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-500">Active:</span>
          {filters.type !== 'all' && (
            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
              {filters.type}
            </Badge>
          )}
          {filters.category !== 'all' && (
            <Badge variant="secondary" className="bg-purple-100 text-purple-800">
              {filters.category.replace(/_/g, ' ')}
            </Badge>
          )}
          {filters.difficulty !== 'all' && (
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              {filters.difficulty}
            </Badge>
          )}
        </div>
      )}
    </div>
  );
}