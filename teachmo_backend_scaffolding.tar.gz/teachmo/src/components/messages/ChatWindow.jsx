import React, { useState, useEffect, useRef, useCallback } from 'react';
import { UserMessage, UserConversation } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Send, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '@/components/ui/use-toast';

export default function ChatWindow({ currentUser, conversation, partner, onNewMessage }) {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef(null);
  const { toast } = useToast();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const loadMessages = useCallback(async () => {
    try {
      const loadedMessages = await UserMessage.filter(
        { thread_id: conversation.thread_id },
        'created_date' // Oldest first
      );
      setMessages(loadedMessages);
    } catch (error) {
      console.error("Failed to load messages:", error);
      toast({ variant: 'destructive', title: 'Error', description: 'Could not load messages for this conversation.' });
    } finally {
      setIsLoading(false);
    }
  }, [conversation.thread_id, toast]);

  useEffect(() => {
    setIsLoading(true);
    loadMessages();
    
    const interval = setInterval(() => {
        loadMessages();
    }, 5000); // Poll every 5 seconds

    return () => clearInterval(interval);
  }, [loadMessages]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    setIsSending(true);
    const tempId = Date.now();
    const sentMessage = {
      id: tempId,
      thread_id: conversation.thread_id,
      sender_id: currentUser.id,
      recipient_id: partner.id,
      content: newMessage,
      created_date: new Date().toISOString()
    };
    
    setMessages(prev => [...prev, sentMessage]);
    setNewMessage('');

    try {
      const createdMessage = await UserMessage.create({
        thread_id: conversation.thread_id,
        sender_id: currentUser.id,
        recipient_id: partner.id,
        content: sentMessage.content
      });
      
      // Update local message with real ID from DB
      setMessages(prev => prev.map(m => m.id === tempId ? createdMessage : m));
      
      // Update the conversation for the sidebar
      await UserConversation.update(conversation.id, {
        last_message_preview: sentMessage.content,
        last_activity: new Date().toISOString(),
      });

      onNewMessage(createdMessage);

    } catch (error) {
      console.error("Failed to send message:", error);
      toast({ variant: 'destructive', title: 'Send Failed', description: 'Your message could not be sent.' });
      // Remove the optimistic message on failure
      setMessages(prev => prev.filter(m => m.id !== tempId));
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header */}
      <header className="flex items-center p-4 border-b">
        <Avatar>
          <AvatarImage src={partner?.avatar_url} />
          <AvatarFallback>{partner?.full_name?.[0] || 'U'}</AvatarFallback>
        </Avatar>
        <div className="ml-4">
          <h3 className="font-semibold">{partner?.full_name || 'User'}</h3>
          <p className="text-xs text-gray-500">{partner?.role?.replace('_', ' ') || 'Parent'}</p>
        </div>
      </header>

      {/* Messages */}
      <div className="flex-1 p-4 overflow-y-auto">
        {isLoading ? (
          <div className="flex justify-center items-center h-full">
            <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((msg, index) => {
              const isCurrentUser = msg.sender_id === currentUser.id;
              const showAvatar = index === 0 || messages[index - 1].sender_id !== msg.sender_id;

              return (
                <div key={msg.id} className={`flex items-end gap-2 ${isCurrentUser ? 'justify-end' : ''}`}>
                  {!isCurrentUser && (
                    <Avatar className={`w-8 h-8 ${showAvatar ? '' : 'invisible'}`}>
                      <AvatarImage src={partner?.avatar_url} />
                      <AvatarFallback>{partner?.full_name?.[0] || 'U'}</AvatarFallback>
                    </Avatar>
                  )}
                  <div className={`max-w-md p-3 rounded-2xl ${
                    isCurrentUser 
                      ? 'bg-blue-500 text-white rounded-br-none'
                      : 'bg-gray-100 text-gray-800 rounded-bl-none'
                  }`}>
                    <p className="text-sm">{msg.content}</p>
                  </div>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Input */}
      <footer className="p-4 border-t bg-gray-50">
        <form onSubmit={handleSendMessage} className="flex items-center gap-3">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type your message..."
            className="flex-1"
            disabled={isSending}
          />
          <Button type="submit" disabled={!newMessage.trim() || isSending}>
            {isSending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            <span className="sr-only">Send</span>
          </Button>
        </form>
      </footer>
    </div>
  );
}