
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Trophy,
  Target,
  TrendingUp,
  Gift,
  BookOpen,
  Users,
  Star,
  Crown,
  Save,
  Loader2,
  CheckCircle2,
  Info,
  Sparkles,
  BarChart3,
  Flame
} from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const GAMIFICATION_FEATURES = [
  {
    id: 'streak_tracker',
    label: 'Daily Streak Tracker',
    description: 'Track consecutive days of engagement to build momentum',
    icon: Flame,
    benefit: 'Encourages consistent daily habits and creates positive momentum',
    example: 'Keep your 7-day streak going! Complete one activity today.'
  },
  {
    id: 'achievement_badges',
    label: 'Achievement Badges',
    description: 'Earn badges for milestones, consistency, and trying new activities',
    icon: Trophy,
    benefit: 'Celebrates your parenting wins and motivates continued growth',
    example: 'Earned "First Week Complete" badge for finishing 7 activities!'
  },
  {
    id: 'parent_growth_tracker',
    label: 'Parent Growth Tracker',
    description: 'Visual progress showing your impact and development over time',
    icon: TrendingUp,
    benefit: 'Helps you see tangible progress in your parenting journey',
    example: 'You\'ve helped Maya develop 3 new skills this month!'
  },
  {
    id: 'surprise_rewards',
    label: 'Surprise Rewards',
    description: 'Random affirmations, tips, and special unlockables',
    icon: Gift,
    benefit: 'Adds delightful moments and recognition for your efforts',
    example: 'Surprise! Here\'s a bonus tip for being such a dedicated parent.'
  },
  {
    id: 'reflection_journals',
    label: 'Reflection Check-ins',
    description: 'Optional moments to reflect on your parenting journey',
    icon: BookOpen,
    benefit: 'Builds self-awareness and helps track emotional growth',
    example: 'How did that bedtime routine activity go? Share your thoughts.'
  },
  {
    id: 'community_challenges',
    label: 'Community Challenges',
    description: 'Join optional weekly challenges with other parents',
    icon: Users,
    benefit: 'Builds connection and motivation through shared goals',
    example: 'This week: Try one outdoor activity with your child!'
  },
  {
    id: 'points_display',
    label: 'Points & Scoring',
    description: 'Earn points for activities and see your total score',
    icon: Star,
    benefit: 'Provides immediate feedback and sense of accomplishment',
    example: 'Great job! You earned 15 points for completing that activity.'
  },
  {
    id: 'leaderboards',
    label: 'Friendly Leaderboards',
    description: 'See how you compare with other parents (anonymous and optional)',
    icon: BarChart3,
    benefit: 'Adds friendly motivation without pressure or judgment',
    example: 'You\'re in the top 25% of parents this week - keep it up!'
  }
];

const PRESET_SETTINGS = {
  full: {
    streak_tracker: true,
    achievement_badges: true,
    parent_growth_tracker: true,
    surprise_rewards: true,
    reflection_journals: true,
    community_challenges: true,
    points_display: true,
    leaderboards: false
  },
  minimal: {
    streak_tracker: true,
    achievement_badges: true,
    parent_growth_tracker: true,
    surprise_rewards: false,
    reflection_journals: false,
    community_challenges: false,
    points_display: false,
    leaderboards: false
  },
  off: {
    streak_tracker: false,
    achievement_badges: false,
    parent_growth_tracker: false,
    surprise_rewards: false,
    reflection_journals: false,
    community_challenges: false,
    points_display: false,
    leaderboards: false
  }
};

const DEFAULT_PREFERENCES = {
  preset: 'full',
  ...PRESET_SETTINGS.full
};

export default function GamificationSettings({ user }) {
  const [prefs, setPrefs] = useState(DEFAULT_PREFERENCES); // Changed initial state
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    if (user?.gamification_preferences) { // Added null/undefined check for user
      const userPrefs = user.gamification_preferences || {};
      const initialPrefs = {
        ...DEFAULT_PREFERENCES,
        ...userPrefs
      };
      setPrefs(initialPrefs);
    }
  }, [user]);

  const handlePresetChange = (preset) => {
    if (preset === 'custom') {
      setPrefs(prev => ({ ...prev, preset: 'custom' }));
    } else {
      setPrefs(prev => ({
        ...prev,
        preset,
        ...PRESET_SETTINGS[preset]
      }));
    }
  };

  const handleFeatureChange = (featureId, value) => {
    setPrefs(prev => ({
      ...prev,
      preset: 'custom',
      [featureId]: value
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveSuccess(false);
    try {
      await User.updateMyUserData({ gamification_preferences: prefs });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (e) {
      console.error("Error saving gamification preferences", e);
    }
    setIsSaving(false);
  };

  const getActiveFeatureCount = () => {
    return GAMIFICATION_FEATURES.filter(feature => prefs[feature.id]).length;
  };

  // Show loading state if user is not loaded yet
  if (!user) {
    return (
      <div className="flex justify-center p-8">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-gray-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-2"></div>
          <p className="text-sm text-gray-500">Loading preferences...</p>
        </div>
      </div>
    );
  }

  return (
    <TooltipProvider>
      <div className="space-y-6">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Personalize Your Experience</h2>
          <p className="text-gray-600">Choose the features that will motivate and support your parenting journey.</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5" style={{color: 'var(--teachmo-sage)'}} />
              Engagement Style
            </CardTitle>
            <CardDescription>
              Choose a preset or customize individual features below. Currently: {prefs.preset}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={prefs.preset} onValueChange={handlePresetChange} className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="full" className="flex flex-col items-center p-3">
                  <Crown className="w-4 h-4 mb-1" />
                  <span className="text-xs">Full Experience</span>
                </TabsTrigger>
                <TabsTrigger value="minimal" className="flex flex-col items-center p-3">
                  <Target className="w-4 h-4 mb-1" />
                  <span className="text-xs">Essential Only</span>
                </TabsTrigger>
                <TabsTrigger value="off" className="flex flex-col items-center p-3">
                  <BookOpen className="w-4 h-4 mb-1" />
                  <span className="text-xs">Just Learning</span>
                </TabsTrigger>
                <TabsTrigger value="custom" className="flex flex-col items-center p-3">
                  <Star className="w-4 h-4 mb-1" />
                  <span className="text-xs">Custom</span>
                </TabsTrigger>
              </TabsList>

              <div className="mt-4 text-center">
                <p className="text-sm text-gray-600">
                  {prefs.preset === 'full' && "All features enabled for maximum engagement and support"}
                  {prefs.preset === 'minimal' && "Core progress tracking with minimal distractions"}
                  {prefs.preset === 'off' && "Focus purely on learning without gamification"}
                  {prefs.preset === 'custom' && `${getActiveFeatureCount()} of ${GAMIFICATION_FEATURES.length} features enabled`}
                </p>
              </div>
            </Tabs>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-4">
          {GAMIFICATION_FEATURES.map((feature) => {
            const IconComponent = feature.icon;
            const isEnabled = prefs[feature.id];

            return (
              <Card key={feature.id} className={`transition-all duration-200 ${isEnabled ? 'ring-2 ring-blue-200 bg-blue-50/30' : 'bg-gray-50/50'}`}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${isEnabled ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-400'}`}>
                        <IconComponent className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">{feature.label}</h4>
                        <p className="text-sm text-gray-600">{feature.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="w-4 h-4 text-gray-400 cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <div className="space-y-2">
                            <p className="font-medium">Why this helps:</p>
                            <p className="text-sm">{feature.benefit}</p>
                            <p className="font-medium">Example:</p>
                            <p className="text-sm italic">"{feature.example}"</p>
                          </div>
                        </TooltipContent>
                      </Tooltip>
                      <Switch
                        checked={isEnabled}
                        onCheckedChange={(value) => handleFeatureChange(feature.id, value)}
                      />
                    </div>
                  </div>

                  {isEnabled && (
                    <div className="mt-3 p-3 bg-white rounded-lg border border-blue-200">
                      <p className="text-sm text-blue-800 italic">"{feature.example}"</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Alert>
          <Sparkles className="h-4 w-4" />
          <AlertTitle>Remember: You're in control</AlertTitle>
          <AlertDescription>
            You can change these settings anytime. Teachmo is designed to support your unique parenting style, not overwhelm you.
            All community features are private by default and completely optional.
          </AlertDescription>
        </Alert>

        <div className="flex items-center justify-end gap-4 pt-4 border-t border-gray-200">
          {saveSuccess && (
            <p className="text-sm text-green-600 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              Settings saved!
            </p>
          )}
          <Button onClick={handleSave} disabled={isSaving} style={{backgroundColor: 'var(--teachmo-sage)'}}>
            {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
            Save Preferences
          </Button>
        </div>
      </div>
    </TooltipProvider>
  );
}
