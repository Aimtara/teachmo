import { useState, useCallback, useRef } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

// Centralized error type classification
const classifyError = (error) => {
  const message = error?.message || error?.toString() || 'Unknown error';
  
  if (message.includes('Unauthorized') || message.includes('401')) {
    return { type: 'auth', code: 'UNAUTHORIZED' };
  }
  
  if (message.includes('403') || message.includes('Forbidden')) {
    return { type: 'permission', code: 'FORBIDDEN' };
  }
  
  if (message.includes('404') || message.includes('Not Found')) {
    return { type: 'not_found', code: 'NOT_FOUND' };
  }
  
  if (message.includes('429') || message.includes('Too Many Requests')) {
    return { type: 'rate_limit', code: 'RATE_LIMITED' };
  }
  
  if (message.includes('500') || message.includes('502') || message.includes('503') || message.includes('504')) {
    return { type: 'server', code: 'SERVER_ERROR' };
  }
  
  if (message.includes('Network') || message.includes('Failed to fetch') || 
      message.includes('ETIMEDOUT') || message.includes('ECONNREFUSED') ||
      message.includes('ServerSelectionTimeoutError') || message.includes('replica set')) {
    return { type: 'network', code: 'NETWORK_ERROR' };
  }
  
  if (message.includes('ValidationError') || message.includes('required') || message.includes('invalid')) {
    return { type: 'validation', code: 'VALIDATION_ERROR' };
  }
  
  return { type: 'general', code: 'GENERAL_ERROR' };
};

// User-friendly error messages
const getErrorMessage = (error, context = '') => {
  const { type } = classifyError(error);
  
  switch (type) {
    case 'auth':
      return 'Your session has expired. Please sign in again.';
    case 'permission':
      return 'You don\'t have permission to perform this action.';
    case 'not_found':
      return `The requested ${context || 'resource'} could not be found.`;
    case 'rate_limit':
      return 'Too many requests. Please wait a moment and try again.';
    case 'server':
      return 'Our servers are experiencing issues. Please try again in a few minutes.';
    case 'network':
      return 'Connection problem. Please check your internet and try again.';
    case 'validation':
      return error?.message || 'Please check your input and try again.';
    default:
      return `Something went wrong${context ? ` with ${context}` : ''}. Please try again.`;
  }
};

// Retry configuration based on error type
const getRetryConfig = (error) => {
  const { type } = classifyError(error);
  
  switch (type) {
    case 'network':
    case 'server':
      return { shouldRetry: true, maxRetries: 3, delay: 1000 };
    case 'rate_limit':
      return { shouldRetry: true, maxRetries: 2, delay: 2000 };
    default:
      return { shouldRetry: false, maxRetries: 0, delay: 0 };
  }
};

// Retry with exponential backoff
const retryWithBackoff = async (fn, retries, delay) => {
  try {
    return await fn();
  } catch (error) {
    if (retries > 0) {
      await new Promise(resolve => setTimeout(resolve, delay));
      return retryWithBackoff(fn, retries - 1, delay * 1.5);
    }
    throw error;
  }
};

// Main useApi hook
export const useApi = (options = {}) => {
  const [loadingStates, setLoadingStates] = useState({});
  const [errors, setErrors] = useState({});
  const { toast } = useToast();
  const navigate = useNavigate();
  const abortControllers = useRef({});
  
  const {
    showToastOnError = true,
    showToastOnSuccess = false,
    redirectOnAuth = true,
    enableRetry = true,
    context = '',
    silent = false // For background operations
  } = options;

  // Set loading state for a specific operation
  const setLoading = useCallback((key, isLoading) => {
    setLoadingStates(prev => ({
      ...prev,
      [key]: isLoading
    }));
  }, []);

  // Set error state for a specific operation
  const setError = useCallback((key, error) => {
    setErrors(prev => ({
      ...prev,
      [key]: error
    }));
  }, []);

  // Clear error for a specific operation
  const clearError = useCallback((key) => {
    setErrors(prev => {
      const newErrors = { ...prev };
      delete newErrors[key];
      return newErrors;
    });
  }, []);

  // Cancel an ongoing request
  const cancelRequest = useCallback((key) => {
    if (abortControllers.current[key]) {
      abortControllers.current[key].abort();
      delete abortControllers.current[key];
      setLoading(key, false);
    }
  }, [setLoading]);

  // Main execution wrapper
  const execute = useCallback(async (
    operationFn, 
    {
      key = 'default',
      successMessage = null,
      errorContext = context,
      onSuccess = null,
      onError = null,
      skipErrorHandling = false,
      retryable = enableRetry
    } = {}
  ) => {
    // Cancel any existing request with the same key
    cancelRequest(key);
    
    // Create new abort controller
    const controller = new AbortController();
    abortControllers.current[key] = controller;
    
    try {
      setLoading(key, true);
      clearError(key);
      
      let result;
      
      if (retryable) {
        result = await retryWithBackoff(
          () => operationFn(controller.signal),
          3,
          1000
        );
      } else {
        result = await operationFn(controller.signal);
      }
      
      // Handle success
      if (onSuccess) {
        await onSuccess(result);
      }
      
      if (successMessage && !silent && showToastOnSuccess) {
        toast({
          title: "Success",
          description: successMessage,
          variant: "default"
        });
      }
      
      return result;
      
    } catch (error) {
      // Don't handle aborted requests
      if (error.name === 'AbortError') {
        return null;
      }
      
      const errorInfo = classifyError(error);
      const userMessage = getErrorMessage(error, errorContext);
      
      // Store error state
      setError(key, {
        original: error,
        type: errorInfo.type,
        code: errorInfo.code,
        message: userMessage,
        timestamp: new Date().toISOString()
      });
      
      // Handle specific error types
      if (errorInfo.type === 'auth' && redirectOnAuth) {
        if (!silent) {
          toast({
            variant: "destructive",
            title: "Authentication Required",
            description: userMessage,
          });
        }
        navigate(createPageUrl("Landing"));
        return null;
      }
      
      // Show error toast (unless disabled or handled by caller)
      if (!skipErrorHandling && showToastOnError && !silent) {
        toast({
          variant: "destructive",
          title: "Error",
          description: userMessage,
        });
      }
      
      // Custom error handler
      if (onError) {
        await onError(error, errorInfo);
      }
      
      // Re-throw for caller to handle if needed
      throw error;
      
    } finally {
      setLoading(key, false);
      // Clean up abort controller
      delete abortControllers.current[key];
    }
  }, [
    cancelRequest, setLoading, clearError, setError, toast, navigate, 
    context, enableRetry, showToastOnError, showToastOnSuccess, 
    redirectOnAuth, silent
  ]);

  // Specialized entity operation wrappers
  const entityOperations = {
    list: useCallback((entity, ...args) => 
      execute(
        () => entity.list(...args),
        { 
          key: `${entity.constructor.name || 'entity'}_list`,
          errorContext: 'loading data'
        }
      ), [execute]),

    filter: useCallback((entity, query, ...args) => 
      execute(
        () => entity.filter(query, ...args),
        { 
          key: `${entity.constructor.name || 'entity'}_filter`,
          errorContext: 'searching data'
        }
      ), [execute]),

    get: useCallback((entity, id) => 
      execute(
        () => entity.get(id),
        { 
          key: `${entity.constructor.name || 'entity'}_get_${id}`,
          errorContext: 'loading item'
        }
      ), [execute]),

    create: useCallback((entity, data, successMessage = 'Item created successfully') => 
      execute(
        () => entity.create(data),
        { 
          key: `${entity.constructor.name || 'entity'}_create`,
          successMessage,
          errorContext: 'creating item'
        }
      ), [execute]),

    update: useCallback((entity, id, data, successMessage = 'Item updated successfully') => 
      execute(
        () => entity.update(id, data),
        { 
          key: `${entity.constructor.name || 'entity'}_update_${id}`,
          successMessage,
          errorContext: 'updating item'
        }
      ), [execute]),

    delete: useCallback((entity, id, successMessage = 'Item deleted successfully') => 
      execute(
        () => entity.delete(id),
        { 
          key: `${entity.constructor.name || 'entity'}_delete_${id}`,
          successMessage,
          errorContext: 'deleting item'
        }
      ), [execute])
  };

  // Function operation wrapper
  const callFunction = useCallback((fn, params = {}, options = {}) => 
    execute(
      () => fn(params),
      {
        key: `function_${fn.name || 'call'}`,
        errorContext: 'performing action',
        ...options
      }
    ), [execute]);

  // Batch operations
  const batch = useCallback(async (operations) => {
    const results = {};
    const errors = {};
    
    await Promise.allSettled(
      operations.map(async ({ key, operation }) => {
        try {
          results[key] = await operation();
        } catch (error) {
          errors[key] = error;
        }
      })
    );
    
    return { results, errors };
  }, []);

  // Utility functions
  const isLoading = useCallback((key = 'default') => 
    Boolean(loadingStates[key]), [loadingStates]);

  const getError = useCallback((key = 'default') => 
    errors[key], [errors]);

  const hasError = useCallback((key = 'default') => 
    Boolean(errors[key]), [errors]);

  const isAnyLoading = useCallback(() => 
    Object.values(loadingStates).some(Boolean), [loadingStates]);

  const hasAnyError = useCallback(() => 
    Object.keys(errors).length > 0, [errors]);

  const clearAllErrors = useCallback(() => 
    setErrors({}), []);

  const cancelAllRequests = useCallback(() => {
    Object.keys(abortControllers.current).forEach(cancelRequest);
  }, [cancelRequest]);

  return {
    // Core execution
    execute,
    
    // Entity operations
    ...entityOperations,
    
    // Function calls
    callFunction,
    
    // Batch operations
    batch,
    
    // State getters
    isLoading,
    getError,
    hasError,
    isAnyLoading,
    hasAnyError,
    
    // State management
    setLoading,
    setError,
    clearError,
    clearAllErrors,
    
    // Request management
    cancelRequest,
    cancelAllRequests,
    
    // Raw states (for debugging)
    loadingStates,
    errors
  };
};

// Specialized hooks for common patterns
export const useEntityCrud = (Entity, options = {}) => {
  const api = useApi(options);
  
  return {
    ...api,
    list: (...args) => api.list(Entity, ...args),
    filter: (query, ...args) => api.filter(Entity, query, ...args),
    get: (id) => api.get(Entity, id),
    create: (data, successMessage) => api.create(Entity, data, successMessage),
    update: (id, data, successMessage) => api.update(Entity, id, data, successMessage),
    delete: (id, successMessage) => api.delete(Entity, id, successMessage)
  };
};

export const useFunction = (fn, options = {}) => {
  const api = useApi(options);
  
  return {
    ...api,
    call: (params, callOptions) => api.callFunction(fn, params, callOptions)
  };
};

// Error boundary integration
export const withApiErrorBoundary = (Component) => {
  return function WrappedComponent(props) {
    const api = useApi({ showToastOnError: false }); // Let error boundary handle display
    
    if (api.hasAnyError()) {
      throw new Error(Object.values(api.errors)[0]?.original || 'API Error');
    }
    
    return <Component {...props} api={api} />;
  };
};

export default useApi;