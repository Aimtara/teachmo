import React from 'react';
import { render, screen } from '@testing-library/react';
import { Button } from '../button';

describe('Button component', () => {
  test('renders with children text', () => {
    render(<Button>Click me</Button>);
    expect(screen.getByText('Click me')).toBeInTheDocument();
  });
});