import { isValidEmail, isValidAge, isValidDate, isValidAgeRange, isNonEmptyString } from './types';

/**
 * @typedef {Object} FormFieldError
 * @property {string} message
 * @property {string} field
 */

/**
 * @typedef {Object} ValidationResult
 * @property {boolean} isValid
 * @property {FormFieldError[]} errors
 */

// Child name validation
export const validateChildName = (name) => {
  const errors = [];
  
  if (!isNonEmptyString(name)) {
    errors.push({ field: 'name', message: 'Child name is required' });
  } else if (name.trim().length < 2) {
    errors.push({ field: 'name', message: 'Child name must be at least 2 characters' });
  } else if (name.trim().length > 50) {
    errors.push({ field: 'name', message: 'Child name must be less than 50 characters' });
  }
  
  return { isValid: errors.length === 0, errors };
};

// Birth date validation
export const validateBirthDate = (birthDate) => {
  const errors = [];
  
  if (!isNonEmptyString(birthDate)) {
    errors.push({ field: 'birth_date', message: 'Birth date is required' });
    return { isValid: false, errors };
  }
  
  if (!isValidDate(birthDate)) {
    errors.push({ field: 'birth_date', message: 'Please enter a valid date' });
    return { isValid: false, errors };
  }
  
  const date = new Date(birthDate);
  const today = new Date();
  const maxDate = new Date();
  maxDate.setFullYear(today.getFullYear() - 18);
  
  if (date > today) {
    errors.push({ field: 'birth_date', message: 'Birth date cannot be in the future' });
  } else if (date < maxDate) {
    errors.push({ field: 'birth_date', message: 'Child must be under 18 years old' });
  }
  
  return { isValid: errors.length === 0, errors };
};

// Activity title validation
export const validateActivityTitle = (title) => {
  const errors = [];
  
  if (!isNonEmptyString(title)) {
    errors.push({ field: 'title', message: 'Activity title is required' });
  } else if (title.trim().length < 3) {
    errors.push({ field: 'title', message: 'Title must be at least 3 characters' });
  } else if (title.trim().length > 100) {
    errors.push({ field: 'title', message: 'Title must be less than 100 characters' });
  }
  
  return { isValid: errors.length === 0, errors };
};

// Activity description validation
export const validateActivityDescription = (description) => {
  const errors = [];
  
  if (!isNonEmptyString(description)) {
    errors.push({ field: 'description', message: 'Activity description is required' });
  } else if (description.trim().length < 10) {
    errors.push({ field: 'description', message: 'Description must be at least 10 characters' });
  } else if (description.trim().length > 1000) {
    errors.push({ field: 'description', message: 'Description must be less than 1000 characters' });
  }
  
  return { isValid: errors.length === 0, errors };
};

// Message content validation
export const validateMessageContent = (content) => {
  const errors = [];
  
  if (!isNonEmptyString(content)) {
    errors.push({ field: 'content', message: 'Message content is required' });
  } else if (content.trim().length > 2000) {
    errors.push({ field: 'content', message: 'Message must be less than 2000 characters' });
  }
  
  return { isValid: errors.length === 0, errors };
};

// School name validation
export const validateSchoolName = (name) => {
  const errors = [];
  
  if (!isNonEmptyString(name)) {
    errors.push({ field: 'name', message: 'School name is required' });
  } else if (name.trim().length < 3) {
    errors.push({ field: 'name', message: 'School name must be at least 3 characters' });
  } else if (name.trim().length > 100) {
    errors.push({ field: 'name', message: 'School name must be less than 100 characters' });
  }
  
  return { isValid: errors.length === 0, errors };
};

// Grade level validation
export const validateGradeLevel = (grade) => {
  const errors = [];
  const validGrades = ['Pre-K', 'K', '1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th', '11th', '12th'];
  
  if (!isNonEmptyString(grade)) {
    errors.push({ field: 'grade_level', message: 'Grade level is required' });
  } else if (!validGrades.includes(grade)) {
    errors.push({ field: 'grade_level', message: 'Please select a valid grade level' });
  }
  
  return { isValid: errors.length === 0, errors };
};

// Comprehensive form validation helper
export const validateForm = (data, validators) => {
  const allErrors = [];
  
  for (const [field, validator] of Object.entries(validators)) {
    const value = data[field];
    const result = validator(value);
    if (!result.isValid) {
      allErrors.push(...result.errors);
    }
  }
  
  return { isValid: allErrors.length === 0, errors: allErrors };
};

// Sanitization helpers
export const sanitizeString = (input) => {
  return input.trim().replace(/\s+/g, ' ');
};

export const sanitizeEmail = (email) => {
  return email.trim().toLowerCase();
};

// URL validation
export const isValidUrl = (url) => {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
};

// Phone number validation (basic)
export const isValidPhoneNumber = (phone) => {
  const phoneRegex = /^\+?[\d\s\-\(\)]{10,}$/;
  return phoneRegex.test(phone);
};