import React, { useState, useEffect } from "react";
import { Product, User } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { ShoppingBag, Star, Filter, Search, Tag, ExternalLink, Heart, TrendingUp, DollarSign } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";

const ProductCard = ({ product, isPremium, onWishlist, isWishlisted }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    whileHover={{ y: -5 }}
    className="border rounded-lg overflow-hidden shadow-sm hover:shadow-lg transition-all bg-white"
  >
    <div className="relative">
      <img 
        src={product.image_url || `https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=600&h=400&fit=crop&crop=center`} 
        alt={product.title} 
        className="w-full h-48 object-cover" 
      />
      <div className="absolute top-2 right-2 flex flex-col gap-1">
        {product.is_sponsored && (
          <Badge className="bg-yellow-400 text-yellow-900 text-xs font-bold flex items-center gap-1">
            <Star className="w-3 h-3" />
            Sponsored
          </Badge>
        )}
        {isPremium && product.discount_percentage && (
          <Badge className="bg-green-500 text-white text-xs font-bold">
            {product.discount_percentage}% OFF
          </Badge>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={(e) => {
            e.preventDefault();
            onWishlist(product.id, isWishlisted);
          }}
          className="w-8 h-8 p-0 bg-white/80 backdrop-blur-sm hover:bg-white"
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
        </Button>
      </div>
    </div>
    <div className="p-4">
      <div className="flex items-center gap-2 mb-2">
        <Badge variant="outline" className="text-xs">
          <Tag className="w-3 h-3 mr-1" />
          {product.category}
        </Badge>
        {product.age_range && (
          <Badge variant="outline" className="text-xs">
            Ages {product.age_range}
          </Badge>
        )}
      </div>
      <h3 className="font-bold text-lg mb-2 line-clamp-2">{product.title}</h3>
      <p className="text-gray-700 text-sm mb-4 line-clamp-3">{product.description}</p>
      <div className="flex items-center justify-between">
        <div className="flex flex-col">
          <span className="font-bold text-lg text-green-600">{product.price}</span>
          {isPremium && product.original_price && (
            <span className="text-sm text-gray-500 line-through">{product.original_price}</span>
          )}
        </div>
        <a 
          href={product.affiliate_url} 
          target="_blank" 
          rel="noopener noreferrer" 
          className="bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors text-sm flex items-center gap-2"
        >
          Shop Now
          <ExternalLink className="w-4 h-4" />
        </a>
      </div>
    </div>
  </motion.div>
);

export default function StorePage() {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [priceFilter, setPriceFilter] = useState("all");
  const [activeTab, setActiveTab] = useState("all");
  const [wishlist, setWishlist] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const [productData, userData] = await Promise.all([
          Product.list('-created_date'),
          User.me().catch(() => null)
        ]);
        
        // Generate products if none exist
        if (productData.length === 0) {
          await generateSampleProducts();
        } else {
          setProducts(productData);
          setFilteredProducts(productData);
        }
        
        setUser(userData);
        
        // Load wishlist from user data
        if (userData && userData.wishlist) {
          setWishlist(userData.wishlist);
        }
      } catch (error) {
        console.error("Error loading store data:", error);
      }
      setIsLoading(false);
    };
    fetchData();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [products, searchQuery, categoryFilter, priceFilter]);

  const generateSampleProducts = async () => {
    try {
      const response = await InvokeLLM({
        prompt: `Generate 20 family-friendly products that would be valuable for parents and children. Include books, toys, educational materials, and parenting tools.

        Categories to include:
        - Books (children's books, parenting guides)
        - Toys (educational, creative, STEM)
        - Tools (parenting apps, safety items)
        - Courses (online parenting classes)

        For each product, provide realistic pricing and make some sponsored. Include age ranges where appropriate.`,
        response_json_schema: {
          type: "object",
          properties: {
            products: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  description: { type: "string" },
                  category: { 
                    type: "string",
                    enum: ["books", "toys", "courses", "tools"]
                  },
                  price: { type: "string" },
                  original_price: { type: "string" },
                  discount_percentage: { type: "integer" },
                  affiliate_url: { type: "string" },
                  is_sponsored: { type: "boolean" },
                  age_range: { type: "string" },
                  rating: { type: "number" }
                }
              }
            }
          }
        }
      });

      if (response.products) {
        const productsWithUrls = response.products.map(p => ({
          ...p,
          affiliate_url: p.affiliate_url || `https://example.com/product/${p.title.toLowerCase().replace(/\s+/g, '-')}`
        }));
        
        await Product.bulkCreate(productsWithUrls);
        setProducts(productsWithUrls);
        setFilteredProducts(productsWithUrls);
      }
    } catch (error) {
      console.error("Error generating sample products:", error);
    }
  };

  const applyFilters = () => {
    let filtered = products;

    // Apply search filter
    if (searchQuery) {
      filtered = filtered.filter(product =>
        product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Apply category filter
    if (categoryFilter !== "all") {
      filtered = filtered.filter(product => product.category === categoryFilter);
    }

    // Apply price filter
    if (priceFilter !== "all") {
      filtered = filtered.filter(product => {
        const price = parseFloat(product.price.replace(/[$,]/g, ''));
        switch (priceFilter) {
          case "under_25": return price < 25;
          case "25_50": return price >= 25 && price <= 50;
          case "50_100": return price > 50 && price <= 100;
          case "over_100": return price > 100;
          default: return true;
        }
      });
    }

    setFilteredProducts(filtered);
  };

  const handleWishlist = async (productId, isCurrentlyWishlisted) => {
    try {
      let newWishlist;
      if (isCurrentlyWishlisted) {
        newWishlist = wishlist.filter(id => id !== productId);
      } else {
        newWishlist = [...wishlist, productId];
      }
      
      setWishlist(newWishlist);
      
      if (user) {
        await User.updateMyUserData({ wishlist: newWishlist });
      }
    } catch (error) {
      console.error("Error updating wishlist:", error);
    }
  };

  const isPremiumUser = user?.subscription_tier === "premium";

  const getWishlistProducts = () => {
    return products.filter(p => wishlist.includes(p.id));
  };

  const getFeaturedProducts = () => {
    return products.filter(p => p.is_sponsored || p.rating >= 4.5).slice(0, 8);
  };

  return (
    <div className="min-h-screen p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-3">
            <ShoppingBag style={{color: 'var(--teachmo-sage)'}} />
            Family Store
          </h1>
          <p className="text-gray-600">
            Discover tools, books, and resources recommended by Teachmo experts and the community.
            {isPremiumUser && " Enjoy exclusive premium member discounts!"}
          </p>
        </div>

        {/* Premium Benefits Alert */}
        {isPremiumUser && (
          <Alert className="mb-6 bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
            <Star className="h-4 w-4 text-purple-600" />
            <AlertDescription className="text-purple-800">
              <strong>Premium Member Benefits:</strong> Exclusive discounts, early access to new products, and personalized recommendations!
            </AlertDescription>
          </Alert>
        )}

        {/* Search and Filter Controls */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="books">Books</SelectItem>
                  <SelectItem value="toys">Toys & Games</SelectItem>
                  <SelectItem value="courses">Courses</SelectItem>
                  <SelectItem value="tools">Tools</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Select value={priceFilter} onValueChange={setPriceFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Price Range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Prices</SelectItem>
                  <SelectItem value="under_25">Under $25</SelectItem>
                  <SelectItem value="25_50">$25 - $50</SelectItem>
                  <SelectItem value="50_100">$50 - $100</SelectItem>
                  <SelectItem value="over_100">Over $100</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all">All Products</TabsTrigger>
            <TabsTrigger value="featured">
              <Star className="w-4 h-4 mr-1" />
              Featured
            </TabsTrigger>
            <TabsTrigger value="wishlist">
              Wishlist ({wishlist.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-6">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow-md animate-pulse">
                    <div className="h-48 bg-gray-200 rounded-t-lg"></div>
                    <div className="p-4 space-y-3">
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                      <div className="h-3 bg-gray-200 rounded w-full"></div>
                      <div className="h-3 bg-gray-200 rounded w-5/6"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <AnimatePresence>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {filteredProducts.map((product) => (
                    <ProductCard 
                      key={product.id} 
                      product={product} 
                      isPremium={isPremiumUser}
                      onWishlist={handleWishlist}
                      isWishlisted={wishlist.includes(product.id)}
                    />
                  ))}
                </div>
              </AnimatePresence>
            )}

            {filteredProducts.length === 0 && !isLoading && (
              <div className="text-center py-12">
                <ShoppingBag className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {searchQuery || categoryFilter !== "all" || priceFilter !== "all"
                    ? "No products match your search" 
                    : "No products available right now"
                  }
                </h3>
                <p className="text-gray-600">
                  {searchQuery || categoryFilter !== "all" || priceFilter !== "all"
                    ? "Try adjusting your search or filters."
                    : "Check back later for curated tools and resources!"
                  }
                </p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="featured" className="mt-6">
            <div className="mb-4">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Staff Picks & Popular Items</h3>
              <p className="text-gray-600 text-sm">Handpicked by our parenting experts and highly rated by the community</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {getFeaturedProducts().map((product) => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  isPremium={isPremiumUser}
                  onWishlist={handleWishlist}
                  isWishlisted={wishlist.includes(product.id)}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="wishlist" className="mt-6">
            {getWishlistProducts().length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {getWishlistProducts().map((product) => (
                  <ProductCard 
                    key={product.id} 
                    product={product} 
                    isPremium={isPremiumUser}
                    onWishlist={handleWishlist}
                    isWishlisted={true}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Heart className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Your wishlist is empty</h3>
                <p className="text-gray-600 mb-4">
                  Save products you're interested in by clicking the heart icon.
                </p>
                <Button onClick={() => setActiveTab("all")} style={{backgroundColor: 'var(--teachmo-sage)'}}>
                  Browse Products
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}