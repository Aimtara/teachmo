import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  Users, 
  Search, 
  Filter, 
  Plus,
  Mail,
  Edit,
  Loader2,
  Trash2
} from 'lucide-react';
import { User } from '@/api/entities';
import { bulkUserManagement } from '@/api/functions';
import { useToast } from '@/components/ui/use-toast';
import { format } from 'date-fns';
import RoleGuard from '@/components/shared/RoleGuard';
import { useDebounce } from '@/components/shared/useDebounce';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const debouncedSearch = useDebounce(searchQuery, 300);

  const loadUsers = useCallback(async () => {
    try {
      setIsLoading(true);
      const usersData = await User.list('-created_date', 500);
      setUsers(usersData);
    } catch (error) {
      console.error('Error loading users:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not load users. Please try again."
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    loadUsers();
  }, [loadUsers]);

  useEffect(() => {
    let filtered = users;

    if (roleFilter !== 'all') {
      filtered = filtered.filter(user => user.role === roleFilter);
    }
    if (statusFilter !== 'all') {
      filtered = filtered.filter(user => user.status === statusFilter);
    }
    if (debouncedSearch.trim()) {
      const query = debouncedSearch.toLowerCase();
      filtered = filtered.filter(user => 
        user.full_name?.toLowerCase().includes(query) ||
        user.email?.toLowerCase().includes(query)
      );
    }

    setFilteredUsers(filtered);
  }, [users, debouncedSearch, roleFilter, statusFilter]);
  
  const getRoleBadge = (role) => {
    const roles = {
      parent: 'bg-blue-100 text-blue-800',
      teacher: 'bg-green-100 text-green-800',
      school_admin: 'bg-purple-100 text-purple-800',
      district_admin: 'bg-yellow-100 text-yellow-800',
      system_admin: 'bg-red-100 text-red-800',
      admin: 'bg-red-100 text-red-800'
    };
    return <Badge className={roles[role] || 'bg-gray-100 text-gray-800'}>{role?.replace('_', ' ')}</Badge>;
  };

  const getStatusBadge = (status) => {
    const statuses = {
      active: 'bg-green-100 text-green-800',
      invited: 'bg-yellow-100 text-yellow-800',
      deactivated: 'bg-gray-200 text-gray-600'
    };
    return <Badge className={statuses[status] || 'bg-gray-100 text-gray-800'}>{status}</Badge>;
  };
  
  return (
    <RoleGuard allowedRoles={['system_admin', 'admin', 'district_admin']}>
      <div className="max-w-7xl mx-auto p-4 md:p-6 space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <Users className="w-8 h-8 text-blue-600" />
              User Management
            </h1>
            <p className="text-gray-600 mt-1">
              Invite, view, and manage all users in the system.
            </p>
          </div>
          <InviteUserModal onInviteSent={loadUsers} />
        </div>

        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search by name or email..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <Select value={roleFilter} onValueChange={setRoleFilter}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Roles</SelectItem>
                    <SelectItem value="parent">Parent</SelectItem>
                    <SelectItem value="teacher">Teacher</SelectItem>
                    <SelectItem value="school_admin">School Admin</SelectItem>
                    <SelectItem value="district_admin">District Admin</SelectItem>
                    <SelectItem value="system_admin">System Admin</SelectItem>
                  </SelectContent>
                </Select>
                 <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="invited">Invited</SelectItem>
                    <SelectItem value="deactivated">Deactivated</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Users ({filteredUsers.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
               <div className="text-center py-12"><Loader2 className="w-8 h-8 mx-auto animate-spin" /></div>
            ) : filteredUsers.length === 0 ? (
              <div className="text-center py-12">
                <Users className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <h3 className="text-lg font-semibold text-gray-900">No users match your filters</h3>
                <p className="text-gray-600">Try adjusting your search criteria.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4 font-semibold">User</th>
                      <th className="text-left py-3 px-4 font-semibold">Role</th>
                      <th className="text-left py-3 px-4 font-semibold">Status</th>
                      <th className="text-left py-3 px-4 font-semibold">School / District</th>
                      <th className="text-left py-3 px-4 font-semibold">Joined</th>
                      <th className="text-left py-3 px-4 font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredUsers.map((user) => (
                      <tr key={user.id} className="border-b hover:bg-gray-50">
                        <td className="py-4 px-4">
                          <div className="flex items-center gap-3">
                            {user.avatar_url ? (
                              <img src={user.avatar_url} alt={user.full_name} className="w-10 h-10 rounded-full" />
                            ) : (
                              <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center font-bold text-gray-600">
                                {user.full_name?.[0] || user.email?.[0]}
                              </div>
                            )}
                            <div>
                              <div className="font-medium text-gray-900">{user.full_name || 'N/A'}</div>
                              <div className="text-sm text-gray-600">{user.email}</div>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-4">{getRoleBadge(user.role)}</td>
                        <td className="py-4 px-4">{getStatusBadge(user.status)}</td>
                        <td className="py-4 px-4 text-sm text-gray-700">
                          {user.school_name || user.district_name || 'N/A'}
                        </td>
                        <td className="py-4 px-4 text-sm text-gray-700">
                          {format(new Date(user.created_date), 'MMM d, yyyy')}
                        </td>
                        <td className="py-4 px-4">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => navigate(createPageUrl(`AdminUserEdit?userId=${user.id}`))}
                          >
                            <Edit className="w-4 h-4 mr-2" />
                            Edit
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </RoleGuard>
  );
}

function InviteUserModal({ onInviteSent }) {
  const [isOpen, setIsOpen] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [emails, setEmails] = useState('');
  const [role, setRole] = useState('teacher');
  const { toast } = useToast();

  const handleInvite = async () => {
    const emailList = emails.split(/[\n,;]+/).map(e => e.trim()).filter(Boolean);
    if (emailList.length === 0) {
      toast({ variant: "destructive", title: "No emails provided" });
      return;
    }

    setIsSending(true);
    try {
      const { data } = await bulkUserManagement({
        action: 'invite',
        invites: emailList.map(email => ({ email, role }))
      });

      if (data.success) {
        toast({
          title: "Invitations Sent!",
          description: `Successfully sent ${data.results.success.length} invitations.`
        });
        if (data.results.failed.length > 0) {
          toast({
            variant: "destructive",
            title: "Some invites failed",
            description: `${data.results.failed.length} emails could not be invited.`
          });
        }
        setIsOpen(false);
        setEmails('');
        onInviteSent();
      } else {
        throw new Error(data.error || 'Failed to send invites');
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Invitation Error",
        description: error.message
      });
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button>
          <Mail className="w-4 h-4 mr-2" />
          Invite Users
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Invite New Users</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div>
            <Label htmlFor="emails">User Emails</Label>
            <Textarea
              id="emails"
              value={emails}
              onChange={(e) => setEmails(e.target.value)}
              placeholder="Enter emails separated by commas, semicolons, or new lines."
              rows={5}
            />
          </div>
          <div>
            <Label htmlFor="role">Assign Role</Label>
            <Select value={role} onValueChange={setRole}>
              <SelectTrigger id="role">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="teacher">Teacher</SelectItem>
                <SelectItem value="school_admin">School Admin</SelectItem>
                <SelectItem value="district_admin">District Admin</SelectItem>
                <SelectItem value="parent">Parent</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleInvite} disabled={isSending} className="w-full">
            {isSending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            Send Invitations
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}