
import React, { useState, useEffect } from 'react';
import { Course, Student, Assignment } from '@/api/entities';
import { User } from '@/api/entities';
import { RoleGuard } from '@/components/shared/RoleGuard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Users, Calendar, Plus, MessageSquare } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

function TeacherClassesPage() {
  const [courses, setCourses] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
        
        // Only fetch courses for this specific teacher
        const teacherCourses = await Course.filter({ teacher_id: currentUser.id });
        setCourses(teacherCourses);
      } catch (error) {
        console.error('Error fetching teacher data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  if (isLoading) {
    return <div className="p-6">Loading your classes...</div>;
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">My Classes</h1>
          <p className="text-gray-600 mt-2">Manage your courses and students</p>
        </div>
        <Button asChild>
          <Link to={createPageUrl('Integrations')}>
            <Plus className="w-4 h-4 mr-2" />
            Connect Google Classroom
          </Link>
        </Button>
      </div>

      {courses.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <BookOpen className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-xl font-semibold mb-2">No Classes Yet</h3>
            <p className="text-gray-600 mb-4">
              Connect your Google Classroom or school information system to see your classes here.
            </p>
            <Button asChild>
              <Link to={createPageUrl('Integrations')}>
                Get Started
              </Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course) => (
            <Card key={course.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5" />
                  {course.name}
                </CardTitle>
                <div className="flex gap-2">
                  <Badge variant="outline">{course.course_code}</Badge>
                  <Badge variant="secondary">{course.source_system}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Users className="w-4 h-4" />
                    <span>Students enrolled</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Calendar className="w-4 h-4" />
                    <span>Recent assignments</span>
                  </div>
                </div>
                
                <div className="flex gap-2 mt-4">
                  <Button size="sm" variant="outline" asChild>
                    <Link to={createPageUrl(`TeacherMessages?courseId=${course.id}`)}>
                      <MessageSquare className="w-4 h-4 mr-1" />
                      Messages
                    </Link>
                  </Button>
                  <Button size="sm" asChild>
                    <Link to={createPageUrl(`CourseDetail?id=${course.id}`)}>
                      View Details
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

export default function ProtectedTeacherClasses() {
  return (
    <RoleGuard allowedRoles={['teacher', 'school_admin', 'district_admin', 'system_admin', 'admin']}>
      <TeacherClassesPage />
    </RoleGuard>
  );
}
