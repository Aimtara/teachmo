
import React, { useState, useEffect } from "react";
import { User, School, District, TeacherClassAssignment, Student, Announcement } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Building2, Users, BookOpen, MessageSquare, TrendingUp, Plus, Settings, UserPlus, Bell } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { RoleGuard } from '@/components/shared/RoleGuard';

function SchoolAdminDashboard() {
  const [user, setUser] = useState(null);
  const [school, setSchool] = useState(null);
  const [district, setDistrict] = useState(null);
  const [teachers, setTeachers] = useState([]);
  const [students, setStudents] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      if (currentUser.role === 'school_admin' && currentUser.school_id) {
        // Fetch school information
        const schoolData = await School.filter({ id: currentUser.school_id });
        if (schoolData.length > 0) {
          setSchool(schoolData[0]);

          // Fetch district information
          if (schoolData[0].district_id) {
            const districtData = await District.filter({ id: schoolData[0].district_id });
            if (districtData.length > 0) {
              setDistrict(districtData[0]);
            }
          }
        }

        // Fetch teachers in this school
        const schoolTeachers = await User.filter({
          school_id: currentUser.school_id,
          role: 'teacher'
        });
        setTeachers(schoolTeachers);

        // Fetch students (this might need adjustment based on your data model)
        const schoolStudents = await Student.filter({
          school_id: currentUser.school_id
        });
        setStudents(schoolStudents);

        // Fetch recent announcements
        const recentAnnouncements = await Announcement.filter({
          school_id: currentUser.school_id
        }, '-created_date', 5);
        setAnnouncements(recentAnnouncements);
      }
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-6 flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="text-center">
          <Building2 className="w-12 h-12 animate-pulse mx-auto mb-4" style={{color: 'var(--teachmo-sage)'}} />
          <p className="text-gray-600">Loading school dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              {school?.name || 'School'} Dashboard
            </h1>
            <p className="text-lg text-gray-700">
              Welcome back, {user?.full_name?.split(' ')[0]}! Here's your school overview.
            </p>
            {district && (
              <p className="text-sm text-gray-600">{district.name} • {district.state}</p>
            )}
          </div>
          <div className="flex gap-3">
            <Link to={createPageUrl("SchoolUsers")}>
              <Button variant="outline" className="gap-2">
                <UserPlus className="w-4 h-4" />
                Manage Users
              </Button>
            </Link>
            <Link to={createPageUrl("Announcements")}>
              <Button style={{backgroundColor: 'var(--teachmo-sage)'}} className="gap-2">
                <Plus className="w-4 h-4" />
                New Announcement
              </Button>
            </Link>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="border-0 shadow-md bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                  <Users className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{teachers.length}</p>
                  <p className="text-sm text-gray-600">Teachers</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{students.length}</p>
                  <p className="text-sm text-gray-600">Students</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center">
                  <Bell className="w-5 h-5 text-yellow-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{announcements.length}</p>
                  <p className="text-sm text-gray-600">Announcements</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                  <MessageSquare className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">12</p>
                  <p className="text-sm text-gray-600">Active Conversations</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Teachers */}
          <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" style={{color: 'var(--teachmo-sage)'}} />
                Recent Teachers
              </CardTitle>
            </CardHeader>
            <CardContent>
              {teachers.length > 0 ? (
                <div className="space-y-3">
                  {teachers.slice(0, 5).map((teacher) => (
                    <motion.div
                      key={teacher.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="p-3 rounded-lg bg-gray-50 flex items-center justify-between"
                    >
                      <div>
                        <h4 className="font-medium text-gray-900">{teacher.full_name}</h4>
                        <p className="text-sm text-gray-600">{teacher.email}</p>
                      </div>
                      <Badge variant="outline" className={
                        teacher.status === 'active' ? 'text-green-600' : 'text-gray-600'
                      }>
                        {teacher.status}
                      </Badge>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Users className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p className="text-gray-600">No teachers found.</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Announcements */}
          <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" style={{color: 'var(--teachmo-sage)'}} />
                Recent Announcements
              </CardTitle>
            </CardHeader>
            <CardContent>
              {announcements.length > 0 ? (
                <div className="space-y-3">
                  {announcements.map((announcement) => (
                    <div key={announcement.id} className="p-3 rounded-lg bg-blue-50 border-l-4 border-blue-400">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900">{announcement.title}</h4>
                          <p className="text-sm text-gray-600">
                            {format(new Date(announcement.created_date), 'MMM d, yyyy')}
                          </p>
                        </div>
                        {announcement.is_urgent && (
                          <Badge variant="destructive">Urgent</Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Bell className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p className="text-gray-600">No recent announcements.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm">
          <CardHeader>
            <CardTitle>School Management</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Link to={createPageUrl("SchoolUsers")}>
                <Button variant="outline" className="w-full h-20 flex-col gap-2">
                  <Users className="w-6 h-6" />
                  Manage Users
                </Button>
              </Link>
              <Link to={createPageUrl("Announcements")}>
                <Button variant="outline" className="w-full h-20 flex-col gap-2">
                  <Bell className="w-6 h-6" />
                  Announcements
                </Button>
              </Link>
              <Link to={createPageUrl("SchoolAnalytics")}>
                <Button variant="outline" className="w-full h-20 flex-col gap-2">
                  <TrendingUp className="w-6 h-6" />
                  Analytics
                </Button>
              </Link>
              <Link to={createPageUrl("SchoolSettings")}>
                <Button variant="outline" className="w-full h-20 flex-col gap-2">
                  <Settings className="w-6 h-6" />
                  School Settings
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default function ProtectedSchoolAdminDashboard() {
  return (
    <RoleGuard allowedRoles={['school_admin', 'district_admin', 'system_admin', 'admin']}>
      <SchoolAdminDashboard />
    </RoleGuard>
  );
}
