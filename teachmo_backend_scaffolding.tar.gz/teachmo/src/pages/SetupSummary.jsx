import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import PersonalizationSummary from "../components/profile/PersonalizationSummary";
import GamificationSettings from "../components/profile/GamificationSettings";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Loader2, Sparkles, Trophy } from "lucide-react";

export default function SetupSummary() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("summary");

  useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await User.me();
        setUser(userData);
      } catch (e) {
        console.error("Error loading user:", e);
      }
      setIsLoading(false);
    };
    loadUser();
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-gray-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-4xl mx-auto">
        <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 m-6 mb-0">
              <TabsTrigger value="summary" className="flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                Your Setup
              </TabsTrigger>
              <TabsTrigger value="gamification" className="flex items-center gap-2">
                <Trophy className="w-4 h-4" />
                Experience Style
              </TabsTrigger>
            </TabsList>

            <div className="p-6">
              <TabsContent value="summary">
                <PersonalizationSummary user={user} />
              </TabsContent>

              <TabsContent value="gamification">
                <GamificationSettings user={user} />
              </TabsContent>
            </div>
          </Tabs>
        </Card>
      </div>
    </div>
  );
}