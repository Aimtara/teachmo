
import React, { useState, useEffect } from 'react';
import { User, School, District } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, Building2, Users, BookOpen, BarChart3 } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { withAdminGuard } from '@/components/shared/AdminRoleGuard';

function DistrictAnalytics() {
  const [analytics, setAnalytics] = useState({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const currentUser = await User.me();
        
        // Fetch district-specific data
        const [users, schools, district] = await Promise.all([
          User.filter({ district_id: currentUser.district_id }),
          School.filter({ district_id: currentUser.district_id }),
          District.get(currentUser.district_id)
        ]);

        setAnalytics({
          district,
          totalSchools: schools.length,
          totalUsers: users.length,
          totalTeachers: users.filter(u => u.role === 'teacher').length,
          totalParents: users.filter(u => u.role === 'parent').length,
          totalAdmins: users.filter(u => u.role === 'school_admin').length,
          activeUsers: users.filter(u => u.status === 'active').length,
          schools: schools
        });
      } catch (error) {
        console.error('District analytics fetch error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchAnalytics();
  }, []);

  if (isLoading) {
    return (
      <div className="p-4 md:p-8 space-y-6">
        <Skeleton className="h-10 w-1/3" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i}><CardContent className="p-6"><Skeleton className="h-16 w-full" /></CardContent></Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-3">
          <BarChart3 className="w-8 h-8" style={{color: 'var(--teachmo-sage)'}} />
          District Analytics
        </h1>
        {analytics.district && (
          <p className="text-gray-600 mb-6">{analytics.district.name} - {analytics.district.state}</p>
        )}

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Schools</p>
                  <p className="text-3xl font-bold text-gray-900">{analytics.totalSchools}</p>
                </div>
                <Building2 className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Users</p>
                  <p className="text-3xl font-bold text-gray-900">{analytics.totalUsers}</p>
                </div>
                <Users className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Teachers</p>
                  <p className="text-3xl font-bold text-gray-900">{analytics.totalTeachers}</p>
                </div>
                <BookOpen className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Parents</p>
                  <p className="text-3xl font-bold text-gray-900">{analytics.totalParents}</p>
                </div>
                <Users className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Analytics */}
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="schools">Schools</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <Card>
              <CardHeader>
                <CardTitle>District Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Active Users</span>
                    <Badge variant="outline">{analytics.activeUsers}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>School Administrators</span>
                    <Badge variant="outline">{analytics.totalAdmins}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Subscription Tier</span>
                    <Badge className="capitalize">{analytics.district?.subscription_tier || 'pilot'}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="schools">
            <Card>
              <CardHeader>
                <CardTitle>Schools in District</CardTitle>
              </CardHeader>
              <CardContent>
                {analytics.schools?.length > 0 ? (
                  <div className="space-y-2">
                    {analytics.schools.map((school) => (
                      <div key={school.id} className="p-3 border rounded-lg flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">{school.name}</h4>
                          <p className="text-sm text-gray-600">{school.school_type} • {school.grade_levels?.join(', ')}</p>
                        </div>
                        <Badge variant={school.is_active ? 'default' : 'secondary'}>
                          {school.is_active ? 'Active' : 'Inactive'}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-600">No schools found in this district.</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users">
            <Card>
              <CardHeader>
                <CardTitle>User Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Teachers</span>
                    <span className="font-medium">{analytics.totalTeachers}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Parents</span>
                    <span className="font-medium">{analytics.totalParents}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>School Admins</span>
                    <span className="font-medium">{analytics.totalAdmins}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default withAdminGuard(DistrictAnalytics, { 
  requiredRoles: ['district_admin', 'system_admin', 'admin'] 
});
