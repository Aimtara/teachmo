import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  MessageSquare, 
  Search, 
  Users, 
  Send,
  Loader2,
  Book,
  User as UserIcon,
  Info
} from 'lucide-react';
import { UserMessage, UserConversation, User, Child } from '@/api/entities';
import { useToast } from '@/components/ui/use-toast';
import { format, isToday, isYesterday } from 'date-fns';
import RoleGuard from '@/components/shared/RoleGuard';
import { DashboardSkeleton } from '@/components/shared/ImprovedSkeletons';
import ChatWindow from '@/components/messages/ChatWindow';

function ConversationItem({ conversation, isSelected, onClick }) {
  const { partner, childName } = conversation.metadata;
  
  const formatTime = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    if (isToday(date)) return format(date, 'p');
    if (isYesterday(date)) return 'Yesterday';
    return format(date, 'MMM d');
  };

  return (
    <div
      onClick={() => onClick(conversation)}
      className={`p-3 cursor-pointer transition-colors border-b border-l-4 ${
        isSelected ? 'bg-blue-50 border-blue-500' : 'hover:bg-gray-50 border-transparent'
      }`}
    >
      <div className="flex items-start gap-3">
        <Avatar className="w-10 h-10">
          <AvatarImage src={partner?.avatar_url} />
          <AvatarFallback className="bg-blue-100 text-blue-800">
            {partner?.full_name?.[0] || 'P'}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-900 truncate text-sm">
              {partner?.full_name || 'Parent'}
            </h3>
            <span className="text-xs text-gray-500 flex-shrink-0 ml-2">
              {formatTime(conversation.last_activity)}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-600 flex items-center gap-1">
                <UserIcon className="w-3 h-3" /> Re: {childName}
            </span>
             {conversation.unread_count > 0 && (
              <span className="bg-red-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                {conversation.unread_count}
              </span>
            )}
          </div>
          <p className="text-xs text-gray-500 truncate mt-1">
            {conversation.last_message_preview || 'No messages yet'}
          </p>
        </div>
      </div>
    </div>
  );
}


export default function TeacherMessagesPage() {
  const [conversations, setConversations] = useState([]);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const { toast } = useToast();

  const loadData = useCallback(async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
      
      const allConversations = await UserConversation.filter({
        participant_ids: { $in: [user.id] }
      }, '-last_activity');

      const userIds = new Set(allConversations.flatMap(c => c.participant_ids));
      const childIds = new Set(allConversations.map(c => c.thread_id.split('_')[2]).filter(Boolean));

      const [users, children] = await Promise.all([
        User.filter({ id: { $in: Array.from(userIds) } }),
        Child.filter({ id: { $in: Array.from(childIds) } })
      ]);

      const usersMap = new Map(users.map(u => [u.id, u]));
      const childrenMap = new Map(children.map(c => [c.id, c]));

      const enhancedConversations = allConversations
        .map(conv => {
          const parentId = conv.participant_ids.find(id => id !== user.id);
          const childId = conv.thread_id.split('_')[2];
          const partner = usersMap.get(parentId);
          const child = childrenMap.get(childId);

          if (!partner || !child) return null;

          return {
            ...conv,
            metadata: {
              partner: partner,
              childName: child.name,
              childAvatar: child.avatar,
            },
            unread_count: conv.unread_count?.[user.id] || 0
          };
        })
        .filter(Boolean);
      
      setConversations(enhancedConversations);

      if (enhancedConversations.length > 0 && !selectedConversation) {
        setSelectedConversation(enhancedConversations[0]);
      }
      
    } catch (error) {
      console.error('Error loading conversations:', error);
      toast({ variant: "destructive", title: "Loading Failed" });
    } finally {
      setIsLoading(false);
    }
  }, [toast, selectedConversation]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleNewMessage = (newMessage) => {
    // This function is called from ChatWindow when a new message is sent/received
    // It updates the conversation list to show the new preview and bring it to the top
    setConversations(prevConvos => {
      const updatedConvos = prevConvos.map(convo => 
        convo.id === newMessage.conversation_id 
        ? { ...convo, last_message_preview: newMessage.content, last_activity: newMessage.created_date }
        : convo
      );
      // Sort by last activity to bring the most recent to the top
      return updatedConvos.sort((a, b) => new Date(b.last_activity) - new Date(a.last_activity));
    });
  };

  const filteredConversations = useMemo(() => 
    conversations.filter(conv =>
      !searchQuery || 
      conv.metadata.partner?.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      conv.metadata.childName?.toLowerCase().includes(searchQuery.toLowerCase())
    ), [conversations, searchQuery]);

  if (isLoading && !currentUser) {
    return <DashboardSkeleton />;
  }

  return (
    <RoleGuard allowedRoles={['teacher', 'school_admin']}>
      <div className="h-[calc(100vh-120px)] flex bg-white rounded-lg border">
        {/* Conversations Sidebar */}
        <div className="w-full md:w-1/3 lg:w-1/4 border-r flex flex-col">
          <div className="p-4 border-b">
            <h1 className="text-xl font-bold text-gray-900 flex items-center gap-2 mb-4">
              <MessageSquare className="w-6 h-6 text-blue-600" />
              Teacher Messages
            </h1>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search by parent or student..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto">
            {isLoading && filteredConversations.length === 0 ? (
              <div className="p-4 text-center text-gray-500">Loading...</div>
            ) : filteredConversations.length === 0 ? (
              <div className="p-8 text-center">
                <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="font-medium text-gray-900 mb-2">No conversations</h3>
                <p className="text-sm text-gray-600">
                  {searchQuery ? 'No one found.' : 'Parents can message you here.'}
                </p>
              </div>
            ) : (
              filteredConversations.map((conversation) => (
                <ConversationItem
                  key={conversation.id}
                  conversation={conversation}
                  isSelected={selectedConversation?.id === conversation.id}
                  onClick={setSelectedConversation}
                />
              ))
            )}
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex-col hidden md:flex">
          {selectedConversation ? (
            <ChatWindow
              key={selectedConversation.id} // Re-mount component on conversation change
              conversation={selectedConversation}
              currentUser={currentUser}
              partner={selectedConversation.metadata.partner}
              onNewMessage={handleNewMessage}
            />
          ) : (
            <div className="flex-1 flex items-center justify-center bg-gray-50">
              <div className="text-center">
                <MessageSquare className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900">Select a conversation</h3>
                <p className="text-gray-600 max-w-xs">Choose a conversation from the list to start messaging.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </RoleGuard>
  );
}