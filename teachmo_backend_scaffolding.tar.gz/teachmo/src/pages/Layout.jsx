
import React, { useState, useEffect, Suspense } from "react";
import { Link, useLocation, useNavigate, Navigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Home, Bot, Lightbulb, Calendar as CalendarIcon, TrendingUp, Users, Settings, LogOut, User as UserIcon, Crown, Heart, BookOpen, ChevronRight, Menu, X, Link as LinkIcon, AlertCircle, RefreshCw, MessageSquare, Megaphone, Building, BarChart, Plug, Search, Bell, Loader2 } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuLabel,
  DropdownMenuTrigger,
}
from "@/components/ui/dropdown-menu";
import { ToastProvider } from "@/components/ui/toast";
import { Toaster } from "@/components/ui/toaster";
import { User } from "@/api/entities";
import { Child } from "@/api/entities";
import { isToday, isYesterday, parseISO } from "date-fns";
import { UndoRedoProvider } from "@/components/shared/UndoRedoSystem";
import { NotificationProvider } from "@/components/shared/SmartNotifications";
import QuickActionsMenu from "@/components/shared/QuickActionsMenu";
import { OfflineBanner } from "@/components/shared/OfflineMode";
import KeyboardShortcuts from "@/components/shared/KeyboardShortcuts";
import ErrorBoundary from "@/components/shared/ErrorBoundary";
import { AccessibilityProvider } from "@/components/shared/AccessibilityProvider";
import { FocusStylesProvider } from "@/components/shared/FocusStyles";
import { TutorialProvider } from "@/components/tour/TutorialSystem";
import { SkipLink } from "@/components/shared/SkipLink";
import { fetchWithRetry } from "@/components/shared/apiUtils";
import CCPABanner from '@/components/compliance/CCPABanner';
import SmartSearch from "@/components/shared/SmartSearch";
import LazyPageWrapper from './components/shared/LazyPageWrapper';
import RoleGuard from './components/shared/RoleGuard';
import InteractiveGuide, { useInteractiveGuide } from './components/tour/InteractiveGuide';
import MobileNavigation from './components/layout/MobileNavigation';

// --- LAZY-LOADED PAGE COMPONENTS ---
// This implements code-splitting for major routes.
const Landing = React.lazy(() => import('./pages/Landing'));
const Welcome = React.lazy(() => import('./pages/Welcome'));
const Dashboard = React.lazy(() => import('./pages/Dashboard'));
const UnifiedDiscover = React.lazy(() => import('./pages/UnifiedDiscover'));
const AIAssistant = React.lazy(() => import('./pages/AIAssistant'));
const Calendar = React.lazy(() => import('./pages/Calendar'));
const Settings = React.lazy(() => import('./pages/Settings'));
const Progress = React.lazy(() => import('./pages/Progress'));
const Library = React.lazy(() => import('./pages/Library'));
const UnifiedCommunity = React.lazy(() => import('./pages/UnifiedCommunity'));
const Messages = React.lazy(() => import('./pages/Messages'));
const TeacherDashboard = React.lazy(() => import('./pages/TeacherDashboard'));
const SchoolAdminDashboard = React.lazy(() => import('./pages/SchoolAdminDashboard'));
const DistrictAdminDashboard = React.lazy(() => import('./pages/DistrictAdminDashboard'));
const SystemAdminDashboard = React.lazy(() => import('./pages/SystemAdminDashboard'));
const DeveloperGuide = React.lazy(() => import('./pages/DeveloperGuide'));

const PageComponentMap = {
  Landing,
  Welcome,
  Dashboard,
  UnifiedDiscover,
  AIAssistant,
  Calendar,
  Settings,
  Progress,
  Library,
  UnifiedCommunity,
  Messages,
  TeacherDashboard,
  SchoolAdminDashboard,
  DistrictAdminDashboard,
  SystemAdminDashboard,
  DeveloperGuide,
};

// Helper functions for dashboard routing
const getDashboardForRole = (role) => {
  switch (role) {
    case 'teacher': return 'TeacherDashboard';
    case 'school_admin': return 'SchoolAdminDashboard';
    case 'district_admin': return 'DistrictAdminDashboard';
    case 'admin': // Treat 'admin' as 'system_admin'
    case 'system_admin': return 'SystemAdminDashboard';
    default: return 'Dashboard'; // Parent dashboard
  }
};

const getDashboardDescription = (role) => {
  switch (role) {
    case 'teacher': return 'Your teaching hub';
    case 'school_admin': return 'School management center';
    case 'district_admin': return 'District oversight hub';
    case 'admin': // Treat 'admin' as 'system_admin'
    case 'system_admin': return 'Platform administration';
    default: return "Your family's daily hub";
  }
};

// Enhanced navigation with better role separation and progressive disclosure
const getNavigationItems = (userRole) => {
  const baseItems = [
    {
      title: "Dashboard",
      url: createPageUrl(getDashboardForRole(userRole)),
      icon: Home,
      description: getDashboardDescription(userRole),
      shortcut: "D",
      isPrimary: true
    }
  ];

  if (userRole === 'parent') {
    return [
      ...baseItems,
      {
        title: "Discover",
        url: createPageUrl("UnifiedDiscover"),
        icon: Lightbulb,
        description: "Find activities & events",
        shortcut: "E",
        isPrimary: true
      },
      {
        title: "AI Coach",
        url: createPageUrl("AIAssistant"),
        icon: Bot,
        description: "Get personalized guidance",
        shortcut: "C",
        isPrimary: true
      },
      {
        title: "Calendar",
        url: createPageUrl("Calendar"),
        icon: CalendarIcon,
        description: "Organize family schedule",
        shortcut: "S",
        isPrimary: true
      },
      // Secondary navigation - Progressive disclosure
      {
        title: "Progress",
        url: createPageUrl("Progress"),
        icon: TrendingUp,
        description: "Track growth & milestones",
        shortcut: "P",
        isPrimary: false
      },
      {
        title: "Library",
        url: createPageUrl("Library"),
        icon: BookOpen,
        description: "Expert resources",
        shortcut: "L",
        isPrimary: false
      },
      {
        title: "Community",
        url: createPageUrl("UnifiedCommunity"),
        icon: Users,
        description: "Connect with parents",
        shortcut: "N",
        isPrimary: false
      },
      {
        title: "Messages",
        url: createPageUrl("Messages"),
        icon: MessageSquare,
        description: "School communication",
        shortcut: "M",
        isPrimary: false
      }
    ];
  } else if (userRole === 'teacher') {
    return [
      ...baseItems,
      {
        title: "My Classes",
        url: createPageUrl("TeacherClasses"),
        icon: BookOpen,
        description: "Manage students & content",
        shortcut: "C",
        isPrimary: true
      },
      {
        title: "Messages",
        url: createPageUrl("TeacherMessages"),
        icon: MessageSquare,
        description: "Parent communication",
        shortcut: "M",
        isPrimary: true
      },
      {
        title: "Announcements",
        url: createPageUrl("Announcements"),
        icon: Megaphone,
        description: "Class updates",
        shortcut: "A",
        isPrimary: true
      },
      // Secondary navigation
      {
        title: "Analytics",
        url: createPageUrl("TeacherAnalytics"),
        icon: TrendingUp,
        description: "Class performance insights",
        shortcut: "I",
        isPrimary: false
      },
      {
        title: "Resources",
        url: createPageUrl("TeacherResources"),
        icon: BookOpen,
        description: "Teaching materials",
        shortcut: "R",
        isPrimary: false
      }
    ];
  } else if (userRole === 'school_admin') {
    return [
      ...baseItems,
      {
        title: "School Users",
        url: createPageUrl("SchoolUsers"),
        icon: Users,
        description: "Manage staff & families",
        shortcut: "U",
        isPrimary: true
      },
      {
        title: "Analytics",
        url: createPageUrl("SchoolAnalytics"),
        icon: TrendingUp,
        description: "School insights",
        shortcut: "A",
        isPrimary: true
      },
      {
        title: "Announcements",
        url: createPageUrl("Announcements"),
        icon: Megaphone,
        description: "School-wide updates",
        shortcut: "N",
        isPrimary: true
      },
      // Secondary navigation
      {
        title: "Settings",
        url: createPageUrl("SchoolSettings"),
        icon: Settings,
        description: "School configuration",
        shortcut: "S",
        isPrimary: false
      },
      {
        title: "Integrations",
        url: createPageUrl("Integrations"),
        icon: LinkIcon,
        description: "Connect systems",
        shortcut: "I",
        isPrimary: false
      }
    ];
  } else if (userRole === 'district_admin') {
    return [
      ...baseItems,
      {
        title: "District Users",
        url: createPageUrl('DistrictUsers'),
        icon: Users,
        description: "Manage all users",
        shortcut: "U",
        isPrimary: true
      },
      {
        title: "Schools",
        url: createPageUrl('DistrictSchools'),
        icon: Building,
        description: "Manage schools",
        shortcut: "H",
        isPrimary: true
      },
      {
        title: "Analytics",
        url: createPageUrl('DistrictAnalytics'),
        icon: BarChart,
        description: "District insights",
        shortcut: "A",
        isPrimary: true
      },
      // Secondary navigation
      {
        title: "Settings",
        url: createPageUrl('DistrictSettings'),
        icon: Settings,
        description: "District configuration",
        shortcut: "S",
        isPrimary: false
      }
    ];
  } else if (userRole === 'system_admin' || userRole === 'admin') {
    return [
      ...baseItems,
      {
        title: "System Users",
        url: createPageUrl('SystemUsers'),
        icon: Users,
        description: "Manage all users",
        shortcut: "U",
        isPrimary: true
      },
      {
        title: "Districts",
        url: createPageUrl('SystemDistricts'),
        icon: Building,
        description: "Manage districts",
        shortcut: "R",
        isPrimary: true
      },
      // Secondary navigation
      {
        title: "Developer Guide",
        url: createPageUrl('DeveloperGuide'),
        icon: BookOpen,
        description: "Development docs",
        shortcut: "G",
        isPrimary: false
      },
      {
        title: "Platform Settings",
        url: createPageUrl('Settings'),
        icon: Settings,
        description: "System configuration",
        shortcut: "S",
        isPrimary: false
      }
    ];
  }

  return baseItems;
};

// Define public pages that do not require authentication.
const PUBLIC_PAGES = ['Landing', 'PartnerSignup', 'PaymentSuccess', 'PaymentCancelled'];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [userChildren, setUserChildren] = useState([]);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const [showSecondaryNav, setShowSecondaryNav] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [authError, setAuthError] = useState(null);

  // Interactive guide integration
  const { shouldShow: shouldShowGuide, isLoading: isGuideLoading } = useInteractiveGuide(user?.role);

  // Session health check function
  const checkSessionHealth = async () => {
    try {
      const currentUser = await fetchWithRetry(() => User.me());
      
      // Check if user account is locked, disabled, or deactivated
      if (currentUser && ['system_locked', 'system_disabled', 'deactivated'].includes(currentUser.status)) {
        // Force logout for locked/disabled/deactivated accounts
        await User.logout();
        return null;
      }
      
      return currentUser;
    } catch (error) {
      if (error.message?.includes('401') || error.message?.includes('Unauthorized')) {
        // Session has expired, redirect to login
        handleLogout(true);
        return null;
      }
      throw error;
    }
  };

  useEffect(() => {
    // Do not run auth check for public pages
    if (PUBLIC_PAGES.includes(currentPageName)) {
      setIsLoadingUser(false);
      return;
    }

    const fetchUser = async () => {
      try {
        setAuthError(null);
        const currentUser = await checkSessionHealth();
        
        if (!currentUser) {
          if (!authError) {
             setAuthError({
              type: 'auth',
              message: 'Could not establish a session. Please sign in.',
              canRetry: true
            });
          }
          setIsLoadingUser(false);
          return;
        }
        
        // --- Login Streak Calculation Logic ---
        if (currentUser) {
          const today = new Date();
          const lastLogin = currentUser.last_login_date ? parseISO(currentUser.last_login_date) : null;
          let newStreak = currentUser.login_streak || 0;
          let needsUpdate = false;

          if (!lastLogin) {
            newStreak = 1;
            needsUpdate = true;
          } else if (!isToday(lastLogin)) {
            if (isYesterday(lastLogin)) {
              newStreak++;
            } else {
              newStreak = 1;
            }
            needsUpdate = true;
          }

          if (needsUpdate) {
            try {
              await User.updateMyUserData({
                login_streak: newStreak,
                last_login_date: today.toISOString()
              });
              currentUser.login_streak = newStreak;
              currentUser.last_login_date = today.toISOString();
            } catch (updateError) {
              console.error("Failed to update user streak:", updateError);
            }
          }
        }

        setUser(currentUser);
        if (currentUser) {
          try {
            const childrenData = await fetchWithRetry(() => Child.list());
            setUserChildren(childrenData || []);
          } catch (childrenError) {
            console.error("Failed to fetch children:", childrenError);
            setUserChildren([]);
          }
        }
      } catch (e) {
        console.error("Critical user authentication error:", e);
        
        if (e.message?.includes('Network') || e.message?.includes('Failed to fetch')) {
          setAuthError({
            type: 'network',
            message: 'Having trouble connecting. Please check your internet connection and try again.',
            canRetry: true
          });
        } else if (e.message?.includes('Unauthorized') || e.message?.includes('401')) {
          setAuthError({
            type: 'auth',
            message: 'Your session has expired. Please sign in again.',
            canRetry: false
          });
        } else {
          setAuthError({
            type: 'general',
            message: 'Something went wrong loading your account. Please try again.',
            canRetry: true
          });
        }
        setUser(null);
      } finally {
        setIsLoadingUser(false);
      }
    };
    
    fetchUser();
  }, [location.pathname, currentPageName, authError]);

  useEffect(() => {
    if (!isLoadingUser && user && !user.onboarding_completed) {
      const onboardingPaths = {
        parent: 'Welcome',
        teacher: 'TeacherOnboarding', 
        school_admin: 'AdminOnboarding',
        district_admin: 'AdminOnboarding',
        system_admin: 'AdminOnboarding',
        admin: 'AdminOnboarding'
      };
      
      const onboardingPath = onboardingPaths[user.role] || 'Welcome';
      setShowOnboarding(true);
      if (currentPageName !== onboardingPath) {
        navigate(createPageUrl(onboardingPath));
      }
    }
  }, [user, isLoadingUser, currentPageName, navigate]);

  // Add keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.altKey && user) {
        const currentNavigationItems = getNavigationItems(user.role);
        const item = currentNavigationItems.find(item => item.shortcut?.toLowerCase() === e.key.toLowerCase());
        if (item) {
          e.preventDefault();
          navigate(item.url);
        }
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [navigate, user]);

  const handleLogout = async (isAutoLogout = false) => {
    try {
      await User.logout();
    } catch (error) {
      console.error("Error during logout:", error);
    }
    setUser(null);
    setUserChildren([]);
    if (!isAutoLogout) {
      navigate(createPageUrl("Landing"));
    }
  };

  const handleRetry = () => {
    setAuthError(null);
    setIsLoadingUser(true);
    window.location.reload();
  };
  
  // Public pages that do not require login or the main layout
  const isPublicPage = PUBLIC_PAGES.includes(currentPageName);

  if (isPublicPage) {
    return (
      <Suspense fallback={<div className="min-h-screen w-full flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin" /></div>}>
        {children}
      </Suspense>
    );
  }

  // Improved loading state
  if (isLoadingUser) {
    return (
      <div className="min-h-screen w-full flex flex-col items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <Heart className="w-10 h-10 animate-pulse mb-4" style={{color: 'var(--teachmo-sage)'}} />
        <p className="text-gray-600 animate-pulse">Loading your dashboard...</p>
      </div>
    );
  }

  // Authentication error handling
  if (authError) {
    return (
      <div className="min-h-screen w-full flex flex-col items-center justify-center p-4" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="max-w-md w-full">
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-red-100 flex items-center justify-center">
              <AlertCircle className="w-8 h-8 text-red-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              {authError.type === 'network' ? 'Connection Issue' : 
               authError.type === 'auth' ? 'Session Expired' : 
               'Something Went Wrong'}
            </h2>
            <p className="text-gray-600 mb-6">
              {authError.message}
            </p>
            
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              {authError.canRetry && (
                <Button onClick={handleRetry} className="flex items-center gap-2">
                  <RefreshCw className="w-4 h-4" />
                  Try Again
                </Button>
              )}
              {authError.type === 'auth' && (
                <Button 
                  onClick={() => navigate(createPageUrl("Landing"))}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  Sign In Again
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  if (!user && !isPublicPage) {
      return <Navigate to={createPageUrl("Landing")} replace />;
  }

  // Force onboarding completion
  if (showOnboarding && currentPageName !== 'Welcome' && currentPageName !== 'TeacherOnboarding' && currentPageName !== 'AdminOnboarding') {
    if (user?.role === 'parent' && userChildren.length === 0) {
      return <>{children}</>;
    }
    return <>{children}</>;
  }

  // Get navigation items with enhanced role separation
  const navigationItems = getNavigationItems(user?.role);
  const primaryNavItems = navigationItems.filter(item => item.isPrimary);
  const secondaryNavItems = navigationItems.filter(item => !item.isPrimary);

  const currentPageTitle = navigationItems.find(item => location.pathname === item.url)?.title || currentPageName;
  const currentPageIcon = navigationItems.find(item => location.pathname === item.url)?.icon;

  // Get the component for the current page
  const CurrentPageComponent = PageComponentMap[currentPageName] || (() => children);

  return (
    <ErrorBoundary>
      <ToastProvider>
        <AccessibilityProvider>
          <FocusStylesProvider>
            <TutorialProvider>
              <UndoRedoProvider>
                <NotificationProvider>
                  <SidebarProvider>
                    <SkipLink href="#main-content" />
                    <KeyboardShortcuts />
                    <OfflineBanner />
                    
                    {/* Interactive Guide */}
                    {shouldShowGuide && !isGuideLoading && user && (
                      <InteractiveGuide
                        userRole={user.role}
                        onComplete={() => {}}
                        onDismiss={() => {}}
                      />
                    )}
                    
                    <style>
                      {`
                      :root {
                        --teachmo-sage: #7C9885;
                        --teachmo-sage-light: #A8C4B0;
                        --teachmo-cream: #F9F7F4;
                        --teachmo-blue: #6B9DC8;
                        --teachmo-coral: #E8A598;
                        --teachmo-warm-white: #FEFCFA;
                      }
                      
                      /* Enhanced mobile touch targets */
                      @media (max-width: 768px) {
                        [data-sidebar="sidebar"] {
                          z-index: 40;
                        }
                        
                        button, a, [role="button"] {
                          min-height: 44px;
                          min-width: 44px;
                        }
                        
                        body {
                          -webkit-text-size-adjust: 100%;
                          text-size-adjust: 100%;
                        }
                      }
                      
                      /* Progressive disclosure styling */
                      .nav-item-active {
                        background: linear-gradient(135deg, var(--teachmo-sage), var(--teachmo-sage-light));
                        color: white;
                        box-shadow: 0 4px 12px rgba(124, 152, 133, 0.3);
                      }
                      
                      .nav-item-inactive {
                        color: #374151;
                        font-weight: 500;
                      }
                      
                      .nav-item-inactive:hover {
                        background: #f8fafc;
                        color: var(--teachmo-sage);
                      }

                      .nav-item-secondary {
                        color: #6b7280;
                        font-weight: 400;
                      }

                      .nav-item-secondary:hover {
                        color: #374151;
                        background: #f9fafb;
                      }

                      /* Enhanced secondary nav expansion */
                      .secondary-nav-expanded {
                        max-height: 400px;
                        opacity: 1;
                        transition: max-height 0.3s ease-in-out, opacity 0.2s ease-in-out;
                      }

                      .secondary-nav-collapsed {
                        max-height: 0;
                        opacity: 0;
                        overflow: hidden;
                        transition: max-height 0.3s ease-in-out, opacity 0.2s ease-in-out;
                      }
                    `}
                    </style>
                    
                    <div className="min-h-screen flex w-full" style={{backgroundColor: 'var(--teachmo-cream)'}}>
                      {/* DESKTOP SIDEBAR - Enhanced with progressive disclosure */}
                      <Sidebar className="border-r border-gray-200 hidden md:flex" style={{backgroundColor: 'var(--teachmo-warm-white)'}}>
                        <SidebarHeader className="border-b border-gray-100 p-6">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-2xl flex items-center justify-center" style={{background: 'linear-gradient(135deg, var(--teachmo-sage), var(--teachmo-sage-light))'}}>
                              <Heart className="w-6 h-6 text-white" />
                            </div>
                            <div>
                              <h2 className="font-bold text-xl text-gray-900">Teachmo</h2>
                              <p className="text-sm" style={{color: 'var(--teachmo-sage)'}}>
                                {user?.role === 'parent' ? 'AI Parenting Coach' : 
                                 user?.role === 'teacher' ? 'Teaching Hub' :
                                 user?.role === 'school_admin' ? 'School Management' :
                                 user?.role === 'district_admin' ? 'District Oversight' :
                                 'System Administration'}
                              </p>
                            </div>
                          </div>
                        </SidebarHeader>

                        <SidebarContent className="p-4">
                          <SidebarGroup>
                            <SidebarGroupContent>
                              <SidebarMenu role="navigation" aria-label="Main navigation">
                                {/* Primary Navigation */}
                                {primaryNavItems.map((item) => {
                                  const isActive = location.pathname === item.url;
                                  const IconComponent = item.icon;
                                  
                                  return (
                                    <SidebarMenuItem key={item.title}>
                                      <SidebarMenuButton
                                        asChild
                                        className={`group relative transition-all duration-300 rounded-xl mb-2 touch-target ${
                                          isActive ? 'nav-item-active' : 'nav-item-inactive'
                                        }`}
                                      >
                                        <Link 
                                          to={item.url} 
                                          className="flex items-center gap-3 px-4 py-3"
                                          aria-label={`Navigate to ${item.title} - ${item.description}`}
                                          aria-current={isActive ? 'page' : undefined}
                                        >
                                          <IconComponent className="w-5 h-5 flex-shrink-0" aria-hidden="true" />
                                          <div className="flex-1 min-w-0">
                                            <span className="font-medium text-base block">{item.title}</span>
                                            <span className={`text-xs block mt-0.5 ${isActive ? 'text-white/80' : 'text-gray-600'}`}>
                                              {item.description}
                                            </span>
                                          </div>
                                        </Link>
                                      </SidebarMenuButton>
                                    </SidebarMenuItem>
                                  );
                                })}

                                {/* Progressive Disclosure for Secondary Navigation */}
                                {secondaryNavItems.length > 0 && (
                                  <div className="mt-6 pt-4 border-t border-gray-100">
                                    <button
                                      onClick={() => setShowSecondaryNav(!showSecondaryNav)}
                                      className="flex items-center justify-between text-sm text-gray-600 hover:text-gray-800 mb-3 w-full px-2 py-1 rounded-lg hover:bg-gray-50 transition-colors"
                                      aria-expanded={showSecondaryNav}
                                      aria-controls="secondary-navigation"
                                    >
                                      <span className="font-medium">More Features</span>
                                      <ChevronRight className={`w-4 h-4 transition-transform duration-200 ${showSecondaryNav ? 'rotate-90' : ''}`} />
                                    </button>
                                    
                                    <div 
                                      id="secondary-navigation"
                                      className={showSecondaryNav ? 'secondary-nav-expanded' : 'secondary-nav-collapsed'}
                                    >
                                      {secondaryNavItems.map((item) => {
                                        const isActive = location.pathname === item.url;
                                        const IconComponent = item.icon;
                                        
                                        return (
                                          <SidebarMenuItem key={item.title}>
                                            <SidebarMenuButton
                                              asChild
                                              className={`group relative transition-all duration-300 rounded-lg mb-1 touch-target ${
                                                isActive ? 'nav-item-active' : 'nav-item-secondary'
                                              }`}
                                            >
                                              <Link 
                                                to={item.url} 
                                                className="flex items-center gap-3 px-3 py-2"
                                                aria-label={`Navigate to ${item.title} - ${item.description}`}
                                                aria-current={isActive ? 'page' : undefined}
                                              >
                                                <IconComponent className="w-4 h-4" aria-hidden="true" />
                                                <div className="flex-1 min-w-0">
                                                  <span className="text-sm font-medium">{item.title}</span>
                                                  <span className="text-xs text-gray-500 block">{item.description}</span>
                                                </div>
                                              </Link>
                                            </SidebarMenuButton>
                                          </SidebarMenuItem>
                                        );
                                      })}
                                    </div>
                                  </div>
                                )}
                              </SidebarMenu>
                            </SidebarGroupContent>
                          </SidebarGroup>
                        </SidebarContent>

                        <SidebarFooter className="border-t border-gray-100 p-4">
                          <div className="flex items-center justify-between">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <button className="flex items-center justify-between cursor-pointer rounded-lg p-2 -m-2 hover:bg-gray-100 transition-colors flex-1 touch-target">
                                  <div className="flex items-center gap-3">
                                    {user?.avatar_url ? (
                                      <img src={user.avatar_url} alt={`Profile picture of ${user.full_name}`} className="w-10 h-10 rounded-full object-cover" />
                                    ) : (
                                      <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-coral)'}}>
                                        <span className="text-white font-semibold text-sm">{(user?.full_name || 'P')[0]}</span>
                                      </div>
                                    )}
                                    <div className="flex-1 min-w-0">
                                      <p className="font-medium text-gray-900 text-sm truncate">{user?.full_name || 'User'}</p>
                                      <div className="text-xs text-gray-600 flex items-center gap-2">
                                        {user?.role === 'parent' && user?.login_streak && (
                                          <span>🔥 {user.login_streak} days</span>
                                        )}
                                        {user?.subscription_tier === 'premium' && (
                                          <span className="text-purple-600 font-medium flex items-center gap-1">
                                            <Crown className="w-3 h-3" />
                                            Pro
                                          </span>
                                        )}
                                        <span className="capitalize">{user?.role.replace('_', ' ')}</span>
                                      </div>
                                    </div>
                                  </div>
                                </button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent className="w-56 mb-2" side="top" align="start">
                                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem onSelect={() => navigate(createPageUrl("Settings"))}>
                                  <Settings className="mr-2 h-4 w-4" />
                                  <span>Settings</span>
                                </DropdownMenuItem>
                                {user?.subscription_tier !== 'premium' && user?.role === 'parent' && (
                                  <DropdownMenuItem onSelect={() => navigate(createPageUrl("Upgrade"))} className="text-purple-600">
                                    <Crown className="mr-2 h-4 w-4" />
                                    <span>Upgrade to Pro</span>
                                  </DropdownMenuItem>
                                )}
                                <DropdownMenuSeparator />
                                <DropdownMenuItem onSelect={handleLogout}>
                                  <LogOut className="mr-2 h-4 w-4" />
                                  <span>Sign Out</span>
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </SidebarFooter>
                      </Sidebar>

                      <main id="main-content" className="flex-1 flex flex-col min-h-screen">
                        {/* Enhanced Mobile Navigation */}
                        <MobileNavigation 
                          userRole={user?.role}
                          currentPageTitle={currentPageTitle}
                          unreadMessageCount={0}
                        />

                        {/* Main Content with mobile padding adjustments */}
                        <div className="flex-1 pt-16 md:pt-0 pb-20 md:pb-0 overflow-y-auto">
                          <div className="h-full p-4 md:p-6">
                            {/* Enhanced Global Search for Desktop */}
                            <div className="hidden md:flex justify-end mb-6">
                              <SmartSearch className="w-96" placeholder="Search everything..." />
                            </div>
                            <LazyPageWrapper page={CurrentPageComponent} />
                          </div>
                        </div>
                      </main>

                      {/* Quick Actions Menu */}
                      <QuickActionsMenu />
                      
                      {/* CCPA Compliance Banner */}
                      <CCPABanner />
                    </div>
                  <Toaster />
                  </SidebarProvider>
                </NotificationProvider>
              </UndoRedoProvider>
            </TutorialProvider>
          </FocusStylesProvider>
        </AccessibilityProvider>
      </ToastProvider>
    </ErrorBoundary>
  );
}
