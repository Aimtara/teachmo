import React, { useState, useEffect } from 'react';
import { JournalEntry, User, Child } from '@/api/entities';
import { InvokeLLM } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar, Loader2, BookHeart, BrainCircuit, BarChart3, Share2, User as UserIcon, Plus } from 'lucide-react';
import GrowthJournal from '../components/growth/GrowthJournal';
import { format, parseISO, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay } from 'date-fns';

function JournalCalendar({ entries, onDateSelect, onEntrySelect }) {
    const today = new Date();
    const [currentMonth, setCurrentMonth] = useState(today);

    const daysInMonth = eachDayOfInterval({
        start: startOfMonth(currentMonth),
        end: endOfMonth(currentMonth),
    });

    const getEntriesForDay = (day) => {
        return entries.filter(entry => isSameDay(parseISO(entry.entry_date), day));
    };

    return (
        <Card>
            <CardHeader>
                <div className="flex justify-between items-center">
                    <CardTitle>{format(currentMonth, 'MMMM yyyy')}</CardTitle>
                    <div>
                        <Button variant="outline" size="sm" onClick={() => setCurrentMonth(prev => new Date(prev.setMonth(prev.getMonth() - 1)))}>‹</Button>
                        <Button variant="outline" size="sm" onClick={() => setCurrentMonth(new Date())} className="mx-2">Today</Button>
                        <Button variant="outline" size="sm" onClick={() => setCurrentMonth(prev => new Date(prev.setMonth(prev.getMonth() + 1)))}>›</Button>
                    </div>
                </div>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-7 gap-2 text-center text-sm">
                    {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => <div key={day} className="font-bold">{day}</div>)}
                    {Array.from({ length: startOfMonth(currentMonth).getDay() }).map((_, i) => <div key={`empty-${i}`} />)}
                    {daysInMonth.map(day => {
                        const dayEntries = getEntriesForDay(day);
                        return (
                            <button
                                key={day.toString()}
                                onClick={() => onDateSelect(day, dayEntries)}
                                className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors relative
                                    ${isSameDay(day, today) ? 'bg-blue-100' : ''}
                                    ${dayEntries.length > 0 ? 'bg-purple-200 hover:bg-purple-300' : 'hover:bg-gray-100'}
                                `}
                            >
                                {format(day, 'd')}
                                {dayEntries.length > 1 && (
                                    <div className="absolute -top-1 -right-1 w-4 h-4 bg-purple-500 text-white text-xs rounded-full flex items-center justify-center">
                                        {dayEntries.length}
                                    </div>
                                )}
                            </button>
                        );
                    })}
                </div>
            </CardContent>
        </Card>
    );
}

export default function JournalPage() {
    const [user, setUser] = useState(null);
    const [children, setChildren] = useState([]);
    const [entries, setEntries] = useState([]);
    const [todayEntries, setTodayEntries] = useState([]);
    const [selectedEntries, setSelectedEntries] = useState([]);
    const [selectedEntry, setSelectedEntry] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    
    const [isInsightModalOpen, setIsInsightModalOpen] = useState(false);
    const [insights, setInsights] = useState(null);
    const [isGeneratingInsights, setIsGeneratingInsights] = useState(false);

    useEffect(() => {
        loadJournalData();
    }, []);

    const loadJournalData = async () => {
        setIsLoading(true);
        try {
            const [currentUser, childData, entryData] = await Promise.all([
                User.me(),
                Child.list(),
                JournalEntry.filter({}, '-created_date')
            ]);
            setUser(currentUser);
            setChildren(childData);
            setEntries(entryData);
            
            const today = format(new Date(), 'yyyy-MM-dd');
            const foundTodayEntries = entryData.filter(e => e.entry_date === today);
            setTodayEntries(foundTodayEntries);

        } catch (error) {
            console.error("Error loading journal data:", error);
        }
        setIsLoading(false);
    };

    const handleDateSelect = (date, dayEntries) => {
        if (dayEntries.length === 1) {
            setSelectedEntry(dayEntries[0]);
        } else if (dayEntries.length > 1) {
            setSelectedEntries(dayEntries);
        } else {
            // No entries for this day - could create new entry for this date
            setSelectedEntry({ entry_date: format(date, 'yyyy-MM-dd') });
        }
    };

    const generateInsights = async () => {
        setIsGeneratingInsights(true);
        setInsights(null);
        try {
            const recentEntries = entries.slice(0, 15).map(e => ({
                date: e.entry_date,
                prompt: e.prompt,
                content: e.content,
                mood: e.mood,
                tags: e.tags
            }));

            const response = await InvokeLLM({
                prompt: `As Teachmo, analyze these recent journal entries from a parent. Identify key themes, emotional patterns, and frequently mentioned topics. Provide a gentle, supportive summary.

                Entries: ${JSON.stringify(recentEntries)}

                Provide a "summary" of key themes, a "word_cloud" array of important words, and an "encouragement" to support the parent.`,
                response_json_schema: {
                    type: "object",
                    properties: {
                        summary: { type: "string" },
                        word_cloud: { type: "array", items: { type: "string" } },
                        encouragement: { type: "string" }
                    },
                    required: ["summary", "word_cloud", "encouragement"]
                }
            });
            setInsights(response);
        } catch (error) {
            console.error("Error generating insights:", error);
            setInsights({ summary: "Could not generate insights at this time.", word_cloud: [], encouragement: "Please try again later." });
        }
        setIsGeneratingInsights(false);
    };
    
    if (isLoading) {
        return <div className="flex items-center justify-center h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;
    }

    return (
        <div className="min-h-screen p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
            <div className="max-w-4xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-3">
                        <BookHeart style={{color: 'var(--teachmo-sage)'}} />
                        Growth Journal
                    </h1>
                    <p className="text-gray-600">A private space for your parenting journey—reflect, celebrate, and grow.</p>
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2">
                        <Tabs defaultValue="today" className="w-full">
                            <TabsList className="grid w-full grid-cols-2">
                                <TabsTrigger value="today" className="gap-2">
                                    <Plus className="w-4 h-4" />
                                    Today's Entries ({todayEntries.length})
                                </TabsTrigger>
                                <TabsTrigger value="write" className="gap-2">
                                    Write New Entry
                                </TabsTrigger>
                            </TabsList>
                            
                            <TabsContent value="today" className="space-y-6 mt-6">
                                {todayEntries.length > 0 ? (
                                    <div className="space-y-4">
                                        {todayEntries.map((entry, index) => (
                                            <Card key={entry.id} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setSelectedEntry(entry)}>
                                                <CardContent className="p-4">
                                                    <div className="flex items-start justify-between mb-2">
                                                        <div className="flex items-center gap-2">
                                                            {entry.mood && (
                                                                <Badge variant="secondary">
                                                                    {entry.mood}
                                                                </Badge>
                                                            )}
                                                            {entry.child_id && children.find(c => c.id === entry.child_id) && (
                                                                <Badge variant="outline" className="flex items-center gap-1">
                                                                    <UserIcon className="w-3 h-3" />
                                                                    {children.find(c => c.id === entry.child_id)?.name}
                                                                </Badge>
                                                            )}
                                                        </div>
                                                        <span className="text-sm text-gray-500">
                                                            {format(new Date(entry.created_date), 'h:mm a')}
                                                        </span>
                                                    </div>
                                                    <p className="text-sm text-gray-700 line-clamp-3">{entry.content}</p>
                                                    {entry.tags && entry.tags.length > 0 && (
                                                        <div className="flex flex-wrap gap-1 mt-2">
                                                            {entry.tags.slice(0, 3).map(tag => (
                                                                <Badge key={tag} variant="outline" className="text-xs">
                                                                    {tag}
                                                                </Badge>
                                                            ))}
                                                            {entry.tags.length > 3 && (
                                                                <Badge variant="outline" className="text-xs">
                                                                    +{entry.tags.length - 3} more
                                                                </Badge>
                                                            )}
                                                        </div>
                                                    )}
                                                </CardContent>
                                            </Card>
                                        ))}
                                    </div>
                                ) : (
                                    <Card className="border-dashed border-2">
                                        <CardContent className="p-8 text-center">
                                            <BookHeart className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                                            <h3 className="text-lg font-semibold text-gray-900 mb-2">No entries today yet</h3>
                                            <p className="text-gray-600 mb-4">Start your daily reflection and capture this moment in your parenting journey.</p>
                                        </CardContent>
                                    </Card>
                                )}
                            </TabsContent>
                            
                            <TabsContent value="write" className="mt-6">
                                <GrowthJournal user={user} children={children} onEntrySaved={loadJournalData} />
                            </TabsContent>
                        </Tabs>
                    </div>
                    
                    <div className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2"><BarChart3 /> Your Progress</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <p>You've written {entries.length} entries. Keep it up!</p>
                                <Button onClick={() => { setIsInsightModalOpen(true); generateInsights(); }} className="w-full" variant="outline">
                                    <BrainCircuit className="w-4 h-4 mr-2" />
                                    Get AI Insights
                                </Button>
                            </CardContent>
                        </Card>
                        <JournalCalendar entries={entries} onDateSelect={handleDateSelect} />
                    </div>
                </div>

                <Dialog open={isInsightModalOpen} onOpenChange={setIsInsightModalOpen}>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle className="flex items-center gap-2"><BrainCircuit /> AI-Powered Insights</DialogTitle>
                            <DialogDescription>Here are some themes from your recent journal entries.</DialogDescription>
                        </DialogHeader>
                        {isGeneratingInsights ? (
                            <div className="text-center p-8"><Loader2 className="w-6 h-6 animate-spin mx-auto" /></div>
                        ) : insights ? (
                            <div className="space-y-4">
                                <div>
                                    <h4 className="font-bold">Summary</h4>
                                    <p className="text-sm text-gray-700">{insights.summary}</p>
                                </div>
                                <div>
                                    <h4 className="font-bold">Key Themes</h4>
                                    <div className="flex flex-wrap gap-2 mt-2">
                                        {insights.word_cloud.map(word => <Badge key={word}>{word}</Badge>)}
                                    </div>
                                </div>
                                <div>
                                    <h4 className="font-bold">A Little Encouragement</h4>
                                    <p className="text-sm text-gray-700 italic">"{insights.encouragement}"</p>
                                </div>
                            </div>
                        ) : null}
                    </DialogContent>
                </Dialog>

                {/* Multiple Entries Dialog */}
                <Dialog open={selectedEntries.length > 0} onOpenChange={() => setSelectedEntries([])}>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Multiple Entries</DialogTitle>
                            <DialogDescription>
                                You have {selectedEntries.length} entries for {selectedEntries[0] && format(parseISO(selectedEntries[0].entry_date), 'MMMM d, yyyy')}
                            </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-3 max-h-96 overflow-y-auto">
                            {selectedEntries.map((entry, index) => (
                                <Card key={entry.id} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => {
                                    setSelectedEntry(entry);
                                    setSelectedEntries([]);
                                }}>
                                    <CardContent className="p-4">
                                        <div className="flex items-center justify-between mb-2">
                                            <div className="flex items-center gap-2">
                                                {entry.mood && <Badge variant="secondary">{entry.mood}</Badge>}
                                                {entry.child_id && children.find(c => c.id === entry.child_id) && (
                                                    <Badge variant="outline" className="flex items-center gap-1">
                                                        <UserIcon className="w-3 h-3" />
                                                        {children.find(c => c.id === entry.child_id)?.name}
                                                    </Badge>
                                                )}
                                            </div>
                                            <span className="text-sm text-gray-500">
                                                {format(new Date(entry.created_date), 'h:mm a')}
                                            </span>
                                        </div>
                                        <p className="text-sm text-gray-700 line-clamp-2">{entry.content}</p>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </DialogContent>
                </Dialog>

                {/* Single Entry Dialog */}
                <Dialog open={!!selectedEntry} onOpenChange={() => setSelectedEntry(null)}>
                    <DialogContent className="max-w-2xl">
                        <DialogHeader>
                            <DialogTitle>Journal Entry</DialogTitle>
                            <DialogDescription>
                                {selectedEntry && selectedEntry.entry_date && format(parseISO(selectedEntry.entry_date), 'MMMM d, yyyy')}
                                {selectedEntry && selectedEntry.created_date && ` at ${format(new Date(selectedEntry.created_date), 'h:mm a')}`}
                            </DialogDescription>
                        </DialogHeader>
                        {selectedEntry && (
                            <div className="space-y-4 py-4">
                                <div className="flex items-center gap-2 mb-4">
                                    {selectedEntry.mood && (
                                        <Badge variant="secondary">{selectedEntry.mood}</Badge>
                                    )}
                                    {selectedEntry.child_id && children.find(c => c.id === selectedEntry.child_id) && (
                                        <Badge variant="outline" className="flex items-center gap-1">
                                            <UserIcon className="w-3 h-3" />
                                            {children.find(c => c.id === selectedEntry.child_id)?.name}
                                        </Badge>
                                    )}
                                </div>
                                
                                {selectedEntry.prompt && (
                                    <div className="p-3 bg-purple-50 rounded-lg border-l-4 border-purple-400">
                                        <p className="text-sm font-medium text-purple-900 mb-1">Prompt:</p>
                                        <p className="text-sm text-purple-800 italic">{selectedEntry.prompt}</p>
                                    </div>
                                )}
                                
                                <div className="prose prose-sm max-w-none">
                                    <p className="whitespace-pre-wrap">{selectedEntry.content}</p>
                                </div>
                                
                                {selectedEntry.tags && selectedEntry.tags.length > 0 && (
                                    <div>
                                        <p className="text-sm font-medium text-gray-700 mb-2">Tags:</p>
                                        <div className="flex flex-wrap gap-2">
                                            {selectedEntry.tags.map(tag => (
                                                <Badge key={tag} variant="outline">{tag}</Badge>
                                            ))}
                                        </div>
                                    </div>
                                )}
                                
                                <div className="flex justify-end gap-2 pt-4 border-t">
                                    <Button variant="ghost" size="sm">
                                        <Share2 className="w-4 h-4 mr-2" /> 
                                        Share to Pod
                                    </Button>
                                </div>
                            </div>
                        )}
                    </DialogContent>
                </Dialog>
            </div>
        </div>
    );
}