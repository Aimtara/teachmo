
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Post, Comment, Like, Follow, User, Pod, PodMember, Kudo } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Users, MessageSquare, Heart, TrendingUp, Plus, Search, Filter, Star, Trophy, Calendar, Home, Crown, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';

import CreatePostForm from '../components/feed/CreatePostForm';
import PostCard from '../components/feed/PostCard';
import UserCard from '../components/community/UserCard';
import PodCard from '../components/pods/PodCard';
import CreatePodModal from '../components/pods/CreatePodModal';
import { usePremium } from '../components/shared/usePremium';

export default function Community() {
  const [activeTab, setActiveTab] = useState('feed');
  const [posts, setPosts] = useState([]);
  const [users, setUsers] = useState([]);
  const [pods, setPods] = useState([]);
  const [myPods, setMyPods] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [showCreatePod, setShowCreatePod] = useState(false); // Used showCreatePod consistently instead of showCreatePodModal
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [followers, setFollowers] = useState([]); // New state for followers
  const [following, setFollowing] = useState([]); // New state for following

  const { isPremium } = usePremium();

  useEffect(() => {
    loadAllContent(); // Renamed from loadCommunityData
  }, []);

  const loadAllContent = async () => { // Renamed from loadCommunityData
    setIsLoading(true);
    try {
      const [
        currentUserData,
        postsData,
        usersData,
        podsData,
        kudosData, // New: Added for potential future use or comprehensive data fetching
        commentsData // New: Added for potential future use or comprehensive data fetching
      ] = await Promise.all([
        User.me(),
        Post.list('-created_date', 50),
        User.list('-created_date', 20),
        Pod.list('-created_date', 20),
        Kudo.list(), // Fetching all kudos (adjust filters if needed)
        Comment.list() // Fetching all comments (adjust filters if needed)
      ]);

      setCurrentUser(currentUserData);
      setPosts(postsData);
      setUsers(usersData.filter(u => u.id !== currentUserData.id));
      setPods(podsData);

      // Load user's pods
      const userPodMemberships = await PodMember.filter({ user_id: currentUserData.id });
      const userPodIds = userPodMemberships.map(pm => pm.pod_id);
      const userPods = podsData.filter(p => userPodIds.includes(p.id));
      setMyPods(userPods);

      // New: Load followers and following for the current user
      if (currentUserData) {
        const userFollowers = await Follow.filter({ following_id: currentUserData.id });
        const userFollowing = await Follow.filter({ follower_id: currentUserData.id });
        setFollowers(userFollowers);
        setFollowing(userFollowing);
      }

    } catch (error) {
      console.error('Error loading community data:', error);
    }
    setIsLoading(false);
  };

  const handleCreatePost = async (postData) => {
    try {
      const newPost = await Post.create({
        ...postData,
        user_id: currentUser.id,
        author_name: currentUser.full_name,
        author_avatar_url: currentUser.avatar_url
      });
      setPosts([newPost, ...posts]);
      setShowCreatePost(false);
    } catch (error) {
      console.error('Error creating post:', error);
    }
  };

  const handleLikePost = async (postId, isLiked) => {
    try {
      if (isLiked) {
        const existingLike = await Like.filter({ post_id: postId, user_id: currentUser.id });
        if (existingLike.length > 0) {
          await Like.delete(existingLike[0].id);
        }
      } else {
        await Like.create({ post_id: postId, user_id: currentUser.id });
      }
      // Update posts to reflect the like change - using loadAllContent for full refresh
      loadAllContent();
    } catch (error) {
      console.error('Error handling like:', error);
    }
  };

  const handleCreatePod = async (podData) => {
    try {
      const newPod = await Pod.create({
        ...podData,
        owner_id: currentUser.id
      });
      
      // Add creator as first member
      await PodMember.create({
        pod_id: newPod.id,
        user_id: currentUser.id
      });

      setShowCreatePod(false);
      // Reload all content to ensure new pod and membership are reflected
      await loadAllContent();
    } catch (error) {
      console.error('Error creating pod:', error);
    }
  };

  const handleFollowToggle = async (targetUserId, isCurrentlyFollowing) => {
    if (!currentUser) return; // Ensure a current user exists
    try {
      if (isCurrentlyFollowing) {
        // Find the specific follow record to delete
        const followRecord = following.find(f => f.following_id === targetUserId && f.follower_id === currentUser.id);
        if (followRecord) {
          await Follow.delete(followRecord.id);
        }
      } else {
        await Follow.create({ follower_id: currentUser.id, following_id: targetUserId });
        // Skip notification creation due to database connectivity issues
        console.log("Skipping notification creation due to database connectivity issues");
      }
      // Refresh all community data to update follow states and counts
      await loadAllContent();
    } catch (error) {
      console.error('Error handling follow:', error);
    }
  };

  const filteredContent = useMemo(() => {
    if (!searchQuery) return { posts, users, pods };
    
    const query = searchQuery.toLowerCase();
    return {
      posts: posts.filter(p => 
        p.content?.toLowerCase().includes(query) ||
        p.author_name?.toLowerCase().includes(query)
      ),
      users: users.filter(u => 
        u.full_name?.toLowerCase().includes(query) ||
        u.username?.toLowerCase().includes(query)
      ),
      pods: pods.filter(p => 
        p.name?.toLowerCase().includes(query) ||
        p.description?.toLowerCase().includes(query)
      )
    };
  }, [posts, users, pods, searchQuery]);

  if (isLoading) {
    return (
      <div className="min-h-screen p-4 flex items-center justify-center" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <div className="text-center">
          <Users className="w-12 h-12 mx-auto mb-4 text-gray-400 animate-pulse" />
          <p className="text-gray-600">Loading community...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8" style={{backgroundColor: 'var(--teachmo-cream)'}}>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Community</h1>
          <p className="text-gray-600">Connect with other parents, share experiences, and learn together</p>
        </div>

        {/* Search Bar */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search posts, people, or pods..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="feed" className="gap-2">
              <Home className="w-4 h-4" />
              Feed ({filteredContent.posts.length})
            </TabsTrigger>
            <TabsTrigger value="people" className="gap-2">
              <Users className="w-4 h-4" />
              People ({filteredContent.users.length})
            </TabsTrigger>
            <TabsTrigger value="pods" className="gap-2">
              <MessageSquare className="w-4 h-4" />
              Pods ({filteredContent.pods.length})
            </TabsTrigger>
            <TabsTrigger value="my-activity" className="gap-2">
              <Star className="w-4 h-4" />
              My Activity
            </TabsTrigger>
          </TabsList>

          {/* Feed Tab */}
          <TabsContent value="feed" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Community Feed</h2>
              <Button
                onClick={() => setShowCreatePost(true)}
                style={{backgroundColor: 'var(--teachmo-sage)'}}
                className="gap-2"
              >
                <Plus className="w-4 h-4" />
                Share Something
              </Button>
            </div>

            {showCreatePost && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <CreatePostForm
                  onSubmit={handleCreatePost}
                  onCancel={() => setShowCreatePost(false)}
                  currentUser={currentUser}
                />
              </motion.div>
            )}

            <div className="space-y-4">
              <AnimatePresence>
                {filteredContent.posts.map((post) => (
                  <PostCard
                    key={post.id}
                    post={post}
                    currentUser={currentUser}
                    onLike={handleLikePost}
                  />
                ))}
              </AnimatePresence>
            </div>

            {filteredContent.posts.length === 0 && (
              <div className="text-center py-12">
                <MessageSquare className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <h3 className="text-xl font-semibold text-gray-700 mb-2">No posts yet</h3>
                <p className="text-gray-500 mb-4">Be the first to share something with the community!</p>
                <Button
                  onClick={() => setShowCreatePost(true)}
                  style={{backgroundColor: 'var(--teachmo-sage)'}}
                >
                  Create First Post
                </Button>
              </div>
            )}
          </TabsContent>

          {/* People Tab */}
          <TabsContent value="people" className="space-y-6">
            <h2 className="text-xl font-semibold">Connect with Parents</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <AnimatePresence>
                {filteredContent.users.map((user) => (
                  <UserCard
                    key={user.id}
                    user={user}
                    currentUser={currentUser}
                    isFollowing={following.some(f => f.following_id === user.id)} // Pass if current user is following this user
                    onFollowToggle={handleFollowToggle} // Pass the follow toggle handler
                  />
                ))}
              </AnimatePresence>
            </div>

            {filteredContent.users.length === 0 && (
              <div className="text-center py-12">
                <Users className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <h3 className="text-xl font-semibold text-gray-700 mb-2">No users found</h3>
                <p className="text-gray-500">Try adjusting your search or check back later!</p>
              </div>
            )}
          </TabsContent>

          {/* Pods Tab */}
          <TabsContent value="pods" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Parent Groups</h2>
              <Button
                onClick={() => setShowCreatePod(true)}
                style={{backgroundColor: 'var(--teachmo-sage)'}}
                className="gap-2"
              >
                <Plus className="w-4 h-4" />
                Create Pod
              </Button>
            </div>

            {myPods.length > 0 && (
              <div className="mb-8">
                <h3 className="text-lg font-medium text-gray-900 mb-4">My Pods</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {myPods.map((pod) => (
                    <PodCard key={pod.id} pod={pod} currentUser={currentUser} isMember={true} />
                  ))}
                </div>
              </div>
            )}

            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Discover Pods</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <AnimatePresence>
                  {filteredContent.pods
                    .filter(pod => !myPods.some(myPod => myPod.id === pod.id))
                    .map((pod) => (
                      <PodCard key={pod.id} pod={pod} currentUser={currentUser} isMember={false} />
                    ))}
                </AnimatePresence>
              </div>
            </div>

            {filteredContent.pods.length === 0 && (
              <div className="text-center py-12">
                <MessageSquare className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <h3 className="text-xl font-semibold text-gray-700 mb-2">No pods found</h3>
                <p className="text-gray-500 mb-4">Create the first pod for your community!</p>
                <Button
                  onClick={() => setShowCreatePod(true)}
                  style={{backgroundColor: 'var(--teachmo-sage)'}}
                >
                  Create First Pod
                </Button>
              </div>
            )}
          </TabsContent>

          {/* My Activity Tab */}
          <TabsContent value="my-activity" className="space-y-6">
            <h2 className="text-xl font-semibold">My Community Activity</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6 text-center">
                  <MessageSquare className="w-12 h-12 mx-auto mb-4 text-blue-600" />
                  <h3 className="font-semibold text-gray-900 mb-2">Posts Created</h3>
                  <p className="text-3xl font-bold text-blue-600">
                    {posts.filter(p => p.user_id === currentUser?.id).length}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <Heart className="w-12 h-12 mx-auto mb-4 text-red-600" />
                  <h3 className="font-semibold text-gray-900 mb-2">Kudos Given</h3>
                  <p className="text-3xl font-bold text-red-600">
                    {currentUser?.points || 0}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <Users className="w-12 h-12 mx-auto mb-4 text-green-600" />
                  <h3 className="font-semibold text-gray-900 mb-2">Pods Joined</h3>
                  <p className="text-3xl font-bold text-green-600">
                    {myPods.length}
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {posts
                    .filter(p => p.user_id === currentUser?.id)
                    .slice(0, 5)
                    .map((post) => (
                      <div key={post.id} className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                        <MessageSquare className="w-5 h-5 text-gray-500 mt-1" />
                        <div className="flex-1">
                          <p className="text-sm text-gray-900 line-clamp-2">{post.content}</p>
                          <p className="text-xs text-gray-500 mt-1">
                            {formatDistanceToNow(new Date(post.created_date))} ago
                          </p>
                        </div>
                      </div>
                    ))}
                  
                  {posts.filter(p => p.user_id === currentUser?.id).length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <p>No posts yet. Start sharing with the community!</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Modals */}
      <AnimatePresence>
        {showCreatePod && (
          <CreatePodModal
            onClose={() => setShowCreatePod(false)}
            onSubmit={handleCreatePod}
            currentUser={currentUser}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
