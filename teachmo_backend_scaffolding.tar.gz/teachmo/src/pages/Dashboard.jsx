import React, { useState, useEffect, useCallback } from "react";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User, Child, Activity, ParentingTip, Achievement, UserAchievement, JournalEntry, Assignment, StudentParentLink } from "@/api/entities";
import { Loader2, Plus, Target, TrendingUp, Calendar, Users, BookOpen, Sparkles, ArrowRight, CheckCircle, Clock, Bot, AlertCircle, RefreshCw, MessageSquare, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format, isToday, startOfWeek, endOfWeek, parseISO, isYesterday } from "date-fns";
import { motion } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";

import EmotionalCheckIn from "../components/dashboard/EmotionalCheckIn";
import { usePremium } from "../components/shared/usePremium";
import QuickChildSetup from "../components/dashboard/QuickChildSetup";
import { DashboardSkeleton } from "../components/shared/ImprovedSkeletons";
import { SkipLink } from "../components/shared/SkipLink";
import { useAccessibility } from "../components/shared/AccessibilityProvider";
import QuickTips from "../components/tour/QuickTips";
import ProgressCelebration from "../components/tour/ProgressCelebration";
import { fetchWithRetry, retryAuthCall } from "@/components/shared/apiUtils";
import { useToast } from "@/components/ui/use-toast";
import TodaysFocus from "../components/dashboard/TodaysFocus";
import QuickActionBar from "../components/dashboard/QuickActionBar";
import OffersCarousel from "../components/offers/OffersCarousel";
import PersonalizedInsights from "../components/dashboard/PersonalizedInsights";
import PersonalizedDashboard from "../components/dashboard/PersonalizedDashboard";

import { useApi, useEntityCrud } from '@/components/hooks/useApi';
import { useEntityData } from '@/components/hooks/useEntityData';
import { ProgressiveLoader, EmptyState, NetworkStatus } from '@/components/shared/LoadingStates';
import { ApiProvider } from '@/components/shared/ApiProvider';

export default function Dashboard() {
  // Replace useState with standardized API hooks
  const userApi = useEntityCrud(User, {
    context: 'dashboard user data',
    showToastOnError: true
  });
  
  const childrenData = useEntityData(Child, {
    enableCache: true,
    dependencies: [userApi.data?.id]
  });
  
  const activitiesData = useEntityData(Activity, {
    initialFilter: { status: { $ne: 'completed' } },
    initialSort: '-created_date',
    pageSize: 10,
    enableCache: true
  });
  
  const tipsData = useEntityData(ParentingTip, {
    initialSort: '-created_date',
    pageSize: 5,
    enableCache: true
  });

  const [user, setUser] = useState(null);
  const [showCelebration, setShowCelebration] = useState(false);
  const [celebrationData, setCelebrationData] = useState(null);
  const [weeklyStats, setWeeklyStats] = useState({
    activitiesCompleted: 0,
    activitiesPlanned: 0,
    streak: 0,
    tipProgress: 0,
    totalTips: 0
  });

  const { isPremium } = usePremium();
  const { announceToScreenReader } = useAccessibility();
  const { toast } = useToast();

  // Load dashboard data with standardized error handling
  const loadDashboardData = useCallback(async () => {
    try {
      // Load user data first
      const userData = await userApi.get('me');
      setUser(userData);

      // --- Login Streak Calculation Logic ---
      if (userData) {
        const today = new Date();
        const lastLogin = userData.last_login_date ? parseISO(userData.last_login_date) : null;
        let newStreak = userData.login_streak || 0;
        let needsUpdate = false;

        if (!lastLogin) {
          newStreak = 1;
          needsUpdate = true;
        } else if (!isToday(lastLogin)) {
          if (isYesterday(lastLogin)) {
            newStreak++;
          } else {
            newStreak = 1;
          }
          needsUpdate = true;
        }

        if (needsUpdate) {
          try {
            await User.updateMyUserData({
              login_streak: newStreak,
              last_login_date: today.toISOString()
            });
            userData.login_streak = newStreak;
            userData.last_login_date = today.toISOString();
            setUser(userData);
          } catch (updateError) {
            console.error("Failed to update user streak:", updateError);
          }
        }
      }

      // Load related data
      await Promise.all([
        childrenData.refresh(),
        activitiesData.refresh(),
        tipsData.refresh()
      ]);

      // Calculate weekly stats AFTER data is refreshed
      const weekStart = startOfWeek(new Date());
      const weekEnd = endOfWeek(new Date());
      
      const currentActivities = activitiesData.data;
      const currentTips = tipsData.data;

      const weeklyActivities = currentActivities.filter(a => 
        a.completion_date && 
        new Date(a.completion_date) >= weekStart && 
        new Date(a.completion_date) <= weekEnd
      );

      setWeeklyStats({
        activitiesCompleted: weeklyActivities.filter(a => a.status === 'completed').length,
        activitiesPlanned: currentActivities.filter(a => a.status === 'planned').length,
        streak: userData?.login_streak || 0,
        tipProgress: currentTips.filter(t => t.is_read).length,
        totalTips: currentTips.length
      });

    } catch (error) {
      console.error('Dashboard data load failed:', error);
      // Error handling is managed by the API hooks and ProgressiveLoader
    }
  }, [userApi, childrenData, activitiesData, tipsData]);

  // Initial load
  useEffect(() => {
    loadDashboardData();
  }, [loadDashboardData]);

  // Check for achievements when data loads or relevant data changes
  useEffect(() => {
    if (!user || userApi.isLoading()) return;

    const userAchievements = user.tutorial_progress?.achievements || [];

    // Check for first activity completion
    if (activitiesData.data.some(a => a.status === 'completed') && 
        !userAchievements.includes('first_activity')) {
      triggerAchievement('first_activity');
    }

    // Check for activity streak
    if (weeklyStats.activitiesCompleted >= 3 && 
        !userAchievements.includes('activity_streak_3')) {
      triggerAchievement('activity_streak_3');
    }
  }, [user, activitiesData.data, weeklyStats.activitiesCompleted, userApi.isLoading()]);

  const triggerAchievement = async (achievementType) => {
    try {
      const currentAchievements = user.tutorial_progress?.achievements || [];
      if (currentAchievements.includes(achievementType)) return;

      const updatedTutorialProgress = {
        ...(user.tutorial_progress || {}),
        achievements: [...currentAchievements, achievementType]
      };

      await User.updateMyUserData({
        tutorial_progress: updatedTutorialProgress
      });
      
      setUser(prev => ({
        ...prev,
        tutorial_progress: updatedTutorialProgress
      }));

      setCelebrationData({ type: achievementType });
      setShowCelebration(true);
      
      toast({
        title: "🎉 Achievement Unlocked!",
        description: `You've earned the "${achievementType.replace(/_/g, ' ')}" badge.`,
      });

      announceToScreenReader(`Achievement unlocked: ${achievementType.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}`);
    } catch (error) {
      console.error('Error saving achievement:', error);
      toast({
        variant: "destructive",
        title: "Oh no!",
        description: "There was a problem saving your achievement.",
      });
      announceToScreenReader("Failed to unlock achievement.");
    }
  };

  const handleMoodUpdate = async (newMood) => {
    try {
      await userApi.update('me', {
        current_mood: newMood,
        last_mood_checkin: new Date().toISOString()
      });
      
      setUser(prev => ({
        ...prev,
        current_mood: newMood,
        last_mood_checkin: new Date().toISOString()
      }));

      announceToScreenReader(`Mood updated to ${newMood}`);
    } catch (error) {
      announceToScreenReader("Failed to update mood");
    }
  };

  const handleChildAdded = async () => {
    await childrenData.refresh();
    loadDashboardData(); 
  };

  // Calculate derived state
  const hasChildren = childrenData.data.length > 0;
  const hasPlannedActivities = activitiesData.data.some(a => a.status === 'planned');
  
  // Combined loading state
  const isLoading = userApi.isLoading() || childrenData.isLoading || activitiesData.isLoading || tipsData.isLoading;
  const primaryError = userApi.error || childrenData.error || activitiesData.error || tipsData.error;

  return (
    <ApiProvider>
      <div className="min-h-screen p-4 md:p-6" style={{backgroundColor: 'var(--teachmo-cream)'}}>
        <SkipLink />
        
        {/* Network Status */}
        <NetworkStatus />
        
        {/* Quick Tips for contextual help */}
        <QuickTips currentPage="Dashboard" />
        
        {/* Achievement Celebration */}
        <ProgressCelebration
          achievement={celebrationData}
          show={showCelebration}
          onClose={() => setShowCelebration(false)}
        />

        <main id="main-content" className="max-w-7xl mx-auto space-y-6">
          <ProgressiveLoader
            isLoading={isLoading}
            error={primaryError}
            onRetry={loadDashboardData}
            fallback={() => <DashboardSkeleton />}
          >
            {/* SIMPLIFIED HEADER */}
            <header className="mb-6">
              <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">
                {new Date().getHours() < 12 ? 'Good morning' : new Date().getHours() < 17 ? 'Good afternoon' : 'Good evening'}, {user?.full_name?.split(' ')[0] || 'Parent'}! 
              </h1>
              {weeklyStats.streak > 0 && (
                <div className="flex items-center gap-2 text-orange-600 font-medium" aria-label={`${weeklyStats.streak} day login streak`}>
                  <span role="img" aria-label="Fire emoji">🔥</span> 
                  <span>{weeklyStats.streak} day streak</span>
                </div>
              )}
            </header>

            {/* CHILD SETUP - Only show if no children */}
            {!hasChildren && (
              <div data-tour="add-child">
                <QuickChildSetup onChildAdded={handleChildAdded} />
              </div>
            )}

            {/* Main Dashboard Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Main Content Column */}
              <div className="lg:col-span-8 space-y-8">
                {/* TODAY'S FOCUS */}
                {hasChildren && (
                  <div data-tour="todays-focus">
                    <TodaysFocus
                      user={user}
                      activities={activitiesData.data}
                      schoolAssignments={[]}
                      messages={[]}
                      onUpdate={loadDashboardData}
                    />
                  </div>
                )}

                {/* QUICK ACTION BAR */}
                <QuickActionBar 
                  user={user}
                  children={childrenData.data}
                  hasChildren={hasChildren}
                  hasPlannedActivities={hasPlannedActivities}
                  hasPremium={isPremium}
                />

                {/* EMOTIONAL CHECK-IN */}
                <div data-tour="emotional-check-in">
                  <EmotionalCheckIn user={user} onMoodUpdate={handleMoodUpdate} />
                </div>

                {/* AD/OFFER CAROUSEL */}
                <OffersCarousel />

                {/* PERSONALIZED INSIGHTS */}
                {hasChildren && (
                  <PersonalizedInsights 
                    user={user}
                    children={childrenData.data} 
                    activities={activitiesData.data} 
                    assignments={[]}
                    schoolAssignments={[]}
                    tips={tipsData.data}
                    onUpdate={loadDashboardData}
                  />
                )}
              </div>

              {/* Right Sidebar Column */}
              <div className="lg:col-span-4 space-y-8">
                {/* PARENTING TIP CARD */}
                {tipsData.data.length > 0 && (
                  <Card className="shadow-lg" data-tour="parenting-tip">
                    <CardHeader>
                      <CardTitle className="text-xl flex items-center justify-between">
                        <span>Parenting Tip of the Day</span>
                        <BookOpen className="w-5 h-5 text-purple-600" />
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 mb-4">{tipsData.data[0].title}</p>
                      <Link to={createPageUrl("Tips")}>
                        <Button variant="outline" className="w-full">
                          View All Tips <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      </Link>
                      {!isPremium && (
                        <div className="mt-4 text-center text-sm text-gray-500">
                          Unlock more personalized tips with <Link to={createPageUrl("Premium")} className="text-purple-600 font-semibold hover:underline">Premium</Link>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}

                {/* WEEKLY STATS CARD */}
                <Card className="shadow-lg" data-tour="weekly-stats">
                  <CardHeader>
                    <CardTitle className="text-xl flex items-center justify-between">
                      <span>Your Weekly Progress</span>
                      <TrendingUp className="w-5 h-5 text-green-600" />
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-700">Activities Completed:</span>
                      <Badge variant="secondary" className="bg-green-100 text-green-700 text-base py-1 px-3">
                        {weeklyStats.activitiesCompleted}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-700">Planned Activities:</span>
                      <Badge variant="secondary" className="bg-blue-100 text-blue-700 text-base py-1 px-3">
                        {weeklyStats.activitiesPlanned}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-700">Login Streak:</span>
                      <Badge variant="secondary" className="bg-orange-100 text-orange-700 text-base py-1 px-3">
                        {weeklyStats.streak} Days 🔥
                      </Badge>
                    </div>
                    {weeklyStats.totalTips > 0 && (
                      <div>
                        <div className="flex items-center justify-between text-gray-700 mb-2">
                          <span>Tips Read:</span>
                          <span>{weeklyStats.tipProgress}/{weeklyStats.totalTips}</span>
                        </div>
                        <Progress value={(weeklyStats.tipProgress / weeklyStats.totalTips) * 100} className="h-2" />
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* CHILD CARDS */}
                {hasChildren && (
                  <Card className="shadow-lg" data-tour="child-overview">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                      <CardTitle className="text-xl">Your Children</CardTitle>
                      <Link to={createPageUrl("Children")}>
                        <Button variant="ghost" size="sm">
                          Manage All
                        </Button>
                      </Link>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {childrenData.data.slice(0, 3).map(child => (
                          <div key={child.id} className="flex items-center justify-between py-2 border-b last:border-b-0">
                            <div className="flex items-center gap-3">
                              <span className="text-2xl" role="img" aria-label="Child avatar">{child.avatar_emoji || '👶'}</span>
                              <div>
                                <p className="font-semibold text-gray-800">{child.first_name}</p>
                                <p className="text-sm text-gray-500">{child.age} years old</p>
                              </div>
                            </div>
                            <Link to={createPageUrl("ChildProfile", { childId: child.id })}>
                              <Button variant="outline" size="sm">View</Button>
                            </Link>
                          </div>
                        ))}
                        {childrenData.data.length > 3 && (
                          <div className="text-center pt-2">
                            <Link to={createPageUrl("Children")} className="text-blue-600 hover:underline text-sm">
                              View {childrenData.data.length - 3} more children
                            </Link>
                          </div>
                        )}
                        <Link to={createPageUrl("ChildSetup")}>
                          <Button variant="ghost" className="w-full mt-2 border border-dashed">
                            <Plus className="mr-2 h-4 w-4" /> Add New Child
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>

            {/* PERSONALIZED DASHBOARD */}
            {hasChildren && (
              <PersonalizedDashboard
                user={user}
                children={childrenData.data}
                activities={activitiesData.data}
                schoolAssignments={[]}
                weeklyStats={weeklyStats}
                onMoodUpdate={handleMoodUpdate}
                tips={tipsData.data}
                isPremium={isPremium}
              />
            )}

            {/* Empty state for no children */}
            {!hasChildren && !childrenData.isLoading && (
              <EmptyState
                title="Welcome to Teachmo!"
                description="Get started by adding your first child profile to receive personalized activities and parenting guidance."
                action={
                  <Link to={createPageUrl("ChildSetup")}>
                    <Button size="lg" className="mt-4">
                      <Plus className="w-5 h-5 mr-2" />
                      Add Your First Child
                    </Button>
                  </Link>
                }
              />
            )}
          </ProgressiveLoader>
        </main>
      </div>
    </ApiProvider>
  );
}