
import React, { useState, useEffect, useCallback, useMemo, lazy, Suspense } from "react";
import { Activity, Child, User, LocalEvent, PartnerEvent } from "@/api/entities"; // Added PartnerEvent, removed unused entities
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"; // New
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Search, Loader2, Map, List, SlidersHorizontal, X, Calendar, MapPin, Lightbulb, AlertCircle } from "lucide-react"; // Added SlidersHorizontal, X
import { motion, AnimatePresence } from "framer-motion";
import { format, isToday, isTomorrow, isThisWeek } from 'date-fns';

import ActivityCard from "@/components/activities/ActivityCard"; // Changed to absolute import path
import LocalEventCard from "@/components/discover/LocalEventCard"; // Changed to absolute import path
import ActivityFilters from "@/components/activities/ActivityFilters"; // Changed to absolute import path
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

import { ProgressiveLoader, ListLoadingSkeleton, EmptyState } from '@/components/shared/LoadingStates'; // EmptyState path changed in outline

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"; // Kept for EventFilters
import { Slider } from "@/components/ui/slider"; // Kept for EventFilters
import { Label } from "@/components/ui/label"; // Kept for EventFilters

import OffersCarousel from "../components/offers/OffersCarousel";

import { usePremium } from "@/hooks/usePremium";
import { realEventSearch } from '@/api/functions';

import { useEntityData } from '@/components/hooks/useEntityData';
import { useFunction } from '@/components/hooks/useApi';
import { useDebounce } from '@/components/hooks/useDebounce'; // New hook

// --- NEW Skeleton Components ---
const SkeletonGrid = () => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    {[...Array(6)].map((_, i) => (
      <div key={i} className="bg-gray-200 h-64 rounded-lg animate-pulse" />
    ))}
  </div>
);

const MapSkeleton = () => (
    <div className="w-full h-[600px] bg-gray-200 rounded-lg animate-pulse flex items-center justify-center">
        <Map className="w-16 h-16 text-gray-400" />
    </div>
);

// --- Re-define InlineLoader (from original, was removed by placeholders) ---
const InlineLoader = () => <Loader2 className="animate-spin h-4 w-4 text-primary" />;

// Lazy load the MapView component
const MapView = React.lazy(() => import('../components/discover/MapView'));

// --- Placeholder for EventFilters component (retained from original file as outline did not provide an import path) ---
const EventFilters = ({ filters, onFiltersChange, isSearching }) => {
  const categories = ["Kids", "Family", "Arts", "Sports", "Music", "Education"]; // Example event categories
  const dates = [
    { value: "all", label: "Any Date" },
    { value: "today", label: "Today" },
    { value: "tomorrow", label: "Tomorrow" },
    { value: "this_week", label: "This Week" },
  ];

  return (
    <div className="bg-white/80 backdrop-blur-sm p-4 rounded-lg shadow-md mb-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
        <div className="space-y-1">
          <Label htmlFor="event-location">Location</Label>
          <Input
            id="event-location"
            placeholder="e.g., Brooklyn, NY or 90210"
            value={filters.location}
            onChange={(e) => onFiltersChange(prev => ({ ...prev, location: e.target.value }))}
            disabled={isSearching}
          />
        </div>
        <div className="space-y-1">
          <Label htmlFor="event-category">Category</Label>
          <Select
            value={filters.category}
            onValueChange={(value) => onFiltersChange(prev => ({ ...prev, category: value }))}
            disabled={isSearching}
          >
            <SelectTrigger id="event-category">
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map(cat => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1">
          <Label htmlFor="event-date">Date</Label>
          <Select
            value={filters.date}
            onValueChange={(value) => onFiltersChange(prev => ({ ...prev, date: value }))}
            disabled={isSearching}
          >
            <SelectTrigger id="event-date">
              <SelectValue placeholder="Any Date" />
            </SelectTrigger>
            <SelectContent>
              {dates.map(d => (
                <SelectItem key={d.value} value={d.value}>{d.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        {/* You could add price/radius filters here too if needed */}
      </div>
    </div>
  );
};
// --- End of retained EventFilters placeholder ---

export default function UnifiedDiscover() {
  const [user, setUser] = useState(null);

  // Replace useState with standardized data hooks
  const activitiesData = useEntityData(Activity, {
    initialSort: '-created_date',
    pageSize: 20,
    enableCache: true
  });

  const eventsData = useEntityData(LocalEvent, {
    initialSort: 'start_time',
    pageSize: 20,
    enableCache: true
  });

  const partnerEventsData = useEntityData(PartnerEvent, { // New data hook for Partner Events
    pageSize: 20,
    enableCache: true
  });

  const childrenData = useEntityData(Child, {
    enableCache: true
  });

  // Function call hook for real-time event search
  const eventSearchApi = useFunction(realEventSearch, {
    context: 'local events search',
    silent: true
  });

  const [view, setView] = useState('grid'); // 'grid' or 'map'
  const [filters, setFilters] = useState({
    category: 'all', // For activities and events
    ageRange: 'all', // For activities
    location: '', // For events
    date: 'all', // For events
    difficulty: 'all' // For activities
  });
  const [searchQuery, setSearchQuery] = useState(''); // Global search input
  const debouncedSearchQuery = useDebounce(searchQuery, 500); // Debounce search input
  const [selectedChild, setSelectedChild] = useState(null); // For AI activity suggestions
  const [showFilters, setShowFilters] = useState(false); // To toggle filter visibility

  const { isPremium, checkFeatureAccess } = usePremium();

  // Load initial user data
  useEffect(() => {
    const loadUserData = async () => {
      try {
        const userData = await User.me();
        const augmentedUserData = { ...userData };
        if (!augmentedUserData.latitude || !augmentedUserData.longitude) {
            augmentedUserData.latitude = 34.052235;
            augmentedUserData.longitude = -118.243683;
            if (!augmentedUserData.location) augmentedUserData.location = "Los Angeles, CA";
        }
        setUser(augmentedUserData);
        if (augmentedUserData?.location) {
          setFilters(prev => ({ ...prev, location: augmentedUserData.location }));
        }
      } catch (loadError) {
        console.error("Error loading initial user data:", loadError);
      }
    };
    loadUserData();
  }, []);

  // Enhanced search with error handling
  const handleEventSearch = useCallback(async (query, currentFilters = filters) => {
    try {
      const results = await eventSearchApi.call({
        query: query,
        location: currentFilters.location || user?.location,
        category: currentFilters.category !== 'all' ? currentFilters.category : undefined,
        date: currentFilters.date !== 'all' ? currentFilters.date : undefined
      });

      if (results?.events) {
        eventsData.setData(results.events);
      }
    } catch (error) {
      console.error('Event search failed:', error);
    }
  }, [filters, eventSearchApi, user?.location, eventsData]);

  // Trigger event search when debouncedSearchQuery changes or event filters/location change
  useEffect(() => {
    handleEventSearch(debouncedSearchQuery, filters);
  }, [debouncedSearchQuery, filters.location, filters.category, filters.date, handleEventSearch]);

  // Filter data based on current filters and search query
  const filteredActivities = useMemo(() => {
    let filtered = activitiesData.data;

    if (selectedChild) {
      filtered = filtered.filter(item =>
        item.child_id === selectedChild.id || !item.child_id
      );
    }

    if (filters.category !== 'all') {
      filtered = filtered.filter(item => item.category?.toLowerCase() === filters.category.toLowerCase());
    }

    if (filters.ageRange !== 'all') {
      const [minAge, maxAge] = filters.ageRange.split('-').map(Number);
      filtered = filtered.filter(item => {
        if (!item.age_range) return true;
        return item.age_range.min_age <= maxAge && item.age_range.max_age >= minAge;
      });
    }

    if (filters.difficulty !== 'all') {
      filtered = filtered.filter(item => item.difficulty?.toLowerCase() === filters.difficulty.toLowerCase());
    }

    if (searchQuery) {
      filtered = filtered.filter(item =>
        item.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    return filtered;
  }, [activitiesData.data, filters, searchQuery, selectedChild]);

  const filteredEvents = useMemo(() => {
    let filtered = eventsData.data;

    if (filters.category !== 'all') {
      filtered = filtered.filter(item => item.category?.toLowerCase() === filters.category.toLowerCase());
    }

    if (filters.date !== 'all') {
      filtered = filtered.filter(item => {
        const eventDate = new Date(item.start_time);
        switch (filters.date) {
          case 'today':
            return isToday(eventDate);
          case 'tomorrow':
            return isTomorrow(eventDate);
          case 'this_week':
            return isThisWeek(eventDate, { weekStartsOn: 0 });
          default:
            return true;
        }
      });
    }

    if (searchQuery) {
      filtered = filtered.filter(item =>
        item.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    return filtered;
  }, [eventsData.data, filters, searchQuery]);

  const filteredPartnerEvents = useMemo(() => {
    let filtered = partnerEventsData.data;

    if (searchQuery) {
        filtered = filtered.filter(item =>
            item.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
            item.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
            item.partner_name?.toLowerCase().includes(searchQuery.toLowerCase())
        );
    }
    // Add any specific PartnerEvent filters if available (e.g., location, type)
    return filtered;
  }, [partnerEventsData.data, searchQuery]);

  const displayItems = useMemo(() => {
    const activitiesWithType = filteredActivities.map(item => ({ ...item, type: 'activity' }));
    const eventsWithType = filteredEvents.map(item => ({ ...item, type: 'event' }));
    const partnerEventsWithType = filteredPartnerEvents.map(item => ({ ...item, type: 'partner_event' }));

    // Concatenate all types and potentially sort them for a unified grid view
    // For now, simple concatenation: activities first, then local events, then partner events.
    // A more advanced approach might involve sorting by date, relevance, etc.
    return [...activitiesWithType, ...eventsWithType, ...partnerEventsWithType];
  }, [filteredActivities, filteredEvents, filteredPartnerEvents]);

  const handleActivityAction = async (activity, action) => {
    try {
      switch (action) {
        case 'schedule':
          console.log('Scheduling activity:', activity.title);
          break;
        case 'bookmark':
          console.log('Toggling bookmark for activity:', activity.title);
          // Example: await UserBookmark.toggle(user.id, activity.id, 'activity');
          break;
        case 'complete':
          await activitiesData.updateItem(activity.id, {
            status: 'completed',
            completion_date: new Date().toISOString()
          });
          break;
        default:
          break;
      }
    } catch (error) {
      console.error('Activity action failed:', error);
    }
  };

  const handleLocalEventAction = (event, action) => {
    switch (action) {
      case 'rsvp':
        console.log('RSVP for event:', event.title);
        // Implement RSVP logic
        break;
      case 'share':
        console.log('Share event:', event.title);
        // Implement share logic
        break;
      default:
        break;
    }
  };

  const handlePartnerEventAction = (event, action) => {
    switch (action) {
      case 'learn_more':
        console.log('Learn more about partner event:', event.title);
        // Navigate to partner event details or external link
        window.open(event.url, '_blank');
        break;
      // Add other partner-specific actions
      default:
        break;
    }
  };

  const isAnyLoading = activitiesData.isLoading || eventsData.isLoading || childrenData.isLoading || partnerEventsData.isLoading || eventSearchApi.isLoading();
  const primaryError = activitiesData.error || eventsData.error || childrenData.error || partnerEventsData.error || eventSearchApi.getError();

  const userCoords = user?.latitude && user?.longitude
    ? { latitude: user.latitude, longitude: user.longitude }
    : null;

  return (
    <div className="min-h-screen p-4 md:p-6" style={{ backgroundColor: 'var(--teachmo-cream)' }}>
      <div className="max-w-7xl mx-auto space-y-6">

        {childrenData.data.length === 0 && (
            <Alert variant="default" className="bg-blue-50 border-blue-200 text-blue-800">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>No Children Added</AlertTitle>
                <AlertDescription>
                    Add a child profile to unlock personalized recommendations and event searches.
                </AlertDescription>
            </Alert>
        )}

        <OffersCarousel userLocation={user?.location} children={childrenData.data} />

        {/* Header and Controls */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Discover</h1>
            <p className="text-gray-600 mt-1">Find personalized activities, local events, and partner offerings all in one place.</p>
          </div>

          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search activities and events..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-64"
              />
            </div>

            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2"
            >
              {showFilters ? <X className="h-4 w-4" /> : <SlidersHorizontal className="h-4 w-4" />}
              Filters
            </Button>

            <ToggleGroup type="single" value={view} onValueChange={(v) => v && setView(v)} className="bg-white rounded-lg shadow-sm">
              <ToggleGroupItem value="grid" aria-label="Grid view">
                <List className="h-4 w-4" />
              </ToggleGroupItem>
              <ToggleGroupItem value="map" aria-label="Map view">
                <Map className="h-4 w-4" />
              </ToggleGroupItem>
            </ToggleGroup>
          </div>
        </div>

        {/* Filter Panel */}
        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              {/* Event filters always visible in the filter panel */}
              <EventFilters
                filters={filters}
                onFiltersChange={setFilters}
                isSearching={eventSearchApi.isLoading()}
              />
              {/* Activity filters always visible in the filter panel */}
              <ActivityFilters
                filters={filters}
                onFiltersChange={setFilters}
                children={childrenData.data}
                selectedChild={selectedChild}
                onChildSelect={setSelectedChild}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Content Area */}
        <ProgressiveLoader
          isLoading={isAnyLoading}
          error={primaryError}
          onRetry={() => {
            activitiesData.refresh();
            eventsData.refresh();
            partnerEventsData.refresh();
            if (searchQuery || filters.location) {
              handleEventSearch(searchQuery, filters);
            }
          }}
          fallback={() => view === 'grid' ? <SkeletonGrid /> : <MapSkeleton />}
        >
          {view === 'grid' ? (
            <>
              {displayItems.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <AnimatePresence>
                    {displayItems.map(item => (
                      <motion.div
                        key={`${item.type}-${item.id}`} // Unique key for combined list
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        layout
                      >
                        {item.type === 'activity' && (
                          <ActivityCard
                            activity={item}
                            child={childrenData.data.find(c => c.id === item.child_id) || selectedChild}
                            isPersonalized={item.is_personalized}
                            onAction={(action) => handleActivityAction(item, action)}
                            isLoading={activitiesData.isUpdatingItem(item.id)}
                          />
                        )}
                        {item.type === 'event' && (
                          <LocalEventCard
                            event={item}
                            onRSVP={() => handleLocalEventAction(item, 'rsvp')}
                            onShare={() => handleLocalEventAction(item, 'share')}
                          />
                        )}
                        {item.type === 'partner_event' && (
                          // Example rendering for PartnerEvent - create a dedicated card or use generic Card
                          <Card className="flex flex-col h-full overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                            <CardHeader className="p-4 pb-2">
                              <CardTitle className="text-lg font-semibold">{item.title || "Untitled Partner Offer"}</CardTitle>
                              <p className="text-sm text-gray-500 mt-1">{item.partner_name}</p>
                            </CardHeader>
                            <CardContent className="p-4 pt-2 flex-grow">
                              <p className="text-gray-700 text-sm line-clamp-3">{item.description || "No description available."}</p>
                              <div className="flex flex-wrap gap-2 mt-3">
                                {item.category && <Badge variant="secondary">{item.category}</Badge>}
                              </div>
                            </CardContent>
                            <div className="p-4 pt-0 flex justify-end gap-2">
                              {item.url && (
                                <Button size="sm" onClick={() => handlePartnerEventAction(item, 'learn_more')}>
                                  Learn More
                                </Button>
                              )}
                            </div>
                          </Card>
                        )}
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              ) : (
                <EmptyState
                  icon={Lightbulb}
                  title="No items found"
                  description="Try adjusting your filters or search terms to find activities, events, or partner offers."
                  action={
                    <div className="flex gap-2">
                      <Button onClick={() => {
                        setSearchQuery('');
                        setFilters({
                          category: 'all',
                          ageRange: 'all',
                          location: user?.location || '',
                          date: 'all',
                          difficulty: 'all'
                        });
                        setSelectedChild(null);
                        setShowFilters(false);
                      }}>
                        Clear Filters
                      </Button>
                    </div>
                  }
                />
              )}

              {/* Load More buttons for each data type */}
              <div className="text-center pt-6 flex justify-center gap-4">
                {activitiesData.hasMore && (
                  <Button onClick={activitiesData.loadMore} disabled={activitiesData.isLoading} variant="outline" size="lg">
                    {activitiesData.isLoading ? <InlineLoader /> : 'Load More Activities'}
                  </Button>
                )}
                {eventsData.hasMore && (
                  <Button onClick={eventsData.loadMore} disabled={eventsData.isLoading} variant="outline" size="lg">
                    {eventsData.isLoading ? <InlineLoader /> : 'Load More Events'}
                  </Button>
                )}
                {partnerEventsData.hasMore && (
                  <Button onClick={partnerEventsData.loadMore} disabled={partnerEventsData.isLoading} variant="outline" size="lg">
                    {partnerEventsData.isLoading ? <InlineLoader /> : 'Load More Partner Offers'}
                  </Button>
                )}
              </div>
            </>
          ) : (
            <Suspense fallback={<MapSkeleton />}>
              <MapView 
                localEvents={filteredEvents} // MapView only takes filtered events
                partnerEvents={filteredPartnerEvents} // And filtered partner events
                userLocation={userCoords}
                isLoading={eventsData.isLoading || partnerEventsData.isLoading || eventSearchApi.isLoading()}
              />
            </Suspense>
          )}
        </ProgressiveLoader>
      </div>
    </div>
  );
}
